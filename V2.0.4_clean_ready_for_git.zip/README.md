# MT5 Trade Logger + Orchestrator (V2.0.4)

This repository contains:
- **mt5-trade-logger/**: Flask backend + Web UI dashboard (trades, analytics, news, system panel, tools)
- **Orch/orchestrator/**: Orchestrator service (pre-trade checks, config, decision log)
- **Services/**: MT5 Services (MarketFeed / NewsFeed)
- **Firma/**: MT5 EA sources

## Quick start (local)
### 1) Trade Logger (Flask)
- Create venv and install requirements (see `mt5-trade-logger/server/requirements.txt` if present)
- Run `python mt5-trade-logger/server/trade_logger.py`
- Open the UI in your browser (or your packaged desktop wrapper)

### 2) Orchestrator
- See `Orch/orchestrator/README.md`
- Ensure `.env.example` is copied to `.env` and filled in (do **not** commit secrets)

### 3) MT5
- Compile and run **Services/MarketFeed.mq5** and **Services/NewsFeed.mq5** as MT5 Services
- Attach the EA from `Firma/` as needed

## Notes
- Runtime artifacts are intentionally excluded (node_modules, venv, logs, backups, compiled ex5).
- Database data is not included; apply migrations from `Orch/orchestrator/migrations/`.
