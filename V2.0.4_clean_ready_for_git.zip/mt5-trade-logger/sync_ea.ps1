# PowerShell skripta za sinhronizaciju EA fajlova iz MetaTrader terminal foldera u radni folder
# Podesite ove promenljive prema vašem okruženju
$source = "$env:APPDATA\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5\Experts\TrendPortfolio_v2_fix_sync.mq5"
$destination = "C:\Users\XEON\Desktop\mt5-trade-logger\TrendPortfolio_v2_fix_sync.mq5"

if (Test-Path $source) {
    Copy-Item -Path $source -Destination $destination -Force
    Write-Host "Fajl je uspešno kopiran iz terminal foldera u radni folder."
} else {
    Write-Host "Izvorni fajl nije pronađen: $source"
}
