import sqlite3

DB_PATH = r'C:\Users\XEON\Desktop\mt5-trade-logger\database\trades.db'
conn = sqlite3.connect(DB_PATH)
c = conn.cursor()

c.execute("SELECT COUNT(*) FROM trades")
print(f"Total trades: {c.fetchone()[0]}")

c.execute("SELECT COUNT(*) FROM trades WHERE status='OPEN'")
print(f"Open trades: {c.fetchone()[0]}")

c.execute("SELECT COUNT(*) FROM trades WHERE status='CLOSED'")
print(f"Closed trades: {c.fetchone()[0]}")

c.execute("SELECT id, ticket, symbol, status, day_of_week FROM trades ORDER BY id DESC LIMIT 5")
for row in c.fetchall():
    print(row)

conn.close()
