# PowerShell skripta za kopiranje TrendPortfolio_v2_fix_sync.mq5 iz podfoldera Firma
$src = "C:\Users\XEON\AppData\Roaming\MetaQuotes\Terminal\D0E8209F77C8CF37AD8BF550E51FF075\MQL5\Experts\Firma\TrendPortfolio_v2_fix_sync.mq5"
$dest = "C:\Users\XEON\Desktop\mt5-trade-logger\TrendPortfolio_v2_fix_sync.mq5"
if (Test-Path $src) {
    Copy-Item -Path $src -Destination $dest -Force
    Write-Host "Fajl je uspešno kopiran iz Firma podfoldera."
} else {
    Write-Host "Fajl nije pronađen: $src"
}
