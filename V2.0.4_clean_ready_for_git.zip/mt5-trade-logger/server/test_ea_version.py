﻿import json
import os
from urllib.request import Request, urlopen

BASE_URL = os.environ.get("BASE_URL", "http://127.0.0.1:5000").rstrip("/")


def post_ea_version():
    payload = {
        "ea_name": "TrendPortfolio_v2_fix_sync",
        "ea_version": "v2.0.0",
        "bot_id": "bot-1",
        "account_id": "demo-001",
        "symbol": "EURUSD",
        "build_time": "2026-02-06 10:10:10",
        "build": 55573,
    }
    body = json.dumps(payload).encode("utf-8")
    req = Request(
        BASE_URL + "/system/ea_version",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(req, timeout=5) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))


def get_system_status():
    with urlopen(BASE_URL + "/system/status", timeout=5) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))


def main():
    status, body = post_ea_version()
    print("POST /system/ea_version", status, body)
    if status != 200 or not body.get("ok"):
        raise SystemExit("POST failed")

    status, data = get_system_status()
    print("GET /system/status", status, "ea_version=", data.get("ea_version"))
    if status != 200:
        raise SystemExit("GET failed")
    if data.get("ea_version") != "TrendPortfolio_v2_fix_sync v2.0.0":
        raise SystemExit("ea_version missing in status")


if __name__ == "__main__":
    main()
