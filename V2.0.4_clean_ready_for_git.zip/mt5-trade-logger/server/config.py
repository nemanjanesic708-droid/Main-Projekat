﻿FTMO_INITIAL_BALANCE = 10000.0
FTMO_DAILY_LOSS_PCT = 0.05
FTMO_MAX_LOSS_PCT = 0.10
FTMO_PROFIT_TARGET_PCT = 0.10

# Optional absolute overrides (set to a number to override percent-based defaults).
FTMO_DAILY_LOSS_LIMIT = None
FTMO_MAX_LOSS_LIMIT = None
FTMO_PROFIT_TARGET = None
