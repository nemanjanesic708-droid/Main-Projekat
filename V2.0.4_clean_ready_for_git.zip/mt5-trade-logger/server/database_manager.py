"""
Database Manager - Alat za upravljanje bazom podataka trejdova
"""

import sqlite3
import os
from datetime import datetime
from tabulate import tabulate

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'database', 'trades.db')


class TradeDatabase:
    def __init__(self):
        self.db_path = DB_PATH
    
    def get_connection(self):
        """Kreira konekciju na bazu"""
        return sqlite3.connect(self.db_path)
    
    def view_all_trades(self):
        """Prikazuje sve trejdove"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM trades ORDER BY open_time DESC')
        trades = cursor.fetchall()
        
        if not trades:
            print("Nema trejdova u bazi.")
            conn.close()
            return
        
        # Formatiranje podataka za prikaz
        headers = ['Ticket', 'Symbol', 'Lot', 'Direkcija', 'Open Time', 'Close Time', 'Profit', 'Status']
        rows = []
        
        for trade in trades:
            rows.append([
                trade['ticket'],
                trade['symbol'],
                trade['lot_size'],
                trade['direction'],
                trade['open_time'],
                trade['close_time'] or 'N/A',
                f"{trade['profit']:.2f}" if trade['profit'] else 'N/A',
                trade['status']
            ])
        
        print("\n" + "="*100)
        print("SVI TREJDOVI")
        print("="*100)
        print(tabulate(rows, headers=headers, tablefmt='grid'))
        print(f"\nUkupno trejdova: {len(trades)}")
        
        conn.close()
    
    def view_open_trades(self):
        """Prikazuje samo otvorene trejdove"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM trades WHERE status = ? ORDER BY open_time DESC', ('OPEN',))
        trades = cursor.fetchall()
        
        if not trades:
            print("Nema otvorenih trejdova.")
            conn.close()
            return
        
        headers = ['Ticket', 'Symbol', 'Lot', 'Direkcija', 'Open Price', 'Open Time', 'SL', 'TP']
        rows = []
        
        for trade in trades:
            rows.append([
                trade['ticket'],
                trade['symbol'],
                trade['lot_size'],
                trade['direction'],
                trade['open_price'],
                trade['open_time'],
                trade['stop_loss'],
                trade['take_profit']
            ])
        
        print("\n" + "="*100)
        print("OTVORENI TREJDOVI")
        print("="*100)
        print(tabulate(rows, headers=headers, tablefmt='grid'))
        print(f"\nUkupno otvorenih: {len(trades)}")
        
        conn.close()
    
    def view_closed_trades(self):
        """Prikazuje samo zatvorene trejdove"""
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM trades WHERE status = ? ORDER BY close_time DESC', ('CLOSED',))
        trades = cursor.fetchall()
        
        if not trades:
            print("Nema zatvorenih trejdova.")
            conn.close()
            return
        
        headers = ['Ticket', 'Symbol', 'Lot', 'Direkcija', 'Open Price', 'Close Price', 'Profit']
        rows = []
        
        for trade in trades:
            rows.append([
                trade['ticket'],
                trade['symbol'],
                trade['lot_size'],
                trade['direction'],
                trade['open_price'],
                trade['close_price'],
                f"{trade['profit']:.2f}"
            ])
        
        print("\n" + "="*100)
        print("ZATVORENI TREJDOVI")
        print("="*100)
        print(tabulate(rows, headers=headers, tablefmt='grid'))
        print(f"\nUkupno zatvorenih: {len(trades)}")
        
        conn.close()
    
    def get_statistics(self):
        """Prikazuje detaljnu statistiku"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Osnovne statistike
        cursor.execute('SELECT COUNT(*) FROM trades')
        total_trades = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM trades WHERE status = ?', ('OPEN',))
        open_trades = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM trades WHERE status = ?', ('CLOSED',))
        closed_trades = cursor.fetchone()[0]
        
        cursor.execute('SELECT SUM(profit) FROM trades WHERE status = ?', ('CLOSED',))
        total_profit = cursor.fetchone()[0] or 0
        
        cursor.execute('SELECT COUNT(*) FROM trades WHERE status = ? AND profit > 0', ('CLOSED',))
        winning_trades = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM trades WHERE status = ? AND profit < 0', ('CLOSED',))
        losing_trades = cursor.fetchone()[0]
        
        cursor.execute('SELECT AVG(profit) FROM trades WHERE status = ? AND profit > 0', ('CLOSED',))
        avg_win = cursor.fetchone()[0] or 0
        
        cursor.execute('SELECT AVG(profit) FROM trades WHERE status = ? AND profit < 0', ('CLOSED',))
        avg_loss = cursor.fetchone()[0] or 0
        
        conn.close()
        
        win_rate = (winning_trades / closed_trades * 100) if closed_trades > 0 else 0
        
        print("\n" + "="*60)
        print("STATISTIKA TREJDOVA")
        print("="*60)
        print(f"Ukupno trejdova:        {total_trades}")
        print(f"Otvoreni trejdovi:      {open_trades}")
        print(f"Zatvoreni trejdovi:     {closed_trades}")
        print("-"*60)
        print(f"Dobitni trejdovi:       {winning_trades}")
        print(f"Gubitni trejdovi:       {losing_trades}")
        print(f"Win Rate:               {win_rate:.2f}%")
        print("-"*60)
        print(f"Ukupan profit/gubitak:  ${total_profit:.2f}")
        print(f"Prosečna dobit:         ${avg_win:.2f}")
        print(f"Prosečan gubitak:       ${avg_loss:.2f}")
        print("="*60 + "\n")
    
    def clear_database(self):
        """Briše sve podatke iz baze"""
        response = input("Da li ste sigurni da želite da obrišete sve trejdove? (da/ne): ")
        if response.lower() == 'da':
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('DELETE FROM trades')
            conn.commit()
            conn.close()
            print("Svi trejdovi su obrisani.")
        else:
            print("Operacija otkazana.")


def main():
    db = TradeDatabase()
    
    while True:
        print("\n" + "="*60)
        print("MT5 TRADE DATABASE MANAGER")
        print("="*60)
        print("1. Prikaži sve trejdove")
        print("2. Prikaži otvorene trejdove")
        print("3. Prikaži zatvorene trejdove")
        print("4. Prikaži statistiku")
        print("5. Obriši sve podatke")
        print("0. Izlaz")
        print("="*60)
        
        choice = input("\nIzaberite opciju: ")
        
        if choice == '1':
            db.view_all_trades()
        elif choice == '2':
            db.view_open_trades()
        elif choice == '3':
            db.view_closed_trades()
        elif choice == '4':
            db.get_statistics()
        elif choice == '5':
            db.clear_database()
        elif choice == '0':
            print("Izlaz...")
            break
        else:
            print("Nepoznata opcija. Pokušajte ponovo.")


if __name__ == '__main__':
    main()
