from flask import Flask, request, jsonify, render_template, Response, send_from_directory
import atexit
from collections import defaultdict
import csv
import io
import json
import importlib.util
import logging
import math
import os
import sqlite3
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import urlencode

try:
    from concurrent_log_handler import ConcurrentRotatingFileHandler as _ConcurrentRotatingFileHandler
except Exception:
    _ConcurrentRotatingFileHandler = None


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)
DB_PATH = os.path.join(PROJECT_ROOT, "database", "trades.db")
LOG_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOG_DIR, "trade_logger.log")
ORCH_LOG_FILE = os.path.join(PROJECT_ROOT, "orch_start.out.log")
DATA_DIR = os.path.join(BASE_DIR, "data")
EA_VERSION_CACHE = os.path.join(DATA_DIR, "ea_version.json")
DT_FORMAT = "%Y-%m-%d %H:%M:%S"
SYSTEM_STATUS_LOCK = threading.Lock()
LAST_HEARTBEAT = None
_ENV_LOADED = False
_CONFIG_MODULE = None
LOG_CLEAR_AT_UTC = None
LOG_CLEAR_AT_ISO = None
LOG_CLEAR_SEQ = 0
LOG_SEQ_COUNTER = 0
LOG_SEQ_CACHE_LIMIT = 5000
LOG_SEQ_BY_KEY = {}
LOG_SEQ_LOCK = threading.Lock()
_LOCAL_UTC_OFFSET = None
EA_STATE_LOCK = threading.Lock()
EA_STATE = {
    "ea_name": None,
    "ea_version_raw": None,
    "ea_version": None,
    "mt5_build": None,
    "build_time": None,
    "updated_at": None,
    "bot_id": None,
    "account_id": None,
    "symbol": None,
}
LAST_EA_VERSION = None
LAST_EA_NAME = None
LAST_EA_VERSION_AT = None
MARKETWATCH_INDICATOR_CACHE_LOCK = threading.Lock()
MARKETWATCH_INDICATOR_CACHE = {}
MARKETWATCH_INDICATOR_CACHE_TTL_SEC = 20
MARKETWATCH_NEWS_MIN_IMPORTANCE_DEFAULT = 2
MARKETWATCH_NEWS_WINDOW_MIN_DEFAULT = 30

app = Flask(__name__)
print("### BUILD MARKER: candles_batch_route_enabled ###")


@app.before_request
def capture_ea_telemetry():
    extract_ea_from_request()


_LOG_CLEANUP_REGISTERED = False


def _warn_rollover_failure(exc):
    try:
        print(
            f"[LOG] rollover failed: {exc}. Continuing without rotation.",
            file=sys.stderr,
        )
    except Exception:
        return


class SafeRotatingFileHandler(RotatingFileHandler):
    def doRollover(self):
        try:
            super().doRollover()
        except Exception as exc:
            _warn_rollover_failure(exc)


if _ConcurrentRotatingFileHandler:
    class SafeConcurrentRotatingFileHandler(_ConcurrentRotatingFileHandler):
        def doRollover(self):
            try:
                super().doRollover()
            except Exception as exc:
                _warn_rollover_failure(exc)
else:
    SafeConcurrentRotatingFileHandler = None


def _close_logging_handlers():
    root_logger = logging.getLogger()
    for handler in list(root_logger.handlers):
        try:
            handler.flush()
        except Exception:
            pass
        try:
            handler.close()
        except Exception:
            pass
        try:
            root_logger.removeHandler(handler)
        except Exception:
            pass


def setup_logging():
    global _LOG_CLEANUP_REGISTERED
    os.makedirs(LOG_DIR, exist_ok=True)
    handler_cls = SafeConcurrentRotatingFileHandler or SafeRotatingFileHandler
    handler = handler_cls(
        LOG_FILE,
        maxBytes=1_000_000,
        backupCount=3,
        encoding="utf-8",
        delay=True,
    )
    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    )
    handler.setFormatter(formatter)
    handler.setLevel(logging.INFO)

    root_logger = logging.getLogger()
    if not any(getattr(h, "baseFilename", None) == handler.baseFilename for h in root_logger.handlers):
        root_logger.setLevel(logging.INFO)
        root_logger.addHandler(handler)

    if not _LOG_CLEANUP_REGISTERED:
        atexit.register(_close_logging_handlers)
        _LOG_CLEANUP_REGISTERED = True


@app.after_request
def add_no_cache_headers(response):
    if request.path == "/" or request.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


setup_logging()

PASSTHROUGH_FIELDS = [
    "trade_index",
    "trend_tf",
    "entry_tf",
    "timestamp",
    "day_of_week",
    "hour",
    "session_active",
    "ema_fast_20",
    "ema_slow_100",
    "ema_fast_above_slow",
    "ema_fast_slope",
    "ema_slow_slope",
    "price_vs_fast_ema",
    "price_vs_slow_ema",
    "trend_direction",
    "pullback_ema_20",
    "price_distance_from_pullback_ema",
    "pullback_valid",
    "pullback_depth_pips",
    "donchian_high",
    "donchian_low",
    "donchian_range",
    "price_vs_don_high",
    "price_vs_don_low",
    "donchian_breakout",
    "don_buffer_pips",
    "adx_value",
    "adx_above_min",
    "di_plus",
    "di_minus",
    "trend_strength",
    "atr_value",
    "atr_pips",
    "atr_above_min",
    "atr_percent_of_price",
    "risk_mode",
    "risk_percent",
    "risk_level",
    "sl_multiplier",
    "tp_multiplier",
    "calculated_sl_pips",
    "calculated_tp_pips",
    "rr_ratio",
    "spread_ok",
    "one_entry_per_bar_pass",
    "session_hour",
    "session_allowed",
    "daily_loss_percent",
    "consecutive_losses",
    "equity_dd_percent",
    "risk_block_active",
    "risk_block_reason",
    "signal_type",
    "allow_longs",
    "allow_shorts",
    "filters_passed_count",
    "filters_failed_count",
    "final_decision",
    "skip_reason",
    "entry_price",
    "bid",
    "ask",
    "bar_time_entry_tf",
    "bar_time_trend_tf",
    "stop_loss",
    "take_profit",
    "comment",
    "swap",
    "commission",
    "snapshot_id",
    "trade_uid",
]

MIGRATION_COLUMNS = {
    "trade_uid": "TEXT",
    "position_id": "INTEGER",
    "lot": "REAL",
    "account_id": "TEXT",
    "timeframe": "TEXT",
    "magic": "INTEGER",
    "risk_level": "TEXT",
    "duration_sec": "INTEGER",
    "close_reason": "TEXT",
    "max_float_profit": "REAL",
    "max_float_dd": "REAL",
    "setup": "TEXT",
    "updated_at": "TEXT",
    "created_at": "TEXT",
}


def now_text():
    return datetime.utcnow().strftime(DT_FORMAT)


def _local_utc_offset():
    global _LOCAL_UTC_OFFSET
    if _LOCAL_UTC_OFFSET is None:
        try:
            _LOCAL_UTC_OFFSET = datetime.now() - datetime.utcnow()
        except Exception:
            _LOCAL_UTC_OFFSET = timedelta(0)
    return _LOCAL_UTC_OFFSET


def _to_utc(dt, assume_local=True):
    if dt is None:
        return None
    if dt.tzinfo is not None:
        return dt.astimezone(timezone.utc)
    if assume_local:
        try:
            adjusted = dt - _local_utc_offset()
        except Exception:
            adjusted = dt
        return adjusted.replace(tzinfo=timezone.utc)
    return dt.replace(tzinfo=timezone.utc)


def _parse_timestamp_to_utc(value):
    if not has_value(value):
        return None
    raw = str(value).strip()
    if not raw:
        return None

    # Log line prefix: "YYYY-MM-DD HH:MM:SS,ms"
    if len(raw) >= 19 and raw[4] == "-" and raw[7] == "-" and raw[10] in (" ", "T"):
        ts_part = None
        if len(raw) >= 23 and raw[19] in (",", "."):
            ts_part = raw[:23]
        else:
            ts_part = raw[:19]
        ts_part = ts_part.replace("T", " ").replace(",", ".")
        for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
            try:
                parsed = datetime.strptime(ts_part, fmt)
                return _to_utc(parsed, assume_local=True)
            except ValueError:
                continue

    iso_raw = raw
    if iso_raw.endswith("Z"):
        iso_raw = iso_raw[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(iso_raw)
        if parsed.tzinfo is not None:
            return parsed.astimezone(timezone.utc)
        return _to_utc(parsed, assume_local=True)
    except Exception:
        pass

    parsed = parse_trade_time(raw)
    if parsed is not None:
        return _to_utc(parsed, assume_local=True)
    return None


def _extract_log_timestamp_value(item):
    if isinstance(item, dict):
        for key in ("timestamp", "time", "ts", "created_at", "logged_at"):
            if has_value(item.get(key)):
                return item.get(key)
        return None
    if isinstance(item, str):
        return item
    return None


def set_logs_cleared():
    global LOG_CLEAR_AT_UTC, LOG_CLEAR_AT_ISO
    LOG_CLEAR_AT_UTC = datetime.utcnow().replace(tzinfo=timezone.utc)
    LOG_CLEAR_AT_ISO = LOG_CLEAR_AT_UTC.isoformat()
    return LOG_CLEAR_AT_ISO


def has_value(value):
    return value is not None and (not isinstance(value, str) or value.strip() != "")


def load_env_file():
    global _ENV_LOADED
    if _ENV_LOADED:
        return
    _ENV_LOADED = True
    env_path = os.path.join(PROJECT_ROOT, ".env")
    if not os.path.exists(env_path):
        return
    try:
        with open(env_path, "r", encoding="utf-8") as handle:
            for raw in handle:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value
    except Exception:
        return


def load_config_module():
    global _CONFIG_MODULE
    if _CONFIG_MODULE is not None:
        return _CONFIG_MODULE if _CONFIG_MODULE is not False else None
    config_path = os.path.join(BASE_DIR, "config.py")
    if not os.path.exists(config_path):
        _CONFIG_MODULE = False
        return None
    try:
        spec = importlib.util.spec_from_file_location("mt5_trade_logger_config", config_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _CONFIG_MODULE = module
        return module
    except Exception:
        _CONFIG_MODULE = False
        return None


def get_float_env(key):
    value = os.environ.get(key)
    if not has_value(value):
        return None
    try:
        return float(str(value).strip())
    except Exception:
        return None


def get_config_float(module, key):
    if module is None or not hasattr(module, key):
        return None
    value = getattr(module, key)
    if not has_value(value):
        return None
    try:
        return float(str(value).strip())
    except Exception:
        return None


def get_risk_config():
    load_env_file()
    cfg = load_config_module()

    initial_balance = get_float_env("FTMO_INITIAL_BALANCE")
    if initial_balance is None:
        initial_balance = get_config_float(cfg, "FTMO_INITIAL_BALANCE")
    if initial_balance is None:
        initial_balance = 10000.0

    daily_limit = get_float_env("FTMO_DAILY_LOSS_LIMIT")
    if daily_limit is None:
        daily_limit = get_config_float(cfg, "FTMO_DAILY_LOSS_LIMIT")
    daily_pct = get_float_env("FTMO_DAILY_LOSS_PCT")
    if daily_pct is None:
        daily_pct = get_config_float(cfg, "FTMO_DAILY_LOSS_PCT")
    if daily_pct is None:
        daily_pct = 0.05
    if daily_limit is None:
        daily_limit = initial_balance * daily_pct

    max_limit = get_float_env("FTMO_MAX_LOSS_LIMIT")
    if max_limit is None:
        max_limit = get_config_float(cfg, "FTMO_MAX_LOSS_LIMIT")
    max_pct = get_float_env("FTMO_MAX_LOSS_PCT")
    if max_pct is None:
        max_pct = get_config_float(cfg, "FTMO_MAX_LOSS_PCT")
    if max_pct is None:
        max_pct = 0.10
    if max_limit is None:
        max_limit = initial_balance * max_pct

    profit_target = get_float_env("FTMO_PROFIT_TARGET")
    if profit_target is None:
        profit_target = get_config_float(cfg, "FTMO_PROFIT_TARGET")
    profit_pct = get_float_env("FTMO_PROFIT_TARGET_PCT")
    if profit_pct is None:
        profit_pct = get_config_float(cfg, "FTMO_PROFIT_TARGET_PCT")
    if profit_pct is None:
        profit_pct = 0.10
    if profit_target is None:
        profit_target = initial_balance * profit_pct

    return {
        "initial_balance": float(initial_balance),
        "daily_loss_limit": float(daily_limit),
        "max_loss_limit": float(max_limit),
        "profit_target": float(profit_target),
    }


def get_orchestrator_url():
    load_env_file()
    url = os.environ.get("ORCH_URL") or os.environ.get("ORCHESTRATOR_URL")
    if has_value(url):
        return str(url).strip()

    config_path = os.path.join(PROJECT_ROOT, "server", "config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except Exception:
            data = None
        if isinstance(data, dict):
            value = data.get("orch_url")
            if has_value(value):
                return str(value).strip()
    return ""


def get_orchestrator_api_key():
    load_env_file()
    for key_name in ("ORCH_API_KEY", "ORCHESTRATOR_API_KEY", "API_KEY"):
        value = os.environ.get(key_name)
        if has_value(value):
            return str(value).strip()
    return ""


def get_request_api_key():
    header_value = request.headers.get("X-API-Key") or request.headers.get("x-api-key")
    if has_value(header_value):
        return str(header_value).strip()
    return ""


def _decode_json_payload(raw_text):
    if not has_value(raw_text):
        return None
    try:
        parsed = json.loads(raw_text)
    except Exception:
        return None
    if isinstance(parsed, (dict, list)):
        return parsed
    return None


def call_orchestrator_api(path, method="GET", payload=None, query=None, timeout_sec=1.5, api_key_override=""):
    base_url = get_orchestrator_url()
    if not has_value(base_url):
        return None, 503, "ORCH_URL not set"

    url = str(base_url).rstrip("/") + str(path or "")
    if isinstance(query, dict):
        query_params = {}
        for key, value in query.items():
            if has_value(value):
                query_params[str(key)] = str(value)
        if query_params:
            url += "?" + urlencode(query_params, doseq=True)

    headers = {"Accept": "application/json"}
    api_key = api_key_override if has_value(api_key_override) else get_orchestrator_api_key()
    if has_value(api_key):
        headers["x-api-key"] = api_key

    data_bytes = None
    if payload is not None:
        try:
            data_bytes = json.dumps(payload).encode("utf-8")
        except Exception as exc:
            return None, 400, f"invalid payload: {exc}"
        headers["Content-Type"] = "application/json"

    request_obj = Request(
        url=url,
        data=data_bytes,
        headers=headers,
        method=str(method or "GET").upper(),
    )

    try:
        with urlopen(request_obj, timeout=float(timeout_sec or 1.5)) as response:
            status_code = int(response.status)
            raw = response.read().decode("utf-8", errors="ignore")
        parsed = _decode_json_payload(raw)
        if parsed is not None:
            return parsed, status_code, None
        return {"ok": status_code < 400, "raw": raw}, status_code, None
    except HTTPError as exc:
        status_code = int(exc.code) if has_value(exc.code) else 502
        try:
            raw = exc.read().decode("utf-8", errors="ignore")
        except Exception:
            raw = str(exc)
        parsed = _decode_json_payload(raw)
        if parsed is not None:
            return parsed, status_code, None
        return None, status_code, raw or str(exc)
    except URLError as exc:
        return None, 502, str(exc)
    except Exception as exc:
        return None, 500, str(exc)


def set_last_heartbeat():
    global LAST_HEARTBEAT
    with SYSTEM_STATUS_LOCK:
        LAST_HEARTBEAT = now_text()


def get_last_heartbeat():
    with SYSTEM_STATUS_LOCK:
        return LAST_HEARTBEAT


def update_ea_telemetry(ea_name=None, ea_version=None, ts=None):
    global LAST_EA_NAME, LAST_EA_VERSION, LAST_EA_VERSION_AT
    if not has_value(ea_name) and not has_value(ea_version):
        return
    ts = ts or now_text()
    with EA_STATE_LOCK:
        if has_value(ea_name):
            LAST_EA_NAME = str(ea_name).strip()
            EA_STATE["ea_name"] = LAST_EA_NAME
        if has_value(ea_version):
            LAST_EA_VERSION = str(ea_version).strip()
            EA_STATE["ea_version_raw"] = LAST_EA_VERSION
        LAST_EA_VERSION_AT = ts
        EA_STATE["updated_at"] = LAST_EA_VERSION_AT


def extract_ea_from_request():
    try:
        ea_name = request.headers.get("X-EA-Name")
        ea_version = request.headers.get("X-EA-Version")
        if not has_value(ea_name) or not has_value(ea_version):
            data = request.get_json(silent=True)
            if isinstance(data, dict):
                if not has_value(ea_name):
                    ea_name = data.get("ea_name")
                if not has_value(ea_version):
                    ea_version = data.get("ea_version")
        if has_value(ea_name) or has_value(ea_version):
            update_ea_telemetry(ea_name, ea_version)
    except Exception:
        return


def ping_health(base_url):
    health_url = str(base_url).rstrip("/") + "/health"
    try:
        with urlopen(health_url, timeout=1.5) as response:
            http_status = response.status
            return (http_status == 200), http_status, ""
    except HTTPError as exc:
        return False, exc.code, str(exc)
    except URLError as exc:
        return False, None, str(exc)
    except Exception as exc:
        return False, None, str(exc)


def check_orchestrator(url):
    if not has_value(url):
        return {
            "url": "",
            "ok": False,
            "http": None,
            "error": "ORCH_URL not set",
        }

    ok, http_status, error = ping_health(url)
    if ok:
        set_last_heartbeat()
    return {
        "url": str(url),
        "ok": bool(ok),
        "http": http_status,
        "error": None if ok else error,
    }


def fetch_orchestrator_status(base_url, timeout_sec=0.8):
    if not has_value(base_url):
        return None, "ORCH_URL not set"
    status_url = str(base_url).rstrip("/") + "/status"
    try:
        with urlopen(status_url, timeout=timeout_sec) as response:
            payload = response.read().decode("utf-8")
        data = json.loads(payload)
        if not isinstance(data, dict):
            return None, "invalid status payload"
        return data, None
    except Exception as exc:
        return None, str(exc)


def get_active_symbols(limit=200):
    symbols = []
    seen = set()
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT symbol FROM trades ORDER BY open_time DESC LIMIT ?",
                (limit,),
            )
            rows = cursor.fetchall()
        for (symbol,) in rows:
            if not has_value(symbol):
                continue
            key = str(symbol).upper()
            if key in seen:
                continue
            seen.add(key)
            symbols.append(symbol)
    except Exception:
        return []
    return symbols


def read_log_lines(limit=400, backups=3):
    """
    Return the last `limit` log lines across the current log file and rotated backups.

    The UI System Logs tab reads this output. Only reading `trade_logger.log` means
    trade events can "disappear" immediately after rotation, so we merge backups too.
    """
    paths = []
    try:
        for i in range(int(backups or 0), 0, -1):
            paths.append(f"{LOG_FILE}.{i}")
    except Exception:
        paths = []
    paths.append(LOG_FILE)

    any_found = False
    merged = []
    for path in paths:
        if not os.path.exists(path):
            continue
        any_found = True
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as handle:
                lines = handle.read().splitlines()
            if lines:
                merged.extend(lines)
        except Exception:
            continue

    if not any_found or not merged:
        return ["No logs available"]
    if limit and len(merged) > limit:
        return merged[-limit:]
    return merged


def _parse_json_line(line):
    if not has_value(line):
        return None
    text = str(line).strip()
    if not text.startswith("{") or not text.endswith("}"):
        return None
    try:
        payload = json.loads(text)
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _extract_orch_payload(item):
    payload = None
    for key in ("payload", "body", "request_body", "requestBody"):
        if key in item:
            payload = item.get(key)
            break
    if isinstance(payload, str):
        text = payload.strip()
        if text.startswith("{") and text.endswith("}"):
            try:
                parsed = json.loads(text)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                return None
        return None
    return payload if isinstance(payload, dict) else None


def _normalize_orch_event(item):
    if not isinstance(item, dict):
        return None
    log = dict(item)
    path = log.get("path") or log.get("request_path") or log.get("endpoint_path")
    method = log.get("method") or log.get("http_method") or log.get("verb")
    if has_value(path):
        log["path"] = str(path)
    if has_value(method):
        log["method"] = str(method).upper()
    if not has_value(log.get("endpoint")) and has_value(log.get("method")) and has_value(log.get("path")):
        log["endpoint"] = f"{log.get('method')} {log.get('path')}"
    if not has_value(log.get("timestamp")):
        for key in ("time", "ts", "created_at", "logged_at"):
            if has_value(log.get(key)):
                log["timestamp"] = log.get(key)
                break
    if not has_value(log.get("http_status")) and has_value(log.get("status")):
        log["http_status"] = log.get("status")

    lower_path = str(log.get("path") or "").lower()
    if "pre_trade" in lower_path or "pretrade" in lower_path:
        log["event_type"] = "pre_trade"
    elif "/health" in lower_path:
        log["event_type"] = "heartbeat"

    payload = _extract_orch_payload(log)
    if isinstance(payload, dict):
        for key in ("symbol", "bot_id", "account_id"):
            if not has_value(log.get(key)) and has_value(payload.get(key)):
                log[key] = payload.get(key)
    return log


def fetch_orchestrator_requests(base_url, timeout_sec=0.6, limit=200):
    if not has_value(base_url):
        return []
    url = str(base_url).rstrip("/") + "/debug/last_requests"
    try:
        with urlopen(url, timeout=timeout_sec) as response:
            payload = response.read().decode("utf-8")
        data = json.loads(payload)
    except Exception:
        return []

    items = None
    if isinstance(data, dict):
        for key in ("items", "requests", "last_requests", "logs", "data"):
            if isinstance(data.get(key), list):
                items = data.get(key)
                break
    elif isinstance(data, list):
        items = data
    if not items:
        return []

    out = []
    tail = items[-limit:] if len(items) > limit else items
    for item in tail:
        normalized = _normalize_orch_event(item)
        if normalized is not None:
            out.append(normalized)
    return out


def read_orchestrator_log_lines(limit=200):
    path = ORCH_LOG_FILE
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as handle:
            lines = handle.read().splitlines()
        if not lines:
            return []
        tail = lines[-max(limit * 3, 200):]
        out = []
        for line in tail:
            payload = _parse_json_line(line)
            if payload is None:
                continue
            normalized = _normalize_orch_event(payload)
            if normalized is not None:
                out.append(normalized)
        return out[-limit:]
    except Exception:
        return []


def merge_system_logs(local_logs, orch_logs, limit=400):
    merged = []
    if isinstance(local_logs, list):
        if not (len(local_logs) == 1 and isinstance(local_logs[0], str) and "No logs available" in local_logs[0]):
            merged.extend(local_logs)
    if isinstance(orch_logs, list):
        merged.extend(orch_logs)
    if LOG_CLEAR_AT_UTC:
        filtered = []
        for item in merged:
            ts_value = _extract_log_timestamp_value(item)
            ts_utc = _parse_timestamp_to_utc(ts_value)
            if ts_utc is None:
                continue
            if ts_utc >= LOG_CLEAR_AT_UTC:
                filtered.append(item)
        merged = filtered
    if not merged:
        return ["No logs available"]
    if limit and len(merged) > limit:
        return merged[-limit:]
    return merged


def read_ea_version_cache():
    if not os.path.exists(EA_VERSION_CACHE):
        return None
    try:
        with open(EA_VERSION_CACHE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        value = data.get("ea_version") if isinstance(data, dict) else None
        return str(value).strip() if has_value(value) else None
    except Exception:
        return None


def read_ea_version_cache_meta():
    if not os.path.exists(EA_VERSION_CACHE):
        return {}
    try:
        with open(EA_VERSION_CACHE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return {}
        meta = {}
        for key in (
            "ea_version",
            "ea_name",
            "bot_id",
            "account_id",
            "symbol",
            "mt5_build",
            "build_time",
            "updated_at",
        ):
            if has_value(data.get(key)):
                meta[key] = data.get(key)
        if has_value(meta.get("ea_version")):
            meta["ea_version_raw"] = meta.get("ea_version")
        return meta
    except Exception:
        return {}


def write_ea_version_cache(value, meta=None):
    if not has_value(value):
        return
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        payload = {"ea_version": str(value).strip(), "updated_at": now_text()}
        if isinstance(meta, dict):
            for key in ("bot_id", "account_id", "ea_name", "symbol", "mt5_build", "build_time"):
                if has_value(meta.get(key)):
                    payload[key] = meta.get(key)
        with open(EA_VERSION_CACHE, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
    except Exception:
        return


def maybe_cache_ea_version(payload):
    value = pick(payload, "ea_version", "expert_version", "ea_build")
    if has_value(value):
        write_ea_version_cache(
            value,
            {
                "bot_id": pick(payload, "bot_id"),
                "account_id": pick(payload, "account_id"),
                "ea_name": pick(payload, "ea_name"),
                "symbol": pick(payload, "symbol"),
                "mt5_build": pick(payload, "mt5_build", "build"),
                "build_time": pick(payload, "build_time"),
            },
        )


def get_ea_version_from_db():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(trades)")
            columns = {row[1] for row in cursor.fetchall()}
            if "ea_version" not in columns:
                return None
            row = cursor.execute(
                """
                SELECT ea_version
                FROM trades
                WHERE ea_version IS NOT NULL AND TRIM(ea_version) != ''
                ORDER BY close_time DESC, open_time DESC, id DESC
                LIMIT 1
                """
            ).fetchone()
        if row and has_value(row[0]):
            return str(row[0]).strip()
    except Exception:
        return None
    return None


def get_ea_version():
    load_env_file()
    value = get_ea_version_from_db()
    if has_value(value):
        return value
    meta = get_system_meta()
    if isinstance(meta, dict):
        ea_name = meta.get("ea_name")
        ea_version_raw = meta.get("ea_version_raw") or meta.get("ea_version")
        if has_value(ea_name) and has_value(ea_version_raw):
            return f"{ea_name} {ea_version_raw}".strip()
        if has_value(ea_version_raw):
            return str(ea_version_raw).strip()
    return None


def pick(payload, *keys, default=None):
    for key in keys:
        if key in payload and has_value(payload.get(key)):
            return payload.get(key)
    return default


def to_int(value):
    if not has_value(value):
        return None
    try:
        return int(str(value).strip())
    except Exception:
        return value


def to_float(value):
    if not has_value(value):
        return None
    try:
        return float(str(value).strip())
    except Exception:
        return value


def normalize_status(value, default_value="OPEN"):
    if not has_value(value):
        return default_value
    status = str(value).upper().strip()
    return status if status in ("OPEN", "CLOSED") else default_value


def normalize_direction(value):
    if not has_value(value):
        return "UNKNOWN"
    direction = str(value).upper().strip()
    if direction == "LONG":
        return "BUY"
    if direction == "SHORT":
        return "SELL"
    return direction


def sanitize_payload(payload):
    clean = {}
    for key, value in payload.items():
        low = str(key).lower()
        if any(token in low for token in ("api_key", "apikey", "token", "secret", "password")):
            clean[key] = "***"
        else:
            clean[key] = value
    return clean


def get_request_id(payload=None):
    candidates = [
        request.headers.get("X-Request-Id"),
        request.headers.get("X-Request-ID"),
        request.headers.get("X-Req-Id"),
        request.headers.get("X-Req-ID"),
        request.headers.get("X-Correlation-Id"),
        request.headers.get("X-Correlation-ID"),
    ]
    for value in candidates:
        if has_value(value):
            return str(value).strip()
    if isinstance(payload, dict):
        for key in ("request_id", "requestId", "req_id", "correlation_id"):
            if has_value(payload.get(key)):
                return str(payload.get(key)).strip()
    return None


def parse_trade_time(value):
    if not has_value(value):
        return None
    if isinstance(value, datetime):
        return _to_utc(value, assume_local=False)
    raw = str(value).strip()
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    raw = raw.replace("T", " ")
    dotted = raw.replace(".", "-")
    for item in (raw, dotted):
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S.%f"):
            try:
                parsed = datetime.strptime(item, fmt)
                return _to_utc(parsed, assume_local=True)
            except ValueError:
                pass
    try:
        parsed = datetime.fromisoformat(raw)
        if parsed.tzinfo is not None:
            return parsed.astimezone(timezone.utc)
        return _to_utc(parsed, assume_local=True)
    except Exception:
        return None


def compute_duration_seconds(open_time, close_time):
    open_dt = parse_trade_time(open_time)
    close_dt = parse_trade_time(close_time)
    if open_dt is None or close_dt is None:
        return None
    value = int((close_dt - open_dt).total_seconds())
    return value if value >= 0 else None


def safe_float(value, default=0.0):
    if not has_value(value):
        return default
    try:
        return float(value)
    except Exception:
        return default


def fetch_closed_trades():
    with sqlite3.connect(DB_PATH, timeout=10) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(
            "SELECT profit, close_time, created_at FROM trades WHERE status = 'CLOSED'"
        )
        return [dict(row) for row in cursor.fetchall()]


def compute_max_drawdown(initial_balance, trades):
    equity = initial_balance
    peak = initial_balance
    max_dd = 0.0
    items = []
    for idx, trade in enumerate(trades):
        profit = safe_float(trade.get("profit"), 0.0)
        close_dt = parse_trade_time(trade.get("close_time")) or parse_trade_time(trade.get("created_at"))
        items.append({"profit": float(profit), "time": close_dt, "index": idx})
    min_dt = datetime.min.replace(tzinfo=timezone.utc)
    items.sort(key=lambda item: (item["time"] or min_dt, item["index"]))
    for item in items:
        equity += item["profit"]
        if equity > peak:
            peak = equity
        drawdown = peak - equity
        if drawdown > max_dd:
            max_dd = drawdown
    return max_dd


def build_empty_risk_summary(cfg):
    daily_limit = cfg["daily_loss_limit"]
    max_limit = cfg["max_loss_limit"]
    profit_target = cfg["profit_target"]
    return {
        "account_balance": cfg["initial_balance"],
        "equity": cfg["initial_balance"],
        "pnl_total": 0,
        "pnl_today": 0,
        "daily_loss_limit": daily_limit,
        "max_loss_limit": max_limit,
        "daily_loss_used": 0,
        "max_loss_used": 0,
        "daily_loss_remaining": daily_limit,
        "max_loss_remaining": max_limit,
        "daily_loss_pct_used": 0,
        "max_loss_pct_used": 0,
        "trading_days_count": 0,
        "profit_target": profit_target,
        "profit_target_remaining": profit_target,
        "profit_target_pct": 0,
        "status": "OK",
    }


def build_risk_summary():
    cfg = get_risk_config()
    summary = build_empty_risk_summary(cfg)
    trades = fetch_closed_trades()
    if not trades:
        return summary

    pnl_total = 0.0
    pnl_today = 0.0
    trading_days = set()
    today = datetime.now().date()

    for trade in trades:
        profit = safe_float(trade.get("profit"), 0.0)
        pnl_total += float(profit)
        close_dt = parse_trade_time(trade.get("close_time")) or parse_trade_time(trade.get("created_at"))
        if close_dt:
            trading_days.add(close_dt.date().isoformat())
            if close_dt.date() == today:
                pnl_today += float(profit)

    daily_loss_used = abs(min(pnl_today, 0.0))
    max_loss_used = compute_max_drawdown(cfg["initial_balance"], trades)

    daily_loss_remaining = cfg["daily_loss_limit"] - daily_loss_used
    max_loss_remaining = cfg["max_loss_limit"] - max_loss_used

    daily_pct_used = (daily_loss_used / cfg["daily_loss_limit"] * 100) if cfg["daily_loss_limit"] > 0 else 0
    max_pct_used = (max_loss_used / cfg["max_loss_limit"] * 100) if cfg["max_loss_limit"] > 0 else 0

    profit_target_remaining = cfg["profit_target"] - pnl_total
    profit_target_pct = (pnl_total / cfg["profit_target"] * 100) if cfg["profit_target"] > 0 else 0

    status = "OK"
    if daily_loss_remaining <= 0 or max_loss_remaining <= 0:
        status = "BREACH"
    elif daily_pct_used >= 80 or max_pct_used >= 80:
        status = "WARNING"

    account_balance = cfg["initial_balance"] + pnl_total

    summary.update(
        {
            "account_balance": round(account_balance, 2),
            "equity": round(account_balance, 2),
            "pnl_total": round(pnl_total, 2),
            "pnl_today": round(pnl_today, 2),
            "daily_loss_used": round(daily_loss_used, 2),
            "max_loss_used": round(max_loss_used, 2),
            "daily_loss_remaining": round(daily_loss_remaining, 2),
            "max_loss_remaining": round(max_loss_remaining, 2),
            "daily_loss_pct_used": round(daily_pct_used, 2),
            "max_loss_pct_used": round(max_pct_used, 2),
            "trading_days_count": len(trading_days),
            "profit_target_remaining": round(profit_target_remaining, 2),
            "profit_target_pct": round(profit_target_pct, 2),
            "status": status,
        }
    )
    return summary


def build_risk_days():
    trades = fetch_closed_trades()
    buckets = {}
    for trade in trades:
        close_dt = parse_trade_time(trade.get("close_time")) or parse_trade_time(trade.get("created_at"))
        if not close_dt:
            continue
        day = close_dt.date().isoformat()
        bucket = buckets.get(day)
        if bucket is None:
            bucket = {"date": day, "pnl": 0.0, "trades": 0, "wins": 0, "losses": 0}
            buckets[day] = bucket
        profit = safe_float(trade.get("profit"), 0.0)
        bucket["pnl"] += profit
        bucket["trades"] += 1
        if profit > 0:
            bucket["wins"] += 1
        elif profit < 0:
            bucket["losses"] += 1

    days = []
    for key in sorted(buckets.keys()):
        item = buckets[key]
        item["pnl"] = round(item["pnl"], 2)
        days.append(item)
    return {"days": days}


def get_trade_columns(cursor):
    cursor.execute("PRAGMA table_info(trades)")
    return {row[1] for row in cursor.fetchall()}


def init_system_meta(cursor):
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS system_meta (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bot_id TEXT,
            account_id TEXT,
            symbol TEXT,
            ea_name TEXT,
            ea_version TEXT,
            mt5_build INTEGER,
            build_time TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_system_meta_updated_at ON system_meta(updated_at)")


def sanitize_ea_version(value):
    if not has_value(value):
        return None
    val = str(value).strip()
    if not val:
        return None
    if len(val) > 128:
        return None
    return val


def sanitize_ea_name(value):
    if not has_value(value):
        return None
    val = str(value).strip()
    if not val:
        return None
    if len(val) > 128:
        return None
    return val


def update_ea_state(meta):
    if not isinstance(meta, dict):
        return
    with EA_STATE_LOCK:
        for key in EA_STATE.keys():
            if key in meta and has_value(meta.get(key)):
                EA_STATE[key] = meta.get(key)


def get_ea_state():
    with EA_STATE_LOCK:
        return dict(EA_STATE)


def save_system_meta(payload):
    ea_name = sanitize_ea_name(pick(payload, "ea_name"))
    ea_version = sanitize_ea_version(pick(payload, "ea_version", "expert_version", "ea_build"))
    if not ea_name or not ea_version:
        return None
    record = {
        "bot_id": pick(payload, "bot_id"),
        "account_id": pick(payload, "account_id"),
        "symbol": pick(payload, "symbol"),
        "ea_name": ea_name,
        "ea_version": ea_version,
        "mt5_build": to_int(pick(payload, "mt5_build", "build")),
        "build_time": pick(payload, "build_time"),
        "updated_at": now_text(),
    }
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            init_system_meta(cursor)
            cursor.execute(
                """
                INSERT INTO system_meta (bot_id, account_id, symbol, ea_name, ea_version, mt5_build, build_time, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record["bot_id"],
                    record["account_id"],
                    record["symbol"],
                    record["ea_name"],
                    record["ea_version"],
                    record["mt5_build"],
                    record["build_time"],
                    record["updated_at"],
                ),
            )
            conn.commit()
    except Exception:
        return record
    return record


def get_latest_system_meta():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            init_system_meta(cursor)
            row = cursor.execute(
                """
                SELECT bot_id, account_id, symbol, ea_name, ea_version, mt5_build, build_time, updated_at
                FROM system_meta
                ORDER BY updated_at DESC, id DESC
                LIMIT 1
                """
            ).fetchone()
        return dict(row) if row else None
    except Exception:
        return None


def get_system_meta():
    state = get_ea_state()
    if has_value(state.get("ea_version_raw")) or has_value(state.get("ea_version")):
        return state
    meta = get_latest_system_meta()
    if meta:
        meta["ea_version_raw"] = meta.get("ea_version")
        update_ea_state(meta)
        return meta
    cache = read_ea_version_cache_meta()
    if cache:
        update_ea_state(cache)
        return cache
    env_value = os.environ.get("EA_VERSION")
    if has_value(env_value):
        return {"ea_version_raw": str(env_value).strip()}
    return {}


def sync_aliases(record):
    if has_value(record.get("lot")) and not has_value(record.get("lot_size")):
        record["lot_size"] = record["lot"]
    if has_value(record.get("lot_size")) and not has_value(record.get("lot")):
        record["lot"] = record["lot_size"]
    if has_value(record.get("magic")) and not has_value(record.get("magic_number")):
        record["magic_number"] = record["magic"]
    if has_value(record.get("magic_number")) and not has_value(record.get("magic")):
        record["magic"] = record["magic_number"]
    if has_value(record.get("duration_sec")) and not has_value(record.get("duration_seconds")):
        record["duration_seconds"] = record["duration_sec"]
    if has_value(record.get("duration_seconds")) and not has_value(record.get("duration_sec")):
        record["duration_sec"] = record["duration_seconds"]
    if has_value(record.get("max_float_profit")) and not has_value(record.get("max_floating_profit")):
        record["max_floating_profit"] = record["max_float_profit"]
    if has_value(record.get("max_floating_profit")) and not has_value(record.get("max_float_profit")):
        record["max_float_profit"] = record["max_floating_profit"]
    if has_value(record.get("max_float_dd")) and not has_value(record.get("max_floating_dd")):
        record["max_floating_dd"] = record["max_float_dd"]
    if has_value(record.get("max_floating_dd")) and not has_value(record.get("max_float_dd")):
        record["max_float_dd"] = record["max_floating_dd"]
    if has_value(record.get("setup")) and not has_value(record.get("setup_result")):
        record["setup_result"] = record["setup"]
    if has_value(record.get("setup_result")) and not has_value(record.get("setup")):
        record["setup"] = record["setup_result"]
    if has_value(record.get("close_reason")) and not has_value(record.get("exit_reason")):
        record["exit_reason"] = record["close_reason"]
    if has_value(record.get("exit_reason")) and not has_value(record.get("close_reason")):
        record["close_reason"] = record["exit_reason"]


def dedupe_trades(cursor):
    try:
        cursor.execute(
            """
            DELETE FROM trades
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM trades
                WHERE account_id IS NOT NULL AND position_id IS NOT NULL
                GROUP BY account_id, position_id
            )
            AND account_id IS NOT NULL AND position_id IS NOT NULL
            """
        )
        removed_pos = cursor.rowcount
        cursor.execute(
            """
            DELETE FROM trades
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM trades
                WHERE position_id IS NOT NULL AND (account_id IS NULL OR TRIM(account_id) = '')
                GROUP BY position_id
            )
            AND position_id IS NOT NULL AND (account_id IS NULL OR TRIM(account_id) = '')
            """
        )
        removed_pos_no_account = cursor.rowcount
        cursor.execute(
            """
            DELETE FROM trades
            WHERE id NOT IN (
                SELECT MAX(id)
                FROM trades
                WHERE account_id IS NOT NULL AND ticket IS NOT NULL
                GROUP BY account_id, ticket
            )
            AND account_id IS NOT NULL AND ticket IS NOT NULL
            """
        )
        removed_ticket = cursor.rowcount
        if (removed_pos or 0) > 0 or (removed_pos_no_account or 0) > 0 or (removed_ticket or 0) > 0:
            app.logger.info(
                "[DB] DEDUPE removed_pos=%s removed_pos_no_account=%s removed_ticket=%s",
                removed_pos,
                removed_pos_no_account,
                removed_ticket,
            )
    except Exception:
        app.logger.exception("[DB] DEDUPE failed")


def ensure_schema(cursor):
    columns = get_trade_columns(cursor)
    for name, ddl in MIGRATION_COLUMNS.items():
        if name not in columns:
            cursor.execute(f"ALTER TABLE trades ADD COLUMN {name} {ddl}")
    cursor.execute("UPDATE trades SET status = 'OPEN' WHERE status IS NULL OR TRIM(status) = ''")
    cursor.execute(
        "UPDATE trades SET updated_at = COALESCE(updated_at, created_at, CURRENT_TIMESTAMP)"
    )
    dedupe_trades(cursor)
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_ticket ON trades(ticket)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_close_time ON trades(close_time)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_position_id ON trades(position_id)")
    cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_trade_uid ON trades(trade_uid)")
    try:
        cursor.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_account_position ON trades(account_id, position_id)"
        )
    except Exception:
        app.logger.exception("[DB] create unique index account_id+position_id failed")
    try:
        cursor.execute(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_position_id_no_account
            ON trades(position_id)
            WHERE position_id IS NOT NULL AND (account_id IS NULL OR TRIM(account_id) = '')
            """
        )
    except Exception:
        app.logger.exception("[DB] create unique index position_id (no account) failed")
    try:
        cursor.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_account_ticket ON trades(account_id, ticket)"
        )
    except Exception:
        app.logger.exception("[DB] create unique index account_id+ticket failed")


def init_market_candles_schema(cursor):
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS market_candles (
            symbol TEXT NOT NULL,
            tf TEXT NOT NULL,
            time INTEGER NOT NULL,
            open REAL NOT NULL,
            high REAL NOT NULL,
            low REAL NOT NULL,
            close REAL NOT NULL,
            volume REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (symbol, tf, time)
        )
        """
    )
    try:
        cursor.execute(
            """
            DELETE FROM market_candles
            WHERE rowid NOT IN (
                SELECT MAX(rowid)
                FROM market_candles
                GROUP BY symbol, tf, time
            )
            """
        )
    except Exception:
        app.logger.exception("[DB] market_candles dedupe failed")

    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_market_candles_symbol_tf_time
        ON market_candles(symbol, tf, time)
        """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_market_candles_symbol_time
        ON market_candles(symbol, time)
        """
    )
    cursor.execute(
        """
        CREATE UNIQUE INDEX IF NOT EXISTS idx_market_candles_symbol_tf_time_uq
        ON market_candles(symbol, tf, time)
        """
    )


def init_chart_drawings_schema(cursor):
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS chart_drawings (
            account_id TEXT NOT NULL,
            symbol TEXT NOT NULL,
            tf TEXT NOT NULL,
            mode TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (account_id, symbol, tf, mode)
        )
        """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_chart_drawings_scope
        ON chart_drawings(account_id, symbol, tf, mode)
        """
    )


def init_economic_events_schema(cursor):
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS economic_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_uid TEXT NOT NULL UNIQUE,
            time_utc TEXT NOT NULL,
            currency TEXT NOT NULL,
            title TEXT NOT NULL,
            importance INTEGER NOT NULL DEFAULT 0,
            actual TEXT,
            forecast TEXT,
            previous TEXT,
            status TEXT NOT NULL DEFAULT 'upcoming',
            source TEXT NOT NULL DEFAULT 'mt5_calendar',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_economic_events_time_utc
        ON economic_events(time_utc)
        """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_economic_events_currency_time
        ON economic_events(currency, time_utc)
        """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_economic_events_importance
        ON economic_events(importance)
        """
    )


def init_user_notes_schema(cursor):
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS user_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL DEFAULT 'Untitled',
            body TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    cursor.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_user_notes_updated_at
        ON user_notes(updated_at)
        """
    )


def init_database():
    with sqlite3.connect(DB_PATH, timeout=10) as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket INTEGER UNIQUE,
                trade_uid TEXT UNIQUE,
                position_id INTEGER,
                symbol TEXT NOT NULL,
                direction TEXT NOT NULL,
                lot REAL,
                lot_size REAL NOT NULL,
                account_id TEXT,
                timeframe TEXT,
                open_time TEXT NOT NULL,
                close_time TEXT,
                duration_sec INTEGER,
                duration_seconds INTEGER,
                open_price REAL NOT NULL,
                close_price REAL,
                profit REAL,
                profit_r REAL,
                close_reason TEXT,
                exit_reason TEXT,
                spread_points REAL,
                max_float_profit REAL,
                max_float_dd REAL,
                max_floating_profit REAL,
                max_floating_dd REAL,
                setup TEXT,
                setup_result TEXT,
                status TEXT NOT NULL DEFAULT 'OPEN',
                stop_loss REAL,
                take_profit REAL,
                magic INTEGER,
                magic_number INTEGER,
                trade_index INTEGER DEFAULT 0,
                comment TEXT,
                trend_tf TEXT,
                entry_tf TEXT,
                timestamp TEXT,
                day_of_week TEXT,
                hour INTEGER,
                session_active INTEGER,
                ema_fast_20 REAL,
                ema_slow_100 REAL,
                ema_fast_above_slow INTEGER,
                ema_fast_slope REAL,
                ema_slow_slope REAL,
                price_vs_fast_ema REAL,
                price_vs_slow_ema REAL,
                trend_direction TEXT,
                pullback_ema_20 REAL,
                price_distance_from_pullback_ema REAL,
                pullback_valid INTEGER,
                pullback_depth_pips REAL,
                donchian_high REAL,
                donchian_low REAL,
                donchian_range REAL,
                price_vs_don_high INTEGER,
                price_vs_don_low INTEGER,
                donchian_breakout INTEGER,
                don_buffer_pips REAL,
                adx_value REAL,
                adx_above_min INTEGER,
                di_plus REAL,
                di_minus REAL,
                trend_strength TEXT,
                atr_value REAL,
                atr_pips REAL,
                atr_above_min INTEGER,
                atr_percent_of_price REAL,
                risk_mode TEXT,
                risk_percent REAL,
                risk_level TEXT,
                sl_multiplier REAL,
                tp_multiplier REAL,
                calculated_sl_pips REAL,
                calculated_tp_pips REAL,
                rr_ratio REAL,
                spread_ok INTEGER,
                one_entry_per_bar_pass INTEGER,
                session_hour INTEGER,
                session_allowed INTEGER,
                daily_loss_percent REAL,
                consecutive_losses INTEGER,
                equity_dd_percent REAL,
                risk_block_active INTEGER,
                risk_block_reason TEXT,
                signal_type TEXT,
                allow_longs INTEGER,
                allow_shorts INTEGER,
                filters_passed_count INTEGER,
                filters_failed_count INTEGER,
                final_decision TEXT,
                skip_reason TEXT,
                entry_price REAL,
                bid REAL,
                ask REAL,
                bar_time_entry_tf TEXT,
                bar_time_trend_tf TEXT,
                exit_price REAL,
                swap REAL,
                commission REAL,
                snapshot_id INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        ensure_schema(cursor)
        init_system_meta(cursor)
        init_market_candles_schema(cursor)
        init_chart_drawings_schema(cursor)
        init_economic_events_schema(cursor)
        init_user_notes_schema(cursor)
        conn.commit()


def record_for_insert(record, columns, status_default="OPEN"):
    out = {}
    for key, value in record.items():
        if key in columns and has_value(value):
            out[key] = value

    defaults = {
        "symbol": "UNKNOWN",
        "direction": "UNKNOWN",
        "open_time": now_text(),
        "open_price": 0.0,
        "lot_size": 0.0,
        "status": status_default,
        "created_at": now_text(),
        "updated_at": now_text(),
    }
    for key, value in defaults.items():
        if key in columns and key not in out:
            out[key] = value
    return out


def resolve_conflict_target(insert_values, columns):
    account_id = insert_values.get("account_id")
    if has_value(insert_values.get("position_id")):
        if has_value(account_id) and "account_id" in columns and "position_id" in columns:
            return ("account_id", "position_id")
        if "position_id" in columns:
            return ("position_id",)
    if has_value(account_id) and has_value(insert_values.get("ticket")):
        if "account_id" in columns and "ticket" in columns:
            return ("account_id", "ticket")
    if has_value(insert_values.get("trade_uid")) and "trade_uid" in columns:
        return ("trade_uid",)
    if has_value(insert_values.get("ticket")) and "ticket" in columns:
        return ("ticket",)
    return None


def update_by_id(cursor, row_id, record, columns, force=None):
    force = force or set()
    values = {}
    for key, value in record.items():
        if key not in columns or key in ("id", "created_at"):
            continue
        if has_value(value) or key in force:
            values[key] = value
    if "updated_at" in columns:
        values["updated_at"] = now_text()
    if not values:
        return

    sql = ", ".join(f"{k} = ?" for k in values.keys())
    args = [values[k] for k in values.keys()] + [row_id]
    cursor.execute(f"UPDATE trades SET {sql} WHERE id = ?", args)


def build_open_record(payload):
    lot = to_float(pick(payload, "lot", "lot_size", "volume", default=0.0))
    trade_uid = pick(payload, "trade_uid")
    account_id = pick(payload, "account_id", "account", "login", "account_login")
    if not has_value(account_id) and has_value(trade_uid):
        # Expected format: "<login>:<server>:<symbol>:<magic>:<position_id>"
        try:
            account_id = str(trade_uid).split(":", 1)[0].strip()
        except Exception:
            account_id = None
    record = {
        "ticket": to_int(pick(payload, "ticket")),
        "trade_uid": trade_uid,
        "position_id": to_int(pick(payload, "position_id")),
        "symbol": pick(payload, "symbol", default="UNKNOWN"),
        "direction": normalize_direction(pick(payload, "direction", "type", "side", default="UNKNOWN")),
        "lot": lot,
        "lot_size": lot,
        "account_id": account_id,
        "timeframe": pick(payload, "timeframe", "entry_tf", "trend_tf", "tf"),
        "magic": to_int(pick(payload, "magic", "magic_number")),
        "magic_number": to_int(pick(payload, "magic_number", "magic")),
        "ea_version": pick(payload, "ea_version", "expert_version", "ea_build"),
        "open_time": pick(payload, "open_time", "entry_time", "timestamp", default=now_text()),
        "open_price": to_float(pick(payload, "open_price", "entry_price", "bid", "ask", default=0.0)),
        "spread_points": to_float(pick(payload, "spread_points", "spread", "spread_pts")),
        "setup": pick(payload, "setup", "setup_result", "regime_signature", "signal_type"),
        "setup_result": pick(payload, "setup_result", "setup", "regime_signature", "signal_type"),
        "status": normalize_status(pick(payload, "status"), "OPEN"),
        "created_at": pick(payload, "created_at"),
        "updated_at": now_text(),
    }
    for field in PASSTHROUGH_FIELDS:
        if not has_value(record.get(field)) and has_value(payload.get(field)):
            record[field] = payload.get(field)
    sync_aliases(record)
    return record


def find_existing_trade(cursor, columns, ticket, position_id, trade_uid=None, account_id=None):
    if has_value(trade_uid) and "trade_uid" in columns:
        row = cursor.execute(
            "SELECT * FROM trades WHERE trade_uid = ? ORDER BY id DESC LIMIT 1",
            (trade_uid,),
        ).fetchone()
        if row is not None:
            return row
    if has_value(account_id):
        if has_value(position_id) and "position_id" in columns and "account_id" in columns:
            row = cursor.execute(
                "SELECT * FROM trades WHERE account_id = ? AND position_id = ? ORDER BY id DESC LIMIT 1",
                (account_id, position_id),
            ).fetchone()
            if row is not None:
                return row
        if has_value(ticket) and "ticket" in columns and "account_id" in columns:
            row = cursor.execute(
                "SELECT * FROM trades WHERE account_id = ? AND ticket = ? ORDER BY id DESC LIMIT 1",
                (account_id, ticket),
            ).fetchone()
            if row is not None:
                return row
    if has_value(ticket) and "ticket" in columns:
        row = cursor.execute(
            "SELECT * FROM trades WHERE ticket = ? ORDER BY id DESC LIMIT 1",
            (ticket,),
        ).fetchone()
        if row is not None:
            return row
    if has_value(position_id) and "position_id" in columns:
        row = cursor.execute(
            "SELECT * FROM trades WHERE position_id = ? ORDER BY id DESC LIMIT 1",
            (position_id,),
        ).fetchone()
        if row is not None:
            return row
    return None


def upsert_open_trade(cursor, payload):
    columns = get_trade_columns(cursor)
    record = build_open_record(payload)
    account_id = record.get("account_id")
    existing = find_existing_trade(
        cursor,
        columns,
        record.get("ticket"),
        record.get("position_id"),
        record.get("trade_uid"),
        account_id,
    )

    insert_values = record_for_insert(record, columns, status_default="OPEN")
    names = list(insert_values.keys())
    placeholders = ", ".join(["?"] * len(names))
    args = [insert_values[k] for k in names]

    conflict_cols = resolve_conflict_target(insert_values, columns)

    preexisting = existing is not None

    if preexisting and not conflict_cols:
        update_by_id(cursor, existing["id"], record, columns)
        return existing["id"], "updated", True

    if conflict_cols:
        update_cols = [k for k in names if k not in (set(conflict_cols) | {"created_at"})]
        if update_cols:
            set_sql = ", ".join(f"{k} = COALESCE(excluded.{k}, trades.{k})" for k in update_cols)
            sql = (
                f"INSERT INTO trades ({', '.join(names)}) VALUES ({placeholders}) "
                f"ON CONFLICT({', '.join(conflict_cols)}) DO UPDATE SET {set_sql}"
            )
        else:
            sql = (
                f"INSERT INTO trades ({', '.join(names)}) VALUES ({placeholders}) "
                f"ON CONFLICT({', '.join(conflict_cols)}) DO NOTHING"
            )
    else:
        sql = f"INSERT INTO trades ({', '.join(names)}) VALUES ({placeholders})"

    cursor.execute(sql, args)
    if preexisting:
        return existing["id"], "updated", True
    trade_id = cursor.lastrowid
    if conflict_cols and not trade_id:
        existing = find_existing_trade(
            cursor,
            columns,
            record.get("ticket"),
            record.get("position_id"),
            record.get("trade_uid"),
            account_id,
        )
        trade_id = existing["id"] if existing is not None else trade_id
    return trade_id, "inserted", False


def build_close_record(payload, existing=None):
    close_time = pick(payload, "close_time", default=now_text())
    duration = to_int(pick(payload, "duration_sec", "duration_seconds", "duration"))
    if not has_value(duration):
        open_time = existing["open_time"] if existing else pick(payload, "open_time")
        duration = compute_duration_seconds(open_time, close_time)

    profit = to_float(pick(payload, "profit", "pnl"))
    profit_r = to_float(pick(payload, "profit_r"))
    if not has_value(profit_r) and has_value(profit):
        risk = to_float(pick(payload, "risk", "risk_amount", "initial_risk", "risk_value"))
        if has_value(risk):
            try:
                if float(risk) != 0:
                    profit_r = float(profit) / float(risk)
            except Exception:
                pass

    record = {
        "ticket": to_int(pick(payload, "ticket")),
        "trade_uid": pick(payload, "trade_uid"),
        "position_id": to_int(pick(payload, "position_id")),
        "close_time": close_time,
        "close_price": to_float(pick(payload, "close_price", "exit_price")),
        "exit_price": to_float(pick(payload, "exit_price", "close_price")),
        "profit": profit,
        "profit_r": profit_r,
        "duration_sec": duration,
        "duration_seconds": duration,
        "close_reason": pick(payload, "close_reason", "exit_reason", "reason", "close_type"),
        "exit_reason": pick(payload, "exit_reason", "close_reason", "reason", "close_type"),
        "max_float_profit": to_float(pick(payload, "max_float_profit", "max_floating_profit")),
        "max_float_dd": to_float(pick(payload, "max_float_dd", "max_floating_dd")),
        "setup": pick(payload, "setup", "setup_result", "regime_signature"),
        "setup_result": pick(payload, "setup_result", "setup", "regime_signature"),
        "status": "CLOSED",
        "updated_at": now_text(),
        "account_id": pick(payload, "account_id", "account", "login", "account_login"),
        "timeframe": pick(payload, "timeframe", "entry_tf", "trend_tf", "tf"),
        "magic": to_int(pick(payload, "magic", "magic_number")),
        "magic_number": to_int(pick(payload, "magic_number", "magic")),
        "ea_version": pick(payload, "ea_version", "expert_version", "ea_build"),
    }
    if not has_value(record.get("account_id")) and has_value(record.get("trade_uid")):
        try:
            record["account_id"] = str(record.get("trade_uid")).split(":", 1)[0].strip()
        except Exception:
            pass
    for field in PASSTHROUGH_FIELDS:
        if not has_value(record.get(field)) and has_value(payload.get(field)):
            record[field] = payload.get(field)
    sync_aliases(record)
    return record


@app.route("/trade/close", methods=["POST"])
@app.route("/trades/close", methods=["POST"])
@app.route("/trade_close", methods=["POST"])
@app.route("/v1/trade_close", methods=["POST"])
def close_trade():
    try:
        data = request.get_json(force=True) or {}
        app.logger.info("trade_close payload=%s", sanitize_payload(data))
        maybe_cache_ea_version(data)
        missing = [k for k in ("ticket", "position_id", "close_time", "profit") if not has_value(data.get(k))]
        if missing:
            app.logger.info("trade_close missing=%s", ", ".join(missing))

        ticket = to_int(pick(data, "ticket"))
        position_id = to_int(pick(data, "position_id"))
        trade_uid = pick(data, "trade_uid")
        account_id = pick(data, "account_id", "account", "login", "account_login")
        if not has_value(ticket) and not has_value(position_id):
            return jsonify({"status": "error", "message": "Nedostaje ticket i position_id."}), 400

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cols = get_trade_columns(cursor)
            existing = find_existing_trade(cursor, cols, ticket, position_id, trade_uid, account_id)
            close_values = build_close_record(data, existing)

            if existing is not None:
                update_by_id(cursor, existing["id"], close_values, cols, force={"status", "close_time"})
                trade_id = existing["id"]
                mode = "updated"
                deduped = True
            else:
                open_values = build_open_record(data)
                open_values.update(close_values)
                open_values["status"] = "CLOSED"
                sync_aliases(open_values)
                insert_values = record_for_insert(open_values, cols, status_default="CLOSED")
                names = list(insert_values.keys())
                placeholders = ", ".join(["?"] * len(names))
                args = [insert_values[k] for k in names]
                conflict_cols = resolve_conflict_target(insert_values, cols)

                if conflict_cols:
                    update_cols = [k for k in names if k not in (set(conflict_cols) | {"created_at"})]
                    set_sql = ", ".join(f"{k} = COALESCE(excluded.{k}, trades.{k})" for k in update_cols)
                    sql = (
                        f"INSERT INTO trades ({', '.join(names)}) VALUES ({placeholders}) "
                        f"ON CONFLICT({', '.join(conflict_cols)}) DO UPDATE SET {set_sql}"
                    )
                else:
                    sql = f"INSERT INTO trades ({', '.join(names)}) VALUES ({placeholders})"
                cursor.execute(sql, args)
                if conflict_cols:
                    existing = find_existing_trade(
                        cursor,
                        cols,
                        ticket,
                        position_id,
                        trade_uid,
                        account_id,
                    )
                trade_id = existing["id"] if existing is not None else cursor.lastrowid
                mode = "inserted"
                deduped = False

            conn.commit()

        app.logger.info(
            "[DB] UPSERT close pos_id=%s ticket=%s account_id=%s deduped=%s",
            position_id,
            ticket,
            account_id,
            deduped,
        )

        # Explicit "OK" marker for the UI System Logs stream.
        app.logger.info(
            "TRADE_CLOSE OK trade_uid=%s pos_id=%s profit=%s",
            trade_uid,
            position_id,
            close_values.get("profit"),
        )
        return (
            jsonify(
                {
                    "status": "success",
                    "mode": mode,
                    "id": trade_id,
                    "ticket": ticket,
                    "deduped": deduped,
                }
            ),
            200,
        )
    except Exception as e:
        app.logger.exception("trade_close error")
        return jsonify({"status": "error", "message": str(e)}), 400


@app.route("/", methods=["GET"])
def index():
    return render_template("dashboard.html")


@app.route("/favicon.ico")
def favicon():
    return send_from_directory(
        os.path.join(app.root_path, "static"),
        "favicon.ico",
        mimetype="image/x-icon",
    )


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True}), 200


@app.route("/logs/clear", methods=["POST", "DELETE"])
def clear_logs():
    cleared_at = set_logs_cleared()
    return jsonify({"ok": True, "cleared_at": cleared_at}), 200


@app.route("/system/status", methods=["GET"])
def system_status():
    try:
        orch_url = get_orchestrator_url()
        orch_status = check_orchestrator(orch_url)
        heartbeat = get_last_heartbeat()
        orch_status["last_heartbeat"] = heartbeat
        orch_detail, orch_error = fetch_orchestrator_status(orch_url)
        meta = get_system_meta()
        ea_name = LAST_EA_NAME or (meta.get("ea_name") if isinstance(meta, dict) else None)
        ea_version_raw = LAST_EA_VERSION or (meta.get("ea_version_raw") if isinstance(meta, dict) else None)
        if not has_value(ea_version_raw):
            ea_version_raw = meta.get("ea_version") if isinstance(meta, dict) else None
        ea_version_at = LAST_EA_VERSION_AT or (meta.get("updated_at") if isinstance(meta, dict) else None)
        ea_last_seen = ea_version_at
        ea_source = "local"
        if isinstance(orch_detail, dict) and has_value(orch_detail.get("ea_version")):
            ea_version_raw = orch_detail.get("ea_version")
            ea_name = orch_detail.get("ea_name") or ea_name
            ea_version_at = orch_detail.get("last_seen_at") or ea_version_at
            ea_last_seen = orch_detail.get("last_seen_at") or ea_last_seen
            ea_source = "orchestrator"
        ea_version = None
        if has_value(ea_name) and has_value(ea_version_raw):
            ea_version = f"{ea_name} {ea_version_raw}".strip()
        elif has_value(ea_version_raw):
            ea_version = str(ea_version_raw).strip()
        active_symbols = get_active_symbols(limit=200)
        logs = read_log_lines()
        orch_logs = fetch_orchestrator_requests(orch_url)
        if not orch_logs:
            orch_logs = read_orchestrator_log_lines()
        logs = merge_system_logs(logs, orch_logs)
        return jsonify(
            {
                "orchestrator": orch_status,
                "orch_url": orch_status.get("url"),
                "orch_http": orch_status.get("http"),
                "orch_ok": orch_status.get("ok"),
                "orch_error": orch_error,
                "last_heartbeat": heartbeat,
                "ea_version": ea_version,
                "ea_name": ea_name,
                "ea_version_raw": ea_version_raw,
                "ea_version_updated_at": ea_version_at,
                "ea_last_seen": ea_last_seen,
                "ea_source": ea_source,
                "mt5_build": meta.get("mt5_build") if isinstance(meta, dict) else None,
                "build_time": meta.get("build_time") if isinstance(meta, dict) else None,
                "active_symbols": active_symbols,
                "logs_cleared_at": LOG_CLEAR_AT_ISO,
                "logs": logs,
            }
        ), 200
    except Exception as exc:
        return jsonify(
            {
                "orchestrator": {
                    "url": "",
                    "ok": False,
                    "http": None,
                    "error": str(exc),
                    "last_heartbeat": get_last_heartbeat(),
                },
                "orch_url": "",
                "orch_http": None,
                "orch_ok": False,
                "orch_error": str(exc),
                "last_heartbeat": get_last_heartbeat(),
                "ea_version": get_ea_version(),
                "ea_name": None,
                "ea_version_raw": None,
                "ea_version_updated_at": None,
                "ea_last_seen": None,
                "ea_source": "local",
                "mt5_build": None,
                "build_time": None,
                "active_symbols": [],
                "logs_cleared_at": LOG_CLEAR_AT_ISO,
                "logs": ["No logs available"],
            }
        ), 200


@app.route("/api/orch/health", methods=["GET"])
def api_orch_health_proxy():
    request_key = get_request_api_key()
    data, status_code, error_text = call_orchestrator_api(
        "/api/orch/health",
        method="GET",
        timeout_sec=1.6,
        api_key_override=request_key,
    )
    if data is None:
        return jsonify({"ok": False, "error": error_text or "orchestrator_unavailable"}), int(status_code or 502)
    return jsonify(data), int(status_code or 200)


@app.route("/api/orch/config", methods=["GET"])
def api_orch_config_get_proxy():
    request_key = get_request_api_key()
    data, status_code, error_text = call_orchestrator_api(
        "/api/orch/config",
        method="GET",
        timeout_sec=1.8,
        api_key_override=request_key,
    )
    if data is None:
        return jsonify({"ok": False, "error": error_text or "orchestrator_unavailable"}), int(status_code or 502)
    return jsonify(data), int(status_code or 200)


@app.route("/api/orch/config", methods=["POST"])
def api_orch_config_post_proxy():
    body = request.get_json(silent=True)
    if body is None:
        body = {}
    if not isinstance(body, dict):
        return jsonify({"ok": False, "error": "Invalid JSON payload"}), 400

    request_key = get_request_api_key()
    data, status_code, error_text = call_orchestrator_api(
        "/api/orch/config",
        method="POST",
        payload=body,
        timeout_sec=2.2,
        api_key_override=request_key,
    )
    if data is None:
        return jsonify({"ok": False, "error": error_text or "orchestrator_unavailable"}), int(status_code or 502)
    return jsonify(data), int(status_code or 200)


@app.route("/api/orch/decisions", methods=["GET"])
def api_orch_decisions_proxy():
    query = {}
    limit_raw = (request.args.get("limit") or "").strip()
    if has_value(limit_raw):
        query["limit"] = limit_raw

    request_key = get_request_api_key()
    data, status_code, error_text = call_orchestrator_api(
        "/api/orch/decisions",
        method="GET",
        query=query,
        timeout_sec=1.8,
        api_key_override=request_key,
    )
    if data is None:
        return jsonify({"ok": False, "error": error_text or "orchestrator_unavailable", "items": []}), int(status_code or 502)
    return jsonify(data), int(status_code or 200)


@app.route("/system/ea_version", methods=["POST"])
def set_ea_version():
    try:
        data = request.get_json(force=True) or {}
        record = save_system_meta(data)
        if not record:
            return jsonify({"ok": False, "message": "ea_name/ea_version missing or invalid"}), 400
        write_ea_version_cache(
            record.get("ea_version"),
            {
                "bot_id": record.get("bot_id"),
                "account_id": record.get("account_id"),
                "ea_name": record.get("ea_name"),
                "symbol": record.get("symbol"),
                "mt5_build": record.get("mt5_build"),
                "build_time": record.get("build_time"),
            },
        )
        update_ea_state(
            {
                "bot_id": record.get("bot_id"),
                "account_id": record.get("account_id"),
                "symbol": record.get("symbol"),
                "ea_name": record.get("ea_name"),
                "ea_version_raw": record.get("ea_version"),
                "mt5_build": record.get("mt5_build"),
                "build_time": record.get("build_time"),
                "updated_at": record.get("updated_at"),
            }
        )
        update_ea_telemetry(record.get("ea_name"), record.get("ea_version"), record.get("updated_at"))
        app.logger.info(
            "[EA_VERSION] received bot_id=%s account_id=%s ea_version=%s",
            record.get("bot_id"),
            record.get("account_id"),
            record.get("ea_version"),
        )
        return jsonify({"ok": True}), 200
    except Exception as exc:
        app.logger.exception("system ea_version error")
        return jsonify({"ok": False, "message": str(exc)}), 400


@app.route("/risk_ftmo/summary", methods=["GET"])
def risk_ftmo_summary():
    try:
        return jsonify(build_risk_summary()), 200
    except Exception:
        app.logger.exception("risk_ftmo summary error")
        return jsonify(build_empty_risk_summary(get_risk_config())), 200


@app.route("/risk_ftmo/days", methods=["GET"])
def risk_ftmo_days():
    try:
        return jsonify(build_risk_days()), 200
    except Exception:
        app.logger.exception("risk_ftmo days error")
        return jsonify({"days": []}), 200


@app.route("/trades/add", methods=["POST"])
@app.route("/trade/open", methods=["POST"])
@app.route("/trade_open", methods=["POST"])
@app.route("/v1/trade_open", methods=["POST"])
def add_trade():
    try:
        data = request.get_json(force=True) or {}
        app.logger.info("trade_open payload=%s", sanitize_payload(data))
        maybe_cache_ea_version(data)
        missing = [k for k in ("ticket", "position_id", "symbol", "direction", "open_time") if not has_value(data.get(k))]
        if missing:
            app.logger.info("trade_open missing=%s", ", ".join(missing))

        if not has_value(data.get("ticket")) and not has_value(data.get("position_id")):
            return jsonify({"status": "error", "message": "ticket ili position_id je obavezan."}), 400

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            trade_id, mode, deduped = upsert_open_trade(cursor, data)
            conn.commit()

        app.logger.info(
            "[DB] UPSERT open pos_id=%s ticket=%s account_id=%s deduped=%s",
            data.get("position_id"),
            data.get("ticket"),
            data.get("account_id"),
            deduped,
        )
        # Explicit "OK" marker for the UI System Logs stream.
        app.logger.info(
            "TRADE_OPEN OK trade_uid=%s pos_id=%s ticket=%s",
            data.get("trade_uid"),
            data.get("position_id"),
            data.get("ticket"),
        )
        if deduped:
            app.logger.info(
                "[DB] DUPLICATE ignored request_id=%s pos_id=%s ticket=%s account_id=%s",
                get_request_id(data),
                data.get("position_id"),
                data.get("ticket"),
                data.get("account_id"),
            )
        return (
            jsonify({"status": "success", "mode": mode, "id": trade_id, "deduped": deduped}),
            (201 if mode == "inserted" else 200),
        )
    except Exception as e:
        app.logger.exception("trade_open error")
        return jsonify({"status": "error", "message": str(e)}), 400


init_database()


@app.route("/trades", methods=["GET"])
def get_all_trades():
    try:
        limit = request.args.get("limit", type=int) or 200
        limit = max(1, min(limit, 5000))
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            status = request.args.get("status")
            if status:
                cursor.execute(
                    "SELECT * FROM trades WHERE status = ? ORDER BY open_time DESC LIMIT ?",
                    (status.upper(), limit),
                )
            else:
                cursor.execute("SELECT * FROM trades ORDER BY open_time DESC LIMIT ?", (limit,))
            trades = [dict(row) for row in cursor.fetchall()]
        return jsonify({"status": "success", "count": len(trades), "trades": trades}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/trades/stats", methods=["GET"])
def get_statistics():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT
                    COUNT(*) AS total_trades,
                    SUM(CASE WHEN status = 'OPEN' THEN 1 ELSE 0 END) AS open_trades,
                    SUM(CASE WHEN status = 'CLOSED' THEN 1 ELSE 0 END) AS closed_trades,
                    COALESCE(SUM(CASE WHEN status = 'CLOSED' THEN profit ELSE 0 END), 0) AS total_profit,
                    SUM(CASE WHEN status = 'CLOSED' AND profit > 0 THEN 1 ELSE 0 END) AS winning_trades,
                    SUM(CASE WHEN status = 'CLOSED' AND profit < 0 THEN 1 ELSE 0 END) AS losing_trades,
                    COALESCE(AVG(CASE WHEN status = 'CLOSED' AND profit > 0 THEN profit END), 0) AS average_win,
                    COALESCE(AVG(CASE WHEN status = 'CLOSED' AND profit < 0 THEN profit END), 0) AS average_loss,
                    COALESCE(MAX(CASE WHEN status = 'CLOSED' THEN profit END), 0) AS best_trade,
                    COALESCE(MIN(CASE WHEN status = 'CLOSED' THEN profit END), 0) AS worst_trade,
                    COALESCE(SUM(CASE WHEN status = 'CLOSED' AND profit > 0 THEN profit ELSE 0 END), 0) AS gross_profit,
                    COALESCE(SUM(CASE WHEN status = 'CLOSED' AND profit < 0 THEN profit ELSE 0 END), 0) AS gross_loss,
                    COALESCE(SUM(COALESCE(lot, lot_size)), 0) AS total_volume
                FROM trades
                """
            )
            row = cursor.fetchone()

        total_trades = row[0] or 0
        open_trades = row[1] or 0
        closed_trades = row[2] or 0
        total_profit = row[3] or 0
        winning_trades = row[4] or 0
        losing_trades = row[5] or 0
        average_win = row[6] or 0
        average_loss = row[7] or 0
        best_trade = row[8] or 0
        worst_trade = row[9] or 0
        gross_profit = row[10] or 0
        gross_loss = row[11] or 0
        total_volume = row[12] or 0

        win_rate = (winning_trades / closed_trades * 100) if closed_trades > 0 else 0
        profit_factor = (gross_profit / abs(gross_loss)) if gross_loss < 0 else (gross_profit if gross_profit > 0 else 0)

        return jsonify(
            {
                "status": "success",
                "statistics": {
                    "total_trades": total_trades,
                    "open_trades": open_trades,
                    "closed_trades": closed_trades,
                    "total_profit": round(total_profit, 2),
                    "winning_trades": winning_trades,
                    "losing_trades": losing_trades,
                    "win_rate": round(win_rate, 2),
                    "average_win": round(average_win, 2),
                    "average_loss": round(average_loss, 2),
                    "best_trade": round(best_trade, 2),
                    "worst_trade": round(worst_trade, 2),
                    "gross_profit": round(gross_profit, 2),
                    "gross_loss": round(gross_loss, 2),
                    "profit_factor": round(profit_factor, 2),
                    "total_volume": round(total_volume, 2),
                },
            }
        ), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/trades/<int:trade_id>", methods=["DELETE"])
def delete_trade_by_id(trade_id):
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM trades WHERE id = ?", (trade_id,))
            deleted_rows = cursor.rowcount
            conn.commit()
        if deleted_rows == 0:
            return jsonify({"status": "error", "message": "Trade not found."}), 404
        return jsonify({"status": "success", "message": f"Trade #{trade_id} deleted."}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400


@app.route("/trades/ticket/<int:ticket>", methods=["DELETE"])
def delete_trade_by_ticket(ticket):
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM trades WHERE ticket = ?", (ticket,))
            deleted_rows = cursor.rowcount
            conn.commit()
        if deleted_rows == 0:
            return jsonify({"status": "error", "message": "Trade not found."}), 404
        return jsonify({"status": "success", "message": f"Trade ticket {ticket} deleted."}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400


@app.route("/trades/delete_all", methods=["DELETE"])
def delete_all_trades():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM trades")
            deleted_rows = cursor.rowcount
            conn.commit()
        return jsonify({"status": "success", "deleted": deleted_rows}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400


@app.route("/trades/export/csv", methods=["GET"])
def export_trades_csv():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trades ORDER BY open_time DESC")
            rows = cursor.fetchall()
            headers = [col[0] for col in cursor.description] if cursor.description else []

        output = io.StringIO()
        writer = csv.writer(output)
        if headers:
            writer.writerow(headers)
        for row in rows:
            writer.writerow([row[key] for key in headers])

        filename = f"trades_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/trades/export/csv/save", methods=["POST"])
def export_trades_csv_to_file():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM trades ORDER BY open_time DESC")
            rows = cursor.fetchall()
            headers = [col[0] for col in cursor.description] if cursor.description else []

        export_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "exports")
        os.makedirs(export_dir, exist_ok=True)
        filename = f"trades_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        file_path = os.path.join(export_dir, filename)

        with open(file_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if headers:
                writer.writerow(headers)
            for row in rows:
                writer.writerow([row[key] for key in headers])

        return jsonify({"status": "success", "file_path": file_path, "rows": len(rows)}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


MARKET_TF_SECONDS = {
    "M1": 60,
    "M5": 5 * 60,
    "M15": 15 * 60,
    "H1": 60 * 60,
}

MARKET_TF_ALIASES = {
    "M1": "M1",
    "1": "M1",
    "PERIOD_M1": "M1",
    "M5": "M5",
    "5": "M5",
    "PERIOD_M5": "M5",
    "M15": "M15",
    "15": "M15",
    "PERIOD_M15": "M15",
    "H1": "H1",
    "60": "H1",
    "PERIOD_H1": "H1",
    "16385": "H1",
}

NEWS_ALLOWED_STATUS = {"upcoming", "released"}
NEWS_ALLOWED_STATUS_WITH_ALL = {"all", "upcoming", "released"}
NOTES_TITLE_MAX_LEN = 120
NOTES_BODY_MAX_LEN = 50_000
NOTES_DEFAULT_TITLE = "Untitled"


def _market_watch_debug_enabled():
    raw = (os.environ.get("MARKET_WATCH_DEBUG") or "").strip().lower()
    return raw in ("1", "true", "yes", "on")


def _market_future_tolerance_sec(tf):
    tf_key = _normalize_market_tf(tf or "M1")
    step = MARKET_TF_SECONDS.get(tf_key, 60)
    # Allow small client/server clock skew, but reject clearly-future bars.
    return max(step * 3, 180)


def _log_market_series_debug(tag, symbol, tf, limit, candles):
    if not _market_watch_debug_enabled():
        return
    first = candles[0] if candles else None
    last = candles[-1] if candles else None
    app.logger.info(
        "[MW][%s] symbol=%s tf=%s limit=%s count=%s first=%s last=%s",
        tag,
        symbol,
        tf,
        limit,
        len(candles),
        first,
        last,
    )


def _normalize_market_tf(value):
    if value is None:
        return ""

    if isinstance(value, (int, float)):
        key = str(int(value))
    else:
        key = str(value).strip().upper()

    if key in MARKET_TF_ALIASES:
        return MARKET_TF_ALIASES[key]

    if key.startswith("PERIOD_"):
        key = key[7:]
        if key in MARKET_TF_ALIASES:
            return MARKET_TF_ALIASES[key]

    return ""


def _get_market_feed_api_key():
    return (os.environ.get("MARKET_FEED_API_KEY") or "").strip()


def _validate_market_feed_api_key():
    required = _get_market_feed_api_key()
    if not has_value(required):
        return True
    received = (request.headers.get("X-API-Key") or "").strip()
    return received == required


def _parse_market_candle_item(item):
    if not isinstance(item, dict):
        return None

    symbol = str(item.get("symbol") or "").strip().upper()
    tf = _normalize_market_tf(item.get("tf"))
    if not has_value(symbol) or tf not in MARKET_TF_SECONDS:
        return None

    try:
        ts = int(float(item.get("time")))
    except Exception:
        return None
    if ts > 10_000_000_000:
        ts = ts // 1000
    if ts <= 0:
        return None
    if ts > int(time.time()) + _market_future_tolerance_sec(tf):
        return None

    try:
        open_price = float(item.get("open"))
        high_price = float(item.get("high"))
        low_price = float(item.get("low"))
        close_price = float(item.get("close"))
    except Exception:
        return None

    if not (math.isfinite(open_price) and math.isfinite(high_price) and math.isfinite(low_price) and math.isfinite(close_price)):
        return None

    # Keep OHLC envelope valid in case feeder sends partially-updated values.
    high_price = max(high_price, open_price, close_price)
    low_price = min(low_price, open_price, close_price)

    volume_raw = item.get("volume", 0)
    try:
        volume = float(volume_raw if has_value(volume_raw) else 0.0)
    except Exception:
        volume = 0.0
    if not math.isfinite(volume) or volume < 0:
        volume = 0.0

    return (
        symbol,
        tf,
        int(ts),
        float(open_price),
        float(high_price),
        float(low_price),
        float(close_price),
        float(volume),
    )


def _fetch_market_history_with_cursor(cursor, symbol, tf, limit):
    symbol = str(symbol or "EURUSD").strip().upper()
    tf = _normalize_market_tf(tf or "M1")
    if tf not in MARKET_TF_SECONDS:
        tf = "M1"
    limit = max(10, min(int(limit), 5000))
    max_time = int(time.time()) + _market_future_tolerance_sec(tf)
    rows = cursor.execute(
        """
        SELECT time, open, high, low, close, volume
        FROM (
            SELECT time, open, high, low, close, volume
            FROM market_candles
            WHERE symbol = ? AND tf = ? AND time <= ?
            ORDER BY time DESC
            LIMIT ?
        ) recent
        ORDER BY time ASC
        """,
        (symbol, tf, max_time, limit),
    ).fetchall()

    candles = []
    for row in rows:
        candles.append(
            {
                "time": int(row["time"]),
                "open": float(row["open"]),
                "high": float(row["high"]),
                "low": float(row["low"]),
                "close": float(row["close"]),
                "volume": float(row["volume"] or 0),
            }
        )
    return candles


def _fetch_market_history_from_db(symbol, tf, limit):
    with sqlite3.connect(DB_PATH, timeout=10) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        return _fetch_market_history_with_cursor(cursor, symbol, tf, limit)


def _parse_market_history_args():
    symbol = (request.args.get("symbol") or "EURUSD").strip().upper()
    tf = _normalize_market_tf(request.args.get("tf") or "M1")
    if tf not in MARKET_TF_SECONDS:
        tf = "M1"
    try:
        limit = int(request.args.get("limit", 500))
    except Exception:
        limit = 500
    return symbol, tf, limit


def _marketwatch_now_utc_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _marketwatch_is_finite_number(value):
    try:
        number = float(value)
    except Exception:
        return False
    return math.isfinite(number)


def _marketwatch_float(value, default_value=None):
    try:
        number = float(value)
    except Exception:
        return default_value
    if not math.isfinite(number):
        return default_value
    return number


def _marketwatch_int(value, default_value=None):
    try:
        return int(value)
    except Exception:
        return default_value


def _marketwatch_round(value, digits=6):
    if not _marketwatch_is_finite_number(value):
        return None
    return round(float(value), int(digits))


def _marketwatch_pip_size(symbol):
    sym = str(symbol or "").upper()
    return 0.01 if "JPY" in sym else 0.0001


def _marketwatch_parse_symbols_query(raw):
    defaults = ["EURUSD", "USDJPY", "GBPUSD"]
    if not has_value(raw):
        return defaults
    out = []
    seen = set()
    for chunk in str(raw).split(","):
        symbol = str(chunk or "").strip().upper()
        if not symbol:
            continue
        if len(symbol) < 3 or len(symbol) > 24:
            continue
        if symbol in seen:
            continue
        seen.add(symbol)
        out.append(symbol)
    return out[:20] if out else defaults


def _marketwatch_empty_item(symbol):
    return {
        "symbol": str(symbol or "").upper(),
        "h1": {
            "trend": "FLAT",
            "ema50": None,
            "ema200": None,
            "adx14": None,
            "atr14": None,
            "atr_state": "NORMAL",
        },
        "m15": {
            "bias": "NEUTRAL",
            "dist_to_h1_ema50_pips": None,
        },
        "risk": {
            "cooldown_active": False,
            "cooldown_reason": None,
            "news_block_active": False,
            "news_minutes_to_event": None,
            "trades_today": None,
            "trades_today_limit": None,
        },
        "updated_utc": _marketwatch_now_utc_iso(),
    }


def _marketwatch_parse_dt_any(value):
    if not has_value(value):
        return None
    raw = str(value).strip()
    if not raw:
        return None

    iso_raw = raw
    if iso_raw.endswith("Z"):
        iso_raw = iso_raw[:-1] + "+00:00"
    if " " in iso_raw and "T" not in iso_raw:
        iso_raw = iso_raw.replace(" ", "T", 1)
    try:
        parsed = datetime.fromisoformat(iso_raw)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except Exception:
        pass

    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%Y.%m.%d %H:%M:%S",
        "%Y.%m.%d %H:%M",
        "%Y.%m.%d",
    ):
        try:
            return datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc)
        except Exception:
            continue
    return None


def _marketwatch_symbol_currencies(symbol):
    sym = str(symbol or "").upper()
    if len(sym) < 6:
        return []
    base = sym[:3]
    quote = sym[3:6]
    out = []
    if base.isalpha():
        out.append(base)
    if quote.isalpha() and quote not in out:
        out.append(quote)
    return out


def _marketwatch_ema_last(values, period):
    if not isinstance(values, list) or len(values) < max(1, int(period)):
        return None
    p = max(1, int(period))
    alpha = 2.0 / (p + 1.0)
    ema = _marketwatch_float(values[0], None)
    if ema is None:
        return None
    for i in range(1, len(values)):
        v = _marketwatch_float(values[i], None)
        if v is None:
            continue
        ema = (v * alpha) + (ema * (1.0 - alpha))
    return ema


def _marketwatch_wilder_atr_series(candles, period=14):
    if not isinstance(candles, list):
        return []
    p = max(1, int(period))
    if len(candles) < p + 1:
        return []

    trs = []
    for i in range(1, len(candles)):
        prev_close = _marketwatch_float((candles[i - 1] or {}).get("close"), None)
        high_price = _marketwatch_float((candles[i] or {}).get("high"), None)
        low_price = _marketwatch_float((candles[i] or {}).get("low"), None)
        if prev_close is None or high_price is None or low_price is None:
            continue
        tr = max(
            high_price - low_price,
            abs(high_price - prev_close),
            abs(low_price - prev_close),
        )
        trs.append(tr)

    if len(trs) < p:
        return []

    atr = sum(trs[:p]) / p
    out = [atr]
    for i in range(p, len(trs)):
        atr = ((atr * (p - 1.0)) + trs[i]) / p
        out.append(atr)
    return out


def _marketwatch_wilder_adx_last(candles, period=14):
    if not isinstance(candles, list):
        return None
    p = max(1, int(period))
    if len(candles) < p + 1:
        return None

    trs = []
    plus_dm = []
    minus_dm = []
    for i in range(1, len(candles)):
        prev = candles[i - 1] or {}
        curr = candles[i] or {}

        prev_high = _marketwatch_float(prev.get("high"), None)
        prev_low = _marketwatch_float(prev.get("low"), None)
        prev_close = _marketwatch_float(prev.get("close"), None)
        curr_high = _marketwatch_float(curr.get("high"), None)
        curr_low = _marketwatch_float(curr.get("low"), None)
        if (
            prev_high is None
            or prev_low is None
            or prev_close is None
            or curr_high is None
            or curr_low is None
        ):
            continue

        up_move = curr_high - prev_high
        down_move = prev_low - curr_low

        pdm = up_move if up_move > down_move and up_move > 0 else 0.0
        mdm = down_move if down_move > up_move and down_move > 0 else 0.0

        tr = max(
            curr_high - curr_low,
            abs(curr_high - prev_close),
            abs(curr_low - prev_close),
        )

        trs.append(tr)
        plus_dm.append(pdm)
        minus_dm.append(mdm)

    if len(trs) < p:
        return None

    atr_smoothed = sum(trs[:p])
    plus_smoothed = sum(plus_dm[:p])
    minus_smoothed = sum(minus_dm[:p])

    def _dx(atr_sum, p_sum, m_sum):
        if atr_sum <= 0:
            return 0.0
        pdi = 100.0 * (p_sum / atr_sum)
        mdi = 100.0 * (m_sum / atr_sum)
        denom = pdi + mdi
        if denom <= 0:
            return 0.0
        return 100.0 * abs(pdi - mdi) / denom

    dx_values = [_dx(atr_smoothed, plus_smoothed, minus_smoothed)]
    for i in range(p, len(trs)):
        atr_smoothed = atr_smoothed - (atr_smoothed / p) + trs[i]
        plus_smoothed = plus_smoothed - (plus_smoothed / p) + plus_dm[i]
        minus_smoothed = minus_smoothed - (minus_smoothed / p) + minus_dm[i]
        dx_values.append(_dx(atr_smoothed, plus_smoothed, minus_smoothed))

    if not dx_values:
        return None
    if len(dx_values) < p:
        return sum(dx_values) / len(dx_values)

    adx = sum(dx_values[:p]) / p
    for i in range(p, len(dx_values)):
        adx = ((adx * (p - 1.0)) + dx_values[i]) / p
    return adx


def _marketwatch_h1_context(symbol, candles_h1):
    out = {
        "trend": "FLAT",
        "ema50": None,
        "ema200": None,
        "adx14": None,
        "atr14": None,
        "atr_state": "NORMAL",
    }
    if not isinstance(candles_h1, list) or not candles_h1:
        return out

    closes = []
    for row in candles_h1:
        close_value = _marketwatch_float((row or {}).get("close"), None)
        if close_value is not None:
            closes.append(close_value)

    ema50 = _marketwatch_ema_last(closes, 50)
    ema200 = _marketwatch_ema_last(closes, 200)
    atr_series = _marketwatch_wilder_atr_series(candles_h1, 14)
    atr14 = atr_series[-1] if atr_series else None
    adx14 = _marketwatch_wilder_adx_last(candles_h1, 14)

    trend = "FLAT"
    if _marketwatch_is_finite_number(ema50) and _marketwatch_is_finite_number(ema200):
        diff = float(ema50) - float(ema200)
        pip_floor = _marketwatch_pip_size(symbol) * 0.5
        adaptive = float(atr14) * 0.05 if _marketwatch_is_finite_number(atr14) else 0.0
        threshold = max(pip_floor, adaptive)
        if abs(diff) < threshold:
            trend = "FLAT"
        elif diff > 0:
            trend = "UP"
        else:
            trend = "DOWN"

    atr_state = "NORMAL"
    if _marketwatch_is_finite_number(atr14) and atr_series:
        lookback = atr_series[-480:] if len(atr_series) > 480 else atr_series
        if lookback:
            avg_atr = sum(lookback) / len(lookback)
            if avg_atr > 0:
                if atr14 < avg_atr * 0.8:
                    atr_state = "LOW"
                elif atr14 > avg_atr * 1.2:
                    atr_state = "HIGH"

    out["trend"] = trend
    out["ema50"] = _marketwatch_round(ema50, 6)
    out["ema200"] = _marketwatch_round(ema200, 6)
    out["adx14"] = _marketwatch_round(adx14, 3)
    out["atr14"] = _marketwatch_round(atr14, 6)
    out["atr_state"] = atr_state
    return out


def _marketwatch_m15_context(symbol, candles_m15, h1_ema50, h1_trend):
    out = {
        "bias": "NEUTRAL",
        "dist_to_h1_ema50_pips": None,
    }
    if not isinstance(candles_m15, list) or not candles_m15:
        return out

    closes = []
    for row in candles_m15:
        close_value = _marketwatch_float((row or {}).get("close"), None)
        if close_value is not None:
            closes.append(close_value)

    ema50_m15 = _marketwatch_ema_last(closes, 50)
    last = candles_m15[-1] or {}
    last_close = _marketwatch_float(last.get("close"), None)
    last_open = _marketwatch_float(last.get("open"), None)

    bias = "NEUTRAL"
    bullish = False
    bearish = False
    if _marketwatch_is_finite_number(last_close):
        if _marketwatch_is_finite_number(ema50_m15):
            bullish = last_close > ema50_m15
            bearish = last_close < ema50_m15
        if not bullish and not bearish and _marketwatch_is_finite_number(last_open):
            bullish = last_close > last_open
            bearish = last_close < last_open

    trend_upper = str(h1_trend or "").upper()
    if bullish and trend_upper != "DOWN":
        bias = "BULL"
    elif bearish and trend_upper != "UP":
        bias = "BEAR"

    dist_to_h1_ema50 = None
    if _marketwatch_is_finite_number(last_close) and _marketwatch_is_finite_number(h1_ema50):
        pip_size = _marketwatch_pip_size(symbol)
        if pip_size > 0:
            dist_to_h1_ema50 = (float(last_close) - float(h1_ema50)) / pip_size

    out["bias"] = bias
    out["dist_to_h1_ema50_pips"] = _marketwatch_round(dist_to_h1_ema50, 1)
    return out


def _marketwatch_latest_v2_stats_map(cursor, symbols):
    if not symbols:
        return {}
    placeholders = ",".join(["?"] * len(symbols))
    out = {}
    try:
        rows = cursor.execute(
            f"""
            SELECT vs.symbol, vd.stats_json, vd.created_at, vd.id
            FROM v2_decisions vd
            JOIN v2_snapshots vs ON vs.id = vd.snapshot_id
            WHERE vs.symbol IN ({placeholders})
            ORDER BY vd.created_at DESC, vd.id DESC
            """,
            symbols,
        ).fetchall()
    except Exception:
        return {}

    for row in rows:
        symbol = str(row["symbol"] or "").upper()
        if not symbol or symbol in out:
            continue
        stats = {}
        raw_json = row["stats_json"]
        if has_value(raw_json):
            try:
                parsed = json.loads(raw_json)
                if isinstance(parsed, dict):
                    stats = parsed
            except Exception:
                stats = {}
        out[symbol] = {
            "stats": stats,
            "created_at": row["created_at"],
        }
    return out


def _marketwatch_latest_news_checks_map(cursor, symbols):
    if not symbols:
        return {}
    placeholders = ",".join(["?"] * len(symbols))
    out = {}
    try:
        rows = cursor.execute(
            f"""
            SELECT symbol, has_news, minutes_to_next, window_min, impact, created_at, id
            FROM news_checks
            WHERE symbol IN ({placeholders})
            ORDER BY created_at DESC, id DESC
            """,
            symbols,
        ).fetchall()
    except Exception:
        return {}

    for row in rows:
        symbol = str(row["symbol"] or "").upper()
        if not symbol or symbol in out:
            continue
        out[symbol] = {
            "has_news": bool(row["has_news"] or 0),
            "minutes_to_next": _marketwatch_int(row["minutes_to_next"], None),
            "window_min": _marketwatch_int(row["window_min"], None),
            "impact": row["impact"],
            "created_at": row["created_at"],
        }
    return out


def _marketwatch_latest_closed_reason_map(cursor, symbols):
    if not symbols:
        return {}
    placeholders = ",".join(["?"] * len(symbols))
    out = {}
    try:
        rows = cursor.execute(
            f"""
            SELECT symbol, close_reason, exit_reason, profit
            FROM trades
            WHERE status = 'CLOSED' AND symbol IN ({placeholders})
            ORDER BY id DESC
            """,
            symbols,
        ).fetchall()
    except Exception:
        return {}

    for row in rows:
        symbol = str(row["symbol"] or "").upper()
        if not symbol or symbol in out:
            continue
        out[symbol] = {
            "close_reason": row["close_reason"],
            "exit_reason": row["exit_reason"],
            "profit": _marketwatch_float(row["profit"], None),
        }
    return out


def _marketwatch_trades_today_counts_map(cursor, symbols, now_utc):
    if not symbols:
        return {}
    placeholders = ",".join(["?"] * len(symbols))
    counts = {str(symbol).upper(): 0 for symbol in symbols}
    try:
        rows = cursor.execute(
            f"""
            SELECT symbol, close_time, open_time, created_at
            FROM trades
            WHERE symbol IN ({placeholders})
            ORDER BY id DESC
            LIMIT 5000
            """,
            symbols,
        ).fetchall()
    except Exception:
        return counts

    today_utc = now_utc.date()
    for row in rows:
        symbol = str(row["symbol"] or "").upper()
        if symbol not in counts:
            continue
        dt_value = (
            _marketwatch_parse_dt_any(row["close_time"])
            or _marketwatch_parse_dt_any(row["open_time"])
            or _marketwatch_parse_dt_any(row["created_at"])
        )
        if dt_value is None:
            continue
        if dt_value.date() == today_utc:
            counts[symbol] = int(counts.get(symbol, 0) + 1)
    return counts


def _marketwatch_map_cooldown_reason(last_result, last_closed_row):
    result = str(last_result or "").strip().lower()
    if result in ("win", "tp", "takeprofit", "take_profit"):
        return "TP"
    if result in ("loss", "sl", "stoploss", "stop_loss"):
        return "SL"

    if isinstance(last_closed_row, dict):
        reason_text = (
            str(last_closed_row.get("close_reason") or last_closed_row.get("exit_reason") or "")
            .strip()
            .upper()
        )
        if "TP" in reason_text or "TAKE" in reason_text:
            return "TP"
        if "SL" in reason_text or "STOP" in reason_text:
            return "SL"
        profit = _marketwatch_float(last_closed_row.get("profit"), None)
        if _marketwatch_is_finite_number(profit):
            return "TP" if profit >= 0 else "SL"
    return None


def _marketwatch_news_from_events(cursor, symbol, now_utc, window_min, min_importance):
    currencies = _marketwatch_symbol_currencies(symbol)
    if not currencies:
        return False, None

    window = _marketwatch_int(window_min, MARKETWATCH_NEWS_WINDOW_MIN_DEFAULT)
    if window is None or window < 0:
        window = MARKETWATCH_NEWS_WINDOW_MIN_DEFAULT
    if window > 240:
        window = 240

    importance = _marketwatch_int(min_importance, MARKETWATCH_NEWS_MIN_IMPORTANCE_DEFAULT)
    if importance is None:
        importance = MARKETWATCH_NEWS_MIN_IMPORTANCE_DEFAULT
    if importance < 0:
        importance = 0
    if importance > 2:
        importance = 2

    start_dt = now_utc - timedelta(minutes=window)
    end_dt = now_utc + timedelta(minutes=window)
    placeholders = ",".join(["?"] * len(currencies))
    args = list(currencies) + [
        int(importance),
        start_dt.strftime(DT_FORMAT),
        end_dt.strftime(DT_FORMAT),
        int(now_utc.timestamp()),
    ]

    try:
        row = cursor.execute(
            f"""
            SELECT time_utc
            FROM economic_events
            WHERE currency IN ({placeholders})
              AND importance >= ?
              AND time_utc >= ?
              AND time_utc <= ?
            ORDER BY ABS(strftime('%s', time_utc) - ?) ASC, importance DESC
            LIMIT 1
            """,
            args,
        ).fetchone()
    except Exception:
        return False, None

    if row is None:
        return False, None
    event_dt = _parse_news_time_utc(row["time_utc"])
    if event_dt is None:
        return False, None

    minutes = int(round((event_dt - now_utc).total_seconds() / 60.0))
    return True, minutes


def _marketwatch_risk_context_for_symbol(
    cursor,
    symbol,
    now_utc,
    stats_by_symbol,
    news_checks_by_symbol,
    last_closed_by_symbol,
    trades_today_map,
):
    risk = {
        "cooldown_active": False,
        "cooldown_reason": None,
        "news_block_active": False,
        "news_minutes_to_event": None,
        "trades_today": None,
        "trades_today_limit": None,
    }

    stats_bundle = stats_by_symbol.get(symbol) if isinstance(stats_by_symbol, dict) else None
    stats_payload = stats_bundle.get("stats") if isinstance(stats_bundle, dict) else {}
    if not isinstance(stats_payload, dict):
        stats_payload = {}

    ladder = stats_payload.get("ladder") if isinstance(stats_payload.get("ladder"), dict) else {}
    limits = ladder.get("limits") if isinstance(ladder.get("limits"), dict) else {}
    daily_metrics = (
        stats_payload.get("daily_metrics")
        if isinstance(stats_payload.get("daily_metrics"), dict)
        else {}
    )
    news = stats_payload.get("news") if isinstance(stats_payload.get("news"), dict) else {}

    cooldown_remaining_sec = _marketwatch_int(
        limits.get("cooldown_remaining_sec", daily_metrics.get("cooldown_remaining_sec")),
        0,
    )
    cooldown_remaining_sec = max(0, int(cooldown_remaining_sec or 0))
    cooldown_active = cooldown_remaining_sec > 0
    cooldown_reason = None
    if cooldown_active:
        cooldown_reason = _marketwatch_map_cooldown_reason(
            daily_metrics.get("last_trade_result"),
            last_closed_by_symbol.get(symbol) if isinstance(last_closed_by_symbol, dict) else None,
        )

    trades_today = _marketwatch_int(
        limits.get("daily_trades_count", daily_metrics.get("daily_trades_count")),
        None,
    )
    if trades_today is None and isinstance(trades_today_map, dict):
        trades_today = _marketwatch_int(trades_today_map.get(symbol), None)
    trades_today_limit = _marketwatch_int(limits.get("daily_trade_limit"), None)

    news_block_active = None
    if "has_news" in news:
        news_block_active = bool(news.get("has_news"))
    news_minutes = _marketwatch_int(news.get("minutes_to_next"), None)
    news_window = _marketwatch_int(news.get("window_min"), None)
    news_min_importance = _marketwatch_int(news.get("min_importance"), None)

    news_check = news_checks_by_symbol.get(symbol) if isinstance(news_checks_by_symbol, dict) else None
    if news_check and news_block_active is None:
        news_block_active = bool(news_check.get("has_news"))
    if news_check and news_minutes is None:
        news_minutes = _marketwatch_int(news_check.get("minutes_to_next"), None)
    if news_check and news_window is None:
        news_window = _marketwatch_int(news_check.get("window_min"), None)

    need_db_news_probe = (
        news_block_active is None
        or news_block_active is False
        or news_minutes is None
    )
    if need_db_news_probe:
        has_news_from_db, minutes_from_db = _marketwatch_news_from_events(
            cursor,
            symbol,
            now_utc,
            news_window if news_window is not None else MARKETWATCH_NEWS_WINDOW_MIN_DEFAULT,
            news_min_importance if news_min_importance is not None else MARKETWATCH_NEWS_MIN_IMPORTANCE_DEFAULT,
        )
        if has_news_from_db:
            news_block_active = True
            news_minutes = minutes_from_db
        else:
            if news_block_active is None:
                news_block_active = False
            if news_minutes is None:
                news_minutes = minutes_from_db

    risk["cooldown_active"] = bool(cooldown_active)
    risk["cooldown_reason"] = cooldown_reason if risk["cooldown_active"] else None
    risk["news_block_active"] = bool(news_block_active) if news_block_active is not None else False
    risk["news_minutes_to_event"] = _marketwatch_int(news_minutes, None)
    risk["trades_today"] = _marketwatch_int(trades_today, None)
    risk["trades_today_limit"] = _marketwatch_int(trades_today_limit, None)
    return risk


def _marketwatch_compute_symbol_item(
    cursor,
    symbol,
    now_utc,
    stats_by_symbol,
    news_checks_by_symbol,
    last_closed_by_symbol,
    trades_today_map,
):
    item = _marketwatch_empty_item(symbol)
    symbol_key = str(symbol or "").upper()

    candles_h1 = _fetch_market_history_with_cursor(cursor, symbol_key, "H1", 520)
    candles_m15 = _fetch_market_history_with_cursor(cursor, symbol_key, "M15", 120)

    h1_context = _marketwatch_h1_context(symbol_key, candles_h1)
    m15_context = _marketwatch_m15_context(
        symbol_key,
        candles_m15,
        h1_context.get("ema50"),
        h1_context.get("trend"),
    )
    risk_context = _marketwatch_risk_context_for_symbol(
        cursor,
        symbol_key,
        now_utc,
        stats_by_symbol,
        news_checks_by_symbol,
        last_closed_by_symbol,
        trades_today_map,
    )

    item["h1"] = h1_context
    item["m15"] = m15_context
    item["risk"] = risk_context
    item["updated_utc"] = now_utc.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    return item


def _marketwatch_compute_symbol_items(symbols):
    computed = {}
    if not symbols:
        return computed

    now_utc = datetime.now(timezone.utc)
    with sqlite3.connect(DB_PATH, timeout=10) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        stats_by_symbol = _marketwatch_latest_v2_stats_map(cursor, symbols)
        news_checks_by_symbol = _marketwatch_latest_news_checks_map(cursor, symbols)
        last_closed_by_symbol = _marketwatch_latest_closed_reason_map(cursor, symbols)
        trades_today_map = _marketwatch_trades_today_counts_map(cursor, symbols, now_utc)

        for symbol in symbols:
            key = str(symbol or "").upper()
            try:
                computed[key] = _marketwatch_compute_symbol_item(
                    cursor,
                    key,
                    now_utc,
                    stats_by_symbol,
                    news_checks_by_symbol,
                    last_closed_by_symbol,
                    trades_today_map,
                )
            except Exception:
                app.logger.exception("marketwatch indicators compute error for %s", key)
                computed[key] = _marketwatch_empty_item(key)
    return computed


def _marketwatch_cache_get(symbol):
    key = str(symbol or "").upper()
    now_ts = time.time()
    with MARKETWATCH_INDICATOR_CACHE_LOCK:
        entry = MARKETWATCH_INDICATOR_CACHE.get(key)
        if not isinstance(entry, dict):
            return None
        if float(entry.get("expires_at", 0)) <= now_ts:
            MARKETWATCH_INDICATOR_CACHE.pop(key, None)
            return None
        payload = entry.get("item")
    if not isinstance(payload, dict):
        return None
    try:
        return json.loads(json.dumps(payload))
    except Exception:
        return dict(payload)


def _marketwatch_cache_set(symbol, item):
    key = str(symbol or "").upper()
    ttl = max(10, min(30, int(MARKETWATCH_INDICATOR_CACHE_TTL_SEC or 20)))
    expires_at = time.time() + ttl
    with MARKETWATCH_INDICATOR_CACHE_LOCK:
        MARKETWATCH_INDICATOR_CACHE[key] = {
            "expires_at": expires_at,
            "item": item,
        }


def _marketwatch_get_items_with_cache(symbols):
    out = {}
    to_compute = []
    for symbol in symbols:
        key = str(symbol or "").upper()
        cached = _marketwatch_cache_get(key)
        if cached is None:
            to_compute.append(key)
        else:
            out[key] = cached

    if to_compute:
        fresh = _marketwatch_compute_symbol_items(to_compute)
        for symbol in to_compute:
            item = fresh.get(symbol) or _marketwatch_empty_item(symbol)
            _marketwatch_cache_set(symbol, item)
            out[symbol] = item

    ordered = []
    for symbol in symbols:
        key = str(symbol or "").upper()
        ordered.append(out.get(key) or _marketwatch_empty_item(key))
    return ordered


def _normalize_market_mode(value):
    raw = str(value or "").strip().upper()
    if raw == "LIVE":
        return "LIVE"
    return "HISTORY"


def _normalize_chart_drawings_payload(payload):
    if isinstance(payload, list):
        drawings = payload
        version = 1
    elif isinstance(payload, dict):
        drawings = payload.get("drawings")
        if not isinstance(drawings, list):
            drawings = payload.get("items")
        if not isinstance(drawings, list):
            drawings = []
        try:
            version = int(payload.get("version", 1))
        except Exception:
            version = 1
    else:
        drawings = []
        version = 1

    if version <= 0:
        version = 1
    return {"version": version, "drawings": drawings}


def _parse_market_drawings_scope(source):
    source = source or {}
    account_id = str(source.get("account_id") or source.get("accountId") or "default").strip()
    symbol = str(source.get("symbol") or "EURUSD").strip().upper()
    tf = _normalize_market_tf(source.get("tf") or "M1")
    mode = _normalize_market_mode(source.get("mode") or "HISTORY")

    if not has_value(account_id):
        account_id = "default"
    if not has_value(symbol):
        symbol = "EURUSD"
    if tf not in MARKET_TF_SECONDS:
        tf = "M1"

    return account_id, symbol, tf, mode


@app.route("/api/market/drawings", methods=["GET"])
@app.route("/api/market/drawings/", methods=["GET"])
@app.route("/api/v1/market/drawings", methods=["GET"])
@app.route("/api/v1/market/drawings/", methods=["GET"])
def api_market_drawings_get():
    try:
        account_id, symbol, tf, mode = _parse_market_drawings_scope(request.args)
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            row = cursor.execute(
                """
                SELECT payload_json, updated_at
                FROM chart_drawings
                WHERE account_id = ? AND symbol = ? AND tf = ? AND mode = ?
                """,
                (account_id, symbol, tf, mode),
            ).fetchone()

        found = row is not None
        payload = {"version": 1, "drawings": []}
        updated_at = None
        if row:
            updated_at = row["updated_at"]
            raw_payload = row["payload_json"]
            try:
                parsed = json.loads(raw_payload) if has_value(raw_payload) else {}
            except Exception:
                app.logger.exception("market drawings: invalid payload_json for %s/%s/%s/%s", account_id, symbol, tf, mode)
                parsed = {}
            payload = _normalize_chart_drawings_payload(parsed)

        return jsonify(
            {
                "ok": True,
                "found": found,
                "account_id": account_id,
                "symbol": symbol,
                "tf": tf,
                "mode": mode,
                "payload": payload,
                "updated_at": updated_at,
            }
        ), 200
    except Exception:
        app.logger.exception("market drawings get error")
        return jsonify({"ok": False, "error": "Failed to load drawings"}), 500


@app.route("/api/market/drawings", methods=["POST"])
@app.route("/api/market/drawings/", methods=["POST"])
@app.route("/api/v1/market/drawings", methods=["POST"])
@app.route("/api/v1/market/drawings/", methods=["POST"])
def api_market_drawings_post():
    try:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"ok": False, "error": "Invalid JSON payload"}), 400

        account_id, symbol, tf, mode = _parse_market_drawings_scope(data)
        payload = _normalize_chart_drawings_payload(data.get("payload"))
        payload_json = json.dumps(payload, ensure_ascii=False)

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO chart_drawings (
                    account_id, symbol, tf, mode, payload_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(account_id, symbol, tf, mode) DO UPDATE SET
                    payload_json = excluded.payload_json,
                    updated_at = CURRENT_TIMESTAMP
                """,
                (account_id, symbol, tf, mode, payload_json),
            )
            conn.commit()

        return jsonify(
            {
                "ok": True,
                "account_id": account_id,
                "symbol": symbol,
                "tf": tf,
                "mode": mode,
            }
        ), 200
    except Exception:
        app.logger.exception("market drawings post error")
        return jsonify({"ok": False, "error": "Failed to save drawings"}), 500


@app.route("/api/market/drawings", methods=["DELETE"])
@app.route("/api/market/drawings/", methods=["DELETE"])
@app.route("/api/v1/market/drawings", methods=["DELETE"])
@app.route("/api/v1/market/drawings/", methods=["DELETE"])
def api_market_drawings_delete():
    try:
        account_id, symbol, tf, mode = _parse_market_drawings_scope(request.args)
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                DELETE FROM chart_drawings
                WHERE account_id = ? AND symbol = ? AND tf = ? AND mode = ?
                """,
                (account_id, symbol, tf, mode),
            )
            conn.commit()

        return jsonify(
            {
                "ok": True,
                "account_id": account_id,
                "symbol": symbol,
                "tf": tf,
                "mode": mode,
            }
        ), 200
    except Exception:
        app.logger.exception("market drawings delete error")
        return jsonify({"ok": False, "error": "Failed to delete drawings"}), 500


@app.route("/api/market/candles/batch", methods=["POST"])
@app.route("/api/market/candles/batch/", methods=["POST"])
@app.route("/api/v1/market/candles/batch", methods=["POST"])
@app.route("/api/v1/market/candles/batch/", methods=["POST"])
def api_market_candles_batch():
    # quick test:
    # curl -X POST http://127.0.0.1:5000/api/market/candles/batch -H "Content-Type: application/json" -d "[]"
    try:
        if not _validate_market_feed_api_key():
            return jsonify({"ok": False, "status": "error", "error": "Unauthorized"}), 401

        data = request.get_json(silent=True)
        items = None
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            if "items" in data:
                items = data.get("items")
                if not isinstance(items, list):
                    return jsonify({"ok": False, "status": "error", "error": "Field 'items' must be an array"}), 400
            else:
                return jsonify({"ok": False, "status": "error", "error": "Invalid JSON payload"}), 400
        else:
            return jsonify({"ok": False, "status": "error", "error": "Invalid JSON payload"}), 400

        if len(items) > 5000:
            return jsonify({"ok": False, "status": "error", "error": "Batch too large (max 5000 items)"}), 413
        if not items:
            return jsonify({"ok": True, "status": "success", "received": 0, "accepted": 0, "skipped": 0}), 200

        sample = items[0] if items else None
        app.logger.info(
            "market candles batch incoming items=%s sample=%s",
            len(items),
            str(sample)[:240] if sample is not None else "None",
        )

        rows = []
        skipped = 0
        for item in items:
            parsed = _parse_market_candle_item(item)
            if parsed is None:
                skipped += 1
                continue
            rows.append(parsed)

        if not rows:
            return jsonify({"ok": False, "status": "error", "error": "No valid candle items", "received": len(items), "accepted": 0, "skipped": skipped}), 400

        grouped = defaultdict(lambda: {"count": 0, "min": None, "max": None})
        for row in rows:
            symbol, tf, ts, _, _, _, _, _ = row
            g = grouped[(symbol, tf)]
            g["count"] += 1
            g["min"] = ts if g["min"] is None else min(g["min"], ts)
            g["max"] = ts if g["max"] is None else max(g["max"], ts)

        group_parts = []
        for (symbol, tf), g in sorted(grouped.items()):
            group_parts.append(
                f"{symbol}/{tf}:count={g['count']} min={g['min']} max={g['max']}"
            )
        app.logger.info(
            "market candles batch parsed accepted=%s skipped=%s groups=%s",
            len(rows),
            skipped,
            " | ".join(group_parts),
        )

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.executemany(
                """
                INSERT INTO market_candles (
                    symbol, tf, time, open, high, low, close, volume, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(symbol, tf, time) DO UPDATE SET
                    open = excluded.open,
                    high = excluded.high,
                    low = excluded.low,
                    close = excluded.close,
                    volume = excluded.volume,
                    updated_at = CURRENT_TIMESTAMP
                """,
                rows,
            )
            conn.commit()

            since_ts = int(time.time()) - 24 * 3600
            recent_rows = cursor.execute(
                """
                SELECT symbol, tf, COUNT(*) AS cnt, MIN(time) AS min_t, MAX(time) AS max_t
                FROM market_candles
                WHERE time >= ?
                GROUP BY symbol, tf
                ORDER BY symbol, tf
                """,
                (since_ts,),
            ).fetchall()

        recent_parts = []
        for symbol, tf, cnt, min_t, max_t in recent_rows:
            recent_parts.append(f"{symbol}/{tf}:cnt24h={cnt} min={min_t} max={max_t}")
        app.logger.info(
            "market candles db snapshot24h groups=%s",
            " | ".join(recent_parts) if recent_parts else "<empty>",
        )

        app.logger.info(
            "market candles batch received=%s accepted=%s skipped=%s",
            len(items),
            len(rows),
            skipped,
        )
        return jsonify(
            {
                "ok": True,
                "status": "success",
                "received": len(items),
                "accepted": len(rows),
                "skipped": skipped,
            }
        ), 200
    except Exception:
        app.logger.exception("market candles batch error")
        return jsonify({"ok": False, "status": "error", "error": "Failed to process candle batch"}), 500


def _parse_news_time_utc(value):
    if not has_value(value):
        return None
    raw = str(value).strip()
    if not raw:
        return None

    iso_raw = raw
    if iso_raw.endswith("Z"):
        iso_raw = iso_raw[:-1] + "+00:00"
    if " " in iso_raw and "T" not in iso_raw:
        iso_raw = iso_raw.replace(" ", "T", 1)

    parsed = None
    try:
        parsed = datetime.fromisoformat(iso_raw)
    except Exception:
        parsed = None

    if parsed is None:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(raw, fmt)
                break
            except Exception:
                continue

    if parsed is None:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _clamp_news_importance(value):
    try:
        importance = int(value)
    except Exception:
        importance = 0
    if importance < 0:
        return 0
    if importance > 2:
        return 2
    return importance


def _normalize_news_status(value, default_value="upcoming"):
    if not has_value(value):
        return default_value
    status = str(value).strip().lower()
    return status if status in NEWS_ALLOWED_STATUS else default_value


def _normalize_news_text(value, max_len=1024):
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if len(text) > max_len:
        text = text[:max_len]
    return text


def _normalize_news_event(item):
    if not isinstance(item, dict):
        return None, "event must be an object"

    event_uid = _normalize_news_text(item.get("event_uid"), 255)
    if not has_value(event_uid):
        return None, "event_uid is required"

    time_dt = _parse_news_time_utc(item.get("time_utc"))
    if time_dt is None:
        return None, "time_utc is required and must be a valid UTC timestamp"

    currency = _normalize_news_text(item.get("currency"), 16)
    if not has_value(currency):
        return None, "currency is required"
    currency = str(currency).upper()

    title = _normalize_news_text(item.get("title"), 1024)
    if not has_value(title):
        return None, "title is required"

    status_raw = item.get("status")
    if has_value(status_raw):
        normalized_status = str(status_raw).strip().lower()
        if normalized_status not in NEWS_ALLOWED_STATUS:
            return None, "status must be one of: upcoming, released"
        status = normalized_status
    else:
        status = "upcoming"

    source = _normalize_news_text(item.get("source"), 64) or "mt5_calendar"

    row = (
        str(event_uid),
        time_dt.strftime(DT_FORMAT),
        str(currency),
        str(title),
        _clamp_news_importance(item.get("importance")),
        _normalize_news_text(item.get("actual"), 256),
        _normalize_news_text(item.get("forecast"), 256),
        _normalize_news_text(item.get("previous"), 256),
        status,
        source,
    )
    return row, None


def _parse_news_ymd(value):
    if not has_value(value):
        return None
    text = str(value).strip()
    try:
        return datetime.strptime(text, "%Y-%m-%d").date()
    except Exception:
        return None


@app.post("/api/news/upsert")
@app.post("/api/news/upsert/")
def api_news_upsert():
    try:
        if not _validate_market_feed_api_key():
            return jsonify({"ok": False, "error": "Unauthorized"}), 401

        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"ok": False, "error": "Invalid JSON payload"}), 400

        events = data.get("events")
        if not isinstance(events, list):
            return jsonify({"ok": False, "error": "Field 'events' must be an array"}), 400
        if len(events) > 5000:
            return jsonify({"ok": False, "error": "Batch too large (max 5000 events)"}), 413
        if not events:
            return jsonify({"ok": True, "upserted": 0}), 200

        rows = []
        for idx, event in enumerate(events):
            normalized, err = _normalize_news_event(event)
            if err:
                return jsonify({"ok": False, "error": f"events[{idx}]: {err}"}), 400
            rows.append(normalized)

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.executemany(
                """
                INSERT INTO economic_events (
                    event_uid,
                    time_utc,
                    currency,
                    title,
                    importance,
                    actual,
                    forecast,
                    previous,
                    status,
                    source,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(event_uid) DO UPDATE SET
                    time_utc = excluded.time_utc,
                    currency = excluded.currency,
                    title = excluded.title,
                    importance = excluded.importance,
                    actual = excluded.actual,
                    forecast = excluded.forecast,
                    previous = excluded.previous,
                    status = excluded.status,
                    source = excluded.source,
                    updated_at = CURRENT_TIMESTAMP
                """,
                rows,
            )
            conn.commit()

        return jsonify({"ok": True, "upserted": len(rows)}), 200
    except Exception:
        app.logger.exception("news upsert error")
        return jsonify({"ok": False, "error": "Failed to upsert news events"}), 500


@app.get("/api/news/ping")
@app.get("/api/news/ping/")
def api_news_ping():
    return jsonify({"ok": True}), 200


@app.route("/api/news", methods=["GET"])
@app.route("/api/news/", methods=["GET"])
def api_news_list():
    try:
        from_raw = (request.args.get("from") or "").strip()
        to_raw = (request.args.get("to") or "").strip()
        from_date = _parse_news_ymd(from_raw) if from_raw else None
        to_date = _parse_news_ymd(to_raw) if to_raw else None
        if from_raw and from_date is None:
            return jsonify({"ok": False, "error": "Invalid 'from' date. Use YYYY-MM-DD"}), 400
        if to_raw and to_date is None:
            return jsonify({"ok": False, "error": "Invalid 'to' date. Use YYYY-MM-DD"}), 400
        if from_date and to_date and from_date > to_date:
            from_date, to_date = to_date, from_date

        currency_arg = (request.args.get("currency") or "").strip()
        currencies = []
        if currency_arg:
            seen = set()
            for part in currency_arg.split(","):
                token = str(part).strip().upper()
                if not token:
                    continue
                if token in seen:
                    continue
                seen.add(token)
                currencies.append(token)

        min_importance = None
        min_importance_raw = request.args.get("min_importance")
        if has_value(min_importance_raw):
            try:
                min_importance = _clamp_news_importance(int(min_importance_raw))
            except Exception:
                return jsonify({"ok": False, "error": "Invalid 'min_importance'. Use 0, 1, or 2"}), 400

        status = (request.args.get("status") or "all").strip().lower()
        if status not in NEWS_ALLOWED_STATUS_WITH_ALL:
            return jsonify({"ok": False, "error": "Invalid 'status'. Use upcoming, released, or all"}), 400

        try:
            limit = int(request.args.get("limit", 200))
        except Exception:
            return jsonify({"ok": False, "error": "Invalid 'limit'"}), 400
        try:
            offset = int(request.args.get("offset", 0))
        except Exception:
            return jsonify({"ok": False, "error": "Invalid 'offset'"}), 400
        limit = max(1, min(limit, 1000))
        offset = max(0, offset)

        where_parts = []
        where_args = []
        if from_date:
            where_parts.append("time_utc >= ?")
            where_args.append(f"{from_date.isoformat()} 00:00:00")
        if to_date:
            where_parts.append("time_utc <= ?")
            where_args.append(f"{to_date.isoformat()} 23:59:59")
        if currencies:
            placeholders = ",".join(["?"] * len(currencies))
            where_parts.append(f"currency IN ({placeholders})")
            where_args.extend(currencies)
        if min_importance is not None:
            where_parts.append("importance >= ?")
            where_args.append(min_importance)
        if status != "all":
            where_parts.append("status = ?")
            where_args.append(status)

        where_sql = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            total = cursor.execute(
                f"SELECT COUNT(*) AS cnt FROM economic_events {where_sql}",
                where_args,
            ).fetchone()["cnt"]

            rows = cursor.execute(
                f"""
                SELECT
                    id,
                    event_uid,
                    time_utc,
                    currency,
                    title,
                    importance,
                    actual,
                    forecast,
                    previous,
                    status,
                    source,
                    created_at,
                    updated_at
                FROM economic_events
                {where_sql}
                ORDER BY time_utc DESC
                LIMIT ? OFFSET ?
                """,
                where_args + [limit, offset],
            ).fetchall()

        items = [dict(row) for row in rows]
        return jsonify({"ok": True, "total": int(total), "items": items}), 200
    except Exception:
        app.logger.exception("news list error")
        return jsonify({"ok": False, "error": "Failed to fetch news events"}), 500


@app.route("/api/news/health", methods=["GET"])
@app.route("/api/news/health/", methods=["GET"])
def api_news_health():
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            row = cursor.execute(
                """
                SELECT
                    MAX(updated_at) AS last_updated_at,
                    SUM(CASE WHEN updated_at >= datetime('now', '-24 hours') THEN 1 ELSE 0 END) AS count_24h
                FROM economic_events
                """
            ).fetchone()

        last_updated_at = row["last_updated_at"] if row else None
        count_24h = int(row["count_24h"] or 0) if row else 0
        return jsonify({"ok": True, "last_updated_at": last_updated_at, "count_24h": count_24h}), 200
    except Exception:
        app.logger.exception("news health error")
        return jsonify({"ok": False, "error": "Failed to read news health"}), 500


def _normalize_note_title(value, fallback=NOTES_DEFAULT_TITLE):
    text = fallback if value is None else str(value).strip()
    if not text:
        text = fallback
    if len(text) > NOTES_TITLE_MAX_LEN:
        raise ValueError(f"title must be at most {NOTES_TITLE_MAX_LEN} characters")
    return text


def _normalize_note_body(value):
    text = "" if value is None else str(value)
    if len(text) > NOTES_BODY_MAX_LEN:
        raise ValueError(f"body must be at most {NOTES_BODY_MAX_LEN} characters")
    return text


def _row_to_note(row):
    if row is None:
        return None
    return {
        "id": row["id"],
        "title": row["title"],
        "body": row["body"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


@app.route("/api/notes", methods=["GET"])
@app.route("/api/notes/", methods=["GET"])
def api_notes_list():
    try:
        try:
            limit = int(request.args.get("limit", 50))
        except Exception:
            return jsonify({"ok": False, "error": "Invalid 'limit'"}), 400
        try:
            offset = int(request.args.get("offset", 0))
        except Exception:
            return jsonify({"ok": False, "error": "Invalid 'offset'"}), 400
        limit = max(1, min(limit, 200))
        offset = max(0, offset)

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            total = cursor.execute("SELECT COUNT(*) AS cnt FROM user_notes").fetchone()["cnt"]
            rows = cursor.execute(
                """
                SELECT id, title, body, created_at, updated_at
                FROM user_notes
                ORDER BY updated_at DESC, id DESC
                LIMIT ? OFFSET ?
                """,
                (limit, offset),
            ).fetchall()

        items = [_row_to_note(row) for row in rows]
        return jsonify({"ok": True, "total": int(total), "items": items}), 200
    except Exception:
        app.logger.exception("notes list error")
        return jsonify({"ok": False, "error": "Failed to load notes"}), 500


@app.route("/api/notes/<int:note_id>", methods=["GET"])
@app.route("/api/notes/<int:note_id>/", methods=["GET"])
def api_notes_get(note_id):
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            row = cursor.execute(
                """
                SELECT id, title, body, created_at, updated_at
                FROM user_notes
                WHERE id = ?
                """,
                (note_id,),
            ).fetchone()
        if row is None:
            return jsonify({"ok": False, "error": "Note not found"}), 404
        return jsonify({"ok": True, "item": _row_to_note(row)}), 200
    except Exception:
        app.logger.exception("note get error")
        return jsonify({"ok": False, "error": "Failed to load note"}), 500


@app.route("/api/notes", methods=["POST"])
@app.route("/api/notes/", methods=["POST"])
def api_notes_create():
    try:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"ok": False, "error": "Invalid JSON payload"}), 400
        try:
            title = _normalize_note_title(data.get("title"), NOTES_DEFAULT_TITLE)
            body = _normalize_note_body(data.get("body"))
        except ValueError as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO user_notes (title, body, updated_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                """,
                (title, body),
            )
            note_id = cursor.lastrowid
            row = cursor.execute(
                """
                SELECT id, title, body, created_at, updated_at
                FROM user_notes
                WHERE id = ?
                """,
                (note_id,),
            ).fetchone()
            conn.commit()

        return jsonify({"ok": True, "item": _row_to_note(row)}), 201
    except Exception:
        app.logger.exception("note create error")
        return jsonify({"ok": False, "error": "Failed to create note"}), 500


@app.route("/api/notes/<int:note_id>", methods=["PUT"])
@app.route("/api/notes/<int:note_id>/", methods=["PUT"])
def api_notes_update(note_id):
    try:
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"ok": False, "error": "Invalid JSON payload"}), 400
        if "title" not in data and "body" not in data:
            return jsonify({"ok": False, "error": "Nothing to update"}), 400

        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            current_row = cursor.execute(
                """
                SELECT id, title, body, created_at, updated_at
                FROM user_notes
                WHERE id = ?
                """,
                (note_id,),
            ).fetchone()
            if current_row is None:
                return jsonify({"ok": False, "error": "Note not found"}), 404

            try:
                next_title = (
                    _normalize_note_title(data.get("title"), NOTES_DEFAULT_TITLE)
                    if "title" in data
                    else current_row["title"]
                )
                next_body = (
                    _normalize_note_body(data.get("body"))
                    if "body" in data
                    else current_row["body"]
                )
            except ValueError as exc:
                return jsonify({"ok": False, "error": str(exc)}), 400

            cursor.execute(
                """
                UPDATE user_notes
                SET title = ?, body = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (next_title, next_body, note_id),
            )
            row = cursor.execute(
                """
                SELECT id, title, body, created_at, updated_at
                FROM user_notes
                WHERE id = ?
                """,
                (note_id,),
            ).fetchone()
            conn.commit()

        return jsonify({"ok": True, "item": _row_to_note(row)}), 200
    except Exception:
        app.logger.exception("note update error")
        return jsonify({"ok": False, "error": "Failed to update note"}), 500


@app.route("/api/notes/<int:note_id>", methods=["DELETE"])
@app.route("/api/notes/<int:note_id>/", methods=["DELETE"])
def api_notes_delete(note_id):
    try:
        with sqlite3.connect(DB_PATH, timeout=10) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM user_notes WHERE id = ?", (note_id,))
            deleted = cursor.rowcount or 0
            conn.commit()
        if deleted <= 0:
            return jsonify({"ok": False, "error": "Note not found"}), 404
        return jsonify({"ok": True}), 200
    except Exception:
        app.logger.exception("note delete error")
        return jsonify({"ok": False, "error": "Failed to delete note"}), 500


def _market_symbol_decimals(symbol):
    sym = str(symbol or "").upper()
    if "JPY" in sym:
        return 3
    if sym.startswith("XAU"):
        return 2
    return 5


def _market_symbol_base(symbol):
    sym = str(symbol or "").upper()
    seed = sum(ord(ch) for ch in sym) or 1
    if "JPY" in sym:
        return 120.0 + (seed % 450) / 10.0
    if sym.startswith("XAU"):
        return 1900.0 + (seed % 350)
    return 1.00000 + (seed % 8000) / 10000.0


def _build_mock_m1_history(symbol, count):
    symbol = str(symbol or "EURUSD").upper()
    count = max(10, min(int(count), 120000))
    step = 60
    now_sec = int(datetime.now(timezone.utc).timestamp())
    aligned = (now_sec // step) * step
    decimals = _market_symbol_decimals(symbol)
    base = _market_symbol_base(symbol)

    # Volatility scale by instrument profile.
    if "JPY" in symbol:
        amp = 0.08
    elif symbol.startswith("XAU"):
        amp = 6.5
    else:
        amp = 0.0022

    seed = (sum(ord(ch) for ch in symbol) % 97) + 3
    candles = []
    prev_close = base

    for i in range(count):
        t = aligned - (count - 1 - i) * step
        open_price = prev_close

        # Keep body and wick proportions realistic for chart readability.
        body_move = (
            math.sin((i + seed) / 6.0) * amp * 0.10
            + math.sin((i + seed) / 17.0) * amp * 0.04
            + math.sin((i + seed) / 43.0) * amp * 0.02
        )
        close_price = open_price + body_move

        wick_pad = abs(body_move) * 0.45 + amp * (0.012 + abs(math.sin((i + seed) / 9.0)) * 0.018)
        high_price = max(open_price, close_price) + wick_pad
        low_price = min(open_price, close_price) - wick_pad
        volume = int(120 + abs(math.sin((i + seed) / 4.0)) * 1600)

        candles.append(
            {
                "time": int(t),
                "open": round(float(open_price), decimals),
                "high": round(float(high_price), decimals),
                "low": round(float(low_price), decimals),
                "close": round(float(close_price), decimals),
                "volume": int(volume),
            }
        )
        prev_close = close_price

    return candles


def _aggregate_mock_history(candles_m1, tf, symbol=None):
    tf_key = str(tf or "M1").upper()
    tf_step = MARKET_TF_SECONDS.get(tf_key, 60)
    if tf_step <= 60:
        return list(candles_m1 or [])

    aggregated = []
    current = None

    for row in candles_m1 or []:
        try:
            t = int(row.get("time"))
            o = float(row.get("open"))
            h = float(row.get("high"))
            l = float(row.get("low"))
            c = float(row.get("close"))
            v = int(row.get("volume") or 0)
        except Exception:
            continue

        bucket = (t // tf_step) * tf_step
        if current is None or current["time"] != bucket:
            if current is not None:
                aggregated.append(current)
            current = {
                "time": int(bucket),
                "open": o,
                "high": h,
                "low": l,
                "close": c,
                "volume": v,
            }
        else:
            current["high"] = max(current["high"], h)
            current["low"] = min(current["low"], l)
            current["close"] = c
            current["volume"] += v

    if current is not None:
        aggregated.append(current)

    decimals = _market_symbol_decimals(symbol=(symbol or "EURUSD"))
    for row in aggregated:
        row["open"] = round(float(row["open"]), decimals)
        row["high"] = round(float(row["high"]), decimals)
        row["low"] = round(float(row["low"]), decimals)
        row["close"] = round(float(row["close"]), decimals)

    return aggregated


def _build_mock_history(symbol, tf, limit):
    symbol = str(symbol or "EURUSD").upper()
    tf = str(tf or "M1").upper()
    limit = max(10, min(int(limit), 2000))
    tf_step = MARKET_TF_SECONDS.get(tf, 60)

    if tf_step <= 60:
        return _build_mock_m1_history(symbol, limit)

    ratio = max(1, tf_step // 60)
    # Build enough M1 bars to aggregate into requested higher timeframe bars.
    m1_needed = limit * ratio + ratio * 4
    m1_candles = _build_mock_m1_history(symbol, m1_needed)

    candles = _aggregate_mock_history(m1_candles, tf, symbol=symbol)
    if len(candles) > limit:
        candles = candles[-limit:]
    return candles


@app.route("/api/market/history", methods=["GET"])
@app.route("/api/v1/market/history", methods=["GET"])
def api_market_history():
    try:
        symbol, tf, limit = _parse_market_history_args()
        candles = _fetch_market_history_from_db(symbol, tf, limit)
        _log_market_series_debug("history", symbol, tf, limit, candles)
        return jsonify(candles), 200
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/market/live", methods=["GET"])
@app.route("/api/v1/market/live", methods=["GET"])
def api_market_live():
    try:
        symbol, tf, limit = _parse_market_history_args()
        if limit > 1000:
            limit = 1000
        candles = _fetch_market_history_from_db(symbol, tf, limit)
        _log_market_series_debug("live", symbol, tf, limit, candles)
        return jsonify(candles), 200
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/marketwatch/indicators", methods=["GET"])
@app.route("/api/marketwatch/indicators/", methods=["GET"])
@app.route("/api/v1/marketwatch/indicators", methods=["GET"])
@app.route("/api/v1/marketwatch/indicators/", methods=["GET"])
def api_marketwatch_indicators():
    try:
        symbols = _marketwatch_parse_symbols_query(request.args.get("symbols"))
        items = _marketwatch_get_items_with_cache(symbols)
        return jsonify({"ok": True, "items": items}), 200
    except Exception:
        app.logger.exception("marketwatch indicators endpoint error")
        return jsonify({"ok": False, "items": [], "error": "Failed to compute indicators"}), 500


###############################################################################
# Analytics / Stats API endpoints
###############################################################################

def parse_date_range(args):
    """
    Parse ?from=YYYY-MM-DD&to=YYYY-MM-DD (inclusive).
    Returns (start_dt, end_dt) as naive datetimes. Analytics treats stored timestamps as UTC-like.
    """
    from_raw = (args.get("from") or "").strip()
    to_raw = (args.get("to") or "").strip()

    def _parse_ymd(value):
        if not value:
            return None
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except Exception:
            return None

    from_d = _parse_ymd(from_raw)
    to_d = _parse_ymd(to_raw)
    if from_d and to_d and from_d > to_d:
        from_d, to_d = to_d, from_d

    start_dt = datetime(from_d.year, from_d.month, from_d.day, 0, 0, 0) if from_d else None
    end_dt = (datetime(to_d.year, to_d.month, to_d.day, 0, 0, 0) + timedelta(days=1) - timedelta(microseconds=1)) if to_d else None
    return start_dt, end_dt


def _trade_dt_for_analytics(t):
    # Prefer close_time for "realized" metrics, fallback to created_at/open_time if missing.
    return _parse_dt(t.get("close_time")) or _parse_dt(t.get("created_at")) or _parse_dt(t.get("open_time"))


def _fetch_closed_trades_for_analytics(start_dt=None, end_dt=None):
    """Return list of dicts with profit, close_time, open_time for closed trades (optionally date-filtered)."""
    with sqlite3.connect(DB_PATH, timeout=10) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute(
            "SELECT profit, close_time, open_time, created_at, status "
            "FROM trades WHERE status = 'CLOSED' AND profit IS NOT NULL "
            "ORDER BY COALESCE(close_time, created_at, open_time) ASC"
        )
        rows = [dict(row) for row in cursor.fetchall()]

    if not start_dt and not end_dt:
        for t in rows:
            t["_analytics_dt"] = _trade_dt_for_analytics(t)
        return rows

    out = []
    for t in rows:
        dt = _trade_dt_for_analytics(t)
        t["_analytics_dt"] = dt
        if not dt:
            continue
        if start_dt and dt < start_dt:
            continue
        if end_dt and dt > end_dt:
            continue
        out.append(t)
    return out


def _parse_dt(value):
    if not value:
        return None
    for dfmt in (DT_FORMAT, "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(value).strip(), dfmt)
        except Exception:
            continue
    return None


@app.route("/api/stats/equity_curve", methods=["GET"])
def api_equity_curve():
    try:
        start_dt, end_dt = parse_date_range(request.args)
        trades = _fetch_closed_trades_for_analytics(start_dt, end_dt)
        series = []
        cumulative = 0.0
        for t in trades:
            profit = float(t.get("profit", 0) or 0)
            cumulative += profit
            dt = t.get("_analytics_dt") or _trade_dt_for_analytics(t)
            label = dt.strftime("%b %d, %H:%M") if dt else "?"
            ts = int(dt.timestamp() * 1000) if dt else None
            series.append({
                "x": ts,
                "label": label,
                "profit": round(profit, 2),
                "equity": round(cumulative, 2),
            })
        return jsonify({"status": "success", "series": series}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/stats/drawdown", methods=["GET"])
def api_drawdown():
    try:
        start_dt, end_dt = parse_date_range(request.args)
        trades = _fetch_closed_trades_for_analytics(start_dt, end_dt)
        series = []
        cumulative = 0.0
        peak = 0.0
        max_dd_abs = 0.0
        max_dd_pct = 0.0
        max_dd_idx = 0
        for i, t in enumerate(trades):
            profit = float(t.get("profit", 0) or 0)
            cumulative += profit
            if cumulative > peak:
                peak = cumulative
            dd_abs = peak - cumulative
            dd_pct = (dd_abs / peak * 100) if peak > 0 else 0.0
            dt = t.get("_analytics_dt") or _trade_dt_for_analytics(t)
            label = dt.strftime("%b %d, %H:%M") if dt else "?"
            ts = int(dt.timestamp() * 1000) if dt else None
            if dd_abs > max_dd_abs:
                max_dd_abs = dd_abs
                max_dd_pct = dd_pct
                max_dd_idx = i
            series.append({
                "x": ts,
                "label": label,
                "equity": round(cumulative, 2),
                "drawdown": round(dd_abs, 2),
                "drawdown_pct": round(dd_pct, 2),
            })
        return jsonify({
            "status": "success",
            "series": series,
            "max_dd_abs": round(max_dd_abs, 2),
            "max_dd_pct": round(max_dd_pct, 2),
            "max_dd_idx": max_dd_idx,
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/stats/winrate_by_hour", methods=["GET"])
def api_winrate_by_hour():
    try:
        start_dt, end_dt = parse_date_range(request.args)
        trades = _fetch_closed_trades_for_analytics(start_dt, end_dt)
        buckets = [{"wins": 0, "losses": 0, "total": 0} for _ in range(24)]
        for t in trades:
            dt = t.get("_analytics_dt") or _parse_dt(t.get("close_time")) or _parse_dt(t.get("open_time"))
            if not dt:
                continue
            hour = dt.hour
            profit = float(t.get("profit", 0) or 0)
            buckets[hour]["total"] += 1
            if profit > 0:
                buckets[hour]["wins"] += 1
            else:
                buckets[hour]["losses"] += 1
        result = []
        for h in range(24):
            b = buckets[h]
            winrate = round(b["wins"] / b["total"] * 100, 1) if b["total"] > 0 else 0
            result.append({
                "hour": h,
                "label": f"{h:02d}-{(h+1) % 24:02d}",
                "wins": b["wins"],
                "losses": b["losses"],
                "total": b["total"],
                "winrate": winrate,
            })
        return jsonify({"status": "success", "hours": result}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/stats/winloss_distribution", methods=["GET"])
def api_winloss_distribution():
    try:
        start_dt, end_dt = parse_date_range(request.args)
        trades = _fetch_closed_trades_for_analytics(start_dt, end_dt)
        profits = [float(t.get("profit", 0) or 0) for t in trades]
        if not profits:
            return jsonify({"status": "success", "bins": [], "total": 0}), 200
        min_p = min(profits)
        max_p = max(profits)
        if min_p == max_p:
            max_p = min_p + 1
        num_bins = 10
        step = (max_p - min_p) / num_bins
        bins = []
        for b in range(num_bins):
            lo = min_p + b * step
            hi = lo + step
            wins = 0
            losses = 0
            for p in profits:
                in_bin = (lo <= p < hi) if b < num_bins - 1 else (lo <= p <= hi)
                if in_bin:
                    if p >= 0:
                        wins += 1
                    else:
                        losses += 1
            bins.append({
                "range": f"{lo:.1f} .. {hi:.1f}",
                "lo": round(lo, 2),
                "hi": round(hi, 2),
                "wins": wins,
                "losses": losses,
                "total": wins + losses,
            })
        return jsonify({"status": "success", "bins": bins, "total": len(profits)}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/stats/daily_pl", methods=["GET"])
def api_daily_pl():
    """
    Daily realized P/L grouped by close_time day (analytics timestamps treated as UTC-like).
    Supports ?from=YYYY-MM-DD&to=YYYY-MM-DD (inclusive).
    """
    try:
        start_dt, end_dt = parse_date_range(request.args)
        trades = _fetch_closed_trades_for_analytics(start_dt, end_dt)
        by_day = {}
        for t in trades:
            dt = t.get("_analytics_dt") or _trade_dt_for_analytics(t)
            if not dt:
                continue
            day_key = dt.strftime("%Y-%m-%d")
            profit = float(t.get("profit", 0) or 0)
            if day_key not in by_day:
                by_day[day_key] = {"profit": 0.0, "trades": 0}
            by_day[day_key]["profit"] += profit
            by_day[day_key]["trades"] += 1

        days = []
        for day_key in sorted(by_day.keys()):
            dt_day = datetime.strptime(day_key, "%Y-%m-%d")
            days.append({
                "day": day_key,
                "label": dt_day.strftime("%b %d"),
                "profit": round(by_day[day_key]["profit"], 2),
                "trades": int(by_day[day_key]["trades"]),
            })
        return jsonify({"status": "success", "days": days}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    has_candles_route = False
    for rule in app.url_map.iter_rules():
        if rule.rule == "/api/market/candles/batch" and "POST" in rule.methods:
            has_candles_route = True
            break
    print(f"candles_batch_route_registered={has_candles_route} host={host} port={port}")
    print("registered_routes=", app.url_map)
    app.run(host=host, port=port, debug=False, use_reloader=False)
