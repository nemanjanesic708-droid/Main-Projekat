﻿import json
import os
from urllib.request import urlopen

BASE_URL = os.environ.get("BASE_URL", "http://127.0.0.1:5000").rstrip("/")


def fetch(path):
    url = BASE_URL + path
    with urlopen(url, timeout=5) as resp:
        payload = resp.read().decode("utf-8")
        return resp.status, json.loads(payload)


def assert_keys(obj, keys):
    for key in keys:
        if key not in obj:
            raise AssertionError("Missing key: %s" % key)


def main():
    status, summary = fetch("/risk_ftmo/summary")
    if status != 200:
        raise AssertionError("/risk_ftmo/summary status %s" % status)

    summary_keys = [
        "account_balance",
        "equity",
        "pnl_total",
        "pnl_today",
        "daily_loss_limit",
        "max_loss_limit",
        "daily_loss_used",
        "max_loss_used",
        "daily_loss_remaining",
        "max_loss_remaining",
        "daily_loss_pct_used",
        "max_loss_pct_used",
        "trading_days_count",
        "profit_target",
        "profit_target_remaining",
        "profit_target_pct",
        "status",
    ]
    assert_keys(summary, summary_keys)

    status, days = fetch("/risk_ftmo/days")
    if status != 200:
        raise AssertionError("/risk_ftmo/days status %s" % status)
    if "days" not in days or not isinstance(days["days"], list):
        raise AssertionError("/risk_ftmo/days invalid payload")

    print("OK")


if __name__ == "__main__":
    main()
