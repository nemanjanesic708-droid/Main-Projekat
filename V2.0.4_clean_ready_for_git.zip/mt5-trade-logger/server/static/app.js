console.log("[APP] loaded", new Date().toISOString());
window.addEventListener("error", function (e) {
  console.error("UI ERROR", e.error || e.message);
});
window.addEventListener("unhandledrejection", function (e) {
  console.error("PROMISE ERROR", e.reason);
});

(function () {
  console.log("APP JS LOADED");
  setTimeout(() => {
    const el = document.getElementById("boot-loader");
    if (el) el.remove();
  }, 0);
  var state = {
    trades: [],
    stats: {},
    lastUpdated: null,
    activeTab: "dashboard",
    needsTradesRender: false,
    isRefreshing: false,
    systemStatus: {},
    orchPanel: {
      health: null,
      config: null,
      decisions: [],
      status: "offline",
      online: false,
      loading: false,
      saving: false,
      error: "",
      saveMessage: "",
      expandedDecisionKey: null
    },
    tools: {
      notes: {
        items: [],
        selectedId: null,
        loading: false,
        saving: false,
        dirty: false,
        statusText: "--"
      },
      calc: {
        history: [],
        resultText: "--"
      }
    },
    riskSummary: null,
    riskDays: null,
    systemStatusLogged: false,
    systemStatusLoading: false,
    systemLogHighlightKey: null,
    systemLogHighlightUntil: 0,
    systemLogHighlightTimer: null,
    systemLogLastTs: null,
    systemLogLastKey: null,
    systemLogDisplayLines: [],
    copyLogsTimer: null,
    systemLogsCleared: false,
    systemLogsClearedAt: null,
    devLogCounter: 0,
    analyticsRange: null,
    tradesSortColumn: "open_time",
    tradesSortDirection: "desc",
    tradesDateField: "open_time",
    tradesDateFrom: "",
    tradesDateTo: "",
    tradesViewMode: "flat",
    newsItems: [],
    newsTotal: 0,
    newsOffset: 0,
    newsLimit: 200,
    newsLoading: false,
    newsLoadedOnce: false,
    newsExpandedUid: null,
    newsLastUpdatedAt: null,
    newsFilters: {
      status: "all",
      from: "",
      to: "",
      currency: "USD,EUR,GBP,JPY",
      minImportance: 0
    }
  };
  var MAX_SYSTEM_LOGS = 300;
  var SYSTEM_LOG_HIGHLIGHT_MS = 2500;
  var MW_HISTORY_DEBUG = false; // Enable temporary console diagnostics for Market Watch.
  try {
    MW_HISTORY_DEBUG = String(localStorage.getItem("mt5tl.debugMarketWatch") || "") === "1";
  } catch (e) {}
  var MW_DEFAULT_VISIBLE_BARS = 120;
  var MW_HISTORY_FETCH_LIMIT = 500;
  var MW_LIVE_FETCH_LIMIT = 220;
  var MW_LIVE_POLL_MS = 2000;
  var MW_INDICATORS_POLL_MS = 30000;
  var MW_FAVORITES_KEY = "mt5_favorites";
  var MW_DRAW_STORAGE_PREFIX = "mw_drawings:";
  var MW_DRAW_STORAGE_PREFIX_LEGACY = "drawings:";
  var MW_DRAW_REMOTE_ENDPOINT = "/api/market/drawings";
  var MW_DRAW_SCHEMA_VERSION = 2;
  var MW_DRAW_SAVE_DEBOUNCE_MS = 300;
  var MW_DRAW_MAX_UNDO = 100;
  var MW_DRAW_PROPS_COMMIT_IDLE_MS = 250;
  var MW_DRAW_PROPS_LIVE_DEBOUNCE_MS = 60;
  var MW_DRAW_HANDLE_RADIUS = 4.5;
  var MW_DRAW_RECT_HANDLE_RADIUS = 5.5;
  var MW_DRAW_RECT_HIT_TOLERANCE_PX = 11;
  var MW_DRAW_MIN_RECT_WIDTH_LOGICAL = 0.2;
  var MW_DRAW_MIN_POSITION_WIDTH_LOGICAL = 0.8;
  var MW_DRAW_DEFAULT_POSITION_WIDTH_BARS = 20;
  var MW_DRAW_MIN_RECT_HEIGHT_RATIO = 0.0006;
  var MW_DRAW_FUTURE_BARS = 120;
  var MW_DRAW_MIN_RIGHT_OFFSET = 10;
  var MW_DRAW_MAX_RIGHT_OFFSET = 80;
  var MW_DRAW_DEFAULT_RIGHT_OFFSET = 20;
  var MW_DRAW_TOOLBAR_POS_PREFIX = "toolbarPos::";
  var MW_DRAW_TOOLBAR_MIN_VISIBLE = 16;
  var MW_DRAW_SNAP_RADIUS_DEFAULT = 8;
  var MW_DRAW_SNAP_RADIUS_MIN = 2;
  var MW_DRAW_SNAP_RADIUS_MAX = 24;
  var MW_NEXT_CANDLE_TICK_MS = 500;
  var MW_LIVE_SUPPRESS_AUTOFOLLOW_MS_DEFAULT = 1500;
  var MW_LIVE_FOLLOW_EDGE_THRESHOLD_BARS = 2;
  // System tab should not spam status polling. Default: 30s, optionally configurable via localStorage.
  // Set localStorage key `mt5tl.systemPollMs` to override (min 20s).
  var SYSTEM_STATUS_POLL_MS_DEFAULT = 30000;
  var SYSTEM_STATUS_POLL_MS_MIN = 20000;
  // UI-level base for orchestrator control endpoints.
  // Examples:
  // - "/api/orch" (same-origin proxy via Flask, default)
  // - "http://127.0.0.1:8081" (direct orchestrator)
  // - "http://127.0.0.1:8081/api/orch" (direct orchestrator with prefix)
  var ORCH_API_BASE = "/api/orch";
  var ORCH_API_KEY_STORAGE_KEY = "Nmj_Orch_Secret_2026";
  var ORCH_API_KEY_STORAGE_KEY_LEGACY = "mt5tl.orchApiKey";
  var NOTES_AUTOSAVE_MS = 800;
  var CALC_HISTORY_LIMIT = 10;
  try {
    var orchApiOverride = localStorage.getItem("mt5tl.orchApiBase");
    if (orchApiOverride && String(orchApiOverride).trim()) {
      ORCH_API_BASE = String(orchApiOverride).trim();
    }
  } catch (e) {}

  var els = {};
  var searchTimer = null;
  var systemStatusTimer = null;
  var notesAutosaveTimer = null;
  var notesEditorSyncing = false;
  var notesDetailToken = 0;
  var toastSeq = 0;
  var tradesById = new Map(); // trade.id -> trade
  var marketWatch = {
    chart: null,
    candleSeries: null,
    volumeSeries: null,
    resizeObserver: null,
    initialized: false,
    loading: false,
    requestToken: 0,
    symbol: "EURUSD",
    tf: "M1",
    mode: "HISTORY",
    lastCandleCount: 0,
    candles: [],
    liveTimer: null,
    lastUpdateTs: 0,
    lastCandleTimeMs: NaN,
    isAutoFollow: true,
    userInteractedAt: 0,
    suppressAutoFollowMs: MW_LIVE_SUPPRESS_AUTOFOLLOW_MS_DEFAULT,
    isUserInteracting: false,
    interactionStartX: 0,
    interactionStartY: 0,
    userInteractionBound: false,
    programmaticFollowUntil: 0,
    nextCandleTimer: null,
    nextCandleText: "",
    favorites: new Set(),
    watchItems: [],
    watchListContainer: null,
    indicatorsBySymbol: {},
    indicatorsLoadedOnce: false,
    indicatorsError: false,
    indicatorsInFlight: false,
    indicatorsTimer: null,
    draw: {
      initialized: false,
      activeTool: "select",
      crosshairEnabled: false,
      snapMode: "off",
      snapRadiusPx: MW_DRAW_SNAP_RADIUS_DEFAULT,
      key: "",
      scope: null,
      items: [],
      drawingsById: new Map(),
      selectedId: null,
      selectedObjectId: null,
      activeObjectId: null,
      selectedIds: [],
      hoverId: null,
      pendingPoint: null,
      interaction: null,
      undoStack: [],
      redoStack: [],
      saveTimer: null,
      remoteLoadToken: 0,
      renderRaf: 0,
      moveRaf: 0,
      queuedMove: null,
      pointer: null,
      propsEdit: {
        baseSnapshot: null,
        targetId: null,
        timer: null
      },
      listenersBound: false,
      hotkeysBound: false,
      outsideClickBound: false,
      ui: {
        moreOpen: false,
        toolbarPosKey: "",
        toolbarX: null,
        toolbarY: null,
        draggingToolbar: false,
        dragStartPointerX: 0,
        dragStartPointerY: 0,
        dragStartToolbarX: 0,
        dragStartToolbarY: 0,
        propsPanelBound: false,
        toolbarDragBound: false,
        hostWheelBound: false,
        hostPointerBound: false,
        unloadBound: false
      }
    }
  };

  // Using: ApexCharts (https://apexcharts.com/).
  // Instances are created via `new ApexCharts(...)` in `server/static/app.js` (analytics renderers + chart modal).

  function getSystemStatusPollIntervalMs() {
    var ms = SYSTEM_STATUS_POLL_MS_DEFAULT;
    try {
      var raw = localStorage.getItem("mt5tl.systemPollMs");
      if (raw !== null && raw !== undefined && String(raw).trim() !== "") {
        var parsed = parseInt(String(raw), 10);
        if (!isNaN(parsed) && isFinite(parsed)) ms = parsed;
      }
    } catch (e) {}
    if (ms < SYSTEM_STATUS_POLL_MS_MIN) ms = SYSTEM_STATUS_POLL_MS_MIN;
    return ms;
  }

  function cacheEls() {
    els.tabs = document.querySelectorAll(".tab");
    els.panels = document.querySelectorAll(".tab-panel");
    els.tabsWrap = document.querySelector(".tabs");
    els.tabUnderline = document.querySelector(".tab-underline");
    els.lastUpdated = document.getElementById("lastUpdated");
    els.headerSymbol = document.getElementById("headerSymbol");
    els.jsStatus = document.getElementById("jsStatus");
    els.tradesCount = document.getElementById("tradesCount");

    els.kpiTotalProfit = document.getElementById("kpiTotalProfit");
    els.kpiWinRate = document.getElementById("kpiWinRate");
    els.kpiProfitFactor = document.getElementById("kpiProfitFactor");

    els.statTotalTrades = document.getElementById("statTotalTrades");
    els.statOpenTrades = document.getElementById("statOpenTrades");
    els.statClosedTrades = document.getElementById("statClosedTrades");
    els.statAvgWin = document.getElementById("statAvgWin");
    els.statAvgLoss = document.getElementById("statAvgLoss");
    els.statBestTrade = document.getElementById("statBestTrade");
    els.statWorstTrade = document.getElementById("statWorstTrade");

    els.dashboardTradesBody = document.getElementById("dashboardTradesBody");
    els.dashboardTradesEmpty = document.getElementById("dashboardTradesEmpty");
    els.dashboardTradesScroll = document.getElementById("dashboardTradesScroll");
    els.equitySparkline = document.getElementById("equitySparkline");
    els.equitySparklineEmpty = document.getElementById("equitySparklineEmpty");

    els.statusFilter = document.getElementById("statusFilter");
    els.searchInput = document.getElementById("searchInput");
    els.viewMode = document.getElementById("viewMode");
    els.dateField = document.getElementById("dateField");
    els.dateFrom = document.getElementById("dateFrom");
    els.dateTo = document.getElementById("dateTo");
    els.dateClear = document.getElementById("dateClear");
    els.closeReasonFilter = document.getElementById("closeReasonFilter");
    els.closeReasonFilterWrap = document.getElementById("closeReasonFilterWrap");
    els.setupFilter = document.getElementById("setupFilter");
    els.setupFilterWrap = document.getElementById("setupFilterWrap");
    els.refreshBtn = document.getElementById("refreshBtn");
    els.exportCsvBtn = document.getElementById("exportCsvBtn");
    els.deleteAllBtn = document.getElementById("deleteAllBtn");
    els.tradesTableBody = document.getElementById("tradesTableBody");
    els.tradesTableEmpty = document.getElementById("tradesTableEmpty");
    els.tradesTableScroll = document.getElementById("tradesTableScroll");
    els.newsStatusButtons = document.querySelectorAll("[data-news-status]");
    els.newsDateFrom = document.getElementById("newsDateFrom");
    els.newsDateTo = document.getElementById("newsDateTo");
    els.newsCurrencyInput = document.getElementById("newsCurrencyInput");
    els.newsMinImportance = document.getElementById("newsMinImportance");
    els.newsRefreshBtn = document.getElementById("newsRefreshBtn");
    els.newsLastUpdated = document.getElementById("newsLastUpdated");
    els.newsTableBody = document.getElementById("newsTableBody");
    els.newsTableEmpty = document.getElementById("newsTableEmpty");
    els.newsTableScroll = document.getElementById("newsTableScroll");
    els.newsLoadMoreBtn = document.getElementById("newsLoadMoreBtn");
    els.newsCountInfo = document.getElementById("newsCountInfo");

    els.analyticsEquityEmpty = document.getElementById("analyticsEquityEmpty");
    els.analyticsDrawdownEmpty = document.getElementById("analyticsDrawdownEmpty");
    els.ddMaxBadge = document.getElementById("ddMaxBadge");
    els.analyticsHistogramEmpty = document.getElementById("analyticsHistogramEmpty");
    els.analyticsWinHourEmpty = document.getElementById("analyticsWinHourEmpty");
    els.apexEquityChart = document.getElementById("apexEquityChart");
    els.apexDrawdownChart = document.getElementById("apexDrawdownChart");
    els.apexWinHourChart = document.getElementById("apexWinHourChart");
    els.apexDistChart = document.getElementById("apexDistChart");
    els.analyticsHistogramNote = document.getElementById("analyticsHistogramNote");
    els.analyticsDailyPlEmpty = document.getElementById("analyticsDailyPlEmpty");
    els.apexDailyPlChart = document.getElementById("apexDailyPlChart");

    els.chartModal = document.getElementById("chartModal");
    els.chartModalBackdrop = els.chartModal ? els.chartModal.querySelector("[data-modal-backdrop]") : null;
    els.chartModalPanel = els.chartModal ? els.chartModal.querySelector(".chart-modal-panel") : null;
    els.chartModalTitle = document.getElementById("chartModalTitle");
    els.chartModalClose = document.getElementById("chartModalClose");
    els.chartModalFrom = document.getElementById("chartModalFrom");
    els.chartModalTo = document.getElementById("chartModalTo");
    els.chartModalApply = document.getElementById("chartModalApply");
    els.chartModalReset = document.getElementById("chartModalReset");
    els.chartModalResetView = document.getElementById("chartModalResetView");
    els.chartModalApplyGlobal = document.getElementById("chartModalApplyGlobal");
    els.chartModalChart = document.getElementById("chartModalChart");
    els.chartModalEmpty = document.getElementById("chartModalEmpty");
    els.chartModalPresets = els.chartModal ? els.chartModal.querySelectorAll("[data-preset]") : [];

    els.tradeModal = document.getElementById("tradeModal");
    els.tradeModalBackdrop = els.tradeModal ? els.tradeModal.querySelector("[data-trade-modal-backdrop]") : null;
    els.tradeModalPanel = els.tradeModal ? els.tradeModal.querySelector(".trade-modal-panel") : null;
    els.tradeModalTitle = document.getElementById("tradeModalTitle");
    els.tradeModalClose = document.getElementById("tradeModalClose");
    els.tradeModalContent = document.getElementById("tradeModalContent");

    els.toastHost = document.getElementById("toastHost");
    els.toolsDropdown = document.getElementById("toolsDropdown");
    els.toolsDropdownBtn = document.getElementById("toolsDropdownBtn");
    els.toolsDropdownMenu = document.getElementById("toolsDropdownMenu");

    els.notesModal = document.getElementById("notesModal");
    els.notesModalBackdrop = els.notesModal ? els.notesModal.querySelector("[data-notes-modal-backdrop]") : null;
    els.notesModalPanel = els.notesModal ? els.notesModal.querySelector(".tools-modal-panel") : null;
    els.notesModalClose = document.getElementById("notesModalClose");
    els.notesNewBtn = document.getElementById("notesNewBtn");
    els.notesList = document.getElementById("notesList");
    els.notesTitleInput = document.getElementById("notesTitleInput");
    els.notesBodyInput = document.getElementById("notesBodyInput");
    els.notesSaveBtn = document.getElementById("notesSaveBtn");
    els.notesDeleteBtn = document.getElementById("notesDeleteBtn");
    els.notesStatusText = document.getElementById("notesStatusText");

    els.calcModal = document.getElementById("calcModal");
    els.calcModalBackdrop = els.calcModal ? els.calcModal.querySelector("[data-calc-modal-backdrop]") : null;
    els.calcModalPanel = els.calcModal ? els.calcModal.querySelector(".tools-modal-panel") : null;
    els.calcModalClose = document.getElementById("calcModalClose");
    els.calcExpressionInput = document.getElementById("calcExpressionInput");
    els.calcEvaluateBtn = document.getElementById("calcEvaluateBtn");
    els.calcClearBtn = document.getElementById("calcClearBtn");
    els.calcResultValue = document.getElementById("calcResultValue");
    els.calcHistory = document.getElementById("calcHistory");

    els.riskStatusBadge = document.getElementById("riskStatusBadge");
    els.riskStatusDetail = document.getElementById("riskStatusDetail");
    els.riskDailyRemaining = document.getElementById("riskDailyRemaining");
    els.riskDailyMeta = document.getElementById("riskDailyMeta");
    els.riskMaxRemaining = document.getElementById("riskMaxRemaining");
    els.riskMaxMeta = document.getElementById("riskMaxMeta");
    els.riskProfitRemaining = document.getElementById("riskProfitRemaining");
    els.riskProfitMeta = document.getElementById("riskProfitMeta");
    els.riskTradingDays = document.getElementById("riskTradingDays");
    els.riskTradingDaysMeta = document.getElementById("riskTradingDaysMeta");
    els.riskEmptyNote = document.getElementById("riskEmptyNote");

    els.sysOrchStatus = document.getElementById("sys-orch-status");
    els.sysHeartbeat = document.getElementById("sys-heartbeat");
    els.sysEaVersion = document.getElementById("sys-ea-version");
    els.sysEaName = document.getElementById("sys-ea-name");
    els.sysMt5Build = document.getElementById("sys-mt5-build");
    els.sysEaUpdated = document.getElementById("sys-ea-updated");
    els.sysActiveSymbols = document.getElementById("sys-active-symbols");
    els.sysLogs = document.getElementById("sys-logs");
    els.copyLogsBtn = document.getElementById("copyLogsBtn");
    els.orchRefreshBtn = document.getElementById("orchRefreshBtn");
    els.orchPanelStatusPill = document.getElementById("orchPanelStatusPill");
    els.orchPanelVersion = document.getElementById("orchPanelVersion");
    els.orchPanelUptime = document.getElementById("orchPanelUptime");
    els.orchPanelLastRequest = document.getElementById("orchPanelLastRequest");
    els.orchPanelError = document.getElementById("orchPanelError");
    els.orchCfgEnabled = document.getElementById("orchCfgEnabled");
    els.orchCfgNewsEnabled = document.getElementById("orchCfgNewsEnabled");
    els.orchCfgMinImportance = document.getElementById("orchCfgMinImportance");
    els.orchApiKeyInput = document.getElementById("orchApiKeyInput");
    els.orchCfgWindowBefore = document.getElementById("orchCfgWindowBefore");
    els.orchCfgWindowAfter = document.getElementById("orchCfgWindowAfter");
    els.orchSaveBtn = document.getElementById("orchSaveBtn");
    els.orchSaveMsg = document.getElementById("orchSaveMsg");
    els.orchDecisionsBody = document.getElementById("orchDecisionsBody");

    els.marketWatchSearch = document.getElementById("marketWatchSearch");
    els.marketWatchSymbol = document.getElementById("marketWatchSymbol");
    els.marketChartWrap = document.getElementById("marketChartWrap");
    els.marketWatchChart = document.getElementById("marketWatchChart");
    els.marketWatchStatus = document.getElementById("marketWatchStatus");
    els.marketWatchTfButtons = document.querySelectorAll("[data-mw-tf]");
    els.marketWatchModeButtons = document.querySelectorAll("[data-mw-mode]");
    els.marketWatchReset = document.getElementById("marketWatchReset");
    els.marketWatchGoLive = document.getElementById("marketWatchGoLive");
    els.marketWatchLivePaused = document.getElementById("marketWatchLivePaused");
    els.marketWatchSnapshot = document.getElementById("marketWatchSnapshot");
    els.marketDrawToolbar = document.getElementById("marketDrawToolbar");
    els.marketDrawToolbarDragHandle = document.getElementById("marketDrawToolbarDragHandle");
    els.marketDrawOverlay = document.getElementById("marketDrawOverlay");
    els.marketDrawTooltip = document.getElementById("marketDrawTooltip");
    els.marketDrawMoreMenu = document.getElementById("marketDrawMoreMenu");
    els.marketDrawSnapMode = document.getElementById("marketDrawSnapMode");
    els.marketDrawSnapRadius = document.getElementById("marketDrawSnapRadius");
    els.marketDrawSnapRadiusValue = document.getElementById("marketDrawSnapRadiusValue");
    els.marketDrawToolButtons = document.querySelectorAll("[data-draw-tool]");
    els.marketDrawActionButtons = document.querySelectorAll("[data-draw-action]");
    els.marketDrawPropsPanel = document.getElementById("marketDrawPropsPanel");
    els.marketDrawPropsTitle = document.getElementById("marketDrawPropsTitle");
    els.marketDrawPropsMeta = document.getElementById("marketDrawPropsMeta");
    els.marketDrawPropsStrokeSection = document.getElementById("marketDrawPropsStrokeSection");
    els.marketDrawPropsFillSection = document.getElementById("marketDrawPropsFillSection");
    els.marketDrawPropsTextSection = document.getElementById("marketDrawPropsTextSection");
    els.marketDrawPropStrokeColor = document.getElementById("marketDrawPropStrokeColor");
    els.marketDrawPropStrokeWidth = document.getElementById("marketDrawPropStrokeWidth");
    els.marketDrawPropStrokeWidthValue = document.getElementById("marketDrawPropStrokeWidthValue");
    els.marketDrawPropStrokeStyle = document.getElementById("marketDrawPropStrokeStyle");
    els.marketDrawPropStrokeOpacity = document.getElementById("marketDrawPropStrokeOpacity");
    els.marketDrawPropStrokeOpacityValue = document.getElementById("marketDrawPropStrokeOpacityValue");
    els.marketDrawPropFillColor = document.getElementById("marketDrawPropFillColor");
    els.marketDrawPropFillOpacity = document.getElementById("marketDrawPropFillOpacity");
    els.marketDrawPropFillOpacityValue = document.getElementById("marketDrawPropFillOpacityValue");
    els.marketDrawPropTextColor = document.getElementById("marketDrawPropTextColor");
    els.marketDrawPropFontSize = document.getElementById("marketDrawPropFontSize");
    els.marketDrawPropFontSizeValue = document.getElementById("marketDrawPropFontSizeValue");
    els.marketDrawPropBgColor = document.getElementById("marketDrawPropBgColor");
    els.marketDrawPropBgOpacity = document.getElementById("marketDrawPropBgOpacity");
    els.marketDrawPropBgOpacityValue = document.getElementById("marketDrawPropBgOpacityValue");
    els.marketDrawPropDuplicate = document.getElementById("marketDrawPropDuplicate");
    els.marketDrawPropBringFront = document.getElementById("marketDrawPropBringFront");
    els.marketDrawPropSendBack = document.getElementById("marketDrawPropSendBack");
    els.marketDrawPropLock = document.getElementById("marketDrawPropLock");
    els.marketDrawPropDelete = document.getElementById("marketDrawPropDelete");
    els.mwInfoSpread = document.getElementById("mwInfoSpread");
    els.mwInfoSession = document.getElementById("mwInfoSession");
    els.mwInfoLastPrice = document.getElementById("mwInfoLastPrice");
    els.mwInfoNextCandle = document.getElementById("mwInfoNextCandle");
    els.mwInfoOhlc = document.getElementById("mwInfoOhlc");
    els.mwInfoLastUpdate = document.getElementById("mwInfoLastUpdate");

    warnMissingElement("#dashboardTradesBody", els.dashboardTradesBody);
    warnMissingElement("#dashboardTradesScroll", els.dashboardTradesScroll);
    warnMissingElement("#tradesTableBody", els.tradesTableBody);
    warnMissingElement("#tradesTableScroll", els.tradesTableScroll);
    warnMissingElement("#newsTableBody", els.newsTableBody);
    warnMissingElement("#newsTableScroll", els.newsTableScroll);
    warnMissingElement("#sys-orch-status", els.sysOrchStatus);
    warnMissingElement("#sys-heartbeat", els.sysHeartbeat);
    warnMissingElement("#sys-ea-version", els.sysEaVersion);
    warnMissingElement("#sys-active-symbols", els.sysActiveSymbols);
    warnMissingElement("#sys-logs", els.sysLogs);
    warnMissingElement("#orchPanelStatusPill", els.orchPanelStatusPill);
    warnMissingElement("#orchSaveBtn", els.orchSaveBtn);
    warnMissingElement("#orchDecisionsBody", els.orchDecisionsBody);
  }

  function warnMissingElement(id, el) {
    if (!el) console.warn("Missing element: " + id);
  }

  function neutralizeOverlays() {
    var ids = ["boot-loader", "loading", "overlay"];
    for (var i = 0; i < ids.length; i++) {
      var node = document.getElementById(ids[i]);
      if (node) {
        node.style.pointerEvents = "none";
        if (node.parentNode) node.parentNode.removeChild(node);
      }
    }
    var overlays = document.querySelectorAll(".overlay, .modal-backdrop, .loading, .loader");
    for (var j = 0; j < overlays.length; j++) {
      overlays[j].style.pointerEvents = "none";
      overlays[j].style.display = "none";
    }
  }

  function showErrorBanner(err) {
    var msg = "JS init failed, open devtools";
    var banner = document.getElementById("jsErrorBanner");
    if (!banner) {
      banner = document.createElement("div");
      banner.id = "jsErrorBanner";
      banner.className = "error-banner";
      banner.textContent = msg;
      document.body.appendChild(banner);
    }
  }


  function showFatalError(err) {
    showErrorBanner(err);
  }

  function setJsStatus(value) {
    var el = els.jsStatus || document.getElementById("jsStatus");
    if (!el) return;
    el.textContent = value;
  }

  function updateDiagnostics() {
    var countEl = els.tradesCount || document.getElementById("tradesCount");
    if (countEl) countEl.textContent = state.trades ? state.trades.length : 0;
  }

  function esc(value) {
    var str = value === null || value === undefined ? "" : String(value);
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function hasValue(value) {
    return !(value === null || value === undefined || (typeof value === "string" && value.trim() === ""));
  }

  function pickValue(obj, keys) {
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      if (hasValue(obj[key])) return obj[key];
    }
    return null;
  }

  function normalizeSeverity(value) {
    if (value === "success" || value === "danger" || value === "warn" || value === "neutral") {
      return value;
    }
    return "neutral";
  }

  function emptyNormalizedLog() {
    return {
      rawText: "",
      timestamp: null,
      method: null,
      path: null,
      status: null,
      endpoint: null,
      allow: null,
      reason: null,
      request_id: null,
      event_type: null,
      symbol: null,
      bot_id: null,
      account_id: null
    };
  }

  function coerceAllow(value) {
    if (value === true || value === false) return value;
    if (typeof value === "string") {
      var lowered = value.toLowerCase();
      if (lowered === "true") return true;
      if (lowered === "false") return false;
    }
    return null;
  }

  function safeJsonStringify(value) {
    try {
      return JSON.stringify(value);
    } catch (err) {
      return "";
    }
  }

  function extractInlineJson(text) {
    if (!hasValue(text)) return null;
    var str = String(text);
    var start = str.indexOf("{");
    var end = str.lastIndexOf("}");
    if (start < 0 || end <= start) return null;
    var snippet = str.slice(start, end + 1);
    try {
      var parsed = JSON.parse(snippet);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return parsed;
    } catch (err) {
      return null;
    }
    return null;
  }

  function normalizeLogObject(obj, rawTextOverride) {
    var normalized = emptyNormalizedLog();
    if (!obj || typeof obj !== "object") return normalized;

    var rawText = hasValue(rawTextOverride) ? String(rawTextOverride) : "";
    if (!rawText && hasValue(obj.rawText)) rawText = String(obj.rawText);
    if (!rawText && hasValue(obj.message)) rawText = String(obj.message);
    if (!rawText && hasValue(obj.detail)) rawText = String(obj.detail);
    if (!rawText) rawText = safeJsonStringify(obj);
    if (!rawText) rawText = String(obj);
    normalized.rawText = rawText;

    var method = pickValue(obj, ["method", "http_method", "verb"]);
    if (hasValue(method)) normalized.method = String(method).toUpperCase();

    var path = pickValue(obj, ["path", "request_path", "url", "endpoint_path"]);
    if (hasValue(path)) normalized.path = String(path);

    var eventType = pickValue(obj, ["event_type", "eventType", "type"]);
    if (hasValue(eventType)) normalized.event_type = String(eventType);

    var status = pickValue(obj, ["status_code", "status", "http_status", "http", "code"]);
    if (hasValue(status)) {
      var statusNum = Number(status);
      if (!isNaN(statusNum) && isFinite(statusNum)) normalized.status = statusNum;
    }

    normalized.allow = coerceAllow(pickValue(obj, ["allow", "allowed"]));

    var reason = pickValue(obj, ["reason", "block_reason", "message", "error", "detail"]);
    if (hasValue(reason)) normalized.reason = String(reason);

    var requestId = pickValue(obj, ["request_id", "requestId", "req_id"]);
    if (hasValue(requestId)) normalized.request_id = String(requestId);

    var timestamp = pickValue(obj, ["timestamp", "time", "ts", "created_at", "createdAt", "logged_at", "loggedAt"]);
    if (hasValue(timestamp)) normalized.timestamp = String(timestamp);

    var symbol = pickValue(obj, ["symbol"]);
    if (hasValue(symbol)) normalized.symbol = String(symbol);
    var botId = pickValue(obj, ["bot_id", "botId"]);
    if (hasValue(botId)) normalized.bot_id = String(botId);
    var accountId = pickValue(obj, ["account_id", "accountId", "account"]);
    if (hasValue(accountId)) normalized.account_id = String(accountId);

    var endpoint = pickValue(obj, ["endpoint"]);
    if (hasValue(endpoint)) normalized.endpoint = String(endpoint);
    if (!hasValue(normalized.endpoint) && normalized.method && normalized.path) {
      normalized.endpoint = normalized.method + " " + normalized.path;
    }

    if (!hasValue(normalized.path) && hasValue(normalized.event_type)) {
      var et = String(normalized.event_type).toLowerCase();
      if (et.indexOf("pre_trade") >= 0 || et.indexOf("pretrade") >= 0) normalized.path = "/pre_trade";
      if (et.indexOf("heartbeat") >= 0) normalized.path = "/health";
    }

    return normalized;
  }

  function normalizeLog(raw) {
    var normalized = emptyNormalizedLog();
    if (raw === null || raw === undefined) return normalized;

    if (typeof raw === "string") {
      normalized.rawText = raw;
      var trimmed = raw.trim();
      // Werkzeug can write ANSI-colored access logs (e.g. \x1b[31m...\x1b[0m) into the log file.
      // Strip those codes for parsing, but keep the original rawText for display/copy.
      var cleaned = stripAnsi(trimmed);
      if (cleaned.indexOf("{") === 0) {
        try {
          var parsed = JSON.parse(cleaned);
          if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
            return normalizeLogObject(parsed, raw);
          }
        } catch (err) {
          // fallthrough
        }
      }

      var tsMatch = cleaned.match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})/);
      if (tsMatch) normalized.timestamp = tsMatch[1];

      var requestMatch = cleaned.match(/\"(GET|POST|PUT|DELETE|PATCH)\s+([^\"\s]+)\s+HTTP\/[0-9.]+\"\s+(\d{3})/);
      if (!requestMatch) {
        requestMatch = cleaned.match(/\b(GET|POST|PUT|DELETE|PATCH)\s+(\/\S+)\s+HTTP\/[0-9.]+\b/);
      }
      if (requestMatch) {
        normalized.method = requestMatch[1];
        normalized.path = requestMatch[2];
        if (requestMatch[3]) normalized.status = Number(requestMatch[3]);
      }
      var inlineJson = extractInlineJson(cleaned);
      if (inlineJson) {
        var jsonNormalized = normalizeLogObject(inlineJson, normalized.rawText);
        if (normalized.allow === null && jsonNormalized.allow !== null) normalized.allow = jsonNormalized.allow;
        if (!hasValue(normalized.reason) && hasValue(jsonNormalized.reason)) normalized.reason = jsonNormalized.reason;
        if (!hasValue(normalized.request_id) && hasValue(jsonNormalized.request_id)) normalized.request_id = jsonNormalized.request_id;
        if (!hasValue(normalized.method) && hasValue(jsonNormalized.method)) normalized.method = jsonNormalized.method;
        if (!hasValue(normalized.path) && hasValue(jsonNormalized.path)) normalized.path = jsonNormalized.path;
        if (normalized.status === null && jsonNormalized.status !== null) normalized.status = jsonNormalized.status;
        if (!hasValue(normalized.timestamp) && hasValue(jsonNormalized.timestamp)) normalized.timestamp = jsonNormalized.timestamp;
        if (!hasValue(normalized.endpoint) && hasValue(jsonNormalized.endpoint)) normalized.endpoint = jsonNormalized.endpoint;
      }

      if (normalized.allow === null) {
        var allowMatch = cleaned.match(/\ballow\b\s*[:=]\s*(true|false)\b/i);
        if (allowMatch) normalized.allow = allowMatch[1].toLowerCase() === "true";
      }
      if (!hasValue(normalized.reason)) {
        var reasonMatch = cleaned.match(/\breason\b\s*[:=]\s*\"([^\"]+)\"/i)
          || cleaned.match(/\breason\b\s*[:=]\s*'([^']+)'/i)
          || cleaned.match(/\breason\b\s*[:=]\s*([^\s,}]+)/i);
        if (reasonMatch) normalized.reason = reasonMatch[1];
      }
      if (normalized.status === null) {
        var httpMatch = cleaned.match(/\bhttp\b\s*[:=]\s*(\d{3})\b/i);
        if (httpMatch) normalized.status = Number(httpMatch[1]);
      }
      if (!hasValue(normalized.path)) {
        var lower = cleaned.toLowerCase();
        if (lower.indexOf("/pre_trade") >= 0 || lower.indexOf("pre_trade") >= 0 || lower.indexOf("pretrade") >= 0) {
          normalized.path = "/pre_trade";
        }
        else if (lower.indexOf("/health") >= 0 || lower.indexOf("heartbeat") >= 0) normalized.path = "/health";
      }

      if (normalized.method && normalized.path) normalized.endpoint = normalized.method + " " + normalized.path;
      return normalized;
    }

    if (typeof raw === "object") return normalizeLogObject(raw, null);

    normalized.rawText = String(raw);
    return normalized;
  }

  function classifyLog(log) {
    var path = hasValue(log.path) ? String(log.path) : "";
    var rawText = hasValue(log.rawText) ? String(log.rawText) : "";
    var pathLower = path.toLowerCase();
    var rawLower = stripAnsi(rawText).toLowerCase();
    var eventType = hasValue(log.event_type) ? String(log.event_type).toLowerCase() : "";

    var isPreTrade = eventType.indexOf("pre_trade") >= 0
      || eventType.indexOf("pretrade") >= 0
      || pathLower.indexOf("/pre_trade") >= 0
      || pathLower.indexOf("pretrade") >= 0
      || rawLower.indexOf("/pre_trade") >= 0
      || rawLower.indexOf("pre_trade") >= 0
      || rawLower.indexOf("pretrade") >= 0;
    if (isPreTrade) {
      if (log.allow === true) return { severity: "success", label: "ALLOW" };
      if (log.allow === false) return { severity: "danger", label: "DENY" };
      return { severity: "neutral", label: "PRE_TRADE" };
    }

    var isHeartbeat = eventType.indexOf("heartbeat") >= 0
      || pathLower.indexOf("/health") >= 0
      || rawLower.indexOf("/health") >= 0
      || rawLower.indexOf("heartbeat") >= 0;
    if (isHeartbeat) {
      // Keep heartbeat visually neutral/grey; it is informational noise.
      return { severity: "neutral", label: "HEARTBEAT" };
    }

    var isTradeOpenMarker = rawLower.indexOf("trade_open ok") >= 0 || rawLower.indexOf("trade open ok") >= 0;
    var isTradeCloseMarker = rawLower.indexOf("trade_close ok") >= 0 || rawLower.indexOf("trade close ok") >= 0;
    var isTradeOpenPath = pathLower.indexOf("/trades/add") >= 0
      || pathLower.indexOf("/trade/open") >= 0
      || pathLower.indexOf("/trade_open") >= 0
      || pathLower.indexOf("/v1/trade_open") >= 0;
    var isTradeClosePath = pathLower.indexOf("/trades/close") >= 0
      || pathLower.indexOf("/trade/close") >= 0
      || pathLower.indexOf("/trade_close") >= 0
      || pathLower.indexOf("/v1/trade_close") >= 0;

    if (isTradeOpenMarker) return { severity: "success", label: "OPEN" };
    if (isTradeCloseMarker) return { severity: "success", label: "CLOSE" };

    // Color trade upserts based on HTTP status.
    if (isTradeOpenPath || isTradeClosePath) {
      var st = typeof log.status === "number" ? log.status : null;
      if (st !== null && st >= 400) return { severity: "danger", label: isTradeOpenPath ? "OPEN" : "CLOSE" };
      if (st !== null && st >= 200 && st < 300) return { severity: "success", label: isTradeOpenPath ? "OPEN" : "CLOSE" };
      return { severity: "neutral", label: isTradeOpenPath ? "OPEN" : "CLOSE" };
    }

    // Generic error coloring for anything that has an HTTP status.
    if (typeof log.status === "number" && log.status >= 400) {
      var errLabel = hasValue(log.endpoint) ? String(log.endpoint) : "HTTP_ERROR";
      return { severity: "danger", label: errLabel };
    }

    var label = hasValue(log.endpoint) ? String(log.endpoint) : "LOG";
    return { severity: "neutral", label: label };
  }

  function stripAnsi(text) {
    if (!hasValue(text)) return text;
    try {
      // Common ANSI SGR sequences: ESC[ ... m
      return String(text).replace(/\u001b\[[0-9;]*m/g, "");
    } catch (e) {
      return String(text);
    }
  }

  function isDevMode() {
    var host = window.location && window.location.hostname ? window.location.hostname : "";
    return host === "localhost" || host === "127.0.0.1";
  }

  function getDevMockLogs() {
    return [
      "2026-02-06 14:37:53,019 INFO \"GET /health HTTP/1.1\" 200 -",
      "2026-02-06 14:37:54,222 INFO [ORCH][PRE_TRADE] allow=true reason=ok http=200 error=0 body={\"allow\":true}",
      "2026-02-06 14:37:55,111 INFO [ORCH][PRE_TRADE] allow=false reason=blocked http=200 error=0 body={\"allow\":false}"
    ];
  }

  function buildLogEntries(logs) {
    var entries = [];
    for (var i = 0; i < logs.length; i++) {
      var normalized = normalizeLog(logs[i]);
      var classification = classifyLog(normalized);
      entries.push({
        normalized: normalized,
        classification: classification,
        count: 1,
        lastSeenAt: hasValue(normalized.timestamp) ? normalized.timestamp : null
      });
    }
    return entries;
  }

  function filterLogsAfterBaseline(logs, baselineMs) {
    if (!Array.isArray(logs) || !baselineMs) return logs;
    var out = [];
    for (var i = 0; i < logs.length; i++) {
      var normalized = normalizeLog(logs[i]);
      var ts = parseLogTimestamp(normalized.timestamp || null);
      if (!ts) continue;
      if (ts.getTime() >= baselineMs) out.push(logs[i]);
    }
    return out;
  }

  function buildLogCopyLinesFromEntries(entries) {
    var out = [];
    if (!Array.isArray(entries)) return out;
    for (var i = 0; i < entries.length; i++) {
      var normalized = entries[i] && entries[i].normalized ? entries[i].normalized : null;
      if (!normalized) continue;
      if (hasValue(normalized.rawText)) {
        out.push(String(normalized.rawText));
      } else {
        try {
          out.push(JSON.stringify(normalized, null, 2));
        } catch (err) {
          out.push(String(normalized));
        }
      }
    }
    return out;
  }

  function aggregateHeartbeatEntries(entries) {
    var aggregated = [];
    var indexBySig = {};
    for (var i = 0; i < entries.length; i++) {
      var entry = entries[i];
      if (!entry || !entry.classification || entry.classification.label !== "HEARTBEAT") {
        aggregated.push(entry);
        continue;
      }
      var n = entry.normalized || {};
      var sig = [
        hasValue(n.method) ? String(n.method) : "",
        hasValue(n.path) ? String(n.path) : "",
        hasValue(n.status) ? String(n.status) : ""
      ].join("|");
      if (indexBySig[sig] === undefined) {
        indexBySig[sig] = aggregated.length;
        aggregated.push(entry);
        continue;
      }
      var existing = aggregated[indexBySig[sig]];
      existing.count = (existing.count || 1) + 1;
      var existingTs = parseLogTimestamp(
        (existing && (existing.lastSeenAt || (existing.normalized && existing.normalized.timestamp))) || null
      );
      var incomingTs = parseLogTimestamp(
        (entry && (entry.lastSeenAt || (entry.normalized && entry.normalized.timestamp))) || null
      );
      if (incomingTs && (!existingTs || incomingTs > existingTs)) {
        existing.lastSeenAt = entry.lastSeenAt || (entry.normalized && entry.normalized.timestamp) || existing.lastSeenAt;
      }
      if (hasValue(n.rawText)) existing.normalized.rawText = n.rawText;
    }
    return aggregated;
  }

  function sortEntriesByTimestamp(entries) {
    if (!Array.isArray(entries)) return entries;
    return entries.slice().sort(function (a, b) {
      var ta = parseLogTimestamp((a && (a.lastSeenAt || (a.normalized && a.normalized.timestamp))) || null);
      var tb = parseLogTimestamp((b && (b.lastSeenAt || (b.normalized && b.normalized.timestamp))) || null);
      if (ta && tb) return tb.getTime() - ta.getTime();
      if (ta && !tb) return -1;
      if (!ta && tb) return 1;
      return 0;
    });
  }

  function fmt(value, digits) {
    if (!hasValue(value)) return "--";
    var num = Number(value);
    if (isNaN(num) || !isFinite(num)) return "--";
    var d = typeof digits === "number" ? digits : 2;
    return num.toFixed(d);
  }

  function formatTime(date) {
    if (!date) return "--";
    try {
      return date.toLocaleTimeString("en-GB", { hour12: false });
    } catch (err) {
      return date.toLocaleTimeString();
    }
  }

  function parseLogTimestamp(value) {
    if (!hasValue(value)) return null;
    var raw = String(value).trim();
    if (!raw) return null;
    var cleaned = raw.replace(",", ".");
    if (cleaned.indexOf("T") === -1 && cleaned.indexOf(" ") >= 0) {
      cleaned = cleaned.replace(" ", "T");
    }
    var parsed = new Date(cleaned);
    if (!isNaN(parsed.getTime())) return parsed;
    var noMs = raw.split(",")[0];
    return parseTradeDate(noMs);
  }

  function deriveLogKey(entry, index) {
    if (!entry) return String(index);
    var n = entry.normalized || {};
    if (hasValue(n.request_id)) return String(n.request_id);
    var ts = hasValue(entry.lastSeenAt) ? entry.lastSeenAt : (hasValue(n.timestamp) ? n.timestamp : "");
    var sig = [
      hasValue(n.method) ? n.method : "",
      hasValue(n.path) ? n.path : "",
      hasValue(n.status) ? n.status : ""
    ].join("|");
    var rawSig = hasValue(n.rawText) ? String(n.rawText).replace(/\s+/g, " ").slice(0, 120) : "";
    var parts = [];
    if (hasValue(ts)) parts.push(String(ts));
    if (hasValue(sig)) parts.push(sig);
    if (rawSig) parts.push(rawSig);
    if (!parts.length) return String(index);
    return parts.join("|");
  }

  function setSystemLogHighlight(key, latestMs) {
    if (!hasValue(key)) return;
    if (state.systemLogHighlightTimer) {
      clearTimeout(state.systemLogHighlightTimer);
      state.systemLogHighlightTimer = null;
    }
    state.systemLogHighlightKey = key;
    state.systemLogHighlightUntil = Date.now() + SYSTEM_LOG_HIGHLIGHT_MS;
    state.systemLogLastKey = key;
    if (typeof latestMs === "number") state.systemLogLastTs = latestMs;
    state.systemLogHighlightTimer = setTimeout(function () {
      if (state.systemLogHighlightKey === key) {
        state.systemLogHighlightKey = null;
        state.systemLogHighlightUntil = 0;
        renderSystemLogs((state.systemStatus && state.systemStatus.logs) || []);
      }
    }, SYSTEM_LOG_HIGHLIGHT_MS);
  }

  function parseTradeDate(value) {
    if (!hasValue(value)) return null;
    var raw = String(value).trim();
    var normalized = raw.replace(/\./g, "-").replace("T", " ");
    if (normalized.length === 16) normalized += ":00";
    var parsed = new Date(normalized);
    if (!isNaN(parsed.getTime())) return parsed;
    return null;
  }

  function isOpenTrade(t) {
    var st = String((t && t.status) || "").toUpperCase();
    if (st === "OPEN") return true;
    // Fallback: no close_time implies open-like record
    return !hasValue(t && t.close_time);
  }

  function getTradeTimeMs(t, col) {
    if (!t) return null;
    if (col === "open_time") {
      var od = parseTradeDate(t.open_time) || parseTradeDate(t.created_at);
      return od ? od.getTime() : null;
    }
    if (col === "close_time") {
      var cd = parseTradeDate(t.close_time);
      return cd ? cd.getTime() : null;
    }
    return null;
  }

  function getDefaultTradesSort() {
    return { column: "open_time", direction: "desc" };
  }

  function normalizeTradesSort(col, dir) {
    var column = col === "close_time" ? "close_time" : "open_time";
    var direction = dir === "asc" ? "asc" : "desc";
    return { column: column, direction: direction };
  }

  function resetTradesSortToDefault() {
    var d = getDefaultTradesSort();
    state.tradesSortColumn = d.column;
    state.tradesSortDirection = d.direction;
    updateTradesSortIndicators();
  }

  function cycleTradesSort(clickedColumn) {
    var current = normalizeTradesSort(state.tradesSortColumn, state.tradesSortDirection);
    var col = clickedColumn === "close_time" ? "close_time" : "open_time";

    if (current.column !== col) {
      state.tradesSortColumn = col;
      state.tradesSortDirection = "desc";
      updateTradesSortIndicators();
      return;
    }

    // Same column: desc -> asc -> default
    if (current.direction === "desc") {
      state.tradesSortDirection = "asc";
      updateTradesSortIndicators();
      return;
    }
    resetTradesSortToDefault();
  }

  function updateTradesSortIndicators() {
    var sort = normalizeTradesSort(state.tradesSortColumn, state.tradesSortDirection);
    var ths = document.querySelectorAll("[data-sort-col]");
    for (var i = 0; i < ths.length; i++) {
      var th = ths[i];
      var col = th.getAttribute("data-sort-col");
      var span = th.querySelector("[data-sort-indicator]");
      var isActive = col === sort.column;
      var symbol = "";
      var aria = "none";
      if (isActive) {
        if (sort.direction === "asc") {
          symbol = "▲";
          aria = "ascending";
        } else {
          symbol = "▼";
          aria = "descending";
        }
      }
      if (span) span.textContent = symbol;
      th.setAttribute("aria-sort", aria);
    }
  }

  function applyTradesSort(list) {
    var sort = normalizeTradesSort(state.tradesSortColumn, state.tradesSortDirection);
    var dirMul = sort.direction === "asc" ? 1 : -1;

    var items = list.slice(0);
    for (var i = 0; i < items.length; i++) items[i]._sortIndex = i;

    items.sort(function (a, b) {
      // Close Time sorting: open trades always stay on top.
      if (sort.column === "close_time") {
        var ao = isOpenTrade(a);
        var bo = isOpenTrade(b);
        if (ao !== bo) return ao ? -1 : 1;
      }

      var ams = getTradeTimeMs(a, sort.column);
      var bms = getTradeTimeMs(b, sort.column);

      // Missing timestamps sink to bottom (after open-trade top rule if sorting by close_time).
      if (ams === null && bms !== null) return 1;
      if (ams !== null && bms === null) return -1;
      if (ams !== null && bms !== null && ams !== bms) return (ams > bms ? 1 : -1) * dirMul;

      // For open trades during close_time sort, keep a stable but sensible order: newest open first.
      if (sort.column === "close_time") {
        var aOpenMs = getTradeTimeMs(a, "open_time");
        var bOpenMs = getTradeTimeMs(b, "open_time");
        if (aOpenMs !== null && bOpenMs !== null && aOpenMs !== bOpenMs) return (aOpenMs > bOpenMs ? -1 : 1);
      }

      return (a._sortIndex || 0) - (b._sortIndex || 0);
    });

    for (var j = 0; j < items.length; j++) delete items[j]._sortIndex;
    return items;
  }

  var tradesGroupOpenState = new Map(); // key -> boolean

  function getTradesGroupOpenKey(mode, key) {
    return String(mode || "flat") + ":" + String(key || "Unknown");
  }

  function getTradesGroupOpen(mode, key) {
    var k = getTradesGroupOpenKey(mode, key);
    if (tradesGroupOpenState.has(k)) return tradesGroupOpenState.get(k) === true;
    return true; // default expanded
  }

  function toggleTradesGroupOpen(mode, key) {
    var k = getTradesGroupOpenKey(mode, key);
    var next = !getTradesGroupOpen(mode, key);
    tradesGroupOpenState.set(k, next);
  }

  function normalizeRawDateKey(value) {
    if (!hasValue(value)) return null;
    var s = String(value).trim().replace(/\./g, "-");
    if (s.length >= 10 && /^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    var dt = parseTradeDate(value);
    if (!dt) return null;
    // Use UTC components for stable grouping aligned with UTC session logic elsewhere.
    return dt.getUTCFullYear() + "-" + pad2(dt.getUTCMonth() + 1) + "-" + pad2(dt.getUTCDate());
  }

  function sessionFromUtcHour(h) {
    if (h === null || h === undefined) return { key: "unknown", label: "Unknown" };
    var hour = Number(h);
    if (isNaN(hour) || !isFinite(hour)) return { key: "unknown", label: "Unknown" };
    hour = Math.max(0, Math.min(23, Math.floor(hour)));
    // UTC ranges: ASIA 22-07, LONDON 07-12, OVERLAP 12-16, NY 16-22
    if (hour >= 22 || hour < 7) return { key: "asia", label: "Asia" };
    if (hour >= 7 && hour < 12) return { key: "london", label: "London" };
    if (hour >= 12 && hour < 16) return { key: "overlap", label: "Overlap" };
    return { key: "ny", label: "NY" };
  }

  function getTradeSessionLabel(t) {
    if (!t) return "Unknown";
    var explicit = pickValue(t, ["session", "session_label", "session_name"]);
    if (hasValue(explicit)) return String(explicit);

    var hour = null;
    if (hasValue(t.hour)) hour = Number(t.hour);
    if ((hour === null || isNaN(hour)) && hasValue(t.session_hour)) hour = Number(t.session_hour);
    if ((hour === null || isNaN(hour))) {
      var dt = parseTradeDate(t.open_time);
      if (dt) hour = dt.getUTCHours();
    }
    return sessionFromUtcHour(hour).label;
  }

  function sumProfit(trades) {
    var total = 0;
    for (var i = 0; i < trades.length; i++) {
      var pr = pickValue(trades[i], ["profit"]);
      if (!hasValue(pr)) continue;
      var n = Number(pr);
      if (!isNaN(n) && isFinite(n)) total += n;
    }
    return total;
  }

  function fmtPnl(num) {
    var n = Number(num || 0);
    var sign = n >= 0 ? "+" : "";
    return sign + n.toFixed(2);
  }

  function groupTradesByDay(trades) {
    var order = [];
    var map = {};
    for (var i = 0; i < trades.length; i++) {
      var t = trades[i];
      var key = normalizeRawDateKey(t && t.open_time) || "Unknown";
      if (!map[key]) {
        map[key] = [];
        order.push(key);
      }
      map[key].push(t);
    }
    var groups = [];
    for (var j = 0; j < order.length; j++) {
      var k = order[j];
      groups.push({ key: k, title: k, trades: map[k] });
    }
    return groups;
  }

  function groupTradesBySession(trades) {
    var order = [];
    var map = {};
    for (var i = 0; i < trades.length; i++) {
      var t = trades[i];
      var label = getTradeSessionLabel(t) || "Unknown";
      var key = label;
      if (!map[key]) {
        map[key] = [];
        order.push(key);
      }
      map[key].push(t);
    }
    var groups = [];
    for (var j = 0; j < order.length; j++) {
      var k = order[j];
      groups.push({ key: k, title: k, trades: map[k] });
    }
    return groups;
  }

  function buildTradeRowHtml(t) {
    var profitRaw = pickValue(t, ["profit"]);
    var profitNum = hasValue(profitRaw) ? Number(profitRaw) : null;
    var profitClass = "profit";
    var profitSymbol = "";
    if (profitNum !== null && !isNaN(profitNum) && isFinite(profitNum)) {
      profitClass += profitNum >= 0 ? " is-positive" : " is-negative";
      profitSymbol = profitNum >= 0 ? "\u25B2" : "\u25BC";
    }
    var status = getStatusLabel(t.status);
    var statusClass = status === "OPEN" ? "pill pill-open" : "pill pill-closed";
    var id = t.id !== undefined && t.id !== null ? t.id : "";
    var ticket = t.ticket !== undefined && t.ticket !== null ? t.ticket : "";
    var tradeKey = hasValue(id) ? String(id) : (hasValue(ticket) ? ("ticket:" + String(ticket)) : "");
    var lot = pickValue(t, ["lot", "lot_size"]);
    var duration = pickValue(t, ["duration_sec", "duration_seconds"]);
    if (!hasValue(duration)) duration = fallbackDurationSeconds(t.open_time, t.close_time);
    var magic = pickValue(t, ["magic", "magic_number"]);
    var maxFloatProfit = pickValue(t, ["max_float_profit", "max_floating_profit"]);
    var maxFloatDD = pickValue(t, ["max_float_dd", "max_floating_dd"]);
    var setup = pickValue(t, ["setup", "setup_result"]);
    var closeReason = pickValue(t, ["close_reason", "exit_reason"]);
    var closeBadge = getCloseReason(closeReason);
    return `
        <tr class="trade-row" data-trade-id="${esc(tradeKey)}" data-trade-ticket="${esc(ticket)}">
          <td>${esc(id)}</td>
          <td>${esc(ticket)}</td>
          <td>${esc(t.symbol || "--")}</td>
          <td>${esc(t.direction || "--")}</td>
          <td>${esc(hasValue(lot) ? lot : "--")}</td>
          <td>${esc(t.risk_level || "--")}</td>
          <td>${esc(t.account_id || t.account || t.login || "--")}</td>
          <td>${esc(t.timeframe || t.entry_tf || "--")}</td>
          <td>${esc(t.open_time || "--")}</td>
          <td>${esc(t.close_time || "--")}</td>
          <td>${esc(t.open_price || "--")}</td>
          <td>${esc(t.close_price || "--")}</td>
          <td class="${profitClass}">${esc(profitSymbol)} ${fmt(profitRaw, 2)}</td>
          <td>${esc(t.profit_r !== undefined && t.profit_r !== null ? t.profit_r : "--")}</td>
          <td>${esc(hasValue(duration) ? duration : "--")}</td>
          <td><span class="badge ${closeBadge.kind}">${esc(closeBadge.label)}</span></td>
          <td>${esc(hasValue(magic) ? magic : "--")}</td>
          <td>${esc(t.spread_points !== undefined && t.spread_points !== null ? t.spread_points : "--")}</td>
          <td>${esc(hasValue(maxFloatProfit) ? maxFloatProfit : "--")}</td>
          <td>${esc(hasValue(maxFloatDD) ? maxFloatDD : "--")}</td>
          <td>${esc(hasValue(setup) ? setup : "--")}</td>
          <td>${esc(t.created_at || "--")}</td>
          <td><span class="${statusClass}">${esc(status)}</span></td>
          <td>
            <button class="icon-btn delete-one-btn" data-id="${esc(id)}" data-ticket="${esc(ticket)}" type="button" title="Delete trade" aria-label="Delete trade">
              <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M3 6h18"></path>
                <path d="M8 6V4h8v2"></path>
                <path d="M6 6l1 14h10l1-14"></path>
                <path d="M10 11v6"></path>
                <path d="M14 11v6"></path>
              </svg>
            </button>
          </td>
        </tr>
      `;
  }

  function renderTradesGrouped(groups, mode) {
    var colCount = 24;
    var out = [];
    for (var i = 0; i < groups.length; i++) {
      var g = groups[i];
      var open = getTradesGroupOpen(mode, g.key);
      var count = g.trades.length;
      var pnl = sumProfit(g.trades);
      var toggle = open ? "▼" : "▶";
      out.push(`
        <tr class="group-header-row" data-group-mode="${esc(mode)}" data-group-key="${esc(g.key)}">
          <td colspan="${colCount}">
            <button class="group-header-btn" type="button" data-group-toggle="1" data-group-mode="${esc(mode)}" data-group-key="${esc(g.key)}" aria-expanded="${open ? "true" : "false"}">
              <span class="group-title">${esc(g.title)}</span>
              <span class="group-meta">Trades: ${esc(count)} • PnL: ${esc(fmtPnl(pnl))}</span>
              <span class="group-toggle">${esc(toggle)}</span>
            </button>
          </td>
        </tr>
      `);
      if (!open) continue;
      for (var j = 0; j < g.trades.length; j++) {
        out.push(buildTradeRowHtml(g.trades[j] || {}));
      }
    }
    return out.join("");
  }

  function rebuildTradesById(trades) {
    tradesById.clear();
    if (!trades || !trades.length) return;
    for (var i = 0; i < trades.length; i++) {
      var t = trades[i];
      if (!t) continue;
      var id = t.id;
      if (id !== undefined && id !== null && id !== "") tradesById.set(String(id), t);
      var ticket = t.ticket;
      if (ticket !== undefined && ticket !== null && String(ticket) !== "") {
        tradesById.set("ticket:" + String(ticket), t);
      }
    }
  }

  function isTradeModalOpen() {
    return !!(els.tradeModal && els.tradeModal.classList.contains("is-open"));
  }

  function syncBodyModalOpen() {
    // Treat "not hidden" as open so body scroll locks during open/close transitions too.
    var chartVisible = !!(els.chartModal && !els.chartModal.classList.contains("is-hidden"));
    var tradeVisible = !!(els.tradeModal && !els.tradeModal.classList.contains("is-hidden"));
    var notesVisible = !!(els.notesModal && !els.notesModal.classList.contains("is-hidden"));
    var calcVisible = !!(els.calcModal && !els.calcModal.classList.contains("is-hidden"));
    var open = chartVisible || tradeVisible || notesVisible || calcVisible;
    if (open) document.body.classList.add("modal-open");
    else document.body.classList.remove("modal-open");
  }

  function closeTradeModal() {
    if (!els.tradeModal) return;
    if (!isTradeModalOpen()) return;
    els.tradeModal.classList.remove("is-open");
    syncBodyModalOpen();
    setTimeout(function () {
      if (!els.tradeModal) return;
      els.tradeModal.classList.add("is-hidden");
      if (els.tradeModalContent) els.tradeModalContent.innerHTML = "";
    }, 170);
  }

  function openTradeModal(tradeKey) {
    if (!els.tradeModal) return;
    if (!tradeKey && tradeKey !== 0) return;

    // Avoid stacked modals.
    if (isChartModalOpen()) closeChartModal();

    var t = tradesById.get(String(tradeKey));
    if (!t) return;

    var ticket = t.ticket !== undefined && t.ticket !== null ? String(t.ticket) : "";
    var symbol = t.symbol || "--";
    var direction = t.direction || "--";
    var lot = pickValue(t, ["lot", "lot_size"]);
    var risk = t.risk_level || "--";
    var account = t.account_id || t.account || t.login || "--";
    var tf = t.timeframe || t.entry_tf || "--";
    var openTime = t.open_time || "--";
    var closeTime = t.close_time || "--";
    var duration = pickValue(t, ["duration_sec", "duration_seconds"]);
    if (!hasValue(duration)) duration = fallbackDurationSeconds(t.open_time, t.close_time);
    var openPrice = t.open_price || "--";
    var closePrice = t.close_price || "--";
    var profitRaw = pickValue(t, ["profit"]);
    var profitNum = hasValue(profitRaw) ? Number(profitRaw) : null;
    var profitText = fmt(profitRaw, 2);
    if (profitNum !== null && !isNaN(profitNum) && isFinite(profitNum)) {
      profitText = (profitNum >= 0 ? "+" : "") + profitNum.toFixed(2);
    }
    var profitClass = "profit";
    if (profitNum !== null && !isNaN(profitNum) && isFinite(profitNum)) {
      profitClass += profitNum >= 0 ? " is-positive" : " is-negative";
    }
    var closeReasonRaw = pickValue(t, ["close_reason", "exit_reason"]);
    var closeBadge = getCloseReason(closeReasonRaw);

    function kv(label, valueHtml) {
      return '<div class=\"trade-detail\">'
        + '<div class=\"label\">' + esc(label) + '</div>'
        + '<div class=\"value\">' + valueHtml + '</div>'
        + '</div>';
    }

    var title = symbol + (ticket ? (" #" + ticket) : "");
    if (els.tradeModalTitle) els.tradeModalTitle.textContent = title;

    var profitHtml = '<span class=\"trade-modal-profit\">'
      + '<span class=\"' + esc(profitClass) + '\">' + esc(profitText) + '</span>'
      + '<span class=\"badge ' + esc(closeBadge.kind) + '\">' + esc(closeBadge.label) + '</span>'
      + '</span>';

    if (els.tradeModalContent) {
      els.tradeModalContent.innerHTML = ''
        + '<div class=\"trade-detail-grid\">'
        + kv('Ticket', esc(ticket || '--'))
        + kv('Symbol', esc(symbol))
        + kv('Direction', esc(direction))
        + kv('Lot', esc(hasValue(lot) ? lot : '--'))
        + kv('Risk', esc(risk))
        + kv('Account', esc(account))
        + kv('Timeframe', esc(tf))
        + kv('Open Time', esc(openTime))
        + kv('Close Time', esc(closeTime))
        + kv('Duration (s)', esc(hasValue(duration) ? duration : '--'))
        + kv('Open Price', esc(openPrice))
        + kv('Close Price', esc(closePrice))
        + kv('Profit', profitHtml)
        + kv('Close Reason', '<span class=\"badge ' + esc(closeBadge.kind) + '\">' + esc(closeBadge.label) + '</span>')
        + '</div>';
    }

    els.tradeModal.classList.remove("is-hidden");
    requestAnimationFrame(function () {
      if (els.tradeModal) els.tradeModal.classList.add("is-open");
      syncBodyModalOpen();
    });
    syncBodyModalOpen();

    if (els.tradeModalClose) {
      try { els.tradeModalClose.focus(); } catch (e) {}
    }
  }

  function initTradeModal() {
    if (!els.tradeModal) return;
    if (els.tradeModalClose) els.tradeModalClose.onclick = closeTradeModal;
    if (els.tradeModalBackdrop) els.tradeModalBackdrop.onclick = closeTradeModal;

    document.addEventListener("keydown", function (e) {
      if (!isTradeModalOpen()) return;
      var key = e.key || e.keyCode;
      if (key === "Escape" || key === "Esc" || key === 27) {
        e.preventDefault();
        closeTradeModal();
      }
    });
  }

  function filterTradesByDateRange(list) {
    var field = state.tradesDateField === "close_time" ? "close_time" : "open_time";
    var from = hasValue(state.tradesDateFrom) ? String(state.tradesDateFrom).trim() : "";
    var to = hasValue(state.tradesDateTo) ? String(state.tradesDateTo).trim() : "";
    if (!from && !to) return list;

    var start = from ? new Date(from + "T00:00:00").getTime() : -Infinity;
    var end = to ? new Date(to + "T23:59:59.999").getTime() : Infinity;

    // If invalid date strings slip in, treat as no bound.
    if (!isFinite(start)) start = -Infinity;
    if (!isFinite(end)) end = Infinity;

    var out = [];
    for (var i = 0; i < list.length; i++) {
      var t = list[i];
      var dt = parseTradeDate(t && t[field]);
      if (!dt) continue;
      var ms = dt.getTime();
      if (ms >= start && ms <= end) out.push(t);
    }
    return out;
  }

  function syncTradesDateFilterUiFromState() {
    if (els.dateField) els.dateField.value = state.tradesDateField === "close_time" ? "close_time" : "open_time";
    if (els.dateFrom) els.dateFrom.value = hasValue(state.tradesDateFrom) ? String(state.tradesDateFrom) : "";
    if (els.dateTo) els.dateTo.value = hasValue(state.tradesDateTo) ? String(state.tradesDateTo) : "";
  }

  function syncTradesViewModeUiFromState() {
    if (!els.viewMode) return;
    var v = String(state.tradesViewMode || "flat");
    if (v !== "day" && v !== "session") v = "flat";
    els.viewMode.value = v;
  }

  function fallbackDurationSeconds(openTime, closeTime) {
    var openDate = parseTradeDate(openTime);
    var closeDate = parseTradeDate(closeTime);
    if (!openDate || !closeDate) return null;
    var diff = Math.floor((closeDate.getTime() - openDate.getTime()) / 1000);
    return diff >= 0 ? diff : null;
  }

  function requestJson(method, url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader("Cache-Control", "no-cache");
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var json = JSON.parse(xhr.responseText);
          callback(null, json);
        } catch (err) {
          callback("Invalid JSON response");
        }
      } else {
        callback("HTTP " + xhr.status + ": " + (xhr.responseText || "error"));
      }
    };
    xhr.onerror = function () {
      callback("Network error");
    };
    xhr.send();
  }

  function requestJsonWithBody(method, url, body, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.setRequestHeader("Cache-Control", "no-cache");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var json = JSON.parse(xhr.responseText);
          callback(null, json);
        } catch (err) {
          callback("Invalid JSON response");
        }
      } else {
        callback("HTTP " + xhr.status + ": " + (xhr.responseText || "error"));
      }
    };
    xhr.onerror = function () {
      callback("Network error");
    };
    xhr.send(body ? JSON.stringify(body) : null);
  }

  function getOrchApiBase() {
    var base = hasValue(ORCH_API_BASE) ? String(ORCH_API_BASE).trim() : "/api/orch";
    if (!hasValue(base)) base = "/api/orch";
    return base.replace(/\/+$/, "");
  }

  function buildOrchApiUrl(endpointPath) {
    var path = hasValue(endpointPath) ? String(endpointPath).trim() : "";
    if (!path) path = "/api/orch/health";
    if (path.charAt(0) !== "/") path = "/" + path;

    var base = getOrchApiBase();
    var lowerBase = base.toLowerCase();
    var lowerPath = path.toLowerCase();

    if (lowerBase.endsWith("/api/orch")) {
      if (lowerPath === "/api/orch") return base;
      if (lowerPath.indexOf("/api/orch/") === 0) {
        return base + path.slice("/api/orch".length);
      }
      return base + path;
    }

    if (lowerPath === "/api/orch" || lowerPath.indexOf("/api/orch/") === 0) {
      return base + path;
    }
    return base + "/api/orch" + path;
  }

  function parseJsonMaybe(text) {
    if (!hasValue(text)) return null;
    try {
      return JSON.parse(text);
    } catch (err) {
      return null;
    }
  }

  function compactText(text, maxLen) {
    if (!hasValue(text)) return "";
    var value = String(text).replace(/\s+/g, " ").trim();
    if (!value) return "";
    var limit = Number(maxLen);
    if (!isFinite(limit) || limit < 24) limit = 220;
    return value.length > limit ? (value.slice(0, limit - 3) + "...") : value;
  }

  function readStoredOrchApiKey() {
    try {
      var raw = localStorage.getItem(ORCH_API_KEY_STORAGE_KEY);
      if (hasValue(raw)) return String(raw).trim();
      var legacy = localStorage.getItem(ORCH_API_KEY_STORAGE_KEY_LEGACY);
      if (hasValue(legacy)) {
        var migrated = String(legacy).trim();
        if (hasValue(migrated)) {
          localStorage.setItem(ORCH_API_KEY_STORAGE_KEY, migrated);
          return migrated;
        }
      }
    } catch (err) {}
    return "";
  }

  function persistOrchApiKey(value) {
    var key = hasValue(value) ? String(value).trim() : "";
    try {
      if (key) {
        localStorage.setItem(ORCH_API_KEY_STORAGE_KEY, key);
        localStorage.removeItem(ORCH_API_KEY_STORAGE_KEY_LEGACY);
      } else {
        localStorage.removeItem(ORCH_API_KEY_STORAGE_KEY);
        localStorage.removeItem(ORCH_API_KEY_STORAGE_KEY_LEGACY);
      }
    } catch (err) {}
    return key;
  }

  function syncOrchApiKeyInputFromStorage() {
    if (!els.orchApiKeyInput) return;
    var stored = readStoredOrchApiKey();
    if (hasValue(stored) && !hasValue(els.orchApiKeyInput.value)) {
      els.orchApiKeyInput.value = stored;
    }
  }

  function getOrchApiKeyForRequest() {
    if (els.orchApiKeyInput) {
      var inputValue = persistOrchApiKey(els.orchApiKeyInput.value);
      if (hasValue(inputValue)) return inputValue;
    }
    return readStoredOrchApiKey();
  }

  function getOrchUnauthorizedMessage(payload, rawText) {
    var errorCode = "";
    var detailText = "";
    if (payload && typeof payload === "object") {
      if (hasValue(payload.error)) errorCode = String(payload.error).trim().toLowerCase();
      if (hasValue(payload.reason)) detailText = String(payload.reason).trim();
      if (!hasValue(detailText) && hasValue(payload.message)) detailText = String(payload.message).trim();
    }
    if (!hasValue(detailText)) detailText = compactText(rawText, 220);
    if (!hasValue(detailText) || detailText.toLowerCase() === "auth_failed") {
      if (errorCode === "api_key_missing") return "Unauthorized (API key missing)";
      if (errorCode === "api_key_invalid") return "Unauthorized (API key invalid)";
      return "Unauthorized (API key missing)";
    }
    if (errorCode === "api_key_missing") return "Unauthorized (API key missing)";
    if (errorCode === "api_key_invalid") return "Unauthorized (API key invalid)";
    return "Unauthorized (" + detailText + ")";
  }

  function formatOrchRequestError(meta) {
    if (!meta || typeof meta !== "object") return "Unavailable";
    if (meta.timeout === true) return "Server Offline";
    if (meta.networkError === true || meta.status === 0) return "Server Offline";
    if (meta.status === 401 || meta.status === 403) {
      return getOrchUnauthorizedMessage(meta.payload, meta.rawText);
    }
    if (meta.status === 502 || meta.status === 503 || meta.status === 504) {
      return "Server Offline";
    }
    var detail = "";
    if (meta.payload && typeof meta.payload === "object") {
      if (hasValue(meta.payload.error)) detail = String(meta.payload.error).trim();
      if (!hasValue(detail) && hasValue(meta.payload.reason)) detail = String(meta.payload.reason).trim();
      if (!hasValue(detail) && hasValue(meta.payload.message)) detail = String(meta.payload.message).trim();
    }
    if (!hasValue(detail)) detail = compactText(meta.rawText, 180);
    if (!hasValue(detail)) detail = "error";
    return "HTTP " + String(meta.status || 0) + ": " + detail;
  }

  function requestOrchRaw(method, endpointPath, payload, callback) {
    var url = buildOrchApiUrl(endpointPath);
    var apiKey = getOrchApiKeyForRequest();
    if (!hasValue(apiKey)) {
      var missingPayload = { ok: false, error: "api_key_missing" };
      var missingMeta = {
        url: url,
        status: 401,
        payload: missingPayload,
        rawText: "",
        timeout: false,
        networkError: false,
        missingApiKey: true
      };
      callback(getOrchUnauthorizedMessage(missingPayload, ""), missingPayload, missingMeta);
      return;
    }

    var xhr = new XMLHttpRequest();
    xhr.open(method, url, true);
    xhr.timeout = 5000;
    xhr.setRequestHeader("Cache-Control", "no-cache");
    xhr.setRequestHeader("Accept", "application/json");
    xhr.setRequestHeader("X-API-Key", String(apiKey));
    if (payload !== null && payload !== undefined) {
      xhr.setRequestHeader("Content-Type", "application/json");
    }

    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4) return;
      var rawText = hasValue(xhr.responseText) ? String(xhr.responseText) : "";
      var parsed = parseJsonMaybe(rawText);
      var meta = {
        url: url,
        status: Number(xhr.status || 0),
        payload: parsed,
        rawText: rawText,
        timeout: false,
        networkError: false
      };
      if (meta.status >= 200 && meta.status < 300) {
        if (parsed === null) {
          callback("Invalid JSON response", null, meta);
          return;
        }
        callback(null, parsed, meta);
        return;
      }
      callback(formatOrchRequestError(meta), parsed, meta);
    };

    xhr.onerror = function () {
      callback(
        formatOrchRequestError({ status: 0, payload: null, rawText: "", timeout: false, networkError: true }),
        null,
        { status: 0, payload: null, rawText: "", timeout: false, networkError: true }
      );
    };

    xhr.ontimeout = function () {
      callback(
        formatOrchRequestError({ status: 0, payload: null, rawText: "", timeout: true, networkError: false }),
        null,
        { status: 0, payload: null, rawText: "", timeout: true, networkError: false }
      );
    };

    if (payload !== null && payload !== undefined) {
      xhr.send(JSON.stringify(payload));
      return;
    }
    xhr.send();
  }

  function requestOrchJson(method, endpointPath, callback) {
    requestOrchRaw(method, endpointPath, null, callback);
  }

  function requestOrchJsonWithBody(method, endpointPath, body, callback) {
    requestOrchRaw(method, endpointPath, body || {}, callback);
  }

  function toBoolValue(value, fallback) {
    if (value === true || value === false) return value;
    if (typeof value === "number") return value !== 0;
    if (typeof value === "string") {
      var raw = value.trim().toLowerCase();
      if (raw === "1" || raw === "true" || raw === "yes" || raw === "on") return true;
      if (raw === "0" || raw === "false" || raw === "no" || raw === "off") return false;
    }
    return fallback;
  }

  function clampIntValue(value, min, max, fallback) {
    var num = parseInt(value, 10);
    if (isNaN(num) || !isFinite(num)) num = fallback;
    if (num < min) num = min;
    if (num > max) num = max;
    return num;
  }

  function hasOwn(obj, key) {
    return !!(obj && typeof obj === "object" && Object.prototype.hasOwnProperty.call(obj, key));
  }

  function resolveOrchEnabled(cfg) {
    if (!cfg || typeof cfg !== "object") return true;
    if (hasOwn(cfg, "enabled")) return toBoolValue(cfg.enabled, true);
    if (hasOwn(cfg, "logic_enabled")) return toBoolValue(cfg.logic_enabled, true);
    if (hasOwn(cfg, "orch_enabled")) return toBoolValue(cfg.orch_enabled, true);
    if (hasOwn(cfg, "disabled")) return !toBoolValue(cfg.disabled, false);
    if (hasOwn(cfg, "logic_disabled")) return !toBoolValue(cfg.logic_disabled, false);
    if (hasOwn(cfg, "orch_disabled")) return !toBoolValue(cfg.orch_disabled, false);
    return true;
  }

  function normalizeOrchConfig(raw) {
    var cfg = raw && typeof raw === "object" ? raw : {};
    return {
      enabled: resolveOrchEnabled(cfg),
      news_filter_enabled: toBoolValue(cfg.news_filter_enabled, true),
      news_min_importance: clampIntValue(cfg.news_min_importance, 0, 2, 2),
      news_window_before_min: clampIntValue(cfg.news_window_before_min, 0, 240, 15),
      news_window_after_min: clampIntValue(cfg.news_window_after_min, 0, 240, 15)
    };
  }

  function applyOrchConfigToControls(cfg) {
    var value = normalizeOrchConfig(cfg);
    if (els.orchCfgEnabled) els.orchCfgEnabled.checked = value.enabled;
    if (window && window.console && typeof window.console.debug === "function") {
      window.console.debug("[ORCH] Toggle state:", !!value.enabled);
    }
    if (els.orchCfgNewsEnabled) els.orchCfgNewsEnabled.checked = value.news_filter_enabled;
    if (els.orchCfgMinImportance) els.orchCfgMinImportance.value = String(value.news_min_importance);
    if (els.orchCfgWindowBefore) els.orchCfgWindowBefore.value = String(value.news_window_before_min);
    if (els.orchCfgWindowAfter) els.orchCfgWindowAfter.value = String(value.news_window_after_min);
  }

  function readOrchConfigFromControls() {
    var toggleState = els.orchCfgEnabled ? !!els.orchCfgEnabled.checked : true;
    if (window && window.console && typeof window.console.debug === "function") {
      window.console.debug("Toggle state:", toggleState);
      window.console.debug("Sending enabled:", toggleState);
    }
    var cfg = normalizeOrchConfig({
      enabled: toggleState,
      disabled: !toggleState,
      news_filter_enabled: els.orchCfgNewsEnabled ? els.orchCfgNewsEnabled.checked : true,
      news_min_importance: els.orchCfgMinImportance ? els.orchCfgMinImportance.value : 2,
      news_window_before_min: els.orchCfgWindowBefore ? els.orchCfgWindowBefore.value : 15,
      news_window_after_min: els.orchCfgWindowAfter ? els.orchCfgWindowAfter.value : 15
    });
    cfg.enabled = toggleState;
    cfg.disabled = !toggleState;
    applyOrchConfigToControls(cfg);
    return cfg;
  }

  function formatOrchUptime(valueSec) {
    var total = Number(valueSec);
    if (isNaN(total) || !isFinite(total) || total < 0) return "--";
    total = Math.floor(total);
    var h = Math.floor(total / 3600);
    var m = Math.floor((total % 3600) / 60);
    var s = total % 60;
    if (h > 0) return h + "h " + m + "m";
    if (m > 0) return m + "m " + s + "s";
    return s + "s";
  }

  function formatOrchTime(value) {
    if (!hasValue(value)) return "--";
    var dt = parseLogTimestamp(value) || parseTradeDate(value);
    if (!dt) return String(value);
    try {
      return dt.toLocaleString(undefined, { hour12: false });
    } catch (err) {
      return dt.toString();
    }
  }

  var orchSaveMessageTimer = null;

  function setOrchSaveMessage(text, timeoutMs) {
    state.orchPanel.saveMessage = hasValue(text) ? String(text) : "";
    if (orchSaveMessageTimer) {
      clearTimeout(orchSaveMessageTimer);
      orchSaveMessageTimer = null;
    }
    if (timeoutMs && timeoutMs > 0 && hasValue(text)) {
      var snapshot = state.orchPanel.saveMessage;
      orchSaveMessageTimer = setTimeout(function () {
        if (state.orchPanel.saveMessage === snapshot) {
          state.orchPanel.saveMessage = "";
          renderOrchPanel();
        }
      }, timeoutMs);
    }
  }

  function buildOrchDecisionKey(item, index) {
    var ts = hasValue(item && item.time_utc) ? String(item.time_utc) : "";
    var symbol = hasValue(item && item.symbol) ? String(item.symbol) : "";
    var reason = hasValue(item && item.reason) ? String(item.reason) : "";
    return ts + "|" + symbol + "|" + reason + "|" + String(index);
  }

  function renderOrchDecisionsTable() {
    if (!els.orchDecisionsBody) return;
    var items = Array.isArray(state.orchPanel.decisions) ? state.orchPanel.decisions : [];
    if (!items.length) {
      els.orchDecisionsBody.innerHTML = '<tr><td colspan="5" class="muted">No decisions yet.</td></tr>';
      return;
    }

    var rows = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i] || {};
      var key = buildOrchDecisionKey(item, i);
      var allow = item.allow === true;
      var pillClass = allow ? "pill pill-open" : "pill pill-closed";
      var pillText = allow ? "ALLOW" : "BLOCK";
      var latency = hasValue(item.latency_ms) ? (String(item.latency_ms) + " ms") : "--";
      rows.push(
        '<tr class="orch-decision-row" data-orch-decision-key="' + esc(key) + '">' +
          '<td>' + esc(formatOrchTime(item.time_utc)) + '</td>' +
          '<td>' + esc(hasValue(item.symbol) ? item.symbol : "--") + '</td>' +
          '<td><span class="' + pillClass + '">' + esc(pillText) + '</span></td>' +
          '<td>' + esc(hasValue(item.reason) ? item.reason : "--") + '</td>' +
          '<td>' + esc(latency) + '</td>' +
        '</tr>'
      );

      if (state.orchPanel.expandedDecisionKey === key) {
        var detailText = "--";
        try {
          if (item.details && typeof item.details === "object") {
            detailText = JSON.stringify(item.details, null, 2);
          } else if (hasValue(item.details)) {
            detailText = String(item.details);
          }
        } catch (err) {
          detailText = String(item.details || "--");
        }
        rows.push(
          '<tr class="orch-decision-details">' +
            '<td colspan="5"><pre class="orch-detail-pre">' + esc(detailText) + '</pre></td>' +
          '</tr>'
        );
      }
    }
    els.orchDecisionsBody.innerHTML = rows.join("");
  }

  function renderOrchPanel() {
    if (!els.orchPanelStatusPill) return;
    var health = state.orchPanel.health || {};
    var status = hasValue(state.orchPanel.status) ? String(state.orchPanel.status) : "offline";
    var online = status === "online";

    if (els.orchPanelStatusPill) {
      if (status === "online") {
        els.orchPanelStatusPill.className = "pill pill-open";
        els.orchPanelStatusPill.textContent = "ONLINE";
      } else if (status === "unauthorized") {
        els.orchPanelStatusPill.className = "pill pill-unauthorized";
        els.orchPanelStatusPill.textContent = "UNAUTHORIZED";
      } else {
        els.orchPanelStatusPill.className = "pill pill-closed";
        els.orchPanelStatusPill.textContent = "SERVER OFFLINE";
      }
    }
    safeSetText(els.orchPanelVersion, hasValue(health.version) ? health.version : "--");
    safeSetText(els.orchPanelUptime, formatOrchUptime(health.uptime_sec));
    safeSetText(els.orchPanelLastRequest, formatOrchTime(health.last_request_utc));

    if (els.orchPanelError) {
      var errText = hasValue(state.orchPanel.error)
        ? String(state.orchPanel.error)
        : (status === "online" ? "Connected" : (status === "unauthorized" ? "Unauthorized (API key missing)" : "Server Offline"));
      els.orchPanelError.textContent = errText;
    }

    if (els.orchRefreshBtn) {
      els.orchRefreshBtn.disabled = state.orchPanel.loading === true;
    }
    if (els.orchSaveBtn) {
      els.orchSaveBtn.disabled = state.orchPanel.saving === true || status !== "online";
    }
    if (els.orchSaveMsg) {
      els.orchSaveMsg.textContent = hasValue(state.orchPanel.saveMessage) ? state.orchPanel.saveMessage : "--";
    }

    renderOrchDecisionsTable();
  }

  function refreshOrchPanel() {
    if (!els.orchPanelStatusPill) return;
    state.orchPanel.loading = true;
    state.orchPanel.error = "";
    renderOrchPanel();

    var pending = 3;
    var errors = [];
    var hasUnauthorized = false;
    var hasOffline = false;
    var healthOk = false;

    function markRequestStatus(meta) {
      if (!meta || typeof meta !== "object") return;
      var statusCode = Number(meta.status || 0);
      if (statusCode === 401 || statusCode === 403) {
        hasUnauthorized = true;
        return;
      }
      if (
        meta.timeout === true ||
        meta.networkError === true ||
        statusCode === 0 ||
        statusCode === 502 ||
        statusCode === 503 ||
        statusCode === 504
      ) {
        hasOffline = true;
      }
    }

    function doneOne() {
      pending -= 1;
      if (pending > 0) return;
      state.orchPanel.loading = false;
      if (hasUnauthorized) {
        state.orchPanel.status = "unauthorized";
        state.orchPanel.online = false;
      } else if (healthOk) {
        state.orchPanel.status = "online";
        state.orchPanel.online = true;
      } else {
        state.orchPanel.status = "offline";
        state.orchPanel.online = false;
      }
      if (errors.length) {
        state.orchPanel.error = errors[0];
      } else if (state.orchPanel.status === "unauthorized") {
        state.orchPanel.error = "Unauthorized (API key missing)";
      } else if (state.orchPanel.status === "offline" && hasOffline) {
        state.orchPanel.error = "Server Offline";
      } else {
        state.orchPanel.error = "";
      }
      renderOrchPanel();
    }

    function addPanelError(scope, errText) {
      var msg = hasValue(errText) ? String(errText) : "Unavailable";
      if (msg === "Server Offline" || msg.indexOf("Unauthorized (") === 0) {
        errors.push(msg);
        return;
      }
      errors.push(scope + ": " + msg);
    }

    requestOrchJson("GET", "/api/orch/health", function (err, data, meta) {
      markRequestStatus(meta);
      if (err || !data || data.ok !== true) {
        state.orchPanel.health = null;
        addPanelError("Health", err);
      } else {
        state.orchPanel.health = data;
        healthOk = true;
      }
      doneOne();
    });

    requestOrchJson("GET", "/api/orch/config", function (err, data, meta) {
      markRequestStatus(meta);
      if (err || !data || data.ok !== true || !data.config || typeof data.config !== "object") {
        addPanelError("Config", err);
      } else {
        state.orchPanel.config = normalizeOrchConfig(data.config);
        applyOrchConfigToControls(state.orchPanel.config);
      }
      doneOne();
    });

    requestOrchJson("GET", "/api/orch/decisions?limit=200", function (err, data, meta) {
      markRequestStatus(meta);
      if (err || !data || data.ok !== true || !Array.isArray(data.items)) {
        state.orchPanel.decisions = [];
        addPanelError("Decisions", err);
      } else {
        state.orchPanel.decisions = data.items;
      }
      doneOne();
    });
  }

  function saveOrchConfig() {
    if (state.orchPanel.saving) return;
    var persistedKey = getOrchApiKeyForRequest();
    if (window && window.console && typeof window.console.debug === "function") {
      window.console.debug("[ORCH] API key persisted (length):", persistedKey ? persistedKey.length : 0);
    }
    var payload = readOrchConfigFromControls();
    state.orchPanel.saving = true;
    setOrchSaveMessage("Saving...");
    renderOrchPanel();
    requestOrchJsonWithBody("POST", "/api/orch/config", payload, function (err, data, meta) {
      state.orchPanel.saving = false;
      if (err || !data || data.ok !== true || !data.config || typeof data.config !== "object") {
        setOrchSaveMessage("Save failed", 1800);
        state.orchPanel.error = err || "Failed to save orchestrator config";
        if (meta && (meta.status === 401 || meta.status === 403)) {
          state.orchPanel.status = "unauthorized";
          state.orchPanel.online = false;
        } else if (meta && (meta.timeout === true || meta.networkError === true || meta.status === 0)) {
          state.orchPanel.status = "offline";
          state.orchPanel.online = false;
        }
        renderOrchPanel();
        return;
      }
      state.orchPanel.config = normalizeOrchConfig(data.config);
      applyOrchConfigToControls(state.orchPanel.config);
      setOrchSaveMessage("Saved", 1400);
      state.orchPanel.error = "";
      state.orchPanel.status = "online";
      state.orchPanel.online = true;
      refreshOrchPanel();
    });
  }

  function showToast(message, kind) {
    if (!els.toastHost || !hasValue(message)) return;
    var type = String(kind || "success").toLowerCase();
    if (type !== "success" && type !== "error") type = "success";

    var node = document.createElement("div");
    node.className = "toast toast-" + type;
    node.textContent = String(message);
    var seq = ++toastSeq;
    node.setAttribute("data-toast-seq", String(seq));
    els.toastHost.appendChild(node);
    requestAnimationFrame(function () {
      node.classList.add("is-visible");
    });

    setTimeout(function () {
      node.classList.remove("is-visible");
      setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 180);
    }, 2200);
  }

  function isToolsDropdownOpen() {
    return !!(els.toolsDropdown && els.toolsDropdown.classList.contains("is-open"));
  }

  function closeToolsDropdown() {
    if (!els.toolsDropdown) return;
    els.toolsDropdown.classList.remove("is-open");
    if (els.toolsDropdownBtn) els.toolsDropdownBtn.setAttribute("aria-expanded", "false");
    if (els.toolsDropdownMenu) els.toolsDropdownMenu.classList.add("is-hidden");
  }

  function toggleToolsDropdown() {
    if (!els.toolsDropdown || !els.toolsDropdownMenu) return;
    var next = !isToolsDropdownOpen();
    els.toolsDropdown.classList.toggle("is-open", next);
    els.toolsDropdownMenu.classList.toggle("is-hidden", !next);
    if (els.toolsDropdownBtn) els.toolsDropdownBtn.setAttribute("aria-expanded", next ? "true" : "false");
  }

  function isNotesModalOpen() {
    return !!(els.notesModal && els.notesModal.classList.contains("is-open"));
  }

  function isCalcModalOpen() {
    return !!(els.calcModal && els.calcModal.classList.contains("is-open"));
  }

  function setNotesStatusText(text) {
    state.tools.notes.statusText = hasValue(text) ? String(text) : "--";
    if (els.notesStatusText) els.notesStatusText.textContent = state.tools.notes.statusText;
  }

  function clearNotesAutosaveTimer() {
    if (notesAutosaveTimer) {
      clearTimeout(notesAutosaveTimer);
      notesAutosaveTimer = null;
    }
  }

  function normalizeNoteItem(raw) {
    if (!raw || typeof raw !== "object") return null;
    var id = parseInt(raw.id, 10);
    if (isNaN(id) || !isFinite(id) || id <= 0) return null;
    var title = hasValue(raw.title) ? String(raw.title).trim() : "Untitled";
    if (!hasValue(title)) title = "Untitled";
    var body = raw.body === null || raw.body === undefined ? "" : String(raw.body);
    return {
      id: id,
      title: title,
      body: body,
      created_at: hasValue(raw.created_at) ? String(raw.created_at) : "",
      updated_at: hasValue(raw.updated_at) ? String(raw.updated_at) : ""
    };
  }

  function upsertNoteItem(item) {
    var note = normalizeNoteItem(item);
    if (!note) return null;
    var items = state.tools.notes.items;
    var replaced = false;
    for (var i = 0; i < items.length; i++) {
      if (Number(items[i].id) === Number(note.id)) {
        items[i] = note;
        replaced = true;
        break;
      }
    }
    if (!replaced) items.unshift(note);
    items.sort(function (a, b) {
      var ta = Date.parse(a.updated_at || "") || 0;
      var tb = Date.parse(b.updated_at || "") || 0;
      if (ta !== tb) return tb - ta;
      return Number(b.id || 0) - Number(a.id || 0);
    });
    return note;
  }

  function getSelectedNoteItem() {
    var selectedId = Number(state.tools.notes.selectedId || 0);
    if (!selectedId) return null;
    var items = state.tools.notes.items;
    for (var i = 0; i < items.length; i++) {
      if (Number(items[i].id) === selectedId) return items[i];
    }
    return null;
  }

  function renderNotesList() {
    if (!els.notesList) return;
    var items = Array.isArray(state.tools.notes.items) ? state.tools.notes.items : [];
    if (!items.length) {
      els.notesList.innerHTML = '<div class="notes-empty muted">No notes yet.</div>';
      return;
    }
    var selectedId = Number(state.tools.notes.selectedId || 0);
    var rows = [];
    for (var i = 0; i < items.length; i++) {
      var note = items[i];
      var active = Number(note.id) === selectedId;
      rows.push(
        '<button class="notes-list-item' + (active ? ' is-active' : '') + '" type="button" data-note-id="' + esc(note.id) + '">' +
          '<div class="notes-list-title">' + esc(note.title) + '</div>' +
          '<div class="notes-list-updated">' + esc(formatOrchTime(note.updated_at)) + '</div>' +
        '</button>'
      );
    }
    els.notesList.innerHTML = rows.join("");
  }

  function syncNotesEditorFromSelection() {
    var note = getSelectedNoteItem();
    var hasSelection = !!note;

    notesEditorSyncing = true;
    if (els.notesTitleInput) {
      els.notesTitleInput.value = hasSelection ? note.title : "";
      els.notesTitleInput.disabled = !hasSelection;
    }
    if (els.notesBodyInput) {
      els.notesBodyInput.value = hasSelection ? note.body : "";
      els.notesBodyInput.disabled = !hasSelection;
    }
    notesEditorSyncing = false;

    if (els.notesSaveBtn) {
      els.notesSaveBtn.disabled = !hasSelection || state.tools.notes.saving;
    }
    if (els.notesDeleteBtn) {
      els.notesDeleteBtn.disabled = !hasSelection || state.tools.notes.saving;
    }
    if (!hasSelection) {
      state.tools.notes.dirty = false;
      clearNotesAutosaveTimer();
      setNotesStatusText("--");
    }
  }

  function loadNoteDetail(noteId) {
    var id = parseInt(noteId, 10);
    if (isNaN(id) || !isFinite(id) || id <= 0) return;
    var token = ++notesDetailToken;
    requestJson("GET", "/api/notes/" + encodeURIComponent(id), function (err, data) {
      if (token !== notesDetailToken) return;
      if (err || !data || data.ok !== true || !data.item) return;
      var note = upsertNoteItem(data.item);
      if (!note) return;
      if (Number(state.tools.notes.selectedId || 0) === Number(note.id)) {
        notesEditorSyncing = true;
        if (els.notesTitleInput) els.notesTitleInput.value = note.title;
        if (els.notesBodyInput) els.notesBodyInput.value = note.body;
        notesEditorSyncing = false;
      }
      renderNotesList();
    });
  }

  function loadNotesList() {
    state.tools.notes.loading = true;
    setNotesStatusText("Loading...");
    requestJson("GET", "/api/notes?limit=50&offset=0", function (err, data) {
      state.tools.notes.loading = false;
      if (err || !data || data.ok !== true || !Array.isArray(data.items)) {
        setNotesStatusText("Load failed");
        showToast("Failed to load notes", "error");
        return;
      }
      var normalized = [];
      for (var i = 0; i < data.items.length; i++) {
        var note = normalizeNoteItem(data.items[i]);
        if (note) normalized.push(note);
      }
      state.tools.notes.items = normalized;

      var selectedId = Number(state.tools.notes.selectedId || 0);
      var hasSelected = false;
      for (var j = 0; j < normalized.length; j++) {
        if (Number(normalized[j].id) === selectedId) {
          hasSelected = true;
          break;
        }
      }
      if (!hasSelected) {
        state.tools.notes.selectedId = normalized.length ? normalized[0].id : null;
      }
      state.tools.notes.dirty = false;
      renderNotesList();
      syncNotesEditorFromSelection();

      var selected = getSelectedNoteItem();
      if (selected) {
        loadNoteDetail(selected.id);
        setNotesStatusText("Loaded");
      } else {
        setNotesStatusText("No notes");
      }
    });
  }

  function scheduleNotesAutosave() {
    clearNotesAutosaveTimer();
    if (!state.tools.notes.dirty) return;
    notesAutosaveTimer = setTimeout(function () {
      notesAutosaveTimer = null;
      saveSelectedNote(false);
    }, NOTES_AUTOSAVE_MS);
  }

  function saveSelectedNote(manual, done) {
    if (typeof done !== "function") done = function () {};
    var note = getSelectedNoteItem();
    if (!note) {
      done(false);
      return;
    }
    if (state.tools.notes.saving) {
      done(false);
      return;
    }
    if (!manual && !state.tools.notes.dirty) {
      done(true);
      return;
    }
    if (notesEditorSyncing) {
      done(false);
      return;
    }

    var title = els.notesTitleInput ? String(els.notesTitleInput.value || "").trim() : "";
    var body = els.notesBodyInput ? String(els.notesBodyInput.value || "") : "";
    if (!hasValue(title)) title = "Untitled";
    if (title.length > 120) {
      setNotesStatusText("Title too long");
      if (manual) showToast("Title must be at most 120 characters", "error");
      done(false);
      return;
    }
    if (body.length > 50000) {
      setNotesStatusText("Body too long");
      if (manual) showToast("Body must be at most 50000 characters", "error");
      done(false);
      return;
    }

    state.tools.notes.saving = true;
    if (els.notesSaveBtn) els.notesSaveBtn.disabled = true;
    setNotesStatusText(manual ? "Saving..." : "Auto-saving...");
    requestJsonWithBody("PUT", "/api/notes/" + encodeURIComponent(note.id), { title: title, body: body }, function (err, data) {
      state.tools.notes.saving = false;
      if (els.notesSaveBtn) els.notesSaveBtn.disabled = false;
      if (err || !data || data.ok !== true || !data.item) {
        setNotesStatusText("Save failed");
        showToast("Failed to save note", "error");
        done(false);
        return;
      }
      var next = upsertNoteItem(data.item);
      if (next) state.tools.notes.selectedId = next.id;
      state.tools.notes.dirty = false;
      renderNotesList();
      syncNotesEditorFromSelection();
      setNotesStatusText("Saved " + formatOrchTime(next ? next.updated_at : new Date().toISOString()));
      if (manual) showToast("Saved", "success");
      done(true);
    });
  }

  function flushNotesPendingSave(done) {
    clearNotesAutosaveTimer();
    if (!state.tools.notes.dirty) {
      if (typeof done === "function") done(true);
      return;
    }
    saveSelectedNote(false, done);
  }

  function selectNote(noteId) {
    var nextId = parseInt(noteId, 10);
    if (isNaN(nextId) || !isFinite(nextId) || nextId <= 0) return;
    if (Number(state.tools.notes.selectedId || 0) === nextId) return;
    flushNotesPendingSave(function () {
      state.tools.notes.selectedId = nextId;
      state.tools.notes.dirty = false;
      renderNotesList();
      syncNotesEditorFromSelection();
      setNotesStatusText("Loaded");
      loadNoteDetail(nextId);
    });
  }

  function createNewNote() {
    if (state.tools.notes.saving || state.tools.notes.loading) return;
    flushNotesPendingSave(function () {
      setNotesStatusText("Creating...");
      requestJsonWithBody("POST", "/api/notes", { title: "Untitled", body: "" }, function (err, data) {
        if (err || !data || data.ok !== true || !data.item) {
          setNotesStatusText("Create failed");
          showToast("Failed to create note", "error");
          return;
        }
        var note = upsertNoteItem(data.item);
        if (note) state.tools.notes.selectedId = note.id;
        state.tools.notes.dirty = false;
        renderNotesList();
        syncNotesEditorFromSelection();
        setNotesStatusText("Created");
        showToast("Note created", "success");
      });
    });
  }

  function deleteSelectedNote() {
    var note = getSelectedNoteItem();
    if (!note) return;
    if (!window.confirm("Delete selected note?")) return;
    setNotesStatusText("Deleting...");
    requestJson("DELETE", "/api/notes/" + encodeURIComponent(note.id), function (err, data) {
      if (err || !data || data.ok !== true) {
        setNotesStatusText("Delete failed");
        showToast("Failed to delete note", "error");
        return;
      }
      var nextItems = [];
      for (var i = 0; i < state.tools.notes.items.length; i++) {
        if (Number(state.tools.notes.items[i].id) !== Number(note.id)) {
          nextItems.push(state.tools.notes.items[i]);
        }
      }
      state.tools.notes.items = nextItems;
      state.tools.notes.selectedId = nextItems.length ? nextItems[0].id : null;
      state.tools.notes.dirty = false;
      renderNotesList();
      syncNotesEditorFromSelection();
      setNotesStatusText(nextItems.length ? "Deleted" : "No notes");
      showToast("Note deleted", "success");
    });
  }

  function openNotesModal() {
    if (!els.notesModal) return;
    closeToolsDropdown();
    if (isChartModalOpen()) closeChartModal();
    if (isTradeModalOpen()) closeTradeModal();
    if (isCalcModalOpen()) closeCalcModal();
    if (isNotesModalOpen()) return;
    els.notesModal.classList.remove("is-hidden");
    requestAnimationFrame(function () {
      if (!els.notesModal) return;
      els.notesModal.classList.add("is-open");
      syncBodyModalOpen();
    });
    syncBodyModalOpen();
    loadNotesList();
    setTimeout(function () {
      if (els.notesTitleInput) {
        try { els.notesTitleInput.focus(); } catch (err) {}
      }
    }, 120);
  }

  function closeNotesModal() {
    if (!els.notesModal || !isNotesModalOpen()) return;
    clearNotesAutosaveTimer();
    if (state.tools.notes.dirty) {
      saveSelectedNote(false);
    }
    els.notesModal.classList.remove("is-open");
    syncBodyModalOpen();
    setTimeout(function () {
      if (!els.notesModal) return;
      els.notesModal.classList.add("is-hidden");
      syncBodyModalOpen();
    }, 170);
  }

  function onNotesEditorInput() {
    if (notesEditorSyncing) return;
    if (!getSelectedNoteItem()) return;
    state.tools.notes.dirty = true;
    setNotesStatusText("Unsaved changes...");
    scheduleNotesAutosave();
  }

  function renderCalcPanel() {
    if (els.calcResultValue) {
      els.calcResultValue.textContent = hasValue(state.tools.calc.resultText) ? String(state.tools.calc.resultText) : "--";
    }
    if (!els.calcHistory) return;
    var items = Array.isArray(state.tools.calc.history) ? state.tools.calc.history : [];
    if (!items.length) {
      els.calcHistory.innerHTML = '<div class="muted">No calculations yet.</div>';
      return;
    }
    var rows = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      rows.push(
        '<div class="calc-history-item">' +
          '<div><strong>' + esc(item.expression) + '</strong> = ' + esc(item.result) + '</div>' +
          '<div class="muted">' + esc(formatOrchTime(item.time_utc)) + '</div>' +
        '</div>'
      );
    }
    els.calcHistory.innerHTML = rows.join("");
  }

  function tokenizeCalcExpression(expression) {
    var text = String(expression || "");
    var tokens = [];
    var i = 0;
    while (i < text.length) {
      var ch = text.charAt(i);
      if (ch === " " || ch === "\t" || ch === "\n" || ch === "\r") {
        i += 1;
        continue;
      }
      if ((ch >= "0" && ch <= "9") || ch === ".") {
        var start = i;
        var dots = 0;
        var digits = 0;
        while (i < text.length) {
          var c = text.charAt(i);
          if (c >= "0" && c <= "9") {
            digits += 1;
            i += 1;
            continue;
          }
          if (c === ".") {
            dots += 1;
            if (dots > 1) throw new Error("Invalid number");
            i += 1;
            continue;
          }
          break;
        }
        if (digits === 0) throw new Error("Invalid number");
        tokens.push({ type: "number", value: parseFloat(text.slice(start, i)) });
        continue;
      }
      if (ch === "+" || ch === "-" || ch === "*" || ch === "/" || ch === "(" || ch === ")" || ch === "%") {
        tokens.push({ type: ch });
        i += 1;
        continue;
      }
      throw new Error("Unsupported character: " + ch);
    }
    return tokens;
  }

  function parseCalcExpression(expression) {
    var tokens = tokenizeCalcExpression(expression);
    if (!tokens.length) throw new Error("Expression is empty");
    var index = 0;

    function peek() {
      return index < tokens.length ? tokens[index] : null;
    }

    function read() {
      var token = peek();
      if (token) index += 1;
      return token;
    }

    function parsePrimary() {
      var token = peek();
      if (!token) throw new Error("Unexpected end of expression");
      if (token.type === "(") {
        read();
        var value = parseExpr();
        var closeToken = read();
        if (!closeToken || closeToken.type !== ")") throw new Error("Missing closing parenthesis");
        return value;
      }
      if (token.type === "number") {
        read();
        return token.value;
      }
      throw new Error("Unexpected token");
    }

    function parseFactor() {
      var sign = 1;
      while (true) {
        var token = peek();
        if (!token) break;
        if (token.type === "+") {
          read();
          continue;
        }
        if (token.type === "-") {
          read();
          sign *= -1;
          continue;
        }
        break;
      }
      var value = parsePrimary() * sign;
      while (true) {
        var next = peek();
        if (!next || next.type !== "%") break;
        read();
        value = value / 100;
      }
      return value;
    }

    function parseTerm() {
      var value = parseFactor();
      while (true) {
        var token = peek();
        if (!token || (token.type !== "*" && token.type !== "/")) break;
        read();
        var right = parseFactor();
        if (token.type === "*") {
          value *= right;
        } else {
          if (right === 0) throw new Error("Division by zero");
          value /= right;
        }
      }
      return value;
    }

    function parseExpr() {
      var value = parseTerm();
      while (true) {
        var token = peek();
        if (!token || (token.type !== "+" && token.type !== "-")) break;
        read();
        var right = parseTerm();
        if (token.type === "+") value += right;
        else value -= right;
      }
      return value;
    }

    var result = parseExpr();
    if (index < tokens.length) throw new Error("Invalid expression");
    if (!isFinite(result)) throw new Error("Invalid result");
    return result;
  }

  function formatCalcResult(value) {
    var num = Number(value);
    if (isNaN(num) || !isFinite(num)) return "--";
    if (Math.abs(num) < 1e-12) num = 0;
    var rounded = Number(num.toFixed(10));
    return String(rounded);
  }

  function evaluateCalculator() {
    if (!els.calcExpressionInput) return;
    var expression = String(els.calcExpressionInput.value || "").trim();
    if (!hasValue(expression)) return;
    try {
      var value = parseCalcExpression(expression);
      var resultText = formatCalcResult(value);
      state.tools.calc.resultText = resultText;
      state.tools.calc.history.unshift({
        expression: expression,
        result: resultText,
        time_utc: new Date().toISOString()
      });
      if (state.tools.calc.history.length > CALC_HISTORY_LIMIT) {
        state.tools.calc.history = state.tools.calc.history.slice(0, CALC_HISTORY_LIMIT);
      }
      renderCalcPanel();
    } catch (err) {
      state.tools.calc.resultText = "Error";
      renderCalcPanel();
      showToast(err && err.message ? err.message : "Invalid expression", "error");
    }
  }

  function clearCalculator() {
    state.tools.calc.resultText = "--";
    state.tools.calc.history = [];
    if (els.calcExpressionInput) els.calcExpressionInput.value = "";
    renderCalcPanel();
  }

  function openCalcModal() {
    if (!els.calcModal) return;
    closeToolsDropdown();
    if (isChartModalOpen()) closeChartModal();
    if (isTradeModalOpen()) closeTradeModal();
    if (isNotesModalOpen()) closeNotesModal();
    if (isCalcModalOpen()) return;
    els.calcModal.classList.remove("is-hidden");
    requestAnimationFrame(function () {
      if (!els.calcModal) return;
      els.calcModal.classList.add("is-open");
      syncBodyModalOpen();
    });
    syncBodyModalOpen();
    renderCalcPanel();
    setTimeout(function () {
      if (els.calcExpressionInput) {
        try { els.calcExpressionInput.focus(); } catch (err) {}
      }
    }, 120);
  }

  function closeCalcModal() {
    if (!els.calcModal || !isCalcModalOpen()) return;
    els.calcModal.classList.remove("is-open");
    syncBodyModalOpen();
    setTimeout(function () {
      if (!els.calcModal) return;
      els.calcModal.classList.add("is-hidden");
      syncBodyModalOpen();
    }, 170);
  }

  function initNotesModal() {
    if (!els.notesModal) return;
    if (els.notesModalClose) els.notesModalClose.onclick = closeNotesModal;
    if (els.notesModalBackdrop) els.notesModalBackdrop.onclick = closeNotesModal;
    if (els.notesNewBtn) els.notesNewBtn.onclick = createNewNote;
    if (els.notesSaveBtn) {
      els.notesSaveBtn.onclick = function () {
        saveSelectedNote(true);
      };
    }
    if (els.notesDeleteBtn) els.notesDeleteBtn.onclick = deleteSelectedNote;
    if (els.notesTitleInput) els.notesTitleInput.addEventListener("input", onNotesEditorInput);
    if (els.notesBodyInput) els.notesBodyInput.addEventListener("input", onNotesEditorInput);
    if (els.notesList) {
      els.notesList.onclick = function (event) {
        var node = event.target;
        while (node && node !== els.notesList && !node.getAttribute("data-note-id")) {
          node = node.parentNode;
        }
        if (!node || node === els.notesList) return;
        selectNote(node.getAttribute("data-note-id"));
      };
    }
    syncNotesEditorFromSelection();
    setNotesStatusText(state.tools.notes.statusText);
  }

  function initCalcModal() {
    if (!els.calcModal) return;
    if (els.calcModalClose) els.calcModalClose.onclick = closeCalcModal;
    if (els.calcModalBackdrop) els.calcModalBackdrop.onclick = closeCalcModal;
    if (els.calcEvaluateBtn) els.calcEvaluateBtn.onclick = evaluateCalculator;
    if (els.calcClearBtn) els.calcClearBtn.onclick = clearCalculator;
    if (els.calcExpressionInput) {
      els.calcExpressionInput.addEventListener("keydown", function (event) {
        var key = event.key || event.keyCode;
        if (key === "Enter" || key === 13) {
          event.preventDefault();
          evaluateCalculator();
        }
      });
    }
    renderCalcPanel();
  }

  function safeSetText(el, value) {
    if (!el) return;
    el.textContent = hasValue(value) ? value : "--";
  }

  function setKpiValue(el, value, digits, suffix) {
    if (!el) return;
    var num = Number(value);
    var text = fmt(value, digits);
    el.textContent = text === "--" ? "--" : text + (suffix || "");
    el.className = "kpi-value";
    if (!isNaN(num) && isFinite(num)) {
      if (num > 0) el.className += " is-positive";
      if (num < 0) el.className += " is-negative";
    }
  }

  function setStatValue(el, value) {
    if (!el) return;
    el.textContent = fmt(value, 2);
  }

  function updateHeader() {
    if (els.lastUpdated) {
      els.lastUpdated.textContent = state.lastUpdated ? formatTime(state.lastUpdated) : "--";
    }
    if (els.headerSymbol) {
      var symbol = "--";
      for (var i = 0; i < state.trades.length; i++) {
        if (hasValue(state.trades[i].symbol)) {
          symbol = state.trades[i].symbol;
          break;
        }
      }
      els.headerSymbol.textContent = symbol;
    }
  }

  function updateTabUnderline() {
    if (!els.tabUnderline || !els.tabsWrap) return;
    var active = document.querySelector(".tab.is-active");
    if (!active) return;
    var tabsRect = els.tabsWrap.getBoundingClientRect();
    var tabRect = active.getBoundingClientRect();
    var left = tabRect.left - tabsRect.left;
    els.tabUnderline.style.width = tabRect.width + "px";
    els.tabUnderline.style.transform = "translateX(" + left + "px)";
    els.tabUnderline.style.opacity = "1";
  }


  function setActiveTab(name, save) {
    var target = name || "dashboard";
    state.activeTab = target;
    if (save !== false) {
      try {
        localStorage.setItem("mt5tl.activeTab", target);
      } catch (err) {}
    }

    var tabs = document.querySelectorAll("[data-tab]");
    for (var i = 0; i < tabs.length; i++) {
      var tab = tabs[i];
      tab.classList.toggle("is-active", tab.getAttribute("data-tab") === target);
    }

    var panels = document.querySelectorAll(".tab-panel");
    var targetPanel = document.getElementById("tab-" + target);
    if (!targetPanel) console.warn("Missing panel: #tab-" + target);
    for (var j = 0; j < panels.length; j++) {
      var panel = panels[j];
      panel.classList.remove("is-active", "is-visible");
    }
    if (targetPanel) {
      targetPanel.classList.add("is-active");
      requestAnimationFrame(function () {
        targetPanel.classList.add("is-visible");
      });
    }

    requestAnimationFrame(updateTabUnderline);

    if (target === "trades") {
      renderTradesTable();
    }
    if (target === "news") {
      syncNewsFilterUiFromState();
      if (!state.newsLoadedOnce) {
        refreshNewsData(true);
      } else {
        renderNewsTable();
        refreshNewsHealth();
      }
    }
    if (target === "analytics") {
      startAnalyticsThrottle();
      setTimeout(function () {
        renderAnalytics();
        var keys = ["equity", "drawdown", "winHour", "dist", "dailyPl"];
        for (var k = 0; k < keys.length; k++) {
          if (_apexCharts[keys[k]]) {
            try { _apexCharts[keys[k]].resize(); } catch (e) {}
          }
        }
      }, 80);
    } else {
      stopAnalyticsThrottle();
    }

    if (target === "system") {
      refreshSystemStatus();
      refreshOrchPanel();
    }
    if (target === "marketwatch") {
      setTimeout(function () {
        activateMarketWatchTab();
      }, 40);
    } else {
      stopMarketWatchLivePolling();
      marketWatchStopNextCandleCountdown();
      if (marketWatch.indicatorsTimer) {
        clearInterval(marketWatch.indicatorsTimer);
        marketWatch.indicatorsTimer = null;
      }
    }
    resetSystemStatusTimer();
  }

  function initTabs() {
    var tabs = document.querySelectorAll("[data-tab]");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener("click", function (event) {
        var name = event.currentTarget.getAttribute("data-tab");
        setActiveTab(name);
      });
    }
    try {
      var stored = localStorage.getItem("mt5tl.activeTab");
      setActiveTab(stored || "dashboard", false);
    } catch (err) {
      setActiveTab("dashboard", false);
    }
  }

  function setMarketWatchStatus(text) {
    if (!els.marketWatchStatus) return;
    els.marketWatchStatus.textContent = hasValue(text) ? String(text) : "History mode";
  }

  function marketWatchDebugLog() {
    if (!MW_HISTORY_DEBUG) return;
    try {
      var args = Array.prototype.slice.call(arguments);
      args.unshift("[MW][DEBUG]");
      console.log.apply(console, args);
    } catch (e) {}
  }

  function marketWatchGetActiveTf() {
    if (els.marketWatchTfButtons && els.marketWatchTfButtons.length) {
      for (var i = 0; i < els.marketWatchTfButtons.length; i++) {
        if (els.marketWatchTfButtons[i].classList.contains("is-active")) {
          return String(els.marketWatchTfButtons[i].getAttribute("data-mw-tf") || "M1").toUpperCase();
        }
      }
    }
    return "M1";
  }

  function marketWatchGetActiveMode() {
    if (els.marketWatchModeButtons && els.marketWatchModeButtons.length) {
      for (var i = 0; i < els.marketWatchModeButtons.length; i++) {
        if (els.marketWatchModeButtons[i].classList.contains("is-active")) {
          return String(els.marketWatchModeButtons[i].getAttribute("data-mw-mode") || "HISTORY").toUpperCase();
        }
      }
    }
    return "HISTORY";
  }

  function marketWatchSetActiveButton(buttons, attrName, value) {
    if (!buttons || !buttons.length) return;
    var target = String(value || "").toUpperCase();
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      var current = String(btn.getAttribute(attrName) || "").toUpperCase();
      var active = current === target;
      btn.classList.toggle("is-active", active);
      if (active) {
        if (btn.classList.contains("btn-ghost")) btn.classList.remove("btn-ghost");
      } else {
        if (!btn.classList.contains("btn-ghost")) btn.classList.add("btn-ghost");
      }
    }
  }

  function marketWatchTimeframeToSec(tf) {
    var key = String(tf || "M1").toUpperCase();
    if (key === "M1") return 60;
    if (key === "M5") return 300;
    if (key === "M15") return 900;
    if (key === "H1") return 3600;
    return 60;
  }

  function marketWatchExtractLastCandleTimeMs(candles) {
    var list = Array.isArray(candles) ? candles : (marketWatch.candles || []);
    if (!list.length) return NaN;
    var last = list[list.length - 1] || {};
    var t = Number(last.time !== undefined ? last.time : last.timestamp);
    if (!isFinite(t)) return NaN;
    if (Math.abs(t) > 10000000000) return Math.floor(t); // already in ms
    return Math.floor(t * 1000); // seconds -> ms
  }

  function marketWatchFormatRemaining(remainingMs) {
    var totalSec = Math.max(0, Math.floor(Number(remainingMs) / 1000));
    var hh = Math.floor(totalSec / 3600);
    var mm = Math.floor((totalSec % 3600) / 60);
    var ss = totalSec % 60;
    if (hh > 0) return pad2(hh) + ":" + pad2(mm) + ":" + pad2(ss);
    return pad2(mm) + ":" + pad2(ss);
  }

  function marketWatchSetNextCandleText(text) {
    if (!els.mwInfoNextCandle) return;
    var next = hasValue(text) ? String(text) : "--";
    if (marketWatch.nextCandleText === next && els.mwInfoNextCandle.textContent === next) return;
    marketWatch.nextCandleText = next;
    els.mwInfoNextCandle.textContent = next;
  }

  function marketWatchRenderNextCandleCountdown() {
    if (!els.mwInfoNextCandle) return;
    var mode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
    if (mode !== "LIVE") {
      marketWatchSetNextCandleText("Paused");
      return;
    }

    var tfSec = Number(marketWatchTimeframeToSec(marketWatch.tf || marketWatchGetActiveTf() || "M1"));
    if (!isFinite(tfSec) || tfSec <= 0) tfSec = 60;
    var nowMs = Date.now();
    var nowSec = Math.floor(nowMs / 1000);
    var clockNextMs = (Math.floor(nowSec / tfSec) + 1) * tfSec * 1000;
    var lastOpenMs = Number(marketWatch.lastCandleTimeMs);
    var nextMs = NaN;
    var fromLastBar = false;

    if (isFinite(lastOpenMs) && lastOpenMs > 0) {
      nextMs = Math.floor(lastOpenMs + tfSec * 1000);
      fromLastBar = true;
    } else {
      nextMs = clockNextMs;
    }

    var remainingMs = nextMs - nowMs;
    if (fromLastBar && remainingMs <= 0) {
      // Live feed can lag or deliver stale candles; fallback to wall-clock countdown.
      nextMs = clockNextMs;
      remainingMs = nextMs - nowMs;
      marketWatchDebugLog(
        "[COUNTDOWN] stale last bar fallback",
        "lastOpenMs=", lastOpenMs,
        "nextFromBarMs=", Math.floor(lastOpenMs + tfSec * 1000),
        "clockNextMs=", clockNextMs
      );
    }

    if (!isFinite(remainingMs) || remainingMs <= 0) {
      marketWatchSetNextCandleText("Updating...");
      return;
    }

    marketWatchSetNextCandleText("Next candle in " + marketWatchFormatRemaining(remainingMs));
  }

  function marketWatchStopNextCandleCountdown() {
    if (marketWatch.nextCandleTimer) {
      clearInterval(marketWatch.nextCandleTimer);
      marketWatch.nextCandleTimer = null;
    }
  }

  function marketWatchStartNextCandleCountdown(restart) {
    if (restart) marketWatchStopNextCandleCountdown();
    if (marketWatch.nextCandleTimer) return;
    marketWatch.nextCandleTimer = setInterval(function () {
      marketWatchRenderNextCandleCountdown();
    }, MW_NEXT_CANDLE_TICK_MS);
  }

  function marketWatchSyncNextCandleCountdown(candles, options) {
    var opts = options || {};
    if (Array.isArray(candles)) {
      marketWatch.lastCandleTimeMs = marketWatchExtractLastCandleTimeMs(candles);
    } else if (opts.useStateCandles) {
      marketWatch.lastCandleTimeMs = marketWatchExtractLastCandleTimeMs(marketWatch.candles);
    }

    var mode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
    var shouldRun = mode === "LIVE" && state.activeTab === "marketwatch";
    if (shouldRun) marketWatchStartNextCandleCountdown(!!opts.restart);
    else marketWatchStopNextCandleCountdown();

    marketWatchRenderNextCandleCountdown();
  }

  function marketWatchModeIsLive() {
    var mode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
    return mode === "LIVE";
  }

  function marketWatchSyncAutoFollowUI() {
    var live = marketWatchModeIsLive();
    var paused = live && !marketWatch.isAutoFollow;
    if (els.marketWatchGoLive) els.marketWatchGoLive.classList.toggle("is-hidden", !paused);
    if (els.marketWatchLivePaused) {
      els.marketWatchLivePaused.classList.toggle("is-hidden", !paused);
      els.marketWatchLivePaused.textContent = paused ? "Paused" : "";
    }
  }

  function marketWatchScrollToRealTime() {
    if (!marketWatch.chart || !marketWatchModeIsLive()) return;
    try {
      var scale = marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (scale && typeof scale.scrollToRealTime === "function") {
        scale.scrollToRealTime();
        marketWatch.programmaticFollowUntil = Date.now() + Number(marketWatch.suppressAutoFollowMs || MW_LIVE_SUPPRESS_AUTOFOLLOW_MS_DEFAULT);
      }
    } catch (e) {}
  }

  function marketWatchSetAutoFollow(enabled, options) {
    var opts = options || {};
    var next = !!enabled;
    if (!marketWatchModeIsLive()) {
      marketWatch.isAutoFollow = true;
      marketWatch.userInteractedAt = 0;
      marketWatch.isUserInteracting = false;
      marketWatchSyncAutoFollowUI();
      return;
    }
    if (marketWatch.isAutoFollow === next) {
      marketWatchSyncAutoFollowUI();
      if (next && opts.scrollNow) marketWatchScrollToRealTime();
      return;
    }
    marketWatch.isAutoFollow = next;
    if (next) {
      marketWatch.userInteractedAt = 0;
      marketWatch.isUserInteracting = false;
      if (opts.scrollNow !== false) marketWatchScrollToRealTime();
    } else {
      marketWatch.userInteractedAt = Date.now();
    }
    marketWatchSyncAutoFollowUI();
  }

  function marketWatchPauseAutoFollow() {
    if (!marketWatchModeIsLive()) return;
    var now = Date.now();
    if (isFinite(Number(marketWatch.programmaticFollowUntil)) && now < Number(marketWatch.programmaticFollowUntil)) return;
    if (!marketWatch.isAutoFollow) {
      marketWatch.userInteractedAt = now;
      marketWatchSyncAutoFollowUI();
      return;
    }
    marketWatchSetAutoFollow(false, { scrollNow: false });
  }

  function marketWatchIsInteractiveChartTarget(target) {
    var host = els.marketChartWrap || els.marketWatchChart;
    if (!host || !target || !host.contains(target)) return false;
    if (els.marketDrawToolbar && els.marketDrawToolbar.contains(target)) return false;
    if (els.marketDrawPropsPanel && els.marketDrawPropsPanel.contains(target)) return false;
    return true;
  }

  function marketWatchCaptureVisibleState() {
    if (!marketWatch.chart || !marketWatch.chart.timeScale) return null;
    try {
      var ts = marketWatch.chart.timeScale();
      if (!ts) return null;
      var logical = null;
      var timeRange = null;
      if (typeof ts.getVisibleLogicalRange === "function") logical = ts.getVisibleLogicalRange();
      if (typeof ts.getVisibleRange === "function") timeRange = ts.getVisibleRange();
      return { logical: logical || null, time: timeRange || null };
    } catch (e) {
      return null;
    }
  }

  function marketWatchRestoreVisibleState(snapshot) {
    if (!snapshot || !marketWatch.chart || !marketWatch.chart.timeScale) return;
    try {
      var ts = marketWatch.chart.timeScale();
      if (!ts) return;
      if (snapshot.logical && typeof ts.setVisibleLogicalRange === "function") {
        ts.setVisibleLogicalRange(snapshot.logical);
        return;
      }
      if (snapshot.time && typeof ts.setVisibleRange === "function") {
        ts.setVisibleRange(snapshot.time);
      }
    } catch (e) {}
  }

  function marketWatchIsAtRightEdge(logicalRange) {
    if (!logicalRange || !isFinite(Number(logicalRange.to))) return true;
    var lastLogical = marketDrawGetLastLogical();
    if (!isFinite(lastLogical)) return true;
    var threshold = Number(MW_LIVE_FOLLOW_EDGE_THRESHOLD_BARS) || 2;
    var delta = Number(logicalRange.to) - Number(lastLogical);
    return delta >= -Math.abs(threshold);
  }

  function marketWatchOnVisibleLogicalRangeChange(range) {
    if (!marketWatchModeIsLive()) return;
    if (!marketWatch.isAutoFollow) return;
    var now = Date.now();
    if (isFinite(Number(marketWatch.programmaticFollowUntil)) && now < Number(marketWatch.programmaticFollowUntil)) return;
    if (!range || !isFinite(Number(range.to))) return;
    if (marketWatchIsAtRightEdge(range)) return;
    // User moved away from right edge while follow was enabled.
    marketWatchSetAutoFollow(false, { scrollNow: false });
  }

  function bindMarketWatchLiveInteractionEvents() {
    if (marketWatch.userInteractionBound) return;
    var host = els.marketChartWrap || els.marketWatchChart;
    if (!host) return;

    host.addEventListener("wheel", function (event) {
      if (!marketWatchModeIsLive()) return;
      if (!marketWatchIsInteractiveChartTarget(event.target)) return;
      marketWatchPauseAutoFollow();
    }, { passive: true });

    host.addEventListener("pointerdown", function (event) {
      if (!marketWatchModeIsLive()) return;
      if (event.button !== 0) return;
      if (!marketWatchIsInteractiveChartTarget(event.target)) return;
      marketWatch.isUserInteracting = true;
      marketWatch.interactionStartX = Number(event.clientX) || 0;
      marketWatch.interactionStartY = Number(event.clientY) || 0;
    });

    host.addEventListener("pointermove", function (event) {
      if (!marketWatchModeIsLive()) return;
      if (!marketWatch.isUserInteracting) return;
      var dx = Math.abs((Number(event.clientX) || 0) - Number(marketWatch.interactionStartX || 0));
      var dy = Math.abs((Number(event.clientY) || 0) - Number(marketWatch.interactionStartY || 0));
      if (dx < 3 && dy < 3) return;
      marketWatch.isUserInteracting = false;
      marketWatchPauseAutoFollow();
    });

    var clearInteractionFlag = function () {
      marketWatch.isUserInteracting = false;
    };
    window.addEventListener("pointerup", clearInteractionFlag);
    window.addEventListener("pointercancel", clearInteractionFlag);
    host.addEventListener("touchstart", function (event) {
      if (!marketWatchModeIsLive()) return;
      if (!marketWatchIsInteractiveChartTarget(event.target)) return;
      marketWatchPauseAutoFollow();
    }, { passive: true });

    document.addEventListener("keydown", function (event) {
      if (state.activeTab !== "marketwatch") return;
      if (!marketWatchModeIsLive()) return;
      var key = String(event.key || "").toLowerCase();
      if (key === "+" || key === "-" || key === "=" || key === "_" || key === "pageup" || key === "pagedown") {
        marketWatchPauseAutoFollow();
      }
    });

    marketWatch.userInteractionBound = true;
  }

  function marketWatchSetEmptyChart(text) {
    if (!els.marketWatchChart) return;
    var label = hasValue(text) ? String(text) : "No data";
    var existing = els.marketWatchChart.querySelector(".marketwatch-chart-empty");
    if (!existing) {
      existing = document.createElement("div");
      existing.className = "marketwatch-chart-empty";
      els.marketWatchChart.appendChild(existing);
    }
    existing.textContent = label;
  }

  function marketWatchClearEmptyChart() {
    if (!els.marketWatchChart) return;
    var existing = els.marketWatchChart.querySelector(".marketwatch-chart-empty");
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
  }

  function ensureMarketWatchChart() {
    if (marketWatch.chart && marketWatch.candleSeries) return true;
    if (!els.marketWatchChart) return false;
    if (!window.LightweightCharts || !window.LightweightCharts.createChart) {
      setMarketWatchStatus("Chart library unavailable");
      marketWatchSetEmptyChart("Chart library unavailable");
      return false;
    }

    var host = els.marketChartWrap || els.marketWatchChart;
    var rect = host.getBoundingClientRect();
    var width = Math.max(320, Math.floor(rect.width || host.clientWidth || 800));
    var height = Math.max(240, Math.floor(rect.height || host.clientHeight || 420));

    marketWatch.chart = window.LightweightCharts.createChart(els.marketWatchChart, {
      width: width,
      height: height,
      layout: {
        background: { type: "solid", color: "#07111a" },
        textColor: "#9db3c4"
      },
      grid: {
        vertLines: { color: "rgba(112,170,202,0.10)" },
        horzLines: { color: "rgba(112,170,202,0.10)" }
      },
      rightPriceScale: {
        borderColor: "rgba(112,170,202,0.25)",
        // Keep main candle area dominant while reserving space for volume band.
        scaleMargins: { top: 0.15, bottom: 0.20 }
      },
      timeScale: {
        borderColor: "rgba(112,170,202,0.25)",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: marketDrawGetRightOffsetTarget()
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: false
      },
      handleScale: {
        mouseWheel: true,
        pinch: true,
        axisPressedMouseMove: true
      },
      crosshair: {
        mode: window.LightweightCharts.CrosshairMode.Normal
      }
    });

    var candleOpts = {
      upColor: "#2fd48a",
      downColor: "#ff6b6b",
      borderUpColor: "#2fd48a",
      borderDownColor: "#ff6b6b",
      wickUpColor: "#2fd48a",
      wickDownColor: "#ff6b6b"
    };
    var volumeOpts = {
      priceFormat: { type: "volume" },
      priceScaleId: "vol",
      // Keep volume in bottom band and visually subtle.
      scaleMargins: { top: 0.75, bottom: 0.0 },
      lastValueVisible: false,
      priceLineVisible: false
    };

    try {
      if (typeof marketWatch.chart.addCandlestickSeries === "function") {
        marketWatch.candleSeries = marketWatch.chart.addCandlestickSeries(candleOpts);
      } else if (
        typeof marketWatch.chart.addSeries === "function" &&
        window.LightweightCharts &&
        window.LightweightCharts.CandlestickSeries
      ) {
        marketWatch.candleSeries = marketWatch.chart.addSeries(window.LightweightCharts.CandlestickSeries, candleOpts);
      }
    } catch (e) {
      console.error("[MW][CHART] candlestick series init failed:", e && e.message ? e.message : e);
    }

    try {
      if (typeof marketWatch.chart.addHistogramSeries === "function") {
        marketWatch.volumeSeries = marketWatch.chart.addHistogramSeries(volumeOpts);
      } else if (
        typeof marketWatch.chart.addSeries === "function" &&
        window.LightweightCharts &&
        window.LightweightCharts.HistogramSeries
      ) {
        marketWatch.volumeSeries = marketWatch.chart.addSeries(window.LightweightCharts.HistogramSeries, volumeOpts);
      }
    } catch (e) {
      console.error("[MW][CHART] volume series init failed:", e && e.message ? e.message : e);
    }

    if (marketWatch.volumeSeries) {
      try {
        // Isolate volume scale to a compact bottom pane-like band.
        if (typeof marketWatch.chart.priceScale === "function") {
          var volScale = marketWatch.chart.priceScale("vol");
          if (volScale && typeof volScale.applyOptions === "function") {
            volScale.applyOptions({
              scaleMargins: { top: 0.75, bottom: 0.0 },
              borderVisible: false,
              visible: true
            });
          }
        }
      } catch (e) {}
    }

    if (!marketWatch.candleSeries || typeof marketWatch.candleSeries.setData !== "function") {
      setMarketWatchStatus("Chart series unavailable");
      marketWatchSetEmptyChart("Chart series unavailable");
      return false;
    }

    marketWatch.candleSeries.setData([]);
    if (marketWatch.volumeSeries) marketWatch.volumeSeries.setData([]);
    marketDrawEnsureFutureSpace();

    marketWatch.initialized = true;
    setupMarketWatchResizeObserver();
    bindMarketWatchLiveInteractionEvents();
    marketDrawEnsureOverlay();
    try {
      var tsScale = marketWatch.chart && marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (tsScale && typeof tsScale.subscribeVisibleLogicalRangeChange === "function") {
        tsScale.subscribeVisibleLogicalRangeChange(function (range) {
          marketDrawScheduleRender();
          marketWatchOnVisibleLogicalRangeChange(range);
        });
      }
      if (tsScale && typeof tsScale.subscribeVisibleTimeRangeChange === "function") {
        tsScale.subscribeVisibleTimeRangeChange(function () {
          marketDrawScheduleRender();
        });
      }
    } catch (e0) {}
    marketWatchClearEmptyChart();
    marketWatchSyncAutoFollowUI();
    marketDrawSyncContext(true);
    marketDrawScheduleRender();
    return true;
  }

  function resizeMarketWatchChart() {
    if (!marketWatch.chart || !els.marketWatchChart) return;
    var host = els.marketChartWrap || els.marketWatchChart;
    var rect = host.getBoundingClientRect();
    var width = Math.max(320, Math.floor(rect.width || host.clientWidth || 800));
    var height = Math.max(240, Math.floor(rect.height || host.clientHeight || 420));
    try {
      if (typeof marketWatch.chart.resize === "function") {
        marketWatch.chart.resize(width, height);
      } else {
        marketWatch.chart.applyOptions({ width: width, height: height });
      }
    } catch (e) {}
    marketDrawEnsureFutureSpace();
    marketDrawEnsureOverlay();
    marketDrawReclampToolbarPosition();
    marketDrawScheduleRender();
  }

  function setupMarketWatchResizeObserver() {
    if (marketWatch.resizeObserver || !window.ResizeObserver) return;
    var host = els.marketChartWrap || els.marketWatchChart;
    if (!host) return;
    marketWatch.resizeObserver = new ResizeObserver(function () {
      if (state.activeTab !== "marketwatch") return;
      resizeMarketWatchChart();
      marketDrawScheduleRender();
    });
    marketWatch.resizeObserver.observe(host);
  }

  function marketDrawState() {
    return marketWatch.draw;
  }

  function marketDrawToolName(tool) {
    return String(tool || "select").toLowerCase();
  }

  function marketDrawIsPanTool(tool) {
    var name = marketDrawToolName(tool);
    return name === "select" || name === "hand";
  }

  function marketDrawIsDrawingTool(tool) {
    return !marketDrawIsPanTool(tool);
  }

  function marketDrawShouldOverlayCaptureBackground() {
    var draw = marketDrawState();
    if (!draw) return false;
    if (draw.interaction) return true;
    if (draw.pendingPoint) return true;
    return marketDrawIsDrawingTool(draw.activeTool);
  }

  function marketDrawSyncOverlayPointerRouting() {
    var overlay = els.marketDrawOverlay;
    if (!overlay) return;
    var shouldCapture = marketDrawShouldOverlayCaptureBackground();
    overlay.classList.toggle("is-pass-through", !shouldCapture);
    overlay.style.pointerEvents = shouldCapture ? "auto" : "none";
  }

  function marketDrawResolveAccountId() {
    var account = null;
    if (state && state.systemStatus && typeof state.systemStatus === "object") {
      account = pickValue(state.systemStatus, ["account_id", "accountId", "account", "login"]);
      if (!hasValue(account) && state.systemStatus.orchestrator && typeof state.systemStatus.orchestrator === "object") {
        account = pickValue(state.systemStatus.orchestrator, ["account_id", "accountId", "account", "login"]);
      }
    }
    if (!hasValue(account) && Array.isArray(state.trades) && state.trades.length) {
      var firstTrade = state.trades[0] || {};
      account = pickValue(firstTrade, ["account_id", "accountId", "account", "login"]);
    }
    var normalized = hasValue(account) ? String(account).trim() : "";
    return normalized || "default";
  }

  function marketDrawBuildScope() {
    var symbol = String(marketWatch.symbol || "EURUSD").toUpperCase();
    var tf = String(marketWatch.tf || "M1").toUpperCase();
    var mode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
    return {
      accountId: marketDrawResolveAccountId(),
      symbol: symbol,
      tf: tf,
      mode: mode
    };
  }

  function marketDrawBuildStorageKey(scope) {
    var ctx = scope || marketDrawBuildScope();
    return MW_DRAW_STORAGE_PREFIX + ctx.accountId + ":" + ctx.symbol + ":" + ctx.tf + ":" + ctx.mode;
  }

  function marketDrawBuildLegacyStorageKeys(scope) {
    var ctx = scope || marketDrawBuildScope();
    return [
      MW_DRAW_STORAGE_PREFIX + ctx.symbol + ":" + ctx.tf + ":" + ctx.mode,
      MW_DRAW_STORAGE_PREFIX_LEGACY + ctx.symbol + ":" + ctx.tf + ":" + ctx.mode
    ];
  }

  function marketDrawBuildRemoteQuery(scope) {
    var ctx = scope || marketDrawBuildScope();
    return "account_id=" + encodeURIComponent(ctx.accountId)
      + "&symbol=" + encodeURIComponent(ctx.symbol)
      + "&tf=" + encodeURIComponent(ctx.tf)
      + "&mode=" + encodeURIComponent(ctx.mode);
  }

  function marketDrawBuildRemoteUrl(scope) {
    return MW_DRAW_REMOTE_ENDPOINT + "?" + marketDrawBuildRemoteQuery(scope);
  }

  function marketDrawBuildPersistPayload(items) {
    return {
      version: MW_DRAW_SCHEMA_VERSION,
      drawings: Array.isArray(items) ? items : []
    };
  }

  function marketDrawBuildToolbarPosKey() {
    var symbol = String(marketWatch.symbol || "EURUSD").toUpperCase();
    var tf = String(marketWatch.tf || "M1").toUpperCase();
    var mode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
    return MW_DRAW_TOOLBAR_POS_PREFIX + mode + "::" + symbol + "::" + tf;
  }

  function marketDrawLoadToolbarPos(key) {
    if (!hasValue(key)) return null;
    try {
      var raw = localStorage.getItem(String(key));
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object") return null;
      var x = Number(parsed.x);
      var y = Number(parsed.y);
      if (!isFinite(x) || !isFinite(y)) return null;
      return { x: x, y: y };
    } catch (e) {
      return null;
    }
  }

  function marketDrawSaveToolbarPos() {
    var draw = marketDrawState();
    var key = draw.ui && draw.ui.toolbarPosKey ? String(draw.ui.toolbarPosKey) : "";
    if (!key) return;
    var x = Number(draw.ui.toolbarX);
    var y = Number(draw.ui.toolbarY);
    if (!isFinite(x) || !isFinite(y)) return;
    try {
      localStorage.setItem(key, JSON.stringify({ x: x, y: y }));
    } catch (e) {}
  }

  function marketDrawClampToolbarPosition(x, y) {
    var toolbar = els.marketDrawToolbar;
    var host = els.marketChartWrap;
    var tx = Number(x);
    var ty = Number(y);
    if (!isFinite(tx)) tx = 12;
    if (!isFinite(ty)) ty = 12;
    if (!toolbar || !host) return { x: tx, y: ty };

    var hostW = Math.max(1, host.clientWidth || 1);
    var hostH = Math.max(1, host.clientHeight || 1);
    var toolW = Math.max(1, toolbar.offsetWidth || 1);
    var toolH = Math.max(1, toolbar.offsetHeight || 1);

    var minX = -toolW + MW_DRAW_TOOLBAR_MIN_VISIBLE;
    var maxX = hostW - MW_DRAW_TOOLBAR_MIN_VISIBLE;
    var minY = -toolH + MW_DRAW_TOOLBAR_MIN_VISIBLE;
    var maxY = hostH - MW_DRAW_TOOLBAR_MIN_VISIBLE;
    if (!isFinite(minX) || !isFinite(maxX)) return { x: tx, y: ty };

    if (tx < minX) tx = minX;
    if (tx > maxX) tx = maxX;
    if (ty < minY) ty = minY;
    if (ty > maxY) ty = maxY;
    return { x: tx, y: ty };
  }

  function marketDrawApplyToolbarPosition(x, y, persist) {
    var toolbar = els.marketDrawToolbar;
    if (!toolbar) return;
    var clamped = marketDrawClampToolbarPosition(x, y);
    var draw = marketDrawState();
    draw.ui.toolbarX = clamped.x;
    draw.ui.toolbarY = clamped.y;
    toolbar.style.left = clamped.x + "px";
    toolbar.style.top = clamped.y + "px";
    toolbar.style.right = "auto";
    toolbar.style.bottom = "auto";
    if (persist !== false) marketDrawSaveToolbarPos();
  }

  function marketDrawResetToolbarToDefault(persist) {
    marketDrawApplyToolbarPosition(12, 12, persist !== false);
  }

  function marketDrawSyncToolbarContext() {
    var draw = marketDrawState();
    draw.ui.toolbarPosKey = marketDrawBuildToolbarPosKey();
    var stored = marketDrawLoadToolbarPos(draw.ui.toolbarPosKey);
    if (stored) {
      marketDrawApplyToolbarPosition(stored.x, stored.y, false);
    } else {
      marketDrawResetToolbarToDefault(false);
    }
  }

  function marketDrawReclampToolbarPosition() {
    var draw = marketDrawState();
    var x = isFinite(Number(draw.ui.toolbarX)) ? Number(draw.ui.toolbarX) : 12;
    var y = isFinite(Number(draw.ui.toolbarY)) ? Number(draw.ui.toolbarY) : 12;
    marketDrawApplyToolbarPosition(x, y, false);
  }

  function marketDrawStartToolbarDrag(event) {
    if (!event || event.button !== 0) return;
    var draw = marketDrawState();
    var toolbar = els.marketDrawToolbar;
    if (!toolbar) return;
    var currentX = isFinite(Number(draw.ui.toolbarX)) ? Number(draw.ui.toolbarX) : toolbar.offsetLeft;
    var currentY = isFinite(Number(draw.ui.toolbarY)) ? Number(draw.ui.toolbarY) : toolbar.offsetTop;
    draw.ui.draggingToolbar = true;
    draw.ui.dragStartPointerX = Number(event.clientX);
    draw.ui.dragStartPointerY = Number(event.clientY);
    draw.ui.dragStartToolbarX = isFinite(currentX) ? currentX : 12;
    draw.ui.dragStartToolbarY = isFinite(currentY) ? currentY : 12;
    toolbar.classList.add("is-dragging");
    marketDrawCloseMenus();
    event.preventDefault();
    event.stopPropagation();
  }

  function marketDrawMoveToolbarDrag(event) {
    var draw = marketDrawState();
    if (!draw.ui.draggingToolbar) return;
    var dx = Number(event.clientX) - Number(draw.ui.dragStartPointerX);
    var dy = Number(event.clientY) - Number(draw.ui.dragStartPointerY);
    if (!isFinite(dx) || !isFinite(dy)) return;
    marketDrawApplyToolbarPosition(Number(draw.ui.dragStartToolbarX) + dx, Number(draw.ui.dragStartToolbarY) + dy, false);
    event.preventDefault();
  }

  function marketDrawEndToolbarDrag() {
    var draw = marketDrawState();
    if (!draw.ui.draggingToolbar) return;
    draw.ui.draggingToolbar = false;
    if (els.marketDrawToolbar) els.marketDrawToolbar.classList.remove("is-dragging");
    marketDrawSaveToolbarPos();
  }

  function marketDrawClone(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (e) {
      return null;
    }
  }

  function marketDrawSerializeItems() {
    return JSON.stringify(marketDrawState().items || []);
  }

  function marketDrawTimeframeSeconds() {
    return Math.max(1, Number(marketWatchTimeframeToSec(marketWatch.tf || "M1")) || 60);
  }

  function marketDrawGetLastLogical() {
    var candles = marketWatch.candles || [];
    return candles.length ? (candles.length - 1) : 0;
  }

  function marketDrawGetLastBarTime() {
    var candles = marketWatch.candles || [];
    if (!candles.length) return NaN;
    return Number(candles[candles.length - 1].time);
  }

  function marketDrawGetMaxFutureTime() {
    var lastT = marketDrawGetLastBarTime();
    if (!isFinite(lastT)) return NaN;
    return Math.floor(lastT + (Math.max(1, Number(MW_DRAW_FUTURE_BARS) || 120) * marketDrawTimeframeSeconds()));
  }

  function marketDrawGetLastBarX() {
    var chart = marketWatch.chart;
    var lastT = marketDrawGetLastBarTime();
    if (!chart || !isFinite(lastT)) return NaN;
    try {
      var scale = chart.timeScale ? chart.timeScale() : null;
      if (scale && typeof scale.timeToCoordinate === "function") {
        var x = Number(scale.timeToCoordinate(Math.floor(lastT)));
        if (isFinite(x)) return x;
      }
    } catch (e) {}
    return NaN;
  }

  function marketDrawEstimateBarSpacingPx() {
    var chart = marketWatch.chart;
    if (!chart) return 8;
    var candles = marketWatch.candles || [];
    if (candles.length >= 2) {
      try {
        var scale = chart.timeScale ? chart.timeScale() : null;
        if (scale && typeof scale.timeToCoordinate === "function") {
          var a = Number(scale.timeToCoordinate(Math.floor(Number(candles[candles.length - 2].time))));
          var b = Number(scale.timeToCoordinate(Math.floor(Number(candles[candles.length - 1].time))));
          var d = Math.abs(b - a);
          if (isFinite(d) && d > 0.1) return d;
        }
      } catch (e) {}
    }
    try {
      var scale2 = chart.timeScale ? chart.timeScale() : null;
      if (scale2 && typeof scale2.logicalToCoordinate === "function") {
        var l = marketDrawGetLastLogical();
        var x0 = Number(scale2.logicalToCoordinate(l));
        var x1 = Number(scale2.logicalToCoordinate(l + 1));
        var dd = Math.abs(x1 - x0);
        if (isFinite(dd) && dd > 0.1) return dd;
      }
    } catch (e1) {}
    return 8;
  }

  function marketDrawClampRightOffsetBars(value) {
    var n = Number(value);
    if (!isFinite(n)) n = MW_DRAW_DEFAULT_RIGHT_OFFSET;
    var minOff = Number(MW_DRAW_MIN_RIGHT_OFFSET) || 10;
    var maxOff = Number(MW_DRAW_MAX_RIGHT_OFFSET) || 80;
    if (n < minOff) n = minOff;
    if (n > maxOff) n = maxOff;
    return n;
  }

  function marketDrawGetRightOffsetTarget() {
    return marketDrawClampRightOffsetBars(MW_DRAW_DEFAULT_RIGHT_OFFSET);
  }

  function marketDrawEnsureFutureSpace() {
    var chart = marketWatch.chart;
    if (!chart) return;
    var targetOffset = marketDrawGetRightOffsetTarget();

    try {
      chart.applyOptions({
        timeScale: { rightOffset: targetOffset }
      });
    } catch (e) {}
  }

  function marketDrawLogicalToTime(logical) {
    var li = Number(logical);
    if (!isFinite(li)) return NaN;
    var candles = marketWatch.candles || [];
    if (!candles.length) return NaN;

    var n = candles.length;
    var lo = Math.floor(li);
    var hi = Math.ceil(li);
    if (lo >= 0 && hi < n) {
      var tLo = Number(candles[lo].time);
      var tHi = Number(candles[hi].time);
      if (isFinite(tLo) && isFinite(tHi)) {
        var ratio = hi === lo ? 0 : (li - lo) / (hi - lo);
        return Math.floor(tLo + (tHi - tLo) * ratio);
      }
    }

    var tfSec = marketDrawTimeframeSeconds();
    if (li >= n - 1) {
      var lastT = Number(candles[n - 1].time);
      if (!isFinite(lastT)) return NaN;
      return Math.floor(lastT + (li - (n - 1)) * tfSec);
    }

    var firstT = Number(candles[0].time);
    if (!isFinite(firstT)) return NaN;
    return Math.floor(firstT + li * tfSec);
  }

  function marketDrawTimeToLogical(timeSec) {
    var t = Number(timeSec);
    if (!isFinite(t)) return NaN;

    try {
      var scale = marketWatch.chart && marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (scale && typeof scale.timeToCoordinate === "function" && typeof scale.coordinateToLogical === "function") {
        var x = Number(scale.timeToCoordinate(Math.floor(t)));
        if (isFinite(x)) {
          var logicalDirect = Number(scale.coordinateToLogical(x));
          if (isFinite(logicalDirect)) return logicalDirect;
        }
      }
    } catch (e) {}

    var candles = marketWatch.candles || [];
    if (!candles.length) return NaN;
    var tfSec = marketDrawTimeframeSeconds();
    var firstT = Number(candles[0].time);
    var lastIndex = candles.length - 1;
    var lastT = Number(candles[lastIndex].time);

    if (!isFinite(firstT) || !isFinite(lastT)) return NaN;
    if (t <= firstT) return (t - firstT) / tfSec;
    if (t >= lastT) return lastIndex + (t - lastT) / tfSec;

    var lo = 0;
    var hi = lastIndex;
    while (lo <= hi) {
      var mid = Math.floor((lo + hi) / 2);
      var mt = Number(candles[mid].time);
      if (mt === t) return mid;
      if (mt < t) lo = mid + 1;
      else hi = mid - 1;
    }

    var leftIdx = Math.max(0, hi);
    var rightIdx = Math.min(lastIndex, lo);
    if (leftIdx === rightIdx) return leftIdx;
    var leftT = Number(candles[leftIdx].time);
    var rightT = Number(candles[rightIdx].time);
    if (!isFinite(leftT) || !isFinite(rightT) || rightT === leftT) return leftIdx;
    return leftIdx + ((t - leftT) / (rightT - leftT));
  }

  function marketDrawMigratePayload(parsed) {
    if (Array.isArray(parsed)) {
      return { version: 0, items: parsed };
    }
    if (parsed && typeof parsed === "object") {
      var items = Array.isArray(parsed.drawings) ? parsed.drawings : parsed.items;
      if (!Array.isArray(items)) items = [];
      return {
        version: Number(parsed.version) || 1,
        items: items
      };
    }
    return { version: MW_DRAW_SCHEMA_VERSION, items: [] };
  }

  function marketDrawLoadStorageItems(key, scope) {
    var keysToTry = [key];
    var legacyKeys = marketDrawBuildLegacyStorageKeys(scope);
    if (Array.isArray(legacyKeys) && legacyKeys.length) {
      for (var i = 0; i < legacyKeys.length; i++) {
        var candidate = legacyKeys[i];
        if (candidate && keysToTry.indexOf(candidate) < 0) keysToTry.push(candidate);
      }
    }

    var payload = null;
    for (var k = 0; k < keysToTry.length; k++) {
      var keyToRead = keysToTry[k];
      if (!keyToRead) continue;
      try {
        payload = localStorage.getItem(keyToRead);
      } catch (e) {
        payload = null;
      }
      if (payload) {
        if (keyToRead !== key) {
          try {
            localStorage.setItem(key, payload);
          } catch (e2) {}
        }
        break;
      }
    }
    if (!payload) return [];
    try {
      var parsed = marketDrawMigratePayload(JSON.parse(payload));
      return marketDrawNormalizeItems(parsed.items || []);
    } catch (e0) {
      return [];
    }
  }

  function marketDrawSavePayloadToLocalStorage(key, payload) {
    if (!key) return;
    try {
      localStorage.setItem(key, JSON.stringify(payload));
    } catch (e) {}
  }

  function marketDrawLoadRemote(scope, expectedSnapshot) {
    var draw = marketDrawState();
    if (!scope) return;
    draw.remoteLoadToken = Number(draw.remoteLoadToken || 0) + 1;
    var token = draw.remoteLoadToken;
    var url = marketDrawBuildRemoteUrl(scope);

    requestJson("GET", url, function (err, data) {
      var activeDraw = marketDrawState();
      if (token !== Number(activeDraw.remoteLoadToken || 0)) return;
      if (!activeDraw.scope || activeDraw.key !== scope.key) return;
      if (err || !data || data.ok !== true) {
        if (MW_HISTORY_DEBUG) {
          console.warn("[MW][DRAW][REMOTE][LOAD] failed", scope, err || data);
        }
        return;
      }
      if (!data.found) return;
      if (marketDrawSerializeItems() !== expectedSnapshot) return;

      var parsed = marketDrawMigratePayload(data.payload || {});
      activeDraw.items = marketDrawNormalizeItems(parsed.items || []);
      marketDrawReindexItems();
      activeDraw.selectedIds = [];
      activeDraw.selectedId = null;
      activeDraw.selectedObjectId = null;
      activeDraw.activeObjectId = null;
      activeDraw.hoverId = null;
      activeDraw.pendingPoint = null;
      activeDraw.interaction = null;
      activeDraw.pointer = null;
      marketDrawResetPropsEditSession();
      marketDrawUpdateToolbarState();
      marketDrawSyncPropertiesPanel();
      marketDrawSyncOverlayPointerRouting();
      marketDrawScheduleRender();

      marketDrawSavePayloadToLocalStorage(scope.key, {
        version: parsed.version || MW_DRAW_SCHEMA_VERSION,
        drawings: activeDraw.items || []
      });
      if (MW_HISTORY_DEBUG) {
        console.log("[MW][DRAW][REMOTE][LOAD] applied", scope, "items=", activeDraw.items.length);
      }
    });
  }

  function marketDrawSaveRemote(scope, payload, options) {
    if (!scope || !payload) return;
    var opts = options || {};
    var body = {
      account_id: scope.accountId || "default",
      symbol: scope.symbol || "EURUSD",
      tf: scope.tf || "M1",
      mode: scope.mode || "HISTORY",
      payload: payload
    };

    if (opts.useBeacon && navigator && typeof navigator.sendBeacon === "function") {
      try {
        var blob = new Blob([JSON.stringify(body)], { type: "application/json" });
        navigator.sendBeacon(MW_DRAW_REMOTE_ENDPOINT, blob);
        return;
      } catch (e0) {}
    }

    requestJsonWithBody("POST", MW_DRAW_REMOTE_ENDPOINT, body, function (err, data) {
      if (!err && data && data.ok) return;
      if (MW_HISTORY_DEBUG) {
        console.warn("[MW][DRAW][REMOTE][SAVE] failed", scope, err || data);
      }
    });
  }

  function marketDrawNormalizePoint(point) {
    if (!point || typeof point !== "object") return null;
    var t = Number(point.t !== undefined ? point.t : point.time);
    var p = Number(point.p);
    var li = Number(point.li !== undefined ? point.li : point.logical);
    if (!isFinite(p)) return null;
    if (!isFinite(t) && isFinite(li)) t = marketDrawLogicalToTime(li);
    if (!isFinite(li) && isFinite(t)) li = marketDrawTimeToLogical(t);
    if (!isFinite(t)) return null;
    return { t: Math.floor(t), p: p, li: isFinite(li) ? Number(li) : null };
  }

  function marketDrawCanonicalRect(item) {
    if (!item || !item.a || !item.b) return item;
    var minT = Math.min(Number(item.a.t), Number(item.b.t));
    var maxT = Math.max(Number(item.a.t), Number(item.b.t));
    var minP = Math.min(Number(item.a.p), Number(item.b.p));
    var maxP = Math.max(Number(item.a.p), Number(item.b.p));

    var ali = isFinite(Number(item.a.li)) ? Number(item.a.li) : marketDrawTimeToLogical(minT);
    var bli = isFinite(Number(item.b.li)) ? Number(item.b.li) : marketDrawTimeToLogical(maxT);
    var minL = isFinite(ali) && isFinite(bli) ? Math.min(ali, bli) : (isFinite(ali) ? ali : (isFinite(bli) ? bli : null));
    var maxL = isFinite(ali) && isFinite(bli) ? Math.max(ali, bli) : (isFinite(ali) ? ali : (isFinite(bli) ? bli : null));

    item.a = { t: Math.floor(minT), p: maxP, li: isFinite(minL) ? Number(minL) : null };
    item.b = { t: Math.floor(maxT), p: minP, li: isFinite(maxL) ? Number(maxL) : null };
    return item;
  }

  function marketDrawNormalizeLogicalLike(value) {
    var li = Number(value);
    if (!isFinite(li)) return NaN;
    return Number(li);
  }

  function marketDrawNormalizePositionEnd(raw, entryPoint) {
    var entry = marketDrawNormalizePoint(entryPoint);
    if (!entry) return null;
    var entryLi = isFinite(Number(entry.li)) ? Number(entry.li) : marketDrawTimeToLogical(entry.t);
    if (!isFinite(entryLi)) entryLi = marketDrawGetLastLogical();

    var endInput = raw && typeof raw === "object"
      ? (raw.end || raw.to || raw.b || {
        li: raw.endLi !== undefined ? raw.endLi : (raw.toLi !== undefined ? raw.toLi : (raw.endLogical !== undefined ? raw.endLogical : raw.rightLi)),
        t: raw.endTime !== undefined ? raw.endTime : (raw.toTime !== undefined ? raw.toTime : raw.rightTime)
      })
      : null;
    var endPoint = marketDrawNormalizePoint(endInput || {});
    var endLi = endPoint && isFinite(Number(endPoint.li))
      ? Number(endPoint.li)
      : marketDrawNormalizeLogicalLike(endInput && (endInput.li !== undefined ? endInput.li : endInput.logical));

    if (!isFinite(endLi)) {
      var endT = endPoint ? Number(endPoint.t) : Number(endInput && (endInput.t !== undefined ? endInput.t : endInput.time));
      if (isFinite(endT)) endLi = marketDrawTimeToLogical(endT);
    }
    if (!isFinite(endLi)) endLi = entryLi + MW_DRAW_DEFAULT_POSITION_WIDTH_BARS;
    if (endLi < entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL) endLi = entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL;

    var visibleLogical = marketDrawGetVisibleLogicalBounds();
    if (isFinite(Number(visibleLogical.maxL)) && endLi > Number(visibleLogical.maxL)) endLi = Number(visibleLogical.maxL);
    if (isFinite(Number(visibleLogical.minL)) && endLi < Number(visibleLogical.minL)) endLi = Number(visibleLogical.minL);
    if (endLi < entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL) endLi = entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL;

    return marketDrawClampPoint({
      t: marketDrawLogicalToTime(endLi),
      p: Number(entry.p),
      li: endLi
    });
  }

  function marketDrawNormalizeItem(raw) {
    if (!raw || typeof raw !== "object") return null;
    var type = String(raw.type || "").toLowerCase();
    if (type === "longpos" || type === "long-position" || type === "long_position") type = "long";
    if (type === "shortpos" || type === "short-position" || type === "short_position") type = "short";
    var item = {
      id: hasValue(raw.id) ? String(raw.id) : ("d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8)),
      type: type,
      style: raw.style && typeof raw.style === "object" ? marketDrawClone(raw.style) : {}
    };
    if (type === "trendline" || type === "ruler") {
      item.a = marketDrawNormalizePoint(raw.a);
      item.b = marketDrawNormalizePoint(raw.b);
      if (!item.a || !item.b) return null;
      return item;
    }
    if (type === "hline") {
      var p = Number(raw.p);
      if (!isFinite(p)) return null;
      item.p = p;
      return item;
    }
    if (type === "rect") {
      item.a = marketDrawNormalizePoint(raw.a);
      item.b = marketDrawNormalizePoint(raw.b);
      if (!item.a || !item.b) return null;
      item = marketDrawCanonicalRect(item);
      return item;
    }
    if (type === "text") {
      item.at = marketDrawNormalizePoint(raw.at);
      item.text = hasValue(raw.text) ? String(raw.text) : "";
      if (!item.at) return null;
      return item;
    }
    if (type === "long" || type === "short") {
      item.entry = marketDrawNormalizePoint(raw.entry || raw.at || raw.a);
      var sl = Number(raw.sl !== undefined ? raw.sl : (raw.stop !== undefined ? raw.stop : raw.stopPrice));
      var tp = Number(raw.tp !== undefined ? raw.tp : (raw.take !== undefined ? raw.take : raw.takePrice));
      if (!item.entry || !isFinite(sl) || !isFinite(tp)) return null;
      item.sl = sl;
      item.tp = tp;
      item.end = marketDrawNormalizePositionEnd(raw, item.entry);
      return item;
    }
    return null;
  }

  function marketDrawNormalizeItems(items) {
    var out = [];
    if (!Array.isArray(items)) return out;
    for (var i = 0; i < items.length; i++) {
      var normalized = marketDrawNormalizeItem(items[i]);
      if (normalized) out.push(normalized);
    }
    return out;
  }

  function marketDrawClampNumber(value, min, max, fallback) {
    var n = Number(value);
    if (!isFinite(n)) n = Number(fallback);
    if (!isFinite(n)) n = Number(min);
    if (isFinite(min) && n < min) n = min;
    if (isFinite(max) && n > max) n = max;
    return n;
  }

  function marketDrawNormalizeHexColor(value, fallback) {
    var fb = String(fallback || "#f6d365");
    var input = String(value || "").trim();
    if (!input) return fb;
    var hex3 = /^#([0-9a-f]{3})$/i.exec(input);
    if (hex3) {
      var s = hex3[1];
      return "#" + s[0] + s[0] + s[1] + s[1] + s[2] + s[2];
    }
    if (/^#([0-9a-f]{6})$/i.test(input)) return input.toLowerCase();
    var rgb = /^rgba?\(\s*([0-9]{1,3})\s*[, ]\s*([0-9]{1,3})\s*[, ]\s*([0-9]{1,3})/i.exec(input);
    if (rgb) {
      var r = marketDrawClampNumber(rgb[1], 0, 255, 0);
      var g = marketDrawClampNumber(rgb[2], 0, 255, 0);
      var b = marketDrawClampNumber(rgb[3], 0, 255, 0);
      var toHex = function (n) {
        var h = Number(n).toString(16);
        return h.length < 2 ? ("0" + h) : h;
      };
      return ("#" + toHex(r) + toHex(g) + toHex(b)).toLowerCase();
    }
    return fb;
  }

  function marketDrawStrokeDashArray(styleName, strokeWidth) {
    var width = marketDrawClampNumber(strokeWidth, 0.5, 12, 1.5);
    var s = String(styleName || "solid").toLowerCase();
    if (s === "dash") return fmt(Math.max(2, width * 4), 1) + " " + fmt(Math.max(2, width * 2.6), 1);
    if (s === "dot") return fmt(Math.max(1, width * 1.2), 1) + " " + fmt(Math.max(2, width * 2.4), 1);
    return "";
  }

  function marketDrawDefaultStyleForType(type) {
    var t = String(type || "").toLowerCase();
    if (t === "rect") {
      return {
        strokeColor: "#f6d365",
        strokeWidth: 1.5,
        strokeStyle: "solid",
        strokeOpacity: 1,
        fillColor: "#f6d365",
        fillOpacity: 0.12,
        locked: false
      };
    }
    if (t === "text") {
      return {
        strokeColor: "#7bc8ff",
        strokeWidth: 1,
        strokeStyle: "solid",
        strokeOpacity: 1,
        textColor: "#d7ebf7",
        fontSize: 11,
        bgColor: "#050f16",
        bgOpacity: 0.9,
        locked: false
      };
    }
    if (t === "hline") {
      return {
        strokeColor: "#f6d365",
        strokeWidth: 1.6,
        strokeStyle: "dash",
        strokeOpacity: 1,
        locked: false
      };
    }
    if (t === "ruler") {
      return {
        strokeColor: "#f2ffda",
        strokeWidth: 1.6,
        strokeStyle: "dash",
        strokeOpacity: 1,
        locked: false
      };
    }
    return {
      strokeColor: "#f6d365",
      strokeWidth: 1.9,
      strokeStyle: "solid",
      strokeOpacity: 1,
      locked: false
    };
  }

  function marketDrawMergeItemStyle(itemOrType) {
    var type = "";
    var rawStyle = {};
    if (itemOrType && typeof itemOrType === "object") {
      type = String(itemOrType.type || "").toLowerCase();
      rawStyle = itemOrType.style && typeof itemOrType.style === "object" ? itemOrType.style : {};
    } else {
      type = String(itemOrType || "").toLowerCase();
    }
    var base = marketDrawDefaultStyleForType(type);
    var merged = {};
    for (var key in base) {
      if (Object.prototype.hasOwnProperty.call(base, key)) merged[key] = base[key];
    }
    for (var key2 in rawStyle) {
      if (Object.prototype.hasOwnProperty.call(rawStyle, key2)) merged[key2] = rawStyle[key2];
    }

    merged.strokeColor = marketDrawNormalizeHexColor(merged.strokeColor, base.strokeColor || "#f6d365");
    merged.strokeWidth = marketDrawClampNumber(merged.strokeWidth, 0.5, 12, base.strokeWidth || 1.5);
    merged.strokeStyle = String(merged.strokeStyle || "solid").toLowerCase();
    if (merged.strokeStyle !== "dash" && merged.strokeStyle !== "dot") merged.strokeStyle = "solid";
    merged.strokeOpacity = marketDrawClampNumber(merged.strokeOpacity, 0, 1, base.strokeOpacity !== undefined ? base.strokeOpacity : 1);
    merged.fillColor = marketDrawNormalizeHexColor(merged.fillColor, base.fillColor || merged.strokeColor || "#f6d365");
    merged.fillOpacity = marketDrawClampNumber(merged.fillOpacity, 0, 1, base.fillOpacity !== undefined ? base.fillOpacity : 0.12);
    merged.textColor = marketDrawNormalizeHexColor(merged.textColor, base.textColor || "#d7ebf7");
    merged.fontSize = marketDrawClampNumber(merged.fontSize, 8, 64, base.fontSize || 11);
    merged.bgColor = marketDrawNormalizeHexColor(merged.bgColor, base.bgColor || "#050f16");
    merged.bgOpacity = marketDrawClampNumber(merged.bgOpacity, 0, 1, base.bgOpacity !== undefined ? base.bgOpacity : 0.9);
    merged.locked = !!merged.locked;
    if (merged.visible === undefined) merged.visible = true;
    merged.visible = !!merged.visible;
    return merged;
  }

  function marketDrawSupportsPropertyPanelItem(item) {
    if (!item) return false;
    var t = String(item.type || "").toLowerCase();
    return t === "trendline" || t === "hline" || t === "ruler" || t === "rect" || t === "text";
  }

  function marketDrawIsItemLocked(item) {
    var style = marketDrawMergeItemStyle(item);
    return !!style.locked;
  }

  function marketDrawIsItemVisible(item) {
    var style = marketDrawMergeItemStyle(item);
    return style.visible !== false;
  }

  function marketDrawGetSelectionIds() {
    var draw = marketDrawState();
    if (hasValue(draw.selectedObjectId)) return [String(draw.selectedObjectId)];
    return [];
  }

  function marketDrawSetSelection(idsOrId) {
    var draw = marketDrawState();
    var prevKey = hasValue(draw.selectedObjectId) ? String(draw.selectedObjectId) : "";
    var ids = [];
    if (Array.isArray(idsOrId)) ids = idsOrId;
    else if (hasValue(idsOrId)) ids = [idsOrId];

    var nextKey = "";
    for (var i = 0; i < ids.length; i++) {
      if (!hasValue(ids[i])) continue;
      nextKey = String(ids[i]);
      break;
    }
    if (prevKey !== nextKey) marketDrawFinalizePropsCommit();

    draw.selectedObjectId = nextKey || null;
    draw.selectedId = draw.selectedObjectId;
    draw.selectedIds = draw.selectedObjectId ? [draw.selectedObjectId] : [];
    draw.activeObjectId = draw.selectedObjectId;
    if (!draw.selectedObjectId) draw.hoverId = null;
    marketDrawSyncPropertiesPanel();
  }

  function marketDrawClearSelection() {
    var draw = marketDrawState();
    var hadSelection = !!draw.selectedObjectId;
    marketDrawFinalizePropsCommit();
    marketDrawSetSelection(null);
    draw.hoverId = null;
    if (hadSelection) marketDrawScheduleRender();
    return hadSelection;
  }

  function marketDrawPushUndoSnapshot(snapshot) {
    var draw = marketDrawState();
    var snap = hasValue(snapshot) ? String(snapshot) : "";
    if (!snap) return;
    if (draw.undoStack.length && draw.undoStack[draw.undoStack.length - 1] === snap) return;
    draw.undoStack.push(snap);
    if (draw.undoStack.length > MW_DRAW_MAX_UNDO) draw.undoStack.shift();
    draw.redoStack = [];
    marketDrawUpdateToolbarState();
  }

  function marketDrawResetPropsEditSession(clearTimer) {
    var draw = marketDrawState();
    var edit = draw.propsEdit || {};
    if (clearTimer !== false && edit.timer) {
      clearTimeout(edit.timer);
      edit.timer = null;
    }
    edit.baseSnapshot = null;
    edit.targetId = null;
    draw.propsEdit = edit;
  }

  function marketDrawFinalizePropsCommit() {
    var draw = marketDrawState();
    var edit = draw.propsEdit || {};
    if (edit.timer) {
      clearTimeout(edit.timer);
      edit.timer = null;
    }
    if (!edit.baseSnapshot) {
      marketDrawResetPropsEditSession(false);
      return;
    }
    var current = marketDrawSerializeItems();
    if (String(current) !== String(edit.baseSnapshot)) {
      marketDrawPushUndoSnapshot(edit.baseSnapshot);
      marketDrawScheduleSave();
    }
    marketDrawResetPropsEditSession(false);
  }

  function marketDrawSchedulePropsCommit(immediate) {
    var draw = marketDrawState();
    var edit = draw.propsEdit || {};
    if (immediate) {
      marketDrawFinalizePropsCommit();
      return;
    }
    if (edit.timer) clearTimeout(edit.timer);
    edit.timer = setTimeout(function () {
      edit.timer = null;
      marketDrawFinalizePropsCommit();
    }, MW_DRAW_PROPS_COMMIT_IDLE_MS);
    draw.propsEdit = edit;
  }

  function marketDrawEnsurePropsEditBase(targetKey) {
    var draw = marketDrawState();
    var edit = draw.propsEdit || {};
    var key = String(targetKey || "");
    if (!edit.baseSnapshot || edit.targetId !== key) {
      if (edit.baseSnapshot && edit.targetId !== key) {
        marketDrawFinalizePropsCommit();
      }
      edit.baseSnapshot = marketDrawSerializeItems();
      edit.targetId = key;
    }
    draw.propsEdit = edit;
  }

  function marketDrawApplyStylePatchToSelection(patch, options) {
    var opts = options || {};
    var ids = marketDrawGetSelectionIds();
    if (!ids.length || !patch || typeof patch !== "object") return;
    var patchKeys = Object.keys(patch);
    if (!patchKeys.length) return;

    var eligible = [];
    for (var i = 0; i < ids.length; i++) {
      var item = marketDrawGetItemById(ids[i]);
      if (!item || !marketDrawSupportsPropertyPanelItem(item)) continue;
      if (marketDrawIsItemLocked(item) && patch.locked === undefined && !opts.ignoreLock) continue;
      eligible.push(item.id);
    }
    if (!eligible.length) return;

    var editKey = eligible.length > 1 ? ("multi:" + eligible.join(",")) : String(eligible[0]);
    marketDrawEnsurePropsEditBase(editKey);

    for (var j = 0; j < eligible.length; j++) {
      var selected = marketDrawGetItemById(eligible[j]);
      if (!selected) continue;
      var merged = marketDrawMergeItemStyle({
        type: selected.type,
        style: Object.assign({}, selected.style || {}, patch)
      });
      selected.style = merged;
      marketDrawReplaceItem(selected);
    }

    marketDrawScheduleRender();
    marketDrawSyncPropertiesPanel();
    marketDrawSchedulePropsCommit(!!opts.commitNow);
  }

  function marketDrawSelectedTypeLabel(item) {
    if (!item) return "Object";
    var t = String(item.type || "").toLowerCase();
    if (t === "rect") return "Rectangle";
    if (t === "text") return "Text";
    if (t === "hline") return "Horizontal Line";
    if (t === "ruler") return "Ruler";
    if (t === "trendline") return "Line";
    return "Object";
  }

  function marketDrawTypeIconSvg(item) {
    var t = String((item && item.type) || "").toLowerCase();
    if (t === "rect") return '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="6" width="14" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="1.8"></rect></svg>';
    if (t === "text") return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6h12M12 6v12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path></svg>';
    if (t === "hline") return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path></svg>';
    if (t === "ruler") return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 18L18 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path></svg>';
    return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 18L19 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path></svg>';
  }

  function marketDrawCreateQuickActionButton(id, iconSvg, label) {
    var btn = document.createElement("button");
    btn.id = id;
    btn.className = "marketwatch-draw-props-icon-btn";
    btn.type = "button";
    btn.setAttribute("aria-label", label);
    btn.setAttribute("title", label);
    btn.innerHTML = iconSvg;
    return btn;
  }

  function marketDrawEnsurePropsDrawerStructure() {
    if (!els.marketDrawPropsPanel) return;
    if (els.marketDrawPropsPanel.dataset.drawerInit === "1") return;

    var head = els.marketDrawPropsPanel.querySelector(".marketwatch-draw-props-head");
    if (head) {
      head.classList.add("marketwatch-draw-props-head-row");
      var quick = document.createElement("div");
      quick.id = "marketDrawPropsQuickActions";
      quick.className = "marketwatch-draw-props-quick-actions";
      var eyeIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z" fill="none" stroke="currentColor" stroke-width="1.7"></path><circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" stroke-width="1.7"></circle></svg>';
      var lockIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"></rect><path d="M8 11V8a4 4 0 018 0v3" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"></path></svg>';
      var trashIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M9 7V5h6v2M8 7l1 12h6l1-12" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
      var eyeBtn = marketDrawCreateQuickActionButton("marketDrawPropVisibility", eyeIcon, "Toggle visibility");
      var lockBtn = marketDrawCreateQuickActionButton("marketDrawPropLockQuick", lockIcon, "Toggle lock");
      var delBtn = marketDrawCreateQuickActionButton("marketDrawPropDeleteQuick", trashIcon, "Delete object");
      delBtn.classList.add("is-danger");
      quick.appendChild(eyeBtn);
      quick.appendChild(lockBtn);
      quick.appendChild(delBtn);
      head.appendChild(quick);
      els.marketDrawPropVisibility = eyeBtn;
      els.marketDrawPropLockQuick = lockBtn;
      els.marketDrawPropDeleteQuick = delBtn;
      if (els.marketDrawPropLock) els.marketDrawPropLock.classList.add("is-aux-hidden");
      if (els.marketDrawPropDelete) els.marketDrawPropDelete.classList.add("is-aux-hidden");
    }

    var sections = els.marketDrawPropsPanel.querySelector(".marketwatch-draw-props-sections");
    if (sections) {
      var coordSection = document.createElement("div");
      coordSection.id = "marketDrawPropsCoordsSection";
      coordSection.className = "marketwatch-draw-props-section marketwatch-draw-props-coordinates";
      coordSection.innerHTML = ''
        + '<div class="marketwatch-draw-props-section-title">Coordinates</div>'
        + '<div id="marketDrawPropsCoordsBody" class="marketwatch-draw-props-coords-body"></div>';
      sections.appendChild(coordSection);
      els.marketDrawPropsCoordsSection = coordSection;
      els.marketDrawPropsCoordsBody = coordSection.querySelector("#marketDrawPropsCoordsBody");
    }

    els.marketDrawPropsPanel.dataset.drawerInit = "1";
  }

  function marketDrawBuildCoordinateRows(item) {
    if (!item) return [];
    var rows = [];
    var addPoint = function (prefix, point) {
      var p = marketDrawNormalizePoint(point);
      if (!p) return;
      rows.push(prefix + " Time|" + marketDrawFormatTimeLabel(p));
      rows.push(prefix + " Price|" + fmt(p.p, 5));
    };
    var t = String(item.type || "").toLowerCase();
    if (t === "trendline" || t === "ruler") {
      addPoint("Start", item.a);
      addPoint("End", item.b);
      return rows;
    }
    if (t === "rect") {
      addPoint("Top Left", item.a);
      addPoint("Bottom Right", item.b);
      return rows;
    }
    if (t === "text") {
      addPoint("Anchor", item.at);
      return rows;
    }
    if (t === "hline") {
      rows.push("Price|" + fmt(item.p, 5));
      return rows;
    }
    return rows;
  }

  function marketDrawRenderCoordinateSection(item) {
    if (!els.marketDrawPropsCoordsSection || !els.marketDrawPropsCoordsBody) return;
    var rows = marketDrawBuildCoordinateRows(item);
    if (!rows.length) {
      els.marketDrawPropsCoordsSection.classList.add("is-hidden");
      els.marketDrawPropsCoordsBody.innerHTML = "";
      return;
    }
    var html = [];
    for (var i = 0; i < rows.length; i++) {
      var pair = rows[i].split("|");
      html.push(
        '<div class="marketwatch-draw-props-coord-row">'
        + '<span>' + esc(pair[0] || "") + '</span>'
        + '<strong>' + esc(pair[1] || "") + '</strong>'
        + '</div>'
      );
    }
    els.marketDrawPropsCoordsBody.innerHTML = html.join("");
    els.marketDrawPropsCoordsSection.classList.remove("is-hidden");
  }

  function marketDrawUpdatePropsPanelOutputs(style) {
    var st = marketDrawMergeItemStyle({ type: "trendline", style: style || {} });
    if (els.marketDrawPropStrokeWidthValue) els.marketDrawPropStrokeWidthValue.textContent = fmt(st.strokeWidth, 1);
    if (els.marketDrawPropStrokeOpacityValue) els.marketDrawPropStrokeOpacityValue.textContent = Math.round(st.strokeOpacity * 100) + "%";
    if (els.marketDrawPropFillOpacityValue) els.marketDrawPropFillOpacityValue.textContent = Math.round(st.fillOpacity * 100) + "%";
    if (els.marketDrawPropFontSizeValue) els.marketDrawPropFontSizeValue.textContent = String(Math.round(st.fontSize));
    if (els.marketDrawPropBgOpacityValue) els.marketDrawPropBgOpacityValue.textContent = Math.round(st.bgOpacity * 100) + "%";
  }

  function marketDrawHidePropertiesPanel() {
    if (!els.marketDrawPropsPanel) return;
    els.marketDrawPropsPanel.classList.add("is-hidden");
    els.marketDrawPropsPanel.classList.remove("is-open");
  }

  function marketDrawShowPropertiesPanel() {
    if (!els.marketDrawPropsPanel) return;
    els.marketDrawPropsPanel.classList.remove("is-hidden");
    els.marketDrawPropsPanel.classList.add("is-open");
  }

  // QA checklist (drawer):
  // 1) Fresh load -> drawer hidden.
  // 2) Select object -> drawer appears with matching fields.
  // 3) Empty chart click / ESC / reset / symbol-tf-mode switch -> drawer closes.
  // 4) Delete selected -> drawer closes.
  // 5) Slider drag updates live and commits one undo on release.
  function marketDrawSyncPropertiesPanel() {
    if (!els.marketDrawPropsPanel) return;
    marketDrawEnsurePropsDrawerStructure();
    var draw = marketDrawState();
    var selectedId = hasValue(draw.selectedObjectId) ? String(draw.selectedObjectId) : "";
    if (!selectedId) {
      marketDrawHidePropertiesPanel();
      return;
    }

    var primary = marketDrawGetItemById(selectedId);
    if (!primary) {
      draw.selectedObjectId = null;
      draw.selectedId = null;
      draw.selectedIds = [];
      draw.activeObjectId = null;
      marketDrawHidePropertiesPanel();
      return;
    }
    if (!marketDrawSupportsPropertyPanelItem(primary)) {
      marketDrawHidePropertiesPanel();
      return;
    }

    var style = marketDrawMergeItemStyle(primary);
    var isRect = String(primary.type || "").toLowerCase() === "rect";
    var isText = String(primary.type || "").toLowerCase() === "text";
    var locked = marketDrawIsItemLocked(primary);
    var visible = marketDrawIsItemVisible(primary);

    if (els.marketDrawPropsTitle) {
      els.marketDrawPropsTitle.innerHTML = ''
        + '<span class="marketwatch-draw-props-title-icon">' + marketDrawTypeIconSvg(primary) + '</span>'
        + '<span class="marketwatch-draw-props-title-label">' + esc(marketDrawSelectedTypeLabel(primary)) + '</span>';
    }
    if (els.marketDrawPropsMeta) {
      if (!visible) els.marketDrawPropsMeta.textContent = "Hidden object style";
      else els.marketDrawPropsMeta.textContent = locked ? "Locked object (unlock to edit)" : "";
    }
    if (els.marketDrawPropsStrokeSection) els.marketDrawPropsStrokeSection.classList.remove("is-hidden");
    if (els.marketDrawPropsFillSection) els.marketDrawPropsFillSection.classList.toggle("is-hidden", !isRect);
    if (els.marketDrawPropsTextSection) els.marketDrawPropsTextSection.classList.toggle("is-hidden", !isText);

    if (els.marketDrawPropStrokeColor) els.marketDrawPropStrokeColor.value = marketDrawNormalizeHexColor(style.strokeColor, "#f6d365");
    if (els.marketDrawPropStrokeWidth) els.marketDrawPropStrokeWidth.value = String(style.strokeWidth);
    if (els.marketDrawPropStrokeStyle) els.marketDrawPropStrokeStyle.value = String(style.strokeStyle || "solid");
    if (els.marketDrawPropStrokeOpacity) els.marketDrawPropStrokeOpacity.value = String(style.strokeOpacity);
    if (els.marketDrawPropFillColor) els.marketDrawPropFillColor.value = marketDrawNormalizeHexColor(style.fillColor, "#f6d365");
    if (els.marketDrawPropFillOpacity) els.marketDrawPropFillOpacity.value = String(style.fillOpacity);
    if (els.marketDrawPropTextColor) els.marketDrawPropTextColor.value = marketDrawNormalizeHexColor(style.textColor, "#d7ebf7");
    if (els.marketDrawPropFontSize) els.marketDrawPropFontSize.value = String(Math.round(style.fontSize));
    if (els.marketDrawPropBgColor) els.marketDrawPropBgColor.value = marketDrawNormalizeHexColor(style.bgColor, "#050f16");
    if (els.marketDrawPropBgOpacity) els.marketDrawPropBgOpacity.value = String(style.bgOpacity);
    marketDrawUpdatePropsPanelOutputs(style);
    marketDrawRenderCoordinateSection(primary);

    var disableForLock = locked;
    var controls = [
      els.marketDrawPropStrokeColor,
      els.marketDrawPropStrokeWidth,
      els.marketDrawPropStrokeStyle,
      els.marketDrawPropStrokeOpacity,
      els.marketDrawPropFillColor,
      els.marketDrawPropFillOpacity,
      els.marketDrawPropTextColor,
      els.marketDrawPropFontSize,
      els.marketDrawPropBgColor,
      els.marketDrawPropBgOpacity
    ];
    for (var c = 0; c < controls.length; c++) {
      if (!controls[c]) continue;
      controls[c].disabled = disableForLock;
    }
    if (els.marketDrawPropLock) {
      els.marketDrawPropLock.textContent = locked ? "Unlock" : "Lock";
      els.marketDrawPropLock.disabled = false;
    }
    if (els.marketDrawPropDuplicate) els.marketDrawPropDuplicate.disabled = disableForLock;
    if (els.marketDrawPropBringFront) els.marketDrawPropBringFront.disabled = false;
    if (els.marketDrawPropSendBack) els.marketDrawPropSendBack.disabled = false;
    if (els.marketDrawPropVisibility) {
      els.marketDrawPropVisibility.classList.toggle("is-active", visible);
      els.marketDrawPropVisibility.setAttribute("aria-pressed", visible ? "true" : "false");
      els.marketDrawPropVisibility.setAttribute("title", visible ? "Hide object" : "Show object");
    }
    if (els.marketDrawPropLockQuick) {
      els.marketDrawPropLockQuick.classList.toggle("is-active", locked);
      els.marketDrawPropLockQuick.setAttribute("aria-pressed", locked ? "true" : "false");
      els.marketDrawPropLockQuick.setAttribute("title", locked ? "Unlock object" : "Lock object");
    }

    marketDrawShowPropertiesPanel();
  }

  function marketDrawDuplicateSelection() {
    var ids = marketDrawGetSelectionIds();
    if (ids.length !== 1) return;
    var source = marketDrawGetItemById(ids[0]);
    if (!source) return;
    marketDrawFinalizePropsCommit();
    marketDrawPushUndo();
    var copy = marketDrawClone(source);
    if (!copy) return;
    copy.id = "d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8);
    var bounds = marketDrawGetDataBounds();
    var dp = (Number(bounds.maxP) - Number(bounds.minP)) * 0.012;
    if (!isFinite(dp)) dp = 0;
    copy = marketDrawShiftItem(copy, 1, dp);
    marketDrawAddItem(copy);
    marketDrawSyncPropertiesPanel();
  }

  function marketDrawMoveSelectionLayer(toFront) {
    var ids = marketDrawGetSelectionIds();
    if (ids.length !== 1) return;
    var key = ids[0];
    var draw = marketDrawState();
    var index = -1;
    for (var i = 0; i < draw.items.length; i++) {
      if (String(draw.items[i].id) === String(key)) {
        index = i;
        break;
      }
    }
    if (index < 0) return;
    if (toFront && index === draw.items.length - 1) return;
    if (!toFront && index === 0) return;
    marketDrawFinalizePropsCommit();
    marketDrawPushUndo();
    var moved = draw.items.splice(index, 1)[0];
    if (toFront) draw.items.push(moved);
    else draw.items.unshift(moved);
    marketDrawScheduleSave();
    marketDrawScheduleRender();
    marketDrawSyncPropertiesPanel();
  }

  function marketDrawToggleLockSelection() {
    var ids = marketDrawGetSelectionIds();
    if (!ids.length) return;
    var allLocked = true;
    for (var i = 0; i < ids.length; i++) {
      var item = marketDrawGetItemById(ids[i]);
      if (!item || !marketDrawIsItemLocked(item)) {
        allLocked = false;
        break;
      }
    }
    marketDrawApplyStylePatchToSelection({ locked: !allLocked }, { commitNow: true, ignoreLock: true });
  }

  function bindMarketDrawPropertiesEvents() {
    if (!els.marketDrawPropsPanel) return;
    marketDrawEnsurePropsDrawerStructure();
    var draw = marketDrawState();
    if (draw.ui.propsPanelBound) return;

    var stopBubble = function (event) { event.stopPropagation(); };
    els.marketDrawPropsPanel.addEventListener("pointerdown", stopBubble);
    els.marketDrawPropsPanel.addEventListener("click", stopBubble);
    els.marketDrawPropsPanel.addEventListener("wheel", stopBubble);

    var bindLive = function (el, parser) {
      if (!el) return;
      var pendingTimer = null;
      var pendingValue = null;
      var flushPending = function () {
        if (pendingTimer) {
          clearTimeout(pendingTimer);
          pendingTimer = null;
        }
        if (pendingValue === null) return;
        var patch = parser(pendingValue);
        pendingValue = null;
        marketDrawApplyStylePatchToSelection(patch, { commitNow: false });
      };
      el.addEventListener("input", function () {
        pendingValue = el.value;
        if (pendingTimer) clearTimeout(pendingTimer);
        pendingTimer = setTimeout(function () {
          pendingTimer = null;
          flushPending();
        }, MW_DRAW_PROPS_LIVE_DEBOUNCE_MS);
      });
      el.addEventListener("change", function () {
        flushPending();
        var patch = parser(el.value);
        marketDrawApplyStylePatchToSelection(patch, { commitNow: true });
      });
      el.addEventListener("pointerup", function () {
        flushPending();
        marketDrawFinalizePropsCommit();
      });
    };

    bindLive(els.marketDrawPropStrokeColor, function (v) { return { strokeColor: marketDrawNormalizeHexColor(v, "#f6d365") }; });
    bindLive(els.marketDrawPropStrokeWidth, function (v) { return { strokeWidth: marketDrawClampNumber(v, 0.5, 12, 1.5) }; });
    bindLive(els.marketDrawPropStrokeStyle, function (v) { return { strokeStyle: String(v || "solid").toLowerCase() }; });
    bindLive(els.marketDrawPropStrokeOpacity, function (v) { return { strokeOpacity: marketDrawClampNumber(v, 0, 1, 1) }; });
    bindLive(els.marketDrawPropFillColor, function (v) { return { fillColor: marketDrawNormalizeHexColor(v, "#f6d365") }; });
    bindLive(els.marketDrawPropFillOpacity, function (v) { return { fillOpacity: marketDrawClampNumber(v, 0, 1, 0.12) }; });
    bindLive(els.marketDrawPropTextColor, function (v) { return { textColor: marketDrawNormalizeHexColor(v, "#d7ebf7") }; });
    bindLive(els.marketDrawPropFontSize, function (v) { return { fontSize: marketDrawClampNumber(v, 8, 64, 11) }; });
    bindLive(els.marketDrawPropBgColor, function (v) { return { bgColor: marketDrawNormalizeHexColor(v, "#050f16") }; });
    bindLive(els.marketDrawPropBgOpacity, function (v) { return { bgOpacity: marketDrawClampNumber(v, 0, 1, 0.9) }; });

    if (els.marketDrawPropDuplicate) {
      els.marketDrawPropDuplicate.addEventListener("click", function () {
        marketDrawDuplicateSelection();
      });
    }
    if (els.marketDrawPropBringFront) {
      els.marketDrawPropBringFront.addEventListener("click", function () {
        marketDrawMoveSelectionLayer(true);
      });
    }
    if (els.marketDrawPropSendBack) {
      els.marketDrawPropSendBack.addEventListener("click", function () {
        marketDrawMoveSelectionLayer(false);
      });
    }
    if (els.marketDrawPropLock) {
      els.marketDrawPropLock.addEventListener("click", function () {
        marketDrawToggleLockSelection();
      });
    }
    if (els.marketDrawPropVisibility) {
      els.marketDrawPropVisibility.addEventListener("click", function () {
        var selected = marketDrawGetSelectedObject();
        if (!selected) return;
        var current = marketDrawIsItemVisible(selected);
        marketDrawApplyStylePatchToSelection({ visible: !current }, { commitNow: true, ignoreLock: true });
      });
    }
    if (els.marketDrawPropLockQuick) {
      els.marketDrawPropLockQuick.addEventListener("click", function () {
        marketDrawToggleLockSelection();
      });
    }
    if (els.marketDrawPropDeleteQuick) {
      els.marketDrawPropDeleteQuick.addEventListener("click", function () {
        marketDrawDeleteSelected();
      });
    }
    if (els.marketDrawPropDelete) {
      els.marketDrawPropDelete.addEventListener("click", function () {
        marketDrawDeleteSelected();
      });
    }

    draw.ui.propsPanelBound = true;
  }

  function marketDrawSaveNow() {
    var draw = marketDrawState();
    if (!draw.key) return;
    var payload = marketDrawBuildPersistPayload(draw.items || []);
    marketDrawSavePayloadToLocalStorage(draw.key, payload);
    if (draw.scope) {
      marketDrawSaveRemote(draw.scope, payload);
    }
  }

  function marketDrawFlushPendingSave(useBeacon) {
    var draw = marketDrawState();
    if (draw.saveTimer) {
      clearTimeout(draw.saveTimer);
      draw.saveTimer = null;
    }
    if (!draw.key) return;
    var payload = marketDrawBuildPersistPayload(draw.items || []);
    marketDrawSavePayloadToLocalStorage(draw.key, payload);
    if (draw.scope) {
      marketDrawSaveRemote(draw.scope, payload, { useBeacon: !!useBeacon });
    }
  }

  function marketDrawOnBeforeUnload() {
    marketDrawFlushPendingSave(true);
  }

  function marketDrawScheduleSave() {
    var draw = marketDrawState();
    if (draw.saveTimer) clearTimeout(draw.saveTimer);
    draw.saveTimer = setTimeout(function () {
      draw.saveTimer = null;
      marketDrawSaveNow();
    }, MW_DRAW_SAVE_DEBOUNCE_MS);
  }

  function marketDrawPushUndo() {
    var snap = marketDrawSerializeItems();
    marketDrawPushUndoSnapshot(snap);
  }

  function marketDrawApplyItems(items, persist) {
    var draw = marketDrawState();
    marketDrawFinalizePropsCommit();
    draw.items = marketDrawNormalizeItems(items);
    marketDrawReindexItems();
    draw.selectedIds = [];
    draw.selectedId = null;
    draw.selectedObjectId = null;
    draw.activeObjectId = null;
    draw.hoverId = null;
    draw.pendingPoint = null;
    draw.interaction = null;
    marketDrawResetPropsEditSession();
    marketDrawScheduleRender();
    marketDrawUpdateToolbarState();
    marketDrawSyncPropertiesPanel();
    if (persist !== false) marketDrawScheduleSave();
  }

  function marketDrawUndo() {
    var draw = marketDrawState();
    marketDrawFinalizePropsCommit();
    if (!draw.undoStack.length) return;
    var current = marketDrawSerializeItems();
    var previous = draw.undoStack.pop();
    draw.redoStack.push(current);
    try {
      var parsed = JSON.parse(previous);
      marketDrawApplyItems(parsed, true);
    } catch (e) {}
  }

  function marketDrawRedo() {
    var draw = marketDrawState();
    marketDrawFinalizePropsCommit();
    if (!draw.redoStack.length) return;
    var current = marketDrawSerializeItems();
    var next = draw.redoStack.pop();
    draw.undoStack.push(current);
    try {
      var parsed = JSON.parse(next);
      marketDrawApplyItems(parsed, true);
    } catch (e) {}
  }

  function marketDrawClearAll() {
    var draw = marketDrawState();
    if (!draw.items.length) return;
    if (!window.confirm("Clear all drawings for current chart context?")) return;
    marketDrawFinalizePropsCommit();
    marketDrawPushUndo();
    marketDrawApplyItems([], true);
  }

  function marketDrawSyncContext(force) {
    var draw = marketDrawState();
    var scope = marketDrawBuildScope();
    var key = marketDrawBuildStorageKey(scope);
    scope.key = key;
    if (!force && draw.key === key) return;
    if (draw.key && draw.key !== key) {
      marketDrawFlushPendingSave(false);
    }
    marketDrawFinalizePropsCommit();
    draw.key = key;
    draw.scope = scope;
    draw.items = marketDrawLoadStorageItems(key, scope);
    marketDrawReindexItems();
    draw.selectedIds = [];
    draw.selectedId = null;
    draw.selectedObjectId = null;
    draw.activeObjectId = null;
    draw.hoverId = null;
    draw.pendingPoint = null;
    draw.interaction = null;
    draw.undoStack = [];
    draw.redoStack = [];
    draw.ui.moreOpen = false;
    draw.pointer = null;
    marketDrawResetPropsEditSession();
    marketDrawSyncToolbarContext();
    marketDrawUpdateToolbarState();
    marketDrawSyncPropertiesPanel();
    marketDrawSyncOverlayPointerRouting();
    marketDrawScheduleRender();
    marketDrawLoadRemote(scope, marketDrawSerializeItems());
  }

  function marketDrawSetTool(tool) {
    var draw = marketDrawState();
    var nextTool = marketDrawToolName(tool);
    if (nextTool === "line") nextTool = "trendline";
    if (nextTool === "box") nextTool = "rect";
    if (nextTool !== "select") marketDrawClearSelection();
    draw.activeTool = nextTool;
    draw.pendingPoint = null;
    draw.interaction = null;
    draw.hoverId = null;
    draw.ui.moreOpen = false;
    marketDrawUpdateToolbarState();
    marketDrawSyncOverlayPointerRouting();
    marketDrawScheduleRender();
  }

  function marketDrawToggleCrosshair() {
    var draw = marketDrawState();
    draw.crosshairEnabled = !draw.crosshairEnabled;
    if (!draw.crosshairEnabled) draw.pointer = null;
    marketDrawUpdateToolbarState();
    marketDrawSyncOverlayPointerRouting();
    marketDrawScheduleRender();
  }

  function marketDrawNormalizeSnapMode(mode) {
    var value = String(mode || "").toLowerCase();
    if (value === "ohlc" || value === "highlow" || value === "off") return value;
    return "off";
  }

  function marketDrawSetSnapMode(mode) {
    var draw = marketDrawState();
    draw.snapMode = marketDrawNormalizeSnapMode(mode);
    marketDrawUpdateToolbarState();
    marketDrawScheduleRender();
  }

  function marketDrawSetSnapRadius(valuePx) {
    var draw = marketDrawState();
    var next = Math.round(Number(valuePx));
    if (!isFinite(next)) next = MW_DRAW_SNAP_RADIUS_DEFAULT;
    if (next < MW_DRAW_SNAP_RADIUS_MIN) next = MW_DRAW_SNAP_RADIUS_MIN;
    if (next > MW_DRAW_SNAP_RADIUS_MAX) next = MW_DRAW_SNAP_RADIUS_MAX;
    draw.snapRadiusPx = next;
    marketDrawUpdateToolbarState();
  }

  function marketDrawToggleMoreMenu(forceOpen) {
    var draw = marketDrawState();
    draw.ui.moreOpen = forceOpen === undefined ? !draw.ui.moreOpen : !!forceOpen;
    marketDrawUpdateToolbarState();
  }

  function marketDrawCloseMenus() {
    var draw = marketDrawState();
    if (!draw.ui.moreOpen) return;
    draw.ui.moreOpen = false;
    marketDrawUpdateToolbarState();
  }

  function marketDrawToggleSnap() {
    marketDrawSetSnapMode(marketDrawState().snapMode === "off" ? "ohlc" : "off");
  }

  function marketDrawUpdateToolbarState() {
    var draw = marketDrawState();
    if (els.marketDrawToolButtons && els.marketDrawToolButtons.length) {
      for (var i = 0; i < els.marketDrawToolButtons.length; i++) {
        var btn = els.marketDrawToolButtons[i];
        var tool = String(btn.getAttribute("data-draw-tool") || "").toLowerCase();
        btn.classList.toggle("is-active", tool === draw.activeTool);
      }
    }
    if (els.marketDrawActionButtons && els.marketDrawActionButtons.length) {
      for (var j = 0; j < els.marketDrawActionButtons.length; j++) {
        var actionBtn = els.marketDrawActionButtons[j];
        var action = String(actionBtn.getAttribute("data-draw-action") || "").toLowerCase();
        if (action === "crosshair") actionBtn.classList.toggle("is-active", !!draw.crosshairEnabled);
        if (action === "undo") actionBtn.disabled = !draw.undoStack.length;
        if (action === "redo") actionBtn.disabled = !draw.redoStack.length;
        if (action === "more") {
          actionBtn.classList.toggle("is-active", !!draw.ui.moreOpen);
          actionBtn.classList.toggle("has-state", draw.snapMode !== "off");
          actionBtn.setAttribute("aria-expanded", draw.ui.moreOpen ? "true" : "false");
        }
      }
    }
    if (els.marketDrawMoreMenu) {
      els.marketDrawMoreMenu.classList.toggle("is-hidden", !draw.ui.moreOpen);
    }
    if (els.marketDrawSnapMode) {
      els.marketDrawSnapMode.value = marketDrawNormalizeSnapMode(draw.snapMode);
    }
    if (els.marketDrawSnapRadius) {
      els.marketDrawSnapRadius.value = String(draw.snapRadiusPx || MW_DRAW_SNAP_RADIUS_DEFAULT);
    }
    if (els.marketDrawSnapRadiusValue) {
      els.marketDrawSnapRadiusValue.textContent = String(draw.snapRadiusPx || MW_DRAW_SNAP_RADIUS_DEFAULT) + "px";
    }
  }

  function marketDrawEnsureOverlay() {
    var draw = marketDrawState();
    var overlay = els.marketDrawOverlay;
    if (!overlay && els.marketChartWrap) {
      overlay = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      overlay.setAttribute("id", "marketDrawOverlay");
      overlay.setAttribute("class", "marketwatch-draw-overlay");
      els.marketChartWrap.appendChild(overlay);
      els.marketDrawOverlay = overlay;
    }
    if (!overlay) return null;

    var w = Math.max(1, overlay.clientWidth || (els.marketChartWrap ? els.marketChartWrap.clientWidth : 0) || 1);
    var h = Math.max(1, overlay.clientHeight || (els.marketChartWrap ? els.marketChartWrap.clientHeight : 0) || 1);
    overlay.setAttribute("viewBox", "0 0 " + w + " " + h);
    overlay.setAttribute("width", String(w));
    overlay.setAttribute("height", String(h));

    if (!draw.listenersBound) {
      overlay.addEventListener("pointerdown", marketDrawOnPointerDown);
      overlay.addEventListener("pointermove", marketDrawOnPointerMove);
      overlay.addEventListener("pointerleave", marketDrawOnPointerLeave);
      overlay.addEventListener("dblclick", marketDrawOnDoubleClick);
      overlay.addEventListener("wheel", marketDrawOnOverlayWheel, { passive: false });
      overlay.addEventListener("pointercancel", marketDrawOnPointerUp);
      overlay.addEventListener("lostpointercapture", marketDrawOnPointerUp);
      window.addEventListener("pointerup", marketDrawOnPointerUp);
      draw.listenersBound = true;
    }
    draw.initialized = true;
    marketDrawSyncOverlayPointerRouting();
    return overlay;
  }

  function marketDrawNormalizeChartTime(value) {
    if (value === null || value === undefined) return NaN;
    if (typeof value === "number" && isFinite(value)) return Math.floor(value);
    if (typeof value === "string") {
      var n = Number(value);
      if (isFinite(n)) return Math.floor(n);
      var ts = Date.parse(value);
      if (isFinite(ts)) return Math.floor(ts / 1000);
      return NaN;
    }
    if (typeof value === "object") {
      if (isFinite(Number(value.timestamp))) return Math.floor(Number(value.timestamp));
      if (isFinite(Number(value.time))) return Math.floor(Number(value.time));
      if (isFinite(Number(value.year)) && isFinite(Number(value.month)) && isFinite(Number(value.day))) {
        var d = Date.UTC(Number(value.year), Number(value.month) - 1, Number(value.day), 0, 0, 0);
        if (isFinite(d)) return Math.floor(d / 1000);
      }
    }
    return NaN;
  }

  function marketDrawGetDataBounds() {
    var candles = marketWatch.candles || [];
    if (!candles.length) {
      return { minT: 0, maxT: 0, minP: 0, maxP: 1 };
    }
    var minT = Number(candles[0].time);
    var maxT = Number(candles[candles.length - 1].time);
    var minP = Infinity;
    var maxP = -Infinity;
    for (var i = 0; i < candles.length; i++) {
      var c = candles[i];
      var low = Number(c.low);
      var high = Number(c.high);
      if (isFinite(low) && low < minP) minP = low;
      if (isFinite(high) && high > maxP) maxP = high;
    }
    if (!isFinite(minP) || !isFinite(maxP) || minP === maxP) {
      minP = Number(candles[candles.length - 1].close || 0);
      maxP = minP + 1;
    }
    var span = Math.max(1e-8, maxP - minP);
    var pad = span * 0.06;
    return {
      minT: Math.floor(minT),
      maxT: Math.floor(maxT),
      minP: minP - pad,
      maxP: maxP + pad
    };
  }

  function marketDrawGetVisibleTimeBounds() {
    var fallback = marketDrawGetDataBounds();
    var logical = marketDrawGetVisibleLogicalBounds();
    if (isFinite(logical.minL) && isFinite(logical.maxL)) {
      var minFromLogical = marketDrawLogicalToTime(logical.minL);
      var maxFromLogical = marketDrawLogicalToTime(logical.maxL);
      if (isFinite(minFromLogical) && isFinite(maxFromLogical)) {
        return {
          minT: Math.floor(Math.min(minFromLogical, maxFromLogical)),
          maxT: Math.floor(Math.max(minFromLogical, maxFromLogical))
        };
      }
    }

    var chart = marketWatch.chart;
    if (!chart || !els.marketWatchChart) return { minT: fallback.minT, maxT: fallback.maxT };
    var scale = chart.timeScale ? chart.timeScale() : null;
    if (!scale || typeof scale.coordinateToTime !== "function") return { minT: fallback.minT, maxT: fallback.maxT };
    var left = marketDrawNormalizeChartTime(scale.coordinateToTime(0));
    var right = marketDrawNormalizeChartTime(scale.coordinateToTime(els.marketWatchChart.clientWidth || 0));
    if (!isFinite(left) || !isFinite(right)) return { minT: fallback.minT, maxT: fallback.maxT };
    return {
      minT: Math.floor(Math.min(left, right)),
      maxT: Math.floor(Math.max(left, right))
    };
  }

  function marketDrawGetVisibleLogicalBounds() {
    var candles = marketWatch.candles || [];
    var fallbackMin = candles.length ? 0 : 0;
    var fallbackMax = candles.length ? (candles.length - 1 + MW_DRAW_FUTURE_BARS) : MW_DRAW_FUTURE_BARS;
    var lastL = marketDrawGetLastLogical();
    var minFutureMax = lastL + MW_DRAW_FUTURE_BARS;
    var chart = marketWatch.chart;
    if (!chart || !els.marketWatchChart) return { minL: fallbackMin, maxL: Math.max(fallbackMax, minFutureMax) };
    var scale = chart.timeScale ? chart.timeScale() : null;
    if (!scale) return { minL: fallbackMin, maxL: Math.max(fallbackMax, minFutureMax) };

    try {
      if (typeof scale.getVisibleLogicalRange === "function") {
        var range = scale.getVisibleLogicalRange();
        if (range && isFinite(Number(range.from)) && isFinite(Number(range.to))) {
          return { minL: Number(range.from), maxL: Math.max(Number(range.to), minFutureMax) };
        }
      }
    } catch (e) {}

    try {
      if (typeof scale.coordinateToLogical === "function") {
        var left = Number(scale.coordinateToLogical(0));
        var right = Number(scale.coordinateToLogical(els.marketWatchChart.clientWidth || 0));
        if (isFinite(left) && isFinite(right)) {
          return {
            minL: Math.min(left, right),
            maxL: Math.max(Math.max(left, right), minFutureMax)
          };
        }
      }
    } catch (e1) {}
    return { minL: fallbackMin, maxL: Math.max(fallbackMax, minFutureMax) };
  }

  function marketDrawClampPoint(point) {
    var p = marketDrawNormalizePoint(point);
    if (!p) return null;
    var visibleLogical = marketDrawGetVisibleLogicalBounds();
    var visibleTime = marketDrawGetVisibleTimeBounds();
    var bounds = marketDrawGetDataBounds();

    if (!isFinite(Number(p.li))) p.li = null;
    if (p.li === null) {
      var inferredLogical = marketDrawTimeToLogical(p.t);
      if (isFinite(inferredLogical)) p.li = inferredLogical;
    }

    if (p.li !== null) {
      if (isFinite(visibleLogical.minL) && p.li < visibleLogical.minL) p.li = visibleLogical.minL;
      if (isFinite(visibleLogical.maxL) && p.li > visibleLogical.maxL) p.li = visibleLogical.maxL;
      var tFromLogical = marketDrawLogicalToTime(p.li);
      if (isFinite(tFromLogical)) p.t = Math.floor(tFromLogical);
    } else {
      if (isFinite(visibleTime.minT) && p.t < visibleTime.minT) p.t = visibleTime.minT;
      var maxFutureT = marketDrawGetMaxFutureTime();
      var hardMaxT = visibleTime.maxT;
      if (isFinite(maxFutureT) && (!isFinite(hardMaxT) || maxFutureT > hardMaxT)) hardMaxT = maxFutureT;
      if (isFinite(hardMaxT) && p.t > hardMaxT) p.t = hardMaxT;
    }

    if (isFinite(bounds.minP) && p.p < bounds.minP) p.p = bounds.minP;
    if (isFinite(bounds.maxP) && p.p > bounds.maxP) p.p = bounds.maxP;
    return p;
  }

  function marketDrawFindNearestCandleWithIndex(t) {
    var candles = marketWatch.candles || [];
    if (!candles.length) return null;
    var target = Number(t);
    if (!isFinite(target)) return { candle: candles[candles.length - 1], index: candles.length - 1 };
    var lo = 0;
    var hi = candles.length - 1;
    while (lo <= hi) {
      var mid = Math.floor((lo + hi) / 2);
      var mt = Number(candles[mid].time);
      if (mt === target) return { candle: candles[mid], index: mid };
      if (mt < target) lo = mid + 1;
      else hi = mid - 1;
    }
    var leftIdx = hi >= 0 ? hi : -1;
    var rightIdx = lo < candles.length ? lo : -1;
    if (leftIdx < 0 && rightIdx < 0) return null;
    if (leftIdx < 0) return { candle: candles[rightIdx], index: rightIdx };
    if (rightIdx < 0) return { candle: candles[leftIdx], index: leftIdx };
    var left = candles[leftIdx];
    var right = candles[rightIdx];
    return Math.abs(Number(left.time) - target) <= Math.abs(Number(right.time) - target)
      ? { candle: left, index: leftIdx }
      : { candle: right, index: rightIdx };
  }

  function marketDrawFindNearestCandle(t) {
    var hit = marketDrawFindNearestCandleWithIndex(t);
    return hit ? hit.candle : null;
  }

  function marketDrawSnapPoint(point) {
    var draw = marketDrawState();
    if (draw.snapMode === "off") return marketDrawNormalizePoint(point);
    var p = marketDrawNormalizePoint(point);
    if (!p) return null;
    var hit = marketDrawFindNearestCandleWithIndex(p.t);
    if (!hit || !hit.candle) return p;

    var candle = hit.candle;
    var prices = draw.snapMode === "highlow"
      ? [Number(candle.high), Number(candle.low)]
      : [Number(candle.close), Number(candle.open), Number(candle.high), Number(candle.low)];

    var best = prices[0];
    var bestDist = Math.abs(p.p - best);
    for (var i = 1; i < prices.length; i++) {
      var candidate = prices[i];
      if (!isFinite(candidate)) continue;
      var dist = Math.abs(p.p - candidate);
      if (dist < bestDist) {
        best = candidate;
        bestDist = dist;
      }
    }

    var snapped = marketDrawClampPoint({ t: Number(candle.time), p: best, li: hit.index });
    if (!snapped) return p;

    var sourceScreen = marketDrawDataToScreen(p.t, p.p, p.li);
    var snappedScreen = marketDrawDataToScreen(snapped.t, snapped.p, snapped.li);
    var radius = Math.max(MW_DRAW_SNAP_RADIUS_MIN, Number(draw.snapRadiusPx) || MW_DRAW_SNAP_RADIUS_DEFAULT);
    if (sourceScreen && snappedScreen) {
      var dx = Number(sourceScreen.x) - Number(snappedScreen.x);
      var dy = Number(sourceScreen.y) - Number(snappedScreen.y);
      var distPx = Math.sqrt(dx * dx + dy * dy);
      if (isFinite(distPx) && distPx > radius) return p;
    }

    return snapped;
  }

  function marketDrawDataToScreen(timeSec, price, logical) {
    if (!marketWatch.chart || !marketWatch.candleSeries) return null;

    var t = Number(timeSec);
    var p = Number(price);
    var li = Number(logical);
    if (typeof timeSec === "object" && timeSec !== null) {
      var pointInput = marketDrawNormalizePoint(timeSec);
      if (!pointInput) return null;
      t = Number(pointInput.t);
      p = Number(pointInput.p);
      li = Number(pointInput.li);
    }

    if (!isFinite(t) || !isFinite(p)) return null;
    var x = null;
    var y = null;
    try {
      var scale = marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (scale && typeof scale.logicalToCoordinate === "function" && isFinite(li)) {
        x = scale.logicalToCoordinate(li);
      }
      if ((!isFinite(Number(x))) && scale && typeof scale.timeToCoordinate === "function") {
        x = scale.timeToCoordinate(Math.floor(t));
      }
      if ((!isFinite(Number(x))) && scale && typeof scale.logicalToCoordinate === "function") {
        var logicalFromTime = marketDrawTimeToLogical(t);
        if (isFinite(logicalFromTime)) x = scale.logicalToCoordinate(logicalFromTime);
      }
    } catch (e) {
      x = null;
    }
    try {
      if (typeof marketWatch.candleSeries.priceToCoordinate === "function") {
        y = marketWatch.candleSeries.priceToCoordinate(p);
      }
    } catch (e1) {
      y = null;
    }
    if (!isFinite(Number(x)) || !isFinite(Number(y))) return null;
    return { x: Number(x), y: Number(y) };
  }

  function marketDrawScreenToDataRaw(x, y) {
    if (!marketWatch.chart || !marketWatch.candleSeries) return null;
    var xx = Number(x);
    var yy = Number(y);
    if (!isFinite(xx) || !isFinite(yy)) return null;
    var t = NaN;
    var p = NaN;
    var li = NaN;
    try {
      var scale = marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (scale && typeof scale.coordinateToTime === "function") {
        t = marketDrawNormalizeChartTime(scale.coordinateToTime(xx));
      }
      if (scale && typeof scale.coordinateToLogical === "function") {
        li = Number(scale.coordinateToLogical(xx));
      }
    } catch (e) {
      t = NaN;
      li = NaN;
    }

    var lastLogical = marketDrawGetLastLogical();
    var lastBarX = marketDrawGetLastBarX();
    var barSpacing = marketDrawEstimateBarSpacingPx();
    if (isFinite(lastBarX) && isFinite(barSpacing) && barSpacing > 0.1 && xx > lastBarX + 0.5) {
      var inferredFutureLogical = lastLogical + ((xx - lastBarX) / barSpacing);
      if (!isFinite(li) || li <= lastLogical + 1e-6) li = inferredFutureLogical;
      if (!isFinite(t) || Number(t) <= Number(marketDrawGetLastBarTime())) {
        t = marketDrawLogicalToTime(li);
      }
    }

    try {
      if (typeof marketWatch.candleSeries.coordinateToPrice === "function") {
        p = Number(marketWatch.candleSeries.coordinateToPrice(yy));
      }
    } catch (e1) {
      p = NaN;
    }

    if (!isFinite(t) && isFinite(li)) {
      t = marketDrawLogicalToTime(li);
    }
    if (!isFinite(li) && isFinite(t)) {
      li = marketDrawTimeToLogical(t);
    }

    if (!isFinite(t)) {
      var nearest = marketDrawFindNearestCandle(0);
      if (nearest) t = Number(nearest.time);
    }
    if (!isFinite(p)) {
      var last = marketWatch.candles && marketWatch.candles.length ? marketWatch.candles[marketWatch.candles.length - 1] : null;
      p = last ? Number(last.close) : NaN;
    }
    if (!isFinite(t) || !isFinite(p)) return null;
    if (!isFinite(li)) li = marketDrawTimeToLogical(t);
    return { t: Math.floor(t), p: p, li: isFinite(li) ? li : null };
  }

  function marketDrawScreenToData(x, y) {
    var raw = marketDrawScreenToDataRaw(x, y);
    if (!raw) return null;
    var snapped = marketDrawSnapPoint(raw);
    return marketDrawClampPoint(snapped || raw);
  }

  function screenToData(x, y) {
    return marketDrawScreenToData(x, y);
  }

  function dataToScreen(timeSec, price, logical) {
    return marketDrawDataToScreen(timeSec, price, logical);
  }

  function marketDrawGetPointerXY(event) {
    var overlay = marketDrawEnsureOverlay();
    if (!overlay) return null;
    var rect = overlay.getBoundingClientRect();
    var x = Number(event.clientX) - rect.left;
    var y = Number(event.clientY) - rect.top;
    if (!isFinite(x) || !isFinite(y)) return null;
    var width = overlay.clientWidth || rect.width || 0;
    var height = overlay.clientHeight || rect.height || 0;
    if (x < 0 || y < 0 || x > width || y > height) return null;
    return { x: x, y: y };
  }

  function marketDrawCapturePointer(event) {
    var overlay = els.marketDrawOverlay;
    if (!overlay || !event || !isFinite(Number(event.pointerId))) return;
    if (typeof overlay.setPointerCapture !== "function") return;
    try {
      overlay.setPointerCapture(Number(event.pointerId));
    } catch (e) {}
  }

  function marketDrawReleasePointer(event) {
    var overlay = els.marketDrawOverlay;
    if (!overlay || !event || !isFinite(Number(event.pointerId))) return;
    if (typeof overlay.releasePointerCapture !== "function") return;
    try {
      overlay.releasePointerCapture(Number(event.pointerId));
    } catch (e) {}
  }

  function marketDrawGetVisibleLogicalRangeSafe() {
    var chart = marketWatch.chart;
    if (!chart || typeof chart.timeScale !== "function") return null;
    var scale = chart.timeScale();
    if (!scale) return null;

    try {
      if (typeof scale.getVisibleLogicalRange === "function") {
        var direct = scale.getVisibleLogicalRange();
        if (direct && isFinite(Number(direct.from)) && isFinite(Number(direct.to))) {
          return { from: Number(direct.from), to: Number(direct.to) };
        }
      }
    } catch (e) {}

    var width = Math.max(1, (els.marketWatchChart && els.marketWatchChart.clientWidth) || 0);
    try {
      if (typeof scale.coordinateToLogical === "function") {
        var l0 = Number(scale.coordinateToLogical(0));
        var l1 = Number(scale.coordinateToLogical(width));
        if (isFinite(l0) && isFinite(l1)) {
          return { from: Math.min(l0, l1), to: Math.max(l0, l1) };
        }
      }
    } catch (e1) {}

    return null;
  }

  function marketDrawLogicalFromCoordinate(x, fallbackRange) {
    var chart = marketWatch.chart;
    if (!chart || typeof chart.timeScale !== "function") return NaN;
    var scale = chart.timeScale();
    if (!scale) return NaN;
    var xx = Number(x);
    if (!isFinite(xx)) return NaN;

    try {
      if (typeof scale.coordinateToLogical === "function") {
        var direct = Number(scale.coordinateToLogical(xx));
        if (isFinite(direct)) return direct;
      }
    } catch (e) {}

    if (!fallbackRange || !isFinite(Number(fallbackRange.from)) || !isFinite(Number(fallbackRange.to))) return NaN;
    var width = Math.max(1, (els.marketWatchChart && els.marketWatchChart.clientWidth) || 0);
    var ratio = xx / width;
    if (!isFinite(ratio)) ratio = 0.5;
    if (ratio < 0) ratio = 0;
    if (ratio > 1) ratio = 1;
    return Number(fallbackRange.from) + (Number(fallbackRange.to) - Number(fallbackRange.from)) * ratio;
  }

  function marketDrawApplyOverlayWheelZoom(event) {
    if (!marketWatch.chart || !event) return;
    var range = marketDrawGetVisibleLogicalRangeSafe();
    if (!range) return;
    var from = Number(range.from);
    var to = Number(range.to);
    if (!isFinite(from) || !isFinite(to)) return;
    if (to <= from) {
      var tmp = from;
      from = to;
      to = tmp;
    }

    var span = Math.max(1e-4, to - from);
    var zoomIn = Number(event.deltaY || 0) < 0;
    var factor = zoomIn ? 0.88 : 1.15;
    var minSpan = 8;
    var maxSpan = Math.max(80, (marketWatch.candles && marketWatch.candles.length ? marketWatch.candles.length : 0) + MW_DRAW_FUTURE_BARS * 2);
    var nextSpan = span * factor;
    if (nextSpan < minSpan) nextSpan = minSpan;
    if (nextSpan > maxSpan) nextSpan = maxSpan;

    var overlay = els.marketDrawOverlay;
    var rect = overlay ? overlay.getBoundingClientRect() : null;
    var x = rect ? (Number(event.clientX) - rect.left) : ((els.marketWatchChart && els.marketWatchChart.clientWidth) ? (els.marketWatchChart.clientWidth / 2) : 0);
    var anchor = marketDrawLogicalFromCoordinate(x, { from: from, to: to });
    if (!isFinite(anchor)) anchor = from + span * 0.5;
    var anchorRatio = span > 0 ? (anchor - from) / span : 0.5;
    if (!isFinite(anchorRatio)) anchorRatio = 0.5;
    if (anchorRatio < 0) anchorRatio = 0;
    if (anchorRatio > 1) anchorRatio = 1;

    var nextFrom = anchor - anchorRatio * nextSpan;
    var nextTo = nextFrom + nextSpan;
    var minLogical = -Math.max(20, MW_DRAW_FUTURE_BARS);
    var maxLogical = marketDrawGetLastLogical() + MW_DRAW_FUTURE_BARS;
    if (isFinite(maxLogical) && nextTo > maxLogical) {
      nextFrom -= (nextTo - maxLogical);
      nextTo = maxLogical;
    }
    if (isFinite(minLogical) && nextFrom < minLogical) {
      nextTo += (minLogical - nextFrom);
      nextFrom = minLogical;
    }
    if ((nextTo - nextFrom) < minSpan) nextTo = nextFrom + minSpan;

    try {
      var scale = marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (!scale || typeof scale.setVisibleLogicalRange !== "function") return;
      scale.setVisibleLogicalRange({ from: nextFrom, to: nextTo });
      marketDrawEnsureFutureSpace();
      marketDrawScheduleRender();
    } catch (e) {}
  }

  function marketDrawOnOverlayWheel(event) {
    if (state.activeTab !== "marketwatch") return;
    if (!marketDrawShouldOverlayCaptureBackground()) return;
    if (els.marketDrawToolbar && els.marketDrawToolbar.contains(event.target)) return;
    event.preventDefault();
    event.stopPropagation();
    marketDrawApplyOverlayWheelZoom(event);
  }

  function marketDrawCreateSvgEl(tagName, attrs, parent) {
    var el = document.createElementNS("http://www.w3.org/2000/svg", tagName);
    if (attrs) {
      for (var key in attrs) {
        if (!Object.prototype.hasOwnProperty.call(attrs, key)) continue;
        el.setAttribute(key, String(attrs[key]));
      }
    }
    if (parent) parent.appendChild(el);
    return el;
  }

  function marketDrawReindexItems() {
    var draw = marketDrawState();
    var next = new Map();
    for (var i = 0; i < draw.items.length; i++) {
      var item = draw.items[i];
      if (!item || !hasValue(item.id)) continue;
      next.set(String(item.id), item);
    }
    draw.drawingsById = next;
  }

  function marketDrawGetItemById(id) {
    var draw = marketDrawState();
    if (!hasValue(id)) return null;
    var key = String(id);
    if (draw.drawingsById && typeof draw.drawingsById.get === "function") {
      var fromMap = draw.drawingsById.get(key);
      if (fromMap) return fromMap;
    }
    for (var i = 0; i < draw.items.length; i++) {
      if (String(draw.items[i].id) === key) return draw.items[i];
    }
    return null;
  }

  function marketDrawGetSelectedObject() {
    var draw = marketDrawState();
    if (!hasValue(draw.selectedObjectId)) return null;
    return marketDrawGetItemById(draw.selectedObjectId);
  }

  function marketDrawGetRectScreenMetrics(item) {
    if (!item || item.type !== "rect" || !item.a || !item.b) return null;
    var pa = marketDrawDataToScreen(item.a);
    var pb = marketDrawDataToScreen(item.b);
    if (!pa || !pb) return null;
    var left = Math.min(pa.x, pb.x);
    var right = Math.max(pa.x, pb.x);
    var top = Math.min(pa.y, pb.y);
    var bottom = Math.max(pa.y, pb.y);
    return {
      left: left,
      right: right,
      top: top,
      bottom: bottom,
      width: Math.max(0, right - left),
      height: Math.max(0, bottom - top)
    };
  }

  function marketDrawRectHitTest(item, pointer) {
    var box = marketDrawGetRectScreenMetrics(item);
    if (!box || !pointer) return null;
    var x = Number(pointer.x);
    var y = Number(pointer.y);
    if (!isFinite(x) || !isFinite(y)) return null;

    var tol = MW_DRAW_RECT_HIT_TOLERANCE_PX;
    var nearLeft = Math.abs(x - box.left) <= tol;
    var nearRight = Math.abs(x - box.right) <= tol;
    var nearTop = Math.abs(y - box.top) <= tol;
    var nearBottom = Math.abs(y - box.bottom) <= tol;
    var insideX = x >= box.left - tol && x <= box.right + tol;
    var insideY = y >= box.top - tol && y <= box.bottom + tol;
    if (!insideX || !insideY) return null;

    if (nearLeft && nearTop) return "resize-nw";
    if (nearRight && nearTop) return "resize-ne";
    if (nearLeft && nearBottom) return "resize-sw";
    if (nearRight && nearBottom) return "resize-se";
    if (nearTop) return "resize-n";
    if (nearBottom) return "resize-s";
    if (nearLeft) return "resize-w";
    if (nearRight) return "resize-e";
    if (x >= box.left && x <= box.right && y >= box.top && y <= box.bottom) return "move";
    return null;
  }

  function marketDrawRectZoneToHandle(zone) {
    var z = String(zone || "").toLowerCase();
    if (z === "resize-nw") return "tl";
    if (z === "resize-ne") return "tr";
    if (z === "resize-sw") return "bl";
    if (z === "resize-se") return "br";
    if (z === "resize-n") return "n";
    if (z === "resize-s") return "s";
    if (z === "resize-w") return "w";
    if (z === "resize-e") return "e";
    return "";
  }

  function marketDrawReplaceItem(item) {
    var draw = marketDrawState();
    if (!item || !hasValue(item.id)) return false;
    var key = String(item.id);
    for (var i = 0; i < draw.items.length; i++) {
      if (String(draw.items[i].id) === key) {
        draw.items[i] = marketDrawNormalizeItem(item) || draw.items[i];
        if (draw.drawingsById && typeof draw.drawingsById.set === "function") {
          draw.drawingsById.set(key, draw.items[i]);
        }
        return true;
      }
    }
    return false;
  }

  function marketDrawAddItem(rawItem) {
    var normalized = marketDrawNormalizeItem(rawItem);
    if (!normalized) return null;
    var draw = marketDrawState();
    draw.items.push(normalized);
    if (draw.drawingsById && typeof draw.drawingsById.set === "function") {
      draw.drawingsById.set(String(normalized.id), normalized);
    }
    marketDrawSetSelection(normalized.id);
    draw.pendingPoint = null;
    draw.interaction = null;
    marketDrawScheduleSave();
    marketDrawScheduleRender();
    marketDrawSyncPropertiesPanel();
    return normalized;
  }

  function marketDrawGetPipMeta() {
    var symbol = String(marketWatch.symbol || "").toUpperCase();
    if (symbol.indexOf("XAU") === 0) return { size: 0.1, unit: "pts" };
    if (symbol.indexOf("XAG") === 0) return { size: 0.01, unit: "pts" };
    if (symbol.indexOf("JPY") >= 0) return { size: 0.01, unit: "pips" };
    return { size: 0.0001, unit: "pips" };
  }

  function marketDrawFormatMeasure(a, b) {
    var diff = Number(b.p) - Number(a.p);
    if (!isFinite(diff)) diff = 0;
    var pct = 0;
    if (isFinite(Number(a.p)) && Number(a.p) !== 0) pct = (diff / Number(a.p)) * 100;
    var pipMeta = marketDrawGetPipMeta();
    var pips = diff / Math.max(1e-10, Number(pipMeta.size) || 0.0001);
    var decimals = pipMeta.unit === "pts" ? 4 : 5;
    return (diff >= 0 ? "+" : "") + fmt(diff, decimals) + " | " + fmt(pct, 2) + "% | " + fmt(pips, 1) + " " + pipMeta.unit;
  }

  function marketDrawBuildPositionDraft(type, entry, stopPrice, takePrice, endInput) {
    var kind = String(type || "").toLowerCase() === "short" ? "short" : "long";
    var entryPoint = marketDrawClampPoint(entry);
    if (!entryPoint) return null;
    var sl = Number(stopPrice);
    var tp = Number(takePrice);
    if (!isFinite(sl)) sl = Number(entryPoint.p);
    if (!isFinite(tp)) tp = Number(entryPoint.p);

    if (kind === "long") {
      if (sl > Number(entryPoint.p)) sl = Number(entryPoint.p);
      if (tp < Number(entryPoint.p)) tp = Number(entryPoint.p);
    } else {
      if (sl < Number(entryPoint.p)) sl = Number(entryPoint.p);
      if (tp > Number(entryPoint.p)) tp = Number(entryPoint.p);
    }

    return {
      id: "draft_" + kind,
      type: kind,
      entry: entryPoint,
      sl: Number(sl),
      tp: Number(tp),
      end: marketDrawNormalizePositionEnd(endInput || {}, entryPoint)
    };
  }

  function marketDrawGetPositionMetrics(item) {
    if (!item || (item.type !== "long" && item.type !== "short") || !item.entry) return null;
    var entryPrice = Number(item.entry.p);
    var sl = Number(item.sl);
    var tp = Number(item.tp);
    if (!isFinite(entryPrice) || !isFinite(sl) || !isFinite(tp)) return null;
    var risk = Math.abs(entryPrice - sl);
    var reward = Math.abs(tp - entryPrice);
    var rr = risk > 0 ? reward / risk : 0;
    var riskPct = entryPrice !== 0 ? (risk / Math.abs(entryPrice)) * 100 : 0;
    var rewardPct = entryPrice !== 0 ? (reward / Math.abs(entryPrice)) * 100 : 0;
    var pipMeta = marketDrawGetPipMeta();
    var unitSize = Math.max(1e-10, Number(pipMeta.size) || 0.0001);
    return {
      kind: item.type === "short" ? "SHORT" : "LONG",
      risk: risk,
      reward: reward,
      rr: rr,
      riskPct: riskPct,
      rewardPct: rewardPct,
      riskUnits: risk / unitSize,
      rewardUnits: reward / unitSize,
      unit: pipMeta.unit
    };
  }

  function marketDrawFormatPositionSummary(item) {
    var metrics = marketDrawGetPositionMetrics(item);
    if (!metrics) return "";
    var riskAbs = fmt(metrics.risk, 5);
    var rewardAbs = fmt(metrics.reward, 5);
    return metrics.kind
      + " | R:R " + fmt(metrics.rr, 2)
      + " | Risk " + riskAbs + " / " + fmt(metrics.riskUnits, 1) + " " + metrics.unit + " (" + fmt(metrics.riskPct, 2) + "%)"
      + " | Reward " + rewardAbs + " / " + fmt(metrics.rewardUnits, 1) + " " + metrics.unit + " (" + fmt(metrics.rewardPct, 2) + "%)";
  }

  function marketDrawGetPositionGeometry(item, width) {
    if (!item || (item.type !== "long" && item.type !== "short") || !item.entry) return null;
    var entry = marketDrawNormalizePoint(item.entry);
    if (!entry) return null;
    var entryL = isFinite(Number(entry.li)) ? Number(entry.li) : marketDrawTimeToLogical(entry.t);
    if (!isFinite(entryL)) entryL = marketDrawGetLastLogical();
    var end = marketDrawNormalizePositionEnd(item, entry);
    var rightL = end && isFinite(Number(end.li))
      ? Number(end.li)
      : (entryL + MW_DRAW_DEFAULT_POSITION_WIDTH_BARS);
    if (rightL < entryL + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL) {
      rightL = entryL + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL;
    }
    var rightPointBase = marketDrawDataToScreen({
      t: marketDrawLogicalToTime(rightL),
      p: Number(entry.p),
      li: rightL
    });
    var entryPoint = marketDrawDataToScreen(entry);
    var slPoint = marketDrawDataToScreen({ t: marketDrawLogicalToTime(rightL), p: Number(item.sl), li: rightL });
    var tpPoint = marketDrawDataToScreen({ t: marketDrawLogicalToTime(rightL), p: Number(item.tp), li: rightL });
    if (!entryPoint || !rightPointBase || !slPoint || !tpPoint) return null;

    var x1 = Number(entryPoint.x);
    var x2 = Number(rightPointBase.x);
    if (!isFinite(x1) || !isFinite(x2)) return null;
    if (x2 < x1 + 8) x2 = x1 + 8;
    var toolWidth = isFinite(Number(width)) ? Number(width) : 0;
    var handleX = x2 - 10;
    if (isFinite(toolWidth) && toolWidth > 20) {
      handleX = Math.min(toolWidth - 10, Math.max(x1 + 24, x2 - 10));
    }
    return {
      x1: x1,
      x2: x2,
      width: Math.max(1, x2 - x1),
      yEntry: Number(entryPoint.y),
      ySl: Number(slPoint.y),
      yTp: Number(tpPoint.y),
      handleX: handleX,
      rightL: rightL
    };
  }

  function marketDrawResolveDisplayTimeSec(input) {
    if (input && typeof input === "object") {
      var tObj = Number(input.t);
      var liObj = Number(input.li);
      var lastL = marketDrawGetLastLogical();
      var lastTime = marketDrawGetLastBarTime();
      if (isFinite(liObj) && isFinite(lastTime) && liObj > lastL + 1e-6) {
        var deltaBars = Math.round(liObj - lastL);
        return Math.floor(lastTime + deltaBars * marketDrawTimeframeSeconds());
      }
      return tObj;
    }
    return Number(input);
  }

  function marketDrawFormatTimeLabel(timeSec) {
    var ts = marketDrawResolveDisplayTimeSec(timeSec);
    if (!isFinite(ts)) return "--";
    var dt = new Date(ts * 1000);
    if (isNaN(dt.getTime())) return "--";
    return formatTime(dt);
  }

  function marketDrawPositionTooltip(text, pointerX, pointerY, width, height) {
    if (!els.marketDrawTooltip) return false;
    els.marketDrawTooltip.textContent = String(text || "");
    els.marketDrawTooltip.style.left = Math.max(6, Math.min(width - 220, Number(pointerX) + 12)) + "px";
    els.marketDrawTooltip.style.top = Math.max(6, Math.min(height - 32, Number(pointerY) + 12)) + "px";
    els.marketDrawTooltip.classList.remove("is-hidden");
    return true;
  }

  function marketDrawHideTooltip() {
    if (els.marketDrawTooltip) els.marketDrawTooltip.classList.add("is-hidden");
  }

  function marketDrawRenderCrosshair(root, width, height) {
    var draw = marketDrawState();
    if (!draw.crosshairEnabled || !draw.pointer) return false;
    var pointer = draw.pointer;
    if (!isFinite(pointer.x) || !isFinite(pointer.y)) return false;

    marketDrawCreateSvgEl("line", {
      x1: pointer.x,
      y1: 0,
      x2: pointer.x,
      y2: height,
      stroke: "rgba(112,170,202,0.58)",
      "stroke-width": 1,
      "stroke-dasharray": "4 4"
    }, root);
    marketDrawCreateSvgEl("line", {
      x1: 0,
      y1: pointer.y,
      x2: width,
      y2: pointer.y,
      stroke: "rgba(112,170,202,0.58)",
      "stroke-width": 1,
      "stroke-dasharray": "4 4"
    }, root);

    var dataPoint = marketDrawScreenToDataRaw(pointer.x, pointer.y);
    if (!dataPoint) return false;
    return marketDrawPositionTooltip(
      marketDrawFormatTimeLabel(dataPoint) + " | " + fmt(dataPoint.p, 5),
      pointer.x,
      pointer.y,
      width,
      height
    );
  }

  function marketDrawRenderMeasureTooltip(width, height) {
    var draw = marketDrawState();
    var pointer = draw.pointer;
    if (!pointer || !isFinite(pointer.x) || !isFinite(pointer.y)) return false;

    if (draw.activeTool === "ruler" && draw.pendingPoint) {
      var preview = marketDrawScreenToData(pointer.x, pointer.y);
      if (!preview) return false;
      return marketDrawPositionTooltip(marketDrawFormatMeasure(draw.pendingPoint, preview), pointer.x, pointer.y, width, height);
    }
    if (draw.interaction && draw.interaction.type === "position-create" && draw.interaction.draft) {
      return marketDrawPositionTooltip(
        marketDrawFormatPositionSummary(draw.interaction.draft),
        pointer.x,
        pointer.y,
        width,
        height
      );
    }

    var sourceItem = null;
    if (draw.interaction && draw.interaction.itemId) sourceItem = marketDrawGetItemById(draw.interaction.itemId);
    if (!sourceItem && draw.hoverId) sourceItem = marketDrawGetItemById(draw.hoverId);
    if (!sourceItem && draw.selectedObjectId) sourceItem = marketDrawGetItemById(draw.selectedObjectId);
    if (!sourceItem) return false;
    if (sourceItem.type === "ruler") {
      return marketDrawPositionTooltip(marketDrawFormatMeasure(sourceItem.a, sourceItem.b), pointer.x, pointer.y, width, height);
    }
    if (sourceItem.type === "long" || sourceItem.type === "short") {
      return marketDrawPositionTooltip(marketDrawFormatPositionSummary(sourceItem), pointer.x, pointer.y, width, height);
    }
    return false;
  }

  function marketDrawRenderHandle(root, itemId, handle, point, cls, radius) {
    if (!point) return;
    marketDrawCreateSvgEl("circle", {
      cx: point.x,
      cy: point.y,
      r: isFinite(Number(radius)) ? Number(radius) : MW_DRAW_HANDLE_RADIUS,
      fill: "#0a1621",
      stroke: "#7bc8ff",
      "stroke-width": 1.7,
      "class": cls || "draw-handle",
      "data-item-id": itemId,
      "data-handle": handle
    }, root);
  }

  function marketDrawRenderHandles(root, item, itemType, sa, sb, width) {
    var draw = marketDrawState();
    if (!item || !sa) return;
    if (draw.selectedObjectId !== item.id) return;
    if (marketDrawIsItemLocked(item)) return;

    if (itemType === "hline") {
      marketDrawRenderHandle(root, item.id, "p", { x: width * 0.5, y: sa.y }, "draw-handle draw-handle-hline", MW_DRAW_RECT_HANDLE_RADIUS);
      return;
    }

    if (itemType === "text") {
      marketDrawRenderHandle(root, item.id, "at", sa, "draw-handle", MW_DRAW_RECT_HANDLE_RADIUS);
      return;
    }

    if (itemType === "long" || itemType === "short") {
      var posGeometry = marketDrawGetPositionGeometry(item, width);
      if (!posGeometry) return;
      var centerY = (Math.min(posGeometry.ySl, posGeometry.yTp) + Math.max(posGeometry.ySl, posGeometry.yTp)) / 2;
      marketDrawRenderHandle(
        root,
        item.id,
        "entry",
        { x: posGeometry.handleX, y: posGeometry.yEntry },
        "draw-handle draw-handle-line",
        MW_DRAW_RECT_HANDLE_RADIUS + 0.5
      );
      marketDrawRenderHandle(
        root,
        item.id,
        "sl",
        { x: posGeometry.handleX, y: posGeometry.ySl },
        "draw-handle draw-handle-hline",
        MW_DRAW_RECT_HANDLE_RADIUS + 0.5
      );
      marketDrawRenderHandle(
        root,
        item.id,
        "tp",
        { x: posGeometry.handleX, y: posGeometry.yTp },
        "draw-handle draw-handle-hline",
        MW_DRAW_RECT_HANDLE_RADIUS + 0.5
      );
      marketDrawRenderHandle(
        root,
        item.id,
        "right",
        { x: posGeometry.x2, y: centerY },
        "draw-handle draw-handle-ew",
        MW_DRAW_RECT_HANDLE_RADIUS + 0.6
      );
      return;
    }

    if (itemType === "rect") {
      var minT = Math.min(Number(item.a.t), Number(item.b.t));
      var maxT = Math.max(Number(item.a.t), Number(item.b.t));
      var minP = Math.min(Number(item.a.p), Number(item.b.p));
      var maxP = Math.max(Number(item.a.p), Number(item.b.p));
      var minL = Math.min(isFinite(Number(item.a.li)) ? Number(item.a.li) : marketDrawTimeToLogical(minT), isFinite(Number(item.b.li)) ? Number(item.b.li) : marketDrawTimeToLogical(maxT));
      var maxL = Math.max(isFinite(Number(item.a.li)) ? Number(item.a.li) : marketDrawTimeToLogical(minT), isFinite(Number(item.b.li)) ? Number(item.b.li) : marketDrawTimeToLogical(maxT));
      var tl = marketDrawDataToScreen({ t: minT, p: maxP, li: minL });
      var tr = marketDrawDataToScreen({ t: maxT, p: maxP, li: maxL });
      var br = marketDrawDataToScreen({ t: maxT, p: minP, li: maxL });
      var bl = marketDrawDataToScreen({ t: minT, p: minP, li: minL });
      var tc = tl && tr ? { x: (tl.x + tr.x) / 2, y: (tl.y + tr.y) / 2 } : null;
      var bc = bl && br ? { x: (bl.x + br.x) / 2, y: (bl.y + br.y) / 2 } : null;
      var lc = tl && bl ? { x: (tl.x + bl.x) / 2, y: (tl.y + bl.y) / 2 } : null;
      var rc = tr && br ? { x: (tr.x + br.x) / 2, y: (tr.y + br.y) / 2 } : null;
      marketDrawRenderHandle(root, item.id, "tl", tl, "draw-handle draw-handle-nwse", MW_DRAW_RECT_HANDLE_RADIUS);
      marketDrawRenderHandle(root, item.id, "tr", tr, "draw-handle draw-handle-nesw", MW_DRAW_RECT_HANDLE_RADIUS);
      marketDrawRenderHandle(root, item.id, "br", br, "draw-handle draw-handle-nwse", MW_DRAW_RECT_HANDLE_RADIUS);
      marketDrawRenderHandle(root, item.id, "bl", bl, "draw-handle draw-handle-nesw", MW_DRAW_RECT_HANDLE_RADIUS);
      marketDrawRenderHandle(root, item.id, "n", tc, "draw-handle draw-handle-hline", MW_DRAW_RECT_HANDLE_RADIUS - 0.5);
      marketDrawRenderHandle(root, item.id, "s", bc, "draw-handle draw-handle-hline", MW_DRAW_RECT_HANDLE_RADIUS - 0.5);
      marketDrawRenderHandle(root, item.id, "w", lc, "draw-handle draw-handle-ew", MW_DRAW_RECT_HANDLE_RADIUS - 0.5);
      marketDrawRenderHandle(root, item.id, "e", rc, "draw-handle draw-handle-ew", MW_DRAW_RECT_HANDLE_RADIUS - 0.5);
      return;
    }

    if (!sb) return;
    marketDrawRenderHandle(root, item.id, "a", sa, "draw-handle draw-handle-line", MW_DRAW_RECT_HANDLE_RADIUS);
    marketDrawRenderHandle(root, item.id, "b", sb, "draw-handle draw-handle-line", MW_DRAW_RECT_HANDLE_RADIUS);
  }

  function marketDrawRenderItem(root, item, width, height, isDraft) {
    if (!item) return;
    var draw = marketDrawState();
    var selected = draw.selectedObjectId === item.id;
    var hovered = draw.hoverId === item.id;
    var style = marketDrawMergeItemStyle(item);
    var visibilityScale = marketDrawIsItemVisible(item) ? 1 : 0.18;
    var strokeDash = marketDrawStrokeDashArray(style.strokeStyle, style.strokeWidth);

    if (item.type === "trendline" || item.type === "ruler") {
      var a = marketDrawDataToScreen(item.a);
      var b = marketDrawDataToScreen(item.b);
      if (!a || !b) return;
      marketDrawCreateSvgEl("line", {
        x1: a.x,
        y1: a.y,
        x2: b.x,
        y2: b.y,
        stroke: style.strokeColor,
        "stroke-width": style.strokeWidth,
        "stroke-dasharray": strokeDash,
        "stroke-opacity": style.strokeOpacity * visibilityScale,
        "opacity": visibilityScale,
        fill: "none",
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "pointer-events": "stroke"
      }, root);
      if (item.type === "ruler") {
        var mx = (a.x + b.x) / 2;
        var my = (a.y + b.y) / 2;
        var measure = marketDrawFormatMeasure(item.a, item.b);
        marketDrawCreateSvgEl("rect", {
          x: mx - 88,
          y: my - 24,
          width: 176,
          height: 18,
          rx: 4,
          fill: "rgba(5,15,22,0.88)",
          stroke: "rgba(112,170,202,0.35)",
          "stroke-width": 1,
          "opacity": visibilityScale
        }, root);
        var tEl = marketDrawCreateSvgEl("text", {
          x: mx,
          y: my - 12,
          fill: "#d7ebf7",
          "font-size": 10,
          "text-anchor": "middle",
          "font-family": "Segoe UI, Trebuchet MS, Helvetica Neue, Arial, sans-serif",
          "opacity": visibilityScale
        }, root);
        tEl.textContent = measure;
      }
      if (!isDraft) marketDrawRenderHandles(root, item, item.type, a, b, width);
      return;
    }

    if (item.type === "hline") {
      var y = marketDrawDataToScreen({ t: marketDrawGetDataBounds().maxT, p: item.p });
      if (!y) return;
      marketDrawCreateSvgEl("line", {
        x1: 0,
        y1: y.y,
        x2: width,
        y2: y.y,
        stroke: style.strokeColor,
        "stroke-width": style.strokeWidth,
        "stroke-dasharray": strokeDash,
        "stroke-opacity": style.strokeOpacity * visibilityScale,
        "opacity": visibilityScale,
        fill: "none",
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "pointer-events": "stroke"
      }, root);
      if (!isDraft) marketDrawRenderHandles(root, item, item.type, { x: width * 0.5, y: y.y }, null, width);
      return;
    }

    if (item.type === "rect") {
      var ra = marketDrawDataToScreen(item.a);
      var rb = marketDrawDataToScreen(item.b);
      if (!ra || !rb) return;
      var rx = Math.min(ra.x, rb.x);
      var ry = Math.min(ra.y, rb.y);
      var rw = Math.abs(ra.x - rb.x);
      var rh = Math.abs(ra.y - rb.y);
      marketDrawCreateSvgEl("rect", {
        x: rx,
        y: ry,
        width: Math.max(1, rw),
        height: Math.max(1, rh),
        fill: style.fillColor,
        "fill-opacity": style.fillOpacity * visibilityScale,
        stroke: style.strokeColor,
        "stroke-width": style.strokeWidth,
        "stroke-dasharray": strokeDash,
        "stroke-opacity": style.strokeOpacity * visibilityScale,
        "opacity": visibilityScale,
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "pointer-events": "all"
      }, root);
      if (!isDraft) marketDrawRenderHandles(root, item, item.type, ra, rb, width);
      return;
    }

    if (item.type === "long" || item.type === "short") {
      var geometry = marketDrawGetPositionGeometry(item, width);
      if (!geometry) return;
      var yRiskTop = Math.min(geometry.yEntry, geometry.ySl);
      var yRiskBottom = Math.max(geometry.yEntry, geometry.ySl);
      var yRewardTop = Math.min(geometry.yEntry, geometry.yTp);
      var yRewardBottom = Math.max(geometry.yEntry, geometry.yTp);
      var riskFill = selected ? "rgba(255, 92, 92, 0.30)" : "rgba(255, 92, 92, 0.20)";
      var rewardFill = selected ? "rgba(47, 212, 138, 0.30)" : "rgba(47, 212, 138, 0.20)";
      var label = marketDrawFormatPositionSummary(item);

      marketDrawCreateSvgEl("rect", {
        x: geometry.x1,
        y: yRiskTop,
        width: Math.max(1, geometry.width),
        height: Math.max(1, yRiskBottom - yRiskTop),
        fill: riskFill,
        stroke: "none",
        "opacity": visibilityScale,
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "data-handle": "move",
        "pointer-events": "all"
      }, root);

      marketDrawCreateSvgEl("rect", {
        x: geometry.x1,
        y: yRewardTop,
        width: Math.max(1, geometry.width),
        height: Math.max(1, yRewardBottom - yRewardTop),
        fill: rewardFill,
        stroke: "none",
        "opacity": visibilityScale,
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "data-handle": "move",
        "pointer-events": "all"
      }, root);

      marketDrawCreateSvgEl("line", {
        x1: geometry.x1,
        y1: geometry.yEntry,
        x2: geometry.x2,
        y2: geometry.yEntry,
        stroke: selected ? "#e8f6ff" : "rgba(230,244,255,0.88)",
        "stroke-width": 1.6,
        "opacity": visibilityScale,
        fill: "none",
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "data-handle": "entry",
        "pointer-events": "stroke"
      }, root);
      marketDrawCreateSvgEl("line", {
        x1: geometry.x1,
        y1: geometry.yEntry,
        x2: geometry.x2,
        y2: geometry.yEntry,
        stroke: "rgba(0,0,0,0)",
        "stroke-width": 12,
        fill: "none",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-handle": "entry",
        "pointer-events": "stroke"
      }, root);

      marketDrawCreateSvgEl("line", {
        x1: geometry.x1,
        y1: geometry.ySl,
        x2: geometry.x2,
        y2: geometry.ySl,
        stroke: "#ff7f7f",
        "stroke-width": 1.6,
        "opacity": visibilityScale,
        fill: "none",
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "data-handle": "sl",
        "pointer-events": "stroke"
      }, root);
      marketDrawCreateSvgEl("line", {
        x1: geometry.x1,
        y1: geometry.ySl,
        x2: geometry.x2,
        y2: geometry.ySl,
        stroke: "rgba(0,0,0,0)",
        "stroke-width": 12,
        fill: "none",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-handle": "sl",
        "pointer-events": "stroke"
      }, root);

      marketDrawCreateSvgEl("line", {
        x1: geometry.x1,
        y1: geometry.yTp,
        x2: geometry.x2,
        y2: geometry.yTp,
        stroke: "#3fe0a1",
        "stroke-width": 1.6,
        "opacity": visibilityScale,
        fill: "none",
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "data-handle": "tp",
        "pointer-events": "stroke"
      }, root);
      marketDrawCreateSvgEl("line", {
        x1: geometry.x1,
        y1: geometry.yTp,
        x2: geometry.x2,
        y2: geometry.yTp,
        stroke: "rgba(0,0,0,0)",
        "stroke-width": 12,
        fill: "none",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-handle": "tp",
        "pointer-events": "stroke"
      }, root);

      var posTopY = Math.min(geometry.ySl, geometry.yTp, geometry.yEntry);
      var posBottomY = Math.max(geometry.ySl, geometry.yTp, geometry.yEntry);
      marketDrawCreateSvgEl("line", {
        x1: geometry.x2,
        y1: posTopY,
        x2: geometry.x2,
        y2: posBottomY,
        stroke: selected ? "rgba(123,200,255,0.95)" : "rgba(123,200,255,0.68)",
        "stroke-width": 1.4,
        "stroke-dasharray": "5 4",
        "opacity": visibilityScale,
        fill: "none",
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "data-handle": "right",
        "pointer-events": "stroke"
      }, root);
      marketDrawCreateSvgEl("line", {
        x1: geometry.x2,
        y1: posTopY,
        x2: geometry.x2,
        y2: posBottomY,
        stroke: "rgba(0,0,0,0)",
        "stroke-width": 14,
        fill: "none",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-handle": "right",
        "pointer-events": "stroke"
      }, root);

      if (hasValue(label)) {
        var labelWidth = Math.max(150, Math.min(390, 14 + String(label).length * 5.2));
        var labelX = Math.min(Math.max(4, geometry.x1 + 4), Math.max(4, width - labelWidth - 4));
        var labelY = Math.max(6, Math.min(height - 22, yRewardTop - 22));
        marketDrawCreateSvgEl("rect", {
          x: labelX,
          y: labelY,
          width: labelWidth,
          height: 18,
          rx: 4,
          fill: "rgba(5,15,22,0.9)",
          stroke: selected ? "rgba(123,200,255,0.70)" : "rgba(112,170,202,0.35)",
          "stroke-width": 1,
          "opacity": visibilityScale,
          "pointer-events": "none"
        }, root);
        var labelEl = marketDrawCreateSvgEl("text", {
          x: labelX + 6,
          y: labelY + 12.5,
          fill: selected ? "#e8f6ff" : "#d7ebf7",
          "font-size": 10.3,
          "text-anchor": "start",
          "font-family": "Segoe UI, Trebuchet MS, Helvetica Neue, Arial, sans-serif",
          "opacity": visibilityScale,
          "pointer-events": "none"
        }, root);
        labelEl.textContent = label;
      }

      if (!isDraft) {
        marketDrawRenderHandles(
          root,
          item,
          item.type,
          { x: geometry.handleX, y: geometry.yEntry },
          { x: geometry.handleX, y: geometry.ySl },
          width
        );
      }
      return;
    }

    if (item.type === "text") {
      var at = marketDrawDataToScreen(item.at);
      if (!at) return;
      var textValue = hasValue(item.text) ? String(item.text) : "Text";
      marketDrawCreateSvgEl("rect", {
        x: at.x - 4,
        y: at.y - 14,
        width: Math.max(36, Math.min(240, 8 + textValue.length * 6.5)),
        height: 18,
        rx: 4,
        fill: style.bgColor,
        "fill-opacity": style.bgOpacity * visibilityScale,
        stroke: style.strokeColor,
        "stroke-width": style.strokeWidth,
        "stroke-dasharray": strokeDash,
        "stroke-opacity": style.strokeOpacity * visibilityScale,
        "opacity": visibilityScale,
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "data-selected": selected ? "1" : "0",
        "data-hover": hovered ? "1" : "0",
        "pointer-events": "all"
      }, root);
      var txt = marketDrawCreateSvgEl("text", {
        x: at.x,
        y: at.y - 2,
        fill: style.textColor,
        "font-size": style.fontSize,
        "text-anchor": "start",
        "font-family": "Segoe UI, Trebuchet MS, Helvetica Neue, Arial, sans-serif",
        "opacity": visibilityScale,
        "class": "draw-shape",
        "data-item-id": item.id,
        "data-item-type": item.type,
        "pointer-events": "none"
      }, root);
      txt.textContent = textValue;
      if (!isDraft) marketDrawRenderHandles(root, item, item.type, at, null, width);
    }
  }

  function marketDrawScheduleRender() {
    var draw = marketDrawState();
    if (draw.renderRaf) return;
    draw.renderRaf = requestAnimationFrame(function () {
      draw.renderRaf = 0;
      marketDrawRenderNow();
    });
  }

  function marketDrawRenderNow() {
    var draw = marketDrawState();
    var overlay = marketDrawEnsureOverlay();
    if (!overlay) return;
    marketDrawSyncOverlayPointerRouting();

    while (overlay.firstChild) overlay.removeChild(overlay.firstChild);
    var width = overlay.clientWidth || (els.marketChartWrap ? els.marketChartWrap.clientWidth : 0) || 1;
    var height = overlay.clientHeight || (els.marketChartWrap ? els.marketChartWrap.clientHeight : 0) || 1;
    overlay.setAttribute("viewBox", "0 0 " + width + " " + height);
    overlay.setAttribute("width", String(width));
    overlay.setAttribute("height", String(height));

    var captureNeeded = marketDrawShouldOverlayCaptureBackground();
    if (captureNeeded) {
      marketDrawCreateSvgEl("rect", {
        x: 0,
        y: 0,
        width: width,
        height: height,
        fill: "transparent",
        "pointer-events": "all",
        "data-role": "capture"
      }, overlay);
    }

    for (var i = 0; i < draw.items.length; i++) {
      marketDrawRenderItem(overlay, draw.items[i], width, height, false);
    }

    if (draw.interaction && draw.interaction.type === "rect-create" && draw.interaction.draft) {
      marketDrawRenderItem(overlay, draw.interaction.draft, width, height, true);
    }
    if (draw.interaction && draw.interaction.type === "position-create" && draw.interaction.draft) {
      marketDrawRenderItem(overlay, draw.interaction.draft, width, height, true);
    }
    if (draw.pendingPoint && (draw.activeTool === "trendline" || draw.activeTool === "ruler")) {
      var pp = marketDrawDataToScreen(draw.pendingPoint);
      if (pp) {
        marketDrawCreateSvgEl("circle", {
          cx: pp.x,
          cy: pp.y,
          r: MW_DRAW_HANDLE_RADIUS,
          fill: "rgba(63,224,197,0.2)",
          stroke: "#3fe0c5",
          "stroke-width": 1.5
        }, overlay);
      }
    }

    var tooltipShown = marketDrawRenderCrosshair(overlay, width, height);
    if (!tooltipShown) tooltipShown = marketDrawRenderMeasureTooltip(width, height);
    if (!tooltipShown) marketDrawHideTooltip();
  }

  function marketDrawSelectItem(id) {
    marketDrawSetSelection(hasValue(id) ? String(id) : null);
    marketDrawScheduleRender();
  }

  function marketDrawDeleteSelected() {
    var draw = marketDrawState();
    var selectedIds = marketDrawGetSelectionIds();
    if (!selectedIds.length) return;
    marketDrawFinalizePropsCommit();
    var next = [];
    var removed = false;
    for (var i = 0; i < draw.items.length; i++) {
      if (selectedIds.indexOf(String(draw.items[i].id)) >= 0) {
        removed = true;
        continue;
      }
      next.push(draw.items[i]);
    }
    if (!removed) return;
    marketDrawPushUndo();
    draw.items = next;
    marketDrawReindexItems();
    draw.selectedIds = [];
    draw.selectedId = null;
    draw.selectedObjectId = null;
    draw.activeObjectId = null;
    draw.hoverId = null;
    draw.pendingPoint = null;
    draw.interaction = null;
    marketDrawResetPropsEditSession();
    marketDrawScheduleSave();
    marketDrawScheduleRender();
    marketDrawUpdateToolbarState();
    marketDrawSyncPropertiesPanel();
  }

  function marketDrawCancelCurrentAction() {
    var draw = marketDrawState();
    marketDrawFinalizePropsCommit();
    draw.pendingPoint = null;
    draw.interaction = null;
    draw.hoverId = null;
    if (draw.activeTool !== "select") draw.activeTool = "select";
    marketDrawCloseMenus();
    marketDrawSyncOverlayPointerRouting();
    marketDrawScheduleRender();
    marketDrawUpdateToolbarState();
  }

  function marketDrawShiftPoint(basePoint, dLogical, dp) {
    var point = marketDrawNormalizePoint(basePoint);
    if (!point) return null;
    var dl = Number(dLogical);
    if (!isFinite(dl)) dl = 0;
    var dpNum = Number(dp);
    if (!isFinite(dpNum)) dpNum = 0;
    var baseLogical = isFinite(Number(point.li)) ? Number(point.li) : marketDrawTimeToLogical(point.t);
    var nextLogical = isFinite(baseLogical) ? baseLogical + dl : NaN;
    var nextTime = isFinite(nextLogical)
      ? marketDrawLogicalToTime(nextLogical)
      : (Number(point.t) + dl * marketDrawTimeframeSeconds());
    return marketDrawClampPoint({
      t: nextTime,
      p: Number(point.p) + dpNum,
      li: isFinite(nextLogical) ? nextLogical : null
    });
  }

  function marketDrawShiftItem(baseItem, dLogical, dp) {
    var item = marketDrawClone(baseItem) || {};
    if (item.type === "trendline" || item.type === "ruler" || item.type === "rect") {
      item.a = marketDrawShiftPoint(item.a, dLogical, dp);
      item.b = marketDrawShiftPoint(item.b, dLogical, dp);
      if (item.type === "rect") item = marketDrawCanonicalRect(item);
    } else if (item.type === "hline") {
      var p = Number(item.p) + dp;
      item.p = marketDrawClampPoint({ t: marketDrawGetVisibleTimeBounds().minT, p: p }).p;
    } else if (item.type === "text") {
      item.at = marketDrawShiftPoint(item.at, dLogical, dp);
    } else if (item.type === "long" || item.type === "short") {
      item.entry = marketDrawShiftPoint(item.entry, dLogical, dp);
      item.end = marketDrawShiftPoint(item.end || item.entry, dLogical, 0);
      item.sl = Number(item.sl) + Number(dp || 0);
      item.tp = Number(item.tp) + Number(dp || 0);
      var bounds = marketDrawGetDataBounds();
      if (isFinite(bounds.minP) && item.sl < bounds.minP) item.sl = bounds.minP;
      if (isFinite(bounds.maxP) && item.sl > bounds.maxP) item.sl = bounds.maxP;
      if (isFinite(bounds.minP) && item.tp < bounds.minP) item.tp = bounds.minP;
      if (isFinite(bounds.maxP) && item.tp > bounds.maxP) item.tp = bounds.maxP;
      item.end = marketDrawNormalizePositionEnd(item, item.entry);
    }
    return item;
  }

  function marketDrawResizeRectItem(baseItem, handle, point) {
    var item = marketDrawClone(baseItem) || {};
    var p = marketDrawClampPoint(point);
    if (!p) return item;

    var ali = isFinite(Number(item.a.li)) ? Number(item.a.li) : marketDrawTimeToLogical(item.a.t);
    var bli = isFinite(Number(item.b.li)) ? Number(item.b.li) : marketDrawTimeToLogical(item.b.t);
    var leftL = isFinite(ali) && isFinite(bli) ? Math.min(ali, bli) : (isFinite(ali) ? ali : bli);
    var rightL = isFinite(ali) && isFinite(bli) ? Math.max(ali, bli) : (isFinite(ali) ? ali : bli);
    var topP = Math.max(Number(item.a.p), Number(item.b.p));
    var bottomP = Math.min(Number(item.a.p), Number(item.b.p));

    var h = String(handle || "br").toLowerCase();
    if (h === "a") h = "tl";
    if (h === "b") h = "br";
    var pLogical = isFinite(Number(p.li)) ? Number(p.li) : marketDrawTimeToLogical(p.t);
    if (!isFinite(pLogical)) pLogical = leftL;

    if (h === "tl" || h === "bl" || h === "w") leftL = pLogical;
    if (h === "tr" || h === "br" || h === "e") rightL = pLogical;
    if (h === "tl" || h === "tr" || h === "n") topP = Number(p.p);
    if (h === "bl" || h === "br" || h === "s") bottomP = Number(p.p);

    if (!isFinite(leftL)) leftL = rightL;
    if (!isFinite(rightL)) rightL = leftL;

    var minWidthL = MW_DRAW_MIN_RECT_WIDTH_LOGICAL;
    if ((rightL - leftL) < minWidthL) {
      if (h === "tl" || h === "bl" || h === "w") {
        leftL = rightL - minWidthL;
      } else if (h === "tr" || h === "br" || h === "e") {
        rightL = leftL + minWidthL;
      } else {
        rightL = leftL + minWidthL;
      }
    }

    var priceSpan = Math.abs(Number(topP) - Number(bottomP));
    var bounds = marketDrawGetDataBounds();
    var minHeightP = Math.max(
      1e-8,
      Math.abs(Number(bounds.maxP) - Number(bounds.minP)) * MW_DRAW_MIN_RECT_HEIGHT_RATIO
    );
    if (priceSpan < minHeightP) {
      if (h === "tl" || h === "tr" || h === "n") {
        topP = bottomP + minHeightP;
      } else if (h === "bl" || h === "br" || h === "s") {
        bottomP = topP - minHeightP;
      } else {
        topP = bottomP + minHeightP;
      }
    }

    if (rightL < leftL) {
      var swapL = leftL;
      leftL = rightL;
      rightL = swapL;
    }
    if (topP < bottomP) {
      var swapP = topP;
      topP = bottomP;
      bottomP = swapP;
    }

    var minPoint = marketDrawClampPoint({ t: marketDrawLogicalToTime(leftL), p: topP, li: leftL });
    var maxPoint = marketDrawClampPoint({ t: marketDrawLogicalToTime(rightL), p: bottomP, li: rightL });
    item.a = minPoint;
    item.b = maxPoint;
    return marketDrawCanonicalRect(item);
  }

  function marketDrawResizeItem(baseItem, handle, point) {
    var item = marketDrawClone(baseItem) || {};
    if (!point) return item;
    if (item.type === "rect") {
      return marketDrawResizeRectItem(item, handle, point);
    }
    if (item.type === "trendline" || item.type === "ruler") {
      var h = String(handle || "b");
      if (h === "a" || h === "b") item[h] = marketDrawClampPoint(point);
      return item;
    }
    if (item.type === "hline") {
      item.p = Number(point.p);
      return item;
    }
    if (item.type === "text") {
      item.at = marketDrawClampPoint(point);
      return item;
    }
    if (item.type === "long" || item.type === "short") {
      var hPos = String(handle || "").toLowerCase();
      if (hPos === "sl") {
        item.sl = Number(point.p);
        return item;
      }
      if (hPos === "tp") {
        item.tp = Number(point.p);
        return item;
      }
      if (hPos === "right") {
        var entryPt = marketDrawNormalizePoint(item.entry);
        if (!entryPt) return item;
        var entryLi = isFinite(Number(entryPt.li)) ? Number(entryPt.li) : marketDrawTimeToLogical(entryPt.t);
        var pointLi = isFinite(Number(point.li)) ? Number(point.li) : marketDrawTimeToLogical(point.t);
        if (!isFinite(pointLi)) pointLi = entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL;
        if (pointLi < entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL) {
          pointLi = entryLi + MW_DRAW_MIN_POSITION_WIDTH_LOGICAL;
        }
        item.end = marketDrawClampPoint({
          t: marketDrawLogicalToTime(pointLi),
          p: Number(entryPt.p),
          li: pointLi
        });
        item.end = marketDrawNormalizePositionEnd(item, entryPt);
        return item;
      }
      if (hPos === "entry" || hPos === "move") {
        var entryPoint = marketDrawNormalizePoint(item.entry);
        if (!entryPoint) return item;
        var entryLogical = isFinite(Number(entryPoint.li)) ? Number(entryPoint.li) : marketDrawTimeToLogical(entryPoint.t);
        var pointLogical = isFinite(Number(point.li)) ? Number(point.li) : marketDrawTimeToLogical(point.t);
        var dLogical = isFinite(entryLogical) && isFinite(pointLogical)
          ? (pointLogical - entryLogical)
          : ((Number(point.t) - Number(entryPoint.t)) / marketDrawTimeframeSeconds());
        var dp = Number(point.p) - Number(entryPoint.p);
        return marketDrawShiftItem(item, dLogical, dp);
      }
      return item;
    }
    return item;
  }

  function marketDrawStartInteraction(event, itemId, handle) {
    var draw = marketDrawState();
    var item = marketDrawGetItemById(itemId);
    if (item && marketDrawIsItemLocked(item)) return;
    var pointer = marketDrawGetPointerXY(event);
    var data = pointer ? marketDrawScreenToData(pointer.x, pointer.y) : null;
    if (!item || !data) return;
    var rawHandle = String(handle || "").toLowerCase();
    var interactionType = (rawHandle && rawHandle !== "move") ? "resize" : "move";
    draw.interaction = {
      type: interactionType,
      itemId: item.id,
      handle: rawHandle,
      baseItem: marketDrawClone(item),
      startData: data
    };
    marketDrawSyncOverlayPointerRouting();
    marketDrawPushUndo();
    marketDrawCapturePointer(event);
    event.preventDefault();
  }

  function marketDrawApplyInteraction(event) {
    var draw = marketDrawState();
    if (!draw.interaction) return;
    var pointer = marketDrawGetPointerXY(event);
    if (!pointer) return;
    var point = marketDrawScreenToData(pointer.x, pointer.y);
    if (!point) return;

    var action = draw.interaction;
    if (action.type === "move") {
      var pointLogical = isFinite(Number(point.li)) ? Number(point.li) : marketDrawTimeToLogical(point.t);
      var startLogical = isFinite(Number(action.startData.li)) ? Number(action.startData.li) : marketDrawTimeToLogical(action.startData.t);
      var dLogical = isFinite(pointLogical) && isFinite(startLogical)
        ? (pointLogical - startLogical)
        : ((Number(point.t) - Number(action.startData.t)) / marketDrawTimeframeSeconds());
      var dp = Number(point.p) - Number(action.startData.p);
      var moved = marketDrawShiftItem(action.baseItem, dLogical, dp);
      marketDrawReplaceItem(moved);
      marketDrawScheduleRender();
      return;
    }
    if (action.type === "resize") {
      var resized = marketDrawResizeItem(action.baseItem, action.handle, point);
      marketDrawReplaceItem(resized);
      marketDrawScheduleRender();
      return;
    }
    if (action.type === "rect-create") {
      action.draft.b = marketDrawClampPoint(point);
      marketDrawScheduleRender();
      return;
    }
    if (action.type === "position-create") {
      if (!action.entry) return;
      if (Number(action.phase || 0) <= 1) {
        action.draft = marketDrawBuildPositionDraft(action.positionType, action.entry, Number(point.p), Number(action.entry.p), point);
      } else {
        action.draft = marketDrawBuildPositionDraft(action.positionType, action.entry, Number(action.stopPrice), Number(point.p), point);
      }
      marketDrawScheduleRender();
    }
  }

  function marketDrawOnPointerDown(event) {
    if (state.activeTab !== "marketwatch") return;
    if (event.button !== 0) return;
    var draw = marketDrawState();
    var target = event.target || {};
    var itemId = target.getAttribute ? target.getAttribute("data-item-id") : null;
    var handle = target.getAttribute ? target.getAttribute("data-handle") : null;
    var pointer = marketDrawGetPointerXY(event);
    if (!pointer) return;
    var point = marketDrawScreenToData(pointer.x, pointer.y);
    if (!point) return;
    marketWatchDebugLog(
      "[DRAW][POINTERDOWN]",
      "item=" + String(itemId || ""),
      "handle=" + String(handle || ""),
      "xLogical=" + fmt(point.li, 3),
      "lastLogical=" + fmt(marketDrawGetLastLogical(), 3)
    );

    draw.pointer = { x: pointer.x, y: pointer.y };
    draw.hoverId = itemId ? String(itemId) : null;
    if (draw.ui.moreOpen) marketDrawCloseMenus();

    if (marketDrawToolName(draw.activeTool) === "hand") {
      return;
    }

    if (draw.activeTool === "select") {
      if (itemId) {
        var resolvedHandle = handle || "";
        var selectedItem = marketDrawGetItemById(itemId);
        var rectZone = null;
        if (selectedItem && selectedItem.type === "rect") {
          rectZone = marketDrawRectHitTest(selectedItem, pointer);
          if (!resolvedHandle) resolvedHandle = marketDrawRectZoneToHandle(rectZone);
        }
        marketWatchDebugLog(
          "[DRAW][HIT]",
          "item=" + String(itemId),
          "zone=" + String(rectZone || ""),
          "handle=" + String(resolvedHandle || ""),
          "xLogical=" + fmt(point.li, 3),
          "lastLogical=" + fmt(marketDrawGetLastLogical(), 3)
        );
        marketDrawSelectItem(itemId);
        marketDrawStartInteraction(event, itemId, resolvedHandle);
      } else {
        var fallbackItemId = "";
        var fallbackHandle = "";
        var fallbackZone = "";
        for (var idx = draw.items.length - 1; idx >= 0; idx--) {
          var probe = draw.items[idx];
          if (!probe || probe.type !== "rect") continue;
          var probeZone = marketDrawRectHitTest(probe, pointer);
          if (!probeZone) continue;
          fallbackItemId = probe.id;
          fallbackHandle = marketDrawRectZoneToHandle(probeZone);
          fallbackZone = probeZone;
          break;
        }
        if (fallbackItemId) {
          marketWatchDebugLog(
            "[DRAW][HIT-FALLBACK]",
            "item=" + String(fallbackItemId),
            "zone=" + String(fallbackZone || ""),
            "handle=" + String(fallbackHandle || ""),
            "xLogical=" + fmt(point.li, 3),
            "lastLogical=" + fmt(marketDrawGetLastLogical(), 3)
          );
          marketDrawSelectItem(fallbackItemId);
          marketDrawStartInteraction(event, fallbackItemId, fallbackHandle);
        } else {
          marketDrawClearSelection();
          draw.interaction = null;
          marketDrawScheduleRender();
        }
      }
      return;
    }

    if (draw.activeTool === "hline") {
      event.preventDefault();
      marketDrawPushUndo();
      marketDrawAddItem({
        id: "d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
        type: "hline",
        p: Number(point.p)
      });
      return;
    }

    if (draw.activeTool === "text") {
      event.preventDefault();
      var text = window.prompt("Text annotation", "");
      if (!hasValue(text)) return;
      marketDrawPushUndo();
      marketDrawAddItem({
        id: "d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
        type: "text",
        at: point,
        text: String(text)
      });
      return;
    }

    if (draw.activeTool === "long" || draw.activeTool === "short") {
      event.preventDefault();
      var posType = draw.activeTool === "short" ? "short" : "long";
      if (!draw.interaction || draw.interaction.type !== "position-create" || draw.interaction.positionType !== posType) {
        draw.interaction = {
          type: "position-create",
          positionType: posType,
          phase: 1,
          entry: point,
          stopPrice: Number(point.p),
          draft: marketDrawBuildPositionDraft(posType, point, Number(point.p), Number(point.p), {
            li: isFinite(Number(point.li)) ? Number(point.li) + MW_DRAW_DEFAULT_POSITION_WIDTH_BARS : null
          })
        };
        marketDrawScheduleRender();
        return;
      }

      if (Number(draw.interaction.phase || 0) <= 1) {
        draw.interaction.phase = 2;
        draw.interaction.stopPrice = Number(point.p);
        draw.interaction.draft = marketDrawBuildPositionDraft(
          posType,
          draw.interaction.entry,
          draw.interaction.stopPrice,
          Number(point.p),
          point
        );
        marketDrawScheduleRender();
        return;
      }

      var finalizedDraft = marketDrawBuildPositionDraft(
        posType,
        draw.interaction.entry,
        draw.interaction.stopPrice,
        Number(point.p),
        point
      );
      if (finalizedDraft) {
        marketDrawPushUndo();
        marketDrawAddItem({
          id: "d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
          type: posType,
          entry: finalizedDraft.entry,
          sl: finalizedDraft.sl,
          tp: finalizedDraft.tp,
          end: finalizedDraft.end
        });
      }
      draw.interaction = null;
      marketDrawScheduleRender();
      return;
    }

    if (draw.activeTool === "trendline" || draw.activeTool === "ruler") {
      event.preventDefault();
      if (!draw.pendingPoint) {
        draw.pendingPoint = point;
        marketDrawScheduleRender();
        return;
      }
      marketDrawPushUndo();
      marketDrawAddItem({
        id: "d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
        type: draw.activeTool === "trendline" ? "trendline" : "ruler",
        a: draw.pendingPoint,
        b: point
      });
      draw.pendingPoint = null;
      marketDrawScheduleRender();
      return;
    }

    if (draw.activeTool === "rect") {
      event.preventDefault();
      marketDrawCapturePointer(event);
      draw.interaction = {
        type: "rect-create",
        draft: {
          id: "draft_rect",
          type: "rect",
          a: point,
          b: point
        }
      };
      marketDrawScheduleRender();
      return;
    }
  }

  function marketDrawOnPointerMove(event) {
    if (state.activeTab !== "marketwatch") return;
    var draw = marketDrawState();
    var target = event.target || {};
    var pointer = marketDrawGetPointerXY(event);
    var prevHover = draw.hoverId;
    var itemId = target.getAttribute ? target.getAttribute("data-item-id") : null;
    var hoverZone = "";
    var hoverProbeItemId = "";

    if (pointer) {
      draw.pointer = { x: pointer.x, y: pointer.y };
    } else {
      draw.pointer = null;
    }

    if (!draw.interaction && draw.activeTool === "select") {
      if (itemId) {
        draw.hoverId = String(itemId);
        var hoverItem = marketDrawGetItemById(itemId);
        if (hoverItem && hoverItem.type === "rect") hoverZone = marketDrawRectHitTest(hoverItem, pointer) || "";
      } else if (pointer) {
        for (var i = draw.items.length - 1; i >= 0; i--) {
          var candidate = draw.items[i];
          if (!candidate || candidate.type !== "rect") continue;
          var zone = marketDrawRectHitTest(candidate, pointer);
          if (!zone) continue;
          hoverZone = zone;
          hoverProbeItemId = String(candidate.id);
          draw.hoverId = hoverProbeItemId;
          break;
        }
        if (!hoverProbeItemId) draw.hoverId = null;
      } else {
        draw.hoverId = null;
      }
    } else if (!draw.interaction) {
      draw.hoverId = null;
    }
    var hoverChanged = prevHover !== draw.hoverId;

    var overlay = els.marketDrawOverlay;
    if (overlay) {
      var nextCursor = "default";
      if (draw.interaction && draw.interaction.type === "move") nextCursor = "move";
      else if (draw.interaction && draw.interaction.type === "resize") {
        var h = String(draw.interaction.handle || "").toLowerCase();
        if (h === "right") nextCursor = "ew-resize";
        else if (h === "sl" || h === "tp") nextCursor = "ns-resize";
        else if (h === "entry" || h === "move") nextCursor = "move";
        else
        if (h === "tr" || h === "bl") nextCursor = "nesw-resize";
        else if (h === "tl" || h === "br" || h === "a" || h === "b") nextCursor = "nwse-resize";
        else if (h === "p" || h === "n" || h === "s") nextCursor = "ns-resize";
        else if (h === "e" || h === "w") nextCursor = "ew-resize";
        else nextCursor = "grab";
      } else if (draw.activeTool === "select") {
        var handle = target.getAttribute ? String(target.getAttribute("data-handle") || "").toLowerCase() : "";
        if (handle) {
          if (handle === "right") nextCursor = "ew-resize";
          else if (handle === "sl" || handle === "tp") nextCursor = "ns-resize";
          else if (handle === "entry" || handle === "move") nextCursor = "move";
          else if (handle === "tr" || handle === "bl") nextCursor = "nesw-resize";
          else if (handle === "tl" || handle === "br" || handle === "a" || handle === "b") nextCursor = "nwse-resize";
          else if (handle === "p" || handle === "n" || handle === "s") nextCursor = "ns-resize";
          else if (handle === "e" || handle === "w") nextCursor = "ew-resize";
          else nextCursor = "grab";
        } else if (itemId) {
          var hoverItem = marketDrawGetItemById(itemId);
          if (hoverItem && marketDrawIsItemLocked(hoverItem)) {
            nextCursor = "not-allowed";
          } else if (hoverItem && hoverItem.type === "rect" && pointer) {
            var zone2 = hoverZone || marketDrawRectHitTest(hoverItem, pointer);
            if (zone2 === "resize-ne" || zone2 === "resize-sw") nextCursor = "nesw-resize";
            else if (zone2 === "resize-nw" || zone2 === "resize-se") nextCursor = "nwse-resize";
            else if (zone2 === "resize-n" || zone2 === "resize-s") nextCursor = "ns-resize";
            else if (zone2 === "resize-e" || zone2 === "resize-w") nextCursor = "ew-resize";
            else nextCursor = "move";
          } else {
            nextCursor = "move";
          }
        } else {
          if (hoverZone === "resize-ne" || hoverZone === "resize-sw") nextCursor = "nesw-resize";
          else if (hoverZone === "resize-nw" || hoverZone === "resize-se") nextCursor = "nwse-resize";
          else if (hoverZone === "resize-n" || hoverZone === "resize-s") nextCursor = "ns-resize";
          else if (hoverZone === "resize-e" || hoverZone === "resize-w") nextCursor = "ew-resize";
          else if (hoverProbeItemId) nextCursor = "move";
          else nextCursor = draw.crosshairEnabled ? "crosshair" : "default";
        }
      } else if (draw.activeTool === "hand") {
        nextCursor = "grab";
      } else if (draw.activeTool === "text") {
        nextCursor = "text";
      } else {
        nextCursor = "crosshair";
      }
      overlay.style.cursor = nextCursor;
    }

    draw.queuedMove = event;
    if (hoverChanged) marketDrawScheduleRender();
    if (draw.moveRaf) return;
    draw.moveRaf = requestAnimationFrame(function () {
      draw.moveRaf = 0;
      if (draw.queuedMove) marketDrawApplyInteraction(draw.queuedMove);
      draw.queuedMove = null;
      if (draw.crosshairEnabled || draw.pendingPoint || draw.interaction) marketDrawScheduleRender();
    });
  }

  function marketDrawOnPointerUp(event) {
    var draw = marketDrawState();
    marketDrawReleasePointer(event);
    if (draw.ui.draggingToolbar) {
      marketDrawEndToolbarDrag();
      return;
    }
    if (!draw.interaction) return;
    if (draw.interaction.type === "position-create") return;
    if (draw.interaction.type === "rect-create") {
      var draft = draw.interaction.draft;
      draw.interaction = null;
      marketDrawSyncOverlayPointerRouting();
      if (draft && draft.a && draft.b && (Math.abs(Number(draft.a.p) - Number(draft.b.p)) > 0 || Math.abs(Number(draft.a.t) - Number(draft.b.t)) > 0)) {
        marketDrawPushUndo();
        marketDrawAddItem({
          id: "d_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8),
          type: "rect",
          a: draft.a,
          b: draft.b
        });
      } else {
        marketDrawScheduleRender();
      }
    } else {
      draw.interaction = null;
      marketDrawSyncOverlayPointerRouting();
      marketDrawScheduleSave();
      marketDrawScheduleRender();
    }
  }

  function marketDrawOnPointerLeave() {
    var draw = marketDrawState();
    draw.pointer = null;
    draw.hoverId = null;
    if (els.marketDrawOverlay) els.marketDrawOverlay.style.cursor = "default";
    marketDrawScheduleRender();
    marketDrawHideTooltip();
  }

  function marketDrawOnDoubleClick(event) {
    var target = event.target || {};
    var itemId = target.getAttribute ? target.getAttribute("data-item-id") : null;
    if (!itemId) return;
    var item = marketDrawGetItemById(itemId);
    if (!item || item.type !== "text") return;
    event.preventDefault();
    event.stopPropagation();
    var nextText = window.prompt("Edit text annotation", hasValue(item.text) ? String(item.text) : "");
    if (!hasValue(nextText)) return;
    marketDrawPushUndo();
    item.text = String(nextText);
    marketDrawReplaceItem(item);
    marketDrawScheduleSave();
    marketDrawScheduleRender();
    marketDrawCloseMenus();
  }

  function marketDrawShouldHandleHotkeys(event) {
    if (state.activeTab !== "marketwatch") return false;
    if (typeof isChartModalOpen === "function" && isChartModalOpen()) return false;
    if (typeof isTradeModalOpen === "function" && isTradeModalOpen()) return false;
    if (typeof isNotesModalOpen === "function" && isNotesModalOpen()) return false;
    if (typeof isCalcModalOpen === "function" && isCalcModalOpen()) return false;
    var target = event.target || null;
    if (target) {
      var tag = String(target.tagName || "").toUpperCase();
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return false;
      if (target.isContentEditable) return false;
    }
    return true;
  }

  function marketDrawHandleHotkeys(event) {
    if (!marketDrawShouldHandleHotkeys(event)) return;
    var key = String(event.key || "").toLowerCase();
    var ctrlLike = !!(event.ctrlKey || event.metaKey);

    if (ctrlLike && key === "z") {
      event.preventDefault();
      if (event.shiftKey) marketDrawRedo();
      else marketDrawUndo();
      return;
    }
    if (ctrlLike && key === "y") {
      event.preventDefault();
      marketDrawRedo();
      return;
    }

    if (key === "escape") {
      event.preventDefault();
      marketDrawClearSelection();
      marketDrawCancelCurrentAction();
      return;
    }

    if (key === "delete" || key === "backspace") {
      event.preventDefault();
      marketDrawDeleteSelected();
      return;
    }

    if (ctrlLike || event.altKey) return;

    if (key === "v") {
      event.preventDefault();
      marketDrawSetTool("select");
      return;
    }
    if (key === "l") {
      event.preventDefault();
      marketDrawSetTool("trendline");
      return;
    }
    if (key === "r") {
      event.preventDefault();
      marketDrawSetTool("rect");
      return;
    }
    if (key === "h") {
      event.preventDefault();
      marketDrawSetTool("hline");
      return;
    }
    if (key === "t") {
      event.preventDefault();
      marketDrawSetTool("text");
      return;
    }
    if (key === "m") {
      event.preventDefault();
      marketDrawSetTool("ruler");
    }
  }

  function marketDrawOnHostWheel(event) {
    if (state.activeTab !== "marketwatch") return;
    if (!els.marketChartWrap || !els.marketChartWrap.contains(event.target)) return;
    if (els.marketDrawToolbar && els.marketDrawToolbar.contains(event.target)) return;
    if (els.marketDrawPropsPanel && els.marketDrawPropsPanel.contains(event.target)) return;
    event.preventDefault();
  }

  function marketDrawOnHostPointerDown(event) {
    if (state.activeTab !== "marketwatch") return;
    if (event.button !== 0) return;
    var draw = marketDrawState();
    if (!draw.selectedObjectId) return;
    var host = els.marketChartWrap || els.marketWatchChart;
    if (!host || !host.contains(event.target)) return;
    if (els.marketDrawToolbar && els.marketDrawToolbar.contains(event.target)) return;
    if (els.marketDrawPropsPanel && els.marketDrawPropsPanel.contains(event.target)) return;
    var target = event.target || {};
    var itemId = target.getAttribute ? target.getAttribute("data-item-id") : null;
    var handle = target.getAttribute ? target.getAttribute("data-handle") : null;
    if (itemId || handle) return;
    marketDrawClearSelection();
  }

  function bindMarketDrawHostWheelGuard() {
    var draw = marketDrawState();
    if (draw.ui.hostWheelBound) return;
    var host = els.marketChartWrap || els.marketWatchChart;
    if (!host) return;
    host.addEventListener("wheel", marketDrawOnHostWheel, { passive: false });
    draw.ui.hostWheelBound = true;
  }

  function bindMarketDrawHostPointerGuard() {
    var draw = marketDrawState();
    if (draw.ui.hostPointerBound) return;
    var host = els.marketChartWrap || els.marketWatchChart;
    if (!host) return;
    host.addEventListener("pointerdown", marketDrawOnHostPointerDown);
    draw.ui.hostPointerBound = true;
  }

  function bindMarketDrawToolbarEvents() {
    var draw = marketDrawState();
    if (els.marketDrawToolbar) {
      var toolbarStops = els.marketDrawToolbar.querySelectorAll("button, input, select");
      var stopToolbarBubble = function (event) { event.stopPropagation(); };
      for (var s = 0; s < toolbarStops.length; s++) {
        toolbarStops[s].addEventListener("pointerdown", stopToolbarBubble);
        toolbarStops[s].addEventListener("click", stopToolbarBubble);
        toolbarStops[s].addEventListener("dblclick", stopToolbarBubble);
        toolbarStops[s].addEventListener("contextmenu", stopToolbarBubble);
        toolbarStops[s].addEventListener("wheel", stopToolbarBubble);
      }
    }
    if (els.marketDrawToolbarDragHandle) {
      els.marketDrawToolbarDragHandle.addEventListener("pointerdown", function (event) {
        marketDrawStartToolbarDrag(event);
      });
    }

    if (els.marketDrawToolButtons && els.marketDrawToolButtons.length) {
      for (var i = 0; i < els.marketDrawToolButtons.length; i++) {
        els.marketDrawToolButtons[i].addEventListener("click", function (event) {
          var tool = String(event.currentTarget.getAttribute("data-draw-tool") || "select").toLowerCase();
          marketWatchDebugLog("[DRAW][CLICK][TOOL]", tool);
          marketDrawCloseMenus();
          marketDrawSetTool(tool);
        });
      }
    }
    if (els.marketDrawActionButtons && els.marketDrawActionButtons.length) {
      for (var j = 0; j < els.marketDrawActionButtons.length; j++) {
        els.marketDrawActionButtons[j].addEventListener("click", function (event) {
          var action = String(event.currentTarget.getAttribute("data-draw-action") || "").toLowerCase();
          marketWatchDebugLog("[DRAW][CLICK][ACTION]", action);
          event.preventDefault();
          if (action === "crosshair") marketDrawToggleCrosshair();
          else if (action === "snap") marketDrawToggleSnap();
          else if (action === "undo") marketDrawUndo();
          else if (action === "redo") marketDrawRedo();
          else if (action === "clear") marketDrawClearAll();
          else if (action === "more") {
            event.stopPropagation();
            marketDrawToggleMoreMenu();
          }
        });
      }
    }

    if (els.marketDrawSnapMode) {
      els.marketDrawSnapMode.addEventListener("change", function () {
        marketDrawSetSnapMode(els.marketDrawSnapMode.value);
      });
    }
    if (els.marketDrawSnapRadius) {
      els.marketDrawSnapRadius.addEventListener("input", function () {
        marketDrawSetSnapRadius(els.marketDrawSnapRadius.value);
      });
    }

    if (!draw.hotkeysBound) {
      document.addEventListener("keydown", marketDrawHandleHotkeys);
      draw.hotkeysBound = true;
    }
    if (!draw.ui.toolbarDragBound) {
      window.addEventListener("pointermove", marketDrawMoveToolbarDrag);
      window.addEventListener("pointerup", marketDrawEndToolbarDrag);
      window.addEventListener("blur", marketDrawEndToolbarDrag);
      draw.ui.toolbarDragBound = true;
    }
    if (!draw.outsideClickBound) {
      document.addEventListener("pointerdown", function (event) {
        if (!draw.ui.moreOpen) return;
        if (!els.marketDrawToolbar) return;
        if (els.marketDrawToolbar.contains(event.target)) return;
        marketDrawCloseMenus();
      });
      draw.outsideClickBound = true;
    }
    if (!draw.ui.unloadBound) {
      window.addEventListener("beforeunload", marketDrawOnBeforeUnload);
      draw.ui.unloadBound = true;
    }

    bindMarketDrawPropertiesEvents();
    marketDrawUpdateToolbarState();
    marketDrawSyncPropertiesPanel();
  }

  function updateMarketWatchInfo(candles, options) {
    var opts = options || {};
    var last = candles && candles.length ? candles[candles.length - 1] : null;
    var sessionLabel = hasValue(opts.sessionLabel) ? String(opts.sessionLabel) : (marketWatch.mode === "LIVE" ? "LIVE" : "History");
    if (!last) {
      safeSetText(els.mwInfoSpread, "--");
      safeSetText(els.mwInfoSession, sessionLabel || "--");
      safeSetText(els.mwInfoLastPrice, "--");
      safeSetText(els.mwInfoOhlc, "-- / -- / -- / --");
      safeSetText(els.mwInfoLastUpdate, "--");
      marketWatchSyncNextCandleCountdown([]);
      return;
    }
    safeSetText(els.mwInfoSpread, "--");
    safeSetText(els.mwInfoSession, sessionLabel || "--");
    safeSetText(els.mwInfoLastPrice, fmt(last.close, 5));
    safeSetText(
      els.mwInfoOhlc,
      fmt(last.open, 5) + " / " + fmt(last.high, 5) + " / " + fmt(last.low, 5) + " / " + fmt(last.close, 5)
    );
    var ts = Number(opts.lastUpdateTsSec);
    if (!isFinite(ts) || ts <= 0) ts = Number(last.time);
    var dt = new Date(ts * 1000);
    safeSetText(els.mwInfoLastUpdate, isNaN(dt.getTime()) ? "--" : formatTime(dt));
    marketWatchSyncNextCandleCountdown(candles);
  }

  function parseMarketTimeToSeconds(value) {
    if (value === null || value === undefined) return NaN;

    if (typeof value === "number") {
      if (!isFinite(value)) return NaN;
      var tNum = value;
      if (tNum > 10000000000) tNum = Math.floor(tNum / 1000); // ms -> sec
      return Math.floor(tNum);
    }

    if (typeof value === "string") {
      var raw = value.trim();
      if (!raw) return NaN;

      if (/^\d+$/.test(raw)) {
        var n = Number(raw);
        if (!isFinite(n)) return NaN;
        if (n > 10000000000) n = Math.floor(n / 1000);
        return Math.floor(n);
      }

      // Handle "YYYY.MM.DD HH:MM:SS" and close variants in UTC.
      var custom = raw.match(/^(\d{4})[.\-\/](\d{1,2})[.\-\/](\d{1,2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
      if (custom) {
        var y = Number(custom[1]);
        var mo = Number(custom[2]) - 1;
        var d = Number(custom[3]);
        var hh = Number(custom[4]);
        var mm = Number(custom[5]);
        var ss = Number(custom[6] || 0);
        var utcTs = Date.UTC(y, mo, d, hh, mm, ss);
        if (isFinite(utcTs)) return Math.floor(utcTs / 1000);
      }

      var normalized = raw.replace(/\./g, "-").replace(" ", "T");
      var ts = Date.parse(normalized);
      if (isFinite(ts)) return Math.floor(ts / 1000);
    }

    return NaN;
  }

  function normalizeCandleEnvelope(openPrice, highPrice, lowPrice, closePrice, rawSample, contextLabel) {
    var maxOc = Math.max(openPrice, closePrice);
    var minOc = Math.min(openPrice, closePrice);
    if (highPrice < maxOc || lowPrice > minOc) {
      marketWatchDebugLog(
        "[OHLC][ASSERT]",
        contextLabel || "candles",
        "raw=",
        rawSample,
        "parsed=",
        { open: openPrice, high: highPrice, low: lowPrice, close: closePrice }
      );
    }

    var high = Math.max(highPrice, maxOc);
    var low = Math.min(lowPrice, minOc);
    if (high < low) {
      var tmp = high;
      high = low;
      low = tmp;
      marketWatchDebugLog("[OHLC][FIX] swapped high/low", contextLabel || "candles", rawSample);
    }
    return { high: high, low: low };
  }

  function normalizeCandles(raw, contextLabel) {
    var input = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.candles) ? raw.candles : []);
    var prepared = [];
    for (var i = 0; i < input.length; i++) {
      var c = input[i] || {};
      var t = parseMarketTimeToSeconds(c.time !== undefined ? c.time : c.timestamp);
      var o = Number(c.open !== undefined ? c.open : c.o);
      var h = Number(c.high !== undefined ? c.high : c.h);
      var l = Number(c.low !== undefined ? c.low : c.l);
      var cl = Number(c.close !== undefined ? c.close : c.c);
      var vRaw = (c.volume !== undefined ? c.volume : c.v);
      var v = Number(vRaw);

      if (!isFinite(t) || !isFinite(o) || !isFinite(h) || !isFinite(l) || !isFinite(cl)) continue;
      if (Math.abs(t) > 10000000000) t = Math.floor(t / 1000); // Defensive ms -> sec guard.

      var envelope = normalizeCandleEnvelope(o, h, l, cl, c, contextLabel);
      h = envelope.high;
      l = envelope.low;
      if (!isFinite(h) || !isFinite(l)) continue;

      prepared.push({
        time: Math.floor(t),
        open: Number(o),
        high: Number(h),
        low: Number(l),
        close: Number(cl),
        volume: isFinite(v) && v >= 0 ? Number(v) : 0
      });
    }

    prepared.sort(function (a, b) { return a.time - b.time; });

    // Remove duplicate timestamps, keeping the last candle for each time key.
    var out = [];
    var duplicates = 0;
    for (var j = 0; j < prepared.length; j++) {
      var current = prepared[j];
      if (out.length && out[out.length - 1].time === current.time) {
        out[out.length - 1] = current;
        duplicates += 1;
      } else {
        out.push(current);
      }
    }

    out._duplicatesRemoved = duplicates;
    return out;
  }

  function buildTimeDiffHistogram(candles) {
    var histogram = {};
    var zeroDiffCount = 0;
    if (!candles || candles.length < 2) {
      return { histogram: histogram, zeroDiffCount: 0, count: 0 };
    }
    for (var i = 1; i < candles.length; i++) {
      var diff = Math.floor(Number(candles[i].time) - Number(candles[i - 1].time));
      if (!isFinite(diff)) continue;
      var key = String(diff);
      histogram[key] = (histogram[key] || 0) + 1;
      if (diff === 0) zeroDiffCount += 1;
    }
    return { histogram: histogram, zeroDiffCount: zeroDiffCount, count: candles.length - 1 };
  }

  function getMarketWatchDominantDiff(histogram) {
    var dominantDiff = null;
    var dominantCount = 0;
    for (var diffKey in histogram) {
      if (!Object.prototype.hasOwnProperty.call(histogram, diffKey)) continue;
      var count = Number(histogram[diffKey] || 0);
      if (count > dominantCount) {
        dominantCount = count;
        dominantDiff = Number(diffKey);
      }
    }
    return dominantDiff;
  }

  function marketWatchStabilizeTimeScale(options) {
    if (!marketWatch.chart) return;
    var opts = options || {};
    var fit = opts.fitContent !== false;
    var offset = marketDrawClampRightOffsetBars(
      opts.rightOffset !== undefined ? opts.rightOffset : marketDrawGetRightOffsetTarget()
    );

    requestAnimationFrame(function () {
      if (!marketWatch.chart) return;
      var scale = marketWatch.chart.timeScale ? marketWatch.chart.timeScale() : null;
      if (!scale) return;

      if (fit && typeof scale.fitContent === "function") {
        try { scale.fitContent(); } catch (e) {}
      }

      setTimeout(function () {
        if (!marketWatch.chart) return;
        try {
          marketWatch.chart.applyOptions({
            timeScale: { rightOffset: offset }
          });
        } catch (e1) {}
        marketDrawEnsureFutureSpace();
      }, 0);
    });
  }

  function applyMarketWatchDefaultZoom(candleCount, options) {
    if (!marketWatch.chart) return;
    var total = Number(candleCount || 0);
    if (!isFinite(total) || total < 0) total = 0;
    var opts = options || {};

    marketWatchStabilizeTimeScale({
      fitContent: true,
      rightOffset: marketDrawGetRightOffsetTarget()
    });

    try {
      if (typeof marketWatch.chart.priceScale === "function") {
        var rightScale = marketWatch.chart.priceScale("right");
        if (rightScale && typeof rightScale.applyOptions === "function") {
          rightScale.applyOptions({
            scaleMargins: { top: 0.15, bottom: 0.20 }
          });
        }
      }
    } catch (e) {}

    if (String(opts.mode || marketWatch.mode || "").toUpperCase() === "LIVE" && marketWatch.isAutoFollow) {
      marketWatchScrollToRealTime();
    }

    marketDrawScheduleRender();
  }

  function buildMarketWatchUrl(mode, symbol, tf, limit) {
    var endpoint = mode === "LIVE" ? "/api/market/live" : "/api/market/history";
    return endpoint
      + "?symbol=" + encodeURIComponent(symbol)
      + "&tf=" + encodeURIComponent(tf)
      + "&limit=" + encodeURIComponent(limit);
  }

  function parseMarketWatchPayload(raw, contextLabel) {
    var isArr = Array.isArray(raw);
    var rawLen = isArr ? raw.length : (raw && Array.isArray(raw.candles) ? raw.candles.length : 0);
    var rawFirst = rawLen > 0 ? (isArr ? raw[0] : raw.candles[0]) : null;
    var rawLast = rawLen > 0 ? (isArr ? raw[rawLen - 1] : raw.candles[rawLen - 1]) : null;
    var candles = normalizeCandles(raw, contextLabel);

    marketWatchDebugLog("[" + contextLabel + "] first raw candle:", rawFirst);
    marketWatchDebugLog("[" + contextLabel + "] last raw candle:", rawLast);
    marketWatchDebugLog("[" + contextLabel + "] first parsed candle:", candles.length ? candles[0] : null);
    marketWatchDebugLog("[" + contextLabel + "] last parsed candle:", candles.length ? candles[candles.length - 1] : null);

    var diffStats = buildTimeDiffHistogram(candles);
    var expectedStep = marketWatchTimeframeToSec(marketWatch.tf);
    var dominantDiff = getMarketWatchDominantDiff(diffStats.histogram);
    marketWatchDebugLog(
      "[" + contextLabel + "] time histogram=",
      diffStats.histogram,
      "expected_step=",
      expectedStep,
      "dominant_diff=",
      dominantDiff,
      "duplicates_removed=",
      Number(candles._duplicatesRemoved || 0)
    );

    return {
      candles: candles,
      expectedStep: expectedStep,
      dominantDiff: dominantDiff
    };
  }

  function fetchMarketWatchCandles(mode, symbol, tf, limit) {
    var url = buildMarketWatchUrl(mode, symbol, tf, limit);
    marketWatchDebugLog("[" + mode + "] fetch url:", url);
    return fetch(url, { method: "GET", cache: "no-store" })
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.json();
      })
      .then(function (raw) {
        return parseMarketWatchPayload(raw, mode);
      });
  }

  function buildMarketWatchVolumeData(candles) {
    var out = [];
    for (var i = 0; i < candles.length; i++) {
      var item = candles[i];
      out.push({
        time: item.time,
        value: isFinite(Number(item.volume)) ? Number(item.volume) : 0,
        color: item.close >= item.open ? "rgba(47, 212, 138, 0.30)" : "rgba(255, 107, 107, 0.30)"
      });
    }
    return out;
  }

  function setMarketWatchSeriesLastCandle(candle) {
    if (!candle) return;
    if (marketWatch.candleSeries && typeof marketWatch.candleSeries.update === "function") {
      marketWatch.candleSeries.update(candle);
    } else {
      setMarketWatchSeriesData(marketWatch.candles || [], { stabilizeTimeScale: false });
      return;
    }
    if (marketWatch.volumeSeries && typeof marketWatch.volumeSeries.update === "function") {
      marketWatch.volumeSeries.update({
        time: candle.time,
        value: isFinite(Number(candle.volume)) ? Number(candle.volume) : 0,
        color: candle.close >= candle.open ? "rgba(47, 212, 138, 0.30)" : "rgba(255, 107, 107, 0.30)"
      });
    } else if (marketWatch.volumeSeries && typeof marketWatch.volumeSeries.setData === "function") {
      marketWatch.volumeSeries.setData(buildMarketWatchVolumeData(marketWatch.candles || []));
    }
    marketDrawScheduleRender();
  }

  function setMarketWatchSeriesData(candles, options) {
    var opts = options || {};
    // Preserve user camera when LIVE follow is paused (TV-like behavior).
    var preserveView = !!opts.preserveView;
    var prevView = preserveView ? marketWatchCaptureVisibleState() : null;
    if (marketWatch.candleSeries && typeof marketWatch.candleSeries.setData === "function") {
      marketWatch.candleSeries.setData(candles);
    }
    if (marketWatch.volumeSeries && typeof marketWatch.volumeSeries.setData === "function") {
      marketWatch.volumeSeries.setData(buildMarketWatchVolumeData(candles));
    }
    if (Array.isArray(candles) && candles.length) {
      if (opts.stabilizeTimeScale !== false) {
        marketWatchStabilizeTimeScale({
          fitContent: opts.fitContent !== false,
          rightOffset: opts.rightOffset
        });
      }
    } else {
      if (opts.stabilizeTimeScale !== false) marketDrawEnsureFutureSpace();
    }
    if (preserveView && !opts.scrollToRealTime) marketWatchRestoreVisibleState(prevView);
    if (opts.scrollToRealTime) marketWatchScrollToRealTime();
    marketDrawScheduleRender();
  }

  function clearMarketWatchData(statusText, chartText, sessionLabel) {
    marketWatch.candles = [];
    marketWatch.lastCandleCount = 0;
    setMarketWatchSeriesData([]);
    if (statusText) setMarketWatchStatus(statusText);
    if (chartText) marketWatchSetEmptyChart(chartText);
    updateMarketWatchInfo([], {
      sessionLabel: sessionLabel || (marketWatch.mode === "LIVE" ? "LIVE" : "History")
    });
    marketWatchSyncAutoFollowUI();
    marketDrawScheduleRender();
  }

  function applyMarketWatchFetchedData(candles, options) {
    var opts = options || {};
    marketDrawSyncContext();
    var mode = opts.mode || marketWatch.mode || "HISTORY";
    var isLive = mode === "LIVE";
    var autoFollowOn = isLive ? !!marketWatch.isAutoFollow : false;
    var labelMode = isLive ? "LIVE" : "HISTORY";
    var sessionLabel = isLive ? "LIVE" : "History";
    var updateTs = Number(opts.lastUpdateTsSec);
    if (!isFinite(updateTs) || updateTs <= 0) {
      updateTs = candles.length ? Number(candles[candles.length - 1].time) : Math.floor(Date.now() / 1000);
    }
    marketWatch.lastUpdateTs = Math.floor(updateTs);
    marketWatch.candles = candles.slice();
    marketWatch.lastCandleCount = candles.length;
    marketWatch.lastCandleTimeMs = marketWatchExtractLastCandleTimeMs(candles);

    if (!candles.length) {
      clearMarketWatchData(
        isLive ? "LIVE " + marketWatch.symbol + " " + marketWatch.tf + " | waiting for candles" : "No history data",
        isLive ? "Waiting for live candles..." : "No history data for selected symbol/timeframe",
        sessionLabel
      );
      return;
    }

    marketWatchClearEmptyChart();
    var fitRequested = opts.fitContent === true;
    var allowFitContent = !isLive && fitRequested;
    var shouldStabilize = !isLive || autoFollowOn || fitRequested;
    var changedCount = Number(opts.appended || 0) + Number(opts.updated || 0);
    var canUseIncremental = isLive
      && opts.useIncrementalUpdate
      && changedCount > 0
      && changedCount <= 1
      && candles.length > 0;
    var noLiveDelta = isLive && opts.useIncrementalUpdate && changedCount <= 0;

    if (canUseIncremental) {
      setMarketWatchSeriesLastCandle(candles[candles.length - 1]);
      if (autoFollowOn) marketWatchScrollToRealTime();
    } else if (!noLiveDelta) {
      setMarketWatchSeriesData(candles, {
        fitContent: allowFitContent,
        rightOffset: marketDrawGetRightOffsetTarget(),
        stabilizeTimeScale: shouldStabilize,
        preserveView: isLive && !autoFollowOn,
        scrollToRealTime: isLive && autoFollowOn
      });
    } else {
      if (autoFollowOn) marketWatchScrollToRealTime();
    }
    updateMarketWatchInfo(candles, {
      sessionLabel: sessionLabel,
      lastUpdateTsSec: marketWatch.lastUpdateTs
    });

    var status = labelMode + " " + marketWatch.symbol + " " + marketWatch.tf + " | " + candles.length + " candles";
    if (isLive) status += " | updated " + formatTime(new Date(marketWatch.lastUpdateTs * 1000));
    setMarketWatchStatus(status);

    try {
      if (opts.forceResize || allowFitContent) resizeMarketWatchChart();
      if (allowFitContent) applyMarketWatchDefaultZoom(candles.length, { mode: mode });
    } catch (e) {}
    marketWatchSyncAutoFollowUI();
  }

  function stopMarketWatchLivePolling() {
    if (marketWatch.liveTimer) {
      clearInterval(marketWatch.liveTimer);
      marketWatch.liveTimer = null;
    }
  }

  function mergeMarketWatchLiveCandles(existing, incoming, maxBars) {
    var source = Array.isArray(existing) ? existing.slice() : [];
    var next = Array.isArray(incoming) ? incoming : [];
    var appended = 0;
    var updated = 0;

    for (var i = 0; i < next.length; i++) {
      var c = next[i];
      if (!source.length) {
        source.push(c);
        appended += 1;
        continue;
      }
      var lastIdx = source.length - 1;
      var lastTime = Number(source[lastIdx].time);
      var currentTime = Number(c.time);
      if (!isFinite(currentTime)) continue;
      if (currentTime > lastTime) {
        source.push(c);
        appended += 1;
      } else if (currentTime === lastTime) {
        source[lastIdx] = c;
        updated += 1;
      }
    }

    source.sort(function (a, b) { return a.time - b.time; });
    if (source.length > maxBars) source = source.slice(source.length - maxBars);
    return { candles: source, appended: appended, updated: updated };
  }

  function loadMarketHistory(symbol, tf) {
    if (!ensureMarketWatchChart()) return;

    stopMarketWatchLivePolling();
    marketWatch.symbol = String(symbol || marketWatch.symbol || "EURUSD").toUpperCase();
    marketWatch.tf = String(tf || marketWatch.tf || "M1").toUpperCase();
    marketWatch.mode = "HISTORY";
    marketWatchSetAutoFollow(true, { scrollNow: false });
    marketWatch.loading = true;
    marketWatch.lastCandleTimeMs = NaN;
    marketDrawSyncContext();
    marketWatchSyncNextCandleCountdown([], { restart: true });
    marketWatchSyncAutoFollowUI();

    setMarketWatchStatus("Loading " + marketWatch.symbol + " " + marketWatch.tf + "...");
    marketWatchSetEmptyChart("Loading history...");
    setMarketWatchSeriesData([]);

    var token = ++marketWatch.requestToken;
    fetchMarketWatchCandles("HISTORY", marketWatch.symbol, marketWatch.tf, MW_HISTORY_FETCH_LIMIT)
      .then(function (result) {
        if (token !== marketWatch.requestToken) return;
        marketWatch.loading = false;
        applyMarketWatchFetchedData(result.candles, { mode: "HISTORY", fitContent: true });
      })
      .catch(function (err) {
        if (token !== marketWatch.requestToken) return;
        marketWatch.loading = false;
        console.error("[MW][HISTORY] load failed:", err && err.message ? err.message : err);
        clearMarketWatchData("History unavailable", "History unavailable", "History");
      });
  }

  function pollMarketWatchLive() {
    if (marketWatch.mode !== "LIVE") return;
    var symbol = marketWatch.symbol || "EURUSD";
    var tf = marketWatch.tf || "M1";
    var token = ++marketWatch.requestToken;

    fetchMarketWatchCandles("LIVE", symbol, tf, MW_LIVE_FETCH_LIMIT)
      .then(function (result) {
        if (token !== marketWatch.requestToken) return;
        if (marketWatch.mode !== "LIVE") return;
        var merged = mergeMarketWatchLiveCandles(marketWatch.candles, result.candles, MW_LIVE_FETCH_LIMIT);
        marketWatchDebugLog("[LIVE] merged candles append=", merged.appended, "updated=", merged.updated);
        applyMarketWatchFetchedData(merged.candles, {
          mode: "LIVE",
          fitContent: false,
          useIncrementalUpdate: true,
          appended: merged.appended,
          updated: merged.updated,
          lastUpdateTsSec: Math.floor(Date.now() / 1000)
        });
      })
      .catch(function (err) {
        if (token !== marketWatch.requestToken) return;
        if (marketWatch.mode !== "LIVE") return;
        console.error("[MW][LIVE] poll failed:", err && err.message ? err.message : err);
        setMarketWatchStatus("LIVE " + symbol + " " + tf + " | disconnected");
      });
  }

  function startMarketWatchLive(symbol, tf) {
    if (!ensureMarketWatchChart()) return;

    stopMarketWatchLivePolling();
    marketWatch.symbol = String(symbol || marketWatch.symbol || "EURUSD").toUpperCase();
    marketWatch.tf = String(tf || marketWatch.tf || "M1").toUpperCase();
    marketWatch.mode = "LIVE";
    marketWatchSetAutoFollow(true, { scrollNow: false });
    marketWatch.loading = true;
    marketWatch.lastCandleTimeMs = NaN;
    marketDrawSyncContext();
    marketWatchSyncNextCandleCountdown([], { restart: true });
    marketWatchSyncAutoFollowUI();

    setMarketWatchStatus("LIVE " + marketWatch.symbol + " " + marketWatch.tf + " | connecting...");
    marketWatchSetEmptyChart("Connecting live feed...");
    setMarketWatchSeriesData([]);

    var token = ++marketWatch.requestToken;
    fetchMarketWatchCandles("LIVE", marketWatch.symbol, marketWatch.tf, MW_LIVE_FETCH_LIMIT)
      .then(function (result) {
        if (token !== marketWatch.requestToken) return;
        marketWatch.loading = false;
        applyMarketWatchFetchedData(result.candles, {
          mode: "LIVE",
          fitContent: true,
          lastUpdateTsSec: Math.floor(Date.now() / 1000)
        });
      })
      .catch(function (err) {
        if (token !== marketWatch.requestToken) return;
        marketWatch.loading = false;
        console.error("[MW][LIVE] initial load failed:", err && err.message ? err.message : err);
        clearMarketWatchData("LIVE unavailable", "LIVE unavailable", "LIVE");
      });

    marketWatch.liveTimer = setInterval(function () {
      pollMarketWatchLive();
    }, MW_LIVE_POLL_MS);
  }

  function buildMarketWatchSnapshotFilename() {
    var now = new Date();
    var stamp = String(now.getFullYear())
      + pad2(now.getMonth() + 1)
      + pad2(now.getDate())
      + "_"
      + pad2(now.getHours())
      + pad2(now.getMinutes())
      + pad2(now.getSeconds());
    var symbol = String(marketWatch.symbol || (els.marketWatchSymbol ? els.marketWatchSymbol.value : "EURUSD") || "EURUSD").toUpperCase();
    var tf = String(marketWatch.tf || marketWatchGetActiveTf() || "M1").toUpperCase();
    var mode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
    return symbol + "_" + tf + "_" + mode + "_" + stamp + ".png";
  }

  function downloadCanvasAsPng(canvas, filename) {
    var dataUrl = canvas.toDataURL("image/png");
    var link = document.createElement("a");
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function takeMarketWatchSnapshot() {
    var container = els.marketChartWrap || els.marketWatchChart;
    if (!container || container.clientWidth <= 0 || container.clientHeight <= 0) {
      setMarketWatchStatus("Snapshot failed: chart container is not ready");
      return;
    }

    setMarketWatchStatus("Capturing snapshot...");
    var done = function (canvas) {
      if (!canvas || canvas.width <= 0 || canvas.height <= 0) {
        setMarketWatchStatus("Snapshot failed: empty image");
        return;
      }
      downloadCanvasAsPng(canvas, buildMarketWatchSnapshotFilename());
      setMarketWatchStatus("Snapshot saved");
    };

    var draw = marketDrawState();
    var hasDrawings = draw && Array.isArray(draw.items) && draw.items.length > 0;
    if (!hasDrawings && marketWatch.chart && typeof marketWatch.chart.takeScreenshot === "function") {
      try {
        var chartCanvas = marketWatch.chart.takeScreenshot();
        if (chartCanvas && chartCanvas.width > 0 && chartCanvas.height > 0) {
          done(chartCanvas);
          return;
        }
      } catch (err) {
        marketWatchDebugLog("[SNAPSHOT] chart screenshot fallback to html2canvas:", err && err.message ? err.message : err);
      }
    }

    if (window.html2canvas) {
      window.html2canvas(container, {
        backgroundColor: null,
        logging: false,
        useCORS: true,
        ignoreElements: function (element) {
          if (!element || !element.id) return false;
          var id = String(element.id);
          return id === "marketDrawToolbar" || id === "marketDrawTooltip";
        }
      })
        .then(function (canvas) {
          done(canvas);
        })
        .catch(function (err) {
          console.error("[MW][SNAPSHOT] failed:", err && err.message ? err.message : err);
          setMarketWatchStatus("Snapshot failed");
        });
      return;
    }

    setMarketWatchStatus("Snapshot failed: export engine unavailable");
  }

  function marketWatchGetSymbolFromItem(itemNode) {
    if (!itemNode) return "EURUSD";
    var symbolEl = itemNode.querySelector(".marketwatch-item-symbol");
    return symbolEl ? String(symbolEl.textContent || "").trim().toUpperCase() : "EURUSD";
  }

  function marketWatchFindItemNode(node) {
    while (node) {
      if (node.classList && node.classList.contains("marketwatch-item")) return node;
      node = node.parentNode;
    }
    return null;
  }

  function marketWatchFindStarNode(node) {
    while (node) {
      if (node.classList && node.classList.contains("marketwatch-star")) return node;
      if (node.classList && node.classList.contains("marketwatch-item")) return null;
      node = node.parentNode;
    }
    return null;
  }

  function loadMarketWatchFavorites() {
    marketWatch.favorites = new Set();
    try {
      var raw = localStorage.getItem(MW_FAVORITES_KEY);
      if (!raw) return;
      var parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return;
      for (var i = 0; i < parsed.length; i++) {
        var symbol = String(parsed[i] || "").trim().toUpperCase();
        if (symbol) marketWatch.favorites.add(symbol);
      }
    } catch (e) {}
  }

  function persistMarketWatchFavorites() {
    try {
      var arr = Array.from(marketWatch.favorites.values());
      arr.sort();
      localStorage.setItem(MW_FAVORITES_KEY, JSON.stringify(arr));
    } catch (e) {}
  }

  function isMarketWatchFavorite(symbol) {
    var key = String(symbol || "").trim().toUpperCase();
    return key ? marketWatch.favorites.has(key) : false;
  }

  function toggleMarketWatchFavorite(symbol) {
    var key = String(symbol || "").trim().toUpperCase();
    if (!key) return;
    if (marketWatch.favorites.has(key)) marketWatch.favorites.delete(key);
    else marketWatch.favorites.add(key);
    persistMarketWatchFavorites();
    renderMarketWatchList();
  }

  function setMarketWatchStarAppearance(starNode, isFavorite) {
    if (!starNode) return;
    starNode.classList.toggle("is-off", !isFavorite);
    starNode.textContent = isFavorite ? "\u2605" : "\u2606";
    starNode.setAttribute("aria-label", isFavorite ? "Favorite" : "Not favorite");
  }

  var MW_INDICATOR_STATE_CLASSES = [
    "up",
    "down",
    "flat",
    "bull",
    "bear",
    "neutral",
    "on",
    "off",
    "low",
    "high",
    "normal",
    "weak",
    "mid",
    "strong",
    "na"
  ];

  function marketWatchIndicatorNode(item, key) {
    if (!item || !item.el) return null;
    return item.el.querySelector('[data-mw-indicator="' + key + '"]');
  }

  function marketWatchSetIndicator(node, text, stateClass, titleText) {
    if (!node) return;
    node.textContent = hasValue(text) ? String(text) : "--";
    for (var i = 0; i < MW_INDICATOR_STATE_CLASSES.length; i++) {
      node.classList.remove(MW_INDICATOR_STATE_CLASSES[i]);
    }
    var cls = hasValue(stateClass) ? String(stateClass).toLowerCase() : "neutral";
    node.classList.add(cls);
    if (hasValue(titleText)) node.title = String(titleText);
    else node.removeAttribute("title");
  }

  function marketWatchRenderIndicatorFallback(item) {
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "trend"), "H1:--", "na", "H1 data unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "adx"), "ADX:--", "na", "ADX14 unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "atr"), "ATR:--", "na", "ATR state unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "bias"), "M15:--", "na", "M15 bias unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "dist"), "Dist:--", "na", "Distance unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "cooldown"), "CD:--", "na", "Cooldown unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "news"), "News:--", "na", "News block unavailable");
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "trades"), "T:--", "na", "Trades today unavailable");
  }

  function marketWatchRenderIndicatorItem(item, payload) {
    if (!item || !payload || typeof payload !== "object") {
      marketWatchRenderIndicatorFallback(item);
      return;
    }

    var h1 = payload.h1 && typeof payload.h1 === "object" ? payload.h1 : {};
    var m15 = payload.m15 && typeof payload.m15 === "object" ? payload.m15 : {};
    var risk = payload.risk && typeof payload.risk === "object" ? payload.risk : {};

    var ema50 = Number(h1.ema50);
    var ema200 = Number(h1.ema200);
    var hasEma = isFinite(ema50) && isFinite(ema200);
    var trend = hasValue(h1.trend) ? String(h1.trend).toUpperCase() : "--";
    if (!hasEma) trend = "--";
    var trendClass = trend === "UP" ? "up" : (trend === "DOWN" ? "down" : (trend === "FLAT" ? "flat" : "na"));
    var trendTitle = hasEma
      ? ("H1 EMA50=" + fmt(ema50, 5) + ", EMA200=" + fmt(ema200, 5) + ", Trend=" + trend)
      : "H1 EMA values unavailable";
    marketWatchSetIndicator(marketWatchIndicatorNode(item, "trend"), "H1:" + trend, trendClass, trendTitle);

    var adx = Number(h1.adx14);
    var hasAdx = isFinite(adx);
    var adxClass = "na";
    if (hasAdx) {
      if (adx < 20) adxClass = "weak";
      else if (adx <= 25) adxClass = "mid";
      else adxClass = "strong";
    }
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "adx"),
      hasAdx ? ("ADX:" + fmt(adx, 1)) : "ADX:--",
      adxClass,
      hasAdx ? ("ADX14=" + fmt(adx, 2)) : "ADX14 unavailable"
    );

    var atrState = hasValue(h1.atr_state) ? String(h1.atr_state).toUpperCase() : "--";
    var atr = Number(h1.atr14);
    var hasAtr = isFinite(atr);
    var atrClass = atrState === "LOW" ? "low" : (atrState === "HIGH" ? "high" : (atrState === "NORMAL" ? "normal" : "na"));
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "atr"),
      atrState === "--" ? "ATR:--" : ("ATR:" + atrState),
      atrClass,
      hasAtr ? ("ATR14=" + fmt(atr, 5) + ", state=" + atrState) : "ATR14/state unavailable"
    );

    var bias = hasValue(m15.bias) ? String(m15.bias).toUpperCase() : "--";
    var biasClass = bias === "BULL" ? "bull" : (bias === "BEAR" ? "bear" : (bias === "NEUTRAL" ? "neutral" : "na"));
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "bias"),
      "M15:" + bias,
      biasClass,
      "M15 bias=" + bias
    );

    var dist = Number(m15.dist_to_h1_ema50_pips);
    var hasDist = isFinite(dist);
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "dist"),
      hasDist ? ("Dist:" + fmt(dist, 1) + "p") : "Dist:--",
      hasDist ? "neutral" : "na",
      hasDist ? ("Distance to H1 EMA50 = " + fmt(dist, 2) + " pips") : "Distance unavailable"
    );

    var cooldownActive = !!risk.cooldown_active;
    var cooldownReason = hasValue(risk.cooldown_reason) ? String(risk.cooldown_reason).toUpperCase() : "";
    var cooldownText = "CD:" + (cooldownActive ? "ON" : "OFF");
    if (cooldownActive && cooldownReason) cooldownText += "-" + cooldownReason;
    var cooldownTitle = cooldownActive
      ? ("Cooldown active" + (cooldownReason ? (" (" + cooldownReason + ")") : ""))
      : "Cooldown inactive";
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "cooldown"),
      cooldownText,
      cooldownActive ? "on" : "off",
      cooldownTitle
    );

    var newsActive = !!risk.news_block_active;
    var newsMinutes = Number(risk.news_minutes_to_event);
    var hasNewsMinutes = isFinite(newsMinutes);
    var newsText = "News:" + (newsActive ? "ON" : "OFF");
    if (hasNewsMinutes) newsText += " " + String(parseInt(newsMinutes, 10)) + "m";
    var newsTitle = newsActive ? "News block active" : "News block inactive";
    if (hasNewsMinutes) newsTitle += ", minutes to event=" + String(parseInt(newsMinutes, 10));
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "news"),
      newsText,
      newsActive ? "on" : "off",
      newsTitle
    );

    var tradesToday = Number(risk.trades_today);
    var tradesLimit = Number(risk.trades_today_limit);
    var hasTradesToday = isFinite(tradesToday);
    var hasTradesLimit = isFinite(tradesLimit);
    var tradesText = "T:" + (hasTradesToday ? String(parseInt(tradesToday, 10)) : "--");
    if (hasTradesLimit) tradesText += "/" + String(parseInt(tradesLimit, 10));
    var tradesTitle = hasTradesToday
      ? ("Trades today=" + String(parseInt(tradesToday, 10)) + (hasTradesLimit ? (", limit=" + String(parseInt(tradesLimit, 10))) : ""))
      : "Trades today unavailable";
    marketWatchSetIndicator(
      marketWatchIndicatorNode(item, "trades"),
      tradesText,
      hasTradesToday ? "neutral" : "na",
      tradesTitle
    );
  }

  function marketWatchRenderIndicators() {
    if (!marketWatch.watchItems || !marketWatch.watchItems.length) return;
    var map = marketWatch.indicatorsBySymbol && typeof marketWatch.indicatorsBySymbol === "object"
      ? marketWatch.indicatorsBySymbol
      : {};
    for (var i = 0; i < marketWatch.watchItems.length; i++) {
      var item = marketWatch.watchItems[i];
      if (!item || !item.symbol) continue;
      if (marketWatch.indicatorsError) {
        marketWatchRenderIndicatorFallback(item);
        continue;
      }
      var payload = map[item.symbol];
      marketWatchRenderIndicatorItem(item, payload);
    }
  }

  function marketWatchBuildIndicatorSymbols() {
    var out = [];
    var seen = {};
    for (var i = 0; i < marketWatch.watchItems.length; i++) {
      var symbol = marketWatch.watchItems[i] && marketWatch.watchItems[i].symbol
        ? String(marketWatch.watchItems[i].symbol).toUpperCase()
        : "";
      if (!symbol || seen[symbol]) continue;
      seen[symbol] = true;
      out.push(symbol);
    }
    return out;
  }

  function refreshMarketWatchIndicators(options) {
    var opts = options || {};
    var symbols = marketWatchBuildIndicatorSymbols();
    if (!symbols.length) return;
    if (marketWatch.indicatorsInFlight && !opts.force) return;

    marketWatch.indicatorsInFlight = true;
    var url = "/api/marketwatch/indicators?symbols=" + encodeURIComponent(symbols.join(","));
    requestJson("GET", url, function (err, data) {
      marketWatch.indicatorsInFlight = false;
      if (err || !data || data.ok !== true || !Array.isArray(data.items)) {
        marketWatch.indicatorsBySymbol = {};
        marketWatch.indicatorsError = true;
        marketWatch.indicatorsLoadedOnce = true;
        marketWatchRenderIndicators();
        return;
      }
      var map = {};
      for (var i = 0; i < data.items.length; i++) {
        var item = data.items[i] || {};
        var symbol = hasValue(item.symbol) ? String(item.symbol).toUpperCase() : "";
        if (!symbol) continue;
        map[symbol] = item;
      }
      marketWatch.indicatorsBySymbol = map;
      marketWatch.indicatorsError = false;
      marketWatch.indicatorsLoadedOnce = true;
      marketWatchRenderIndicators();
    });
  }

  function resetMarketWatchIndicatorsTimer() {
    if (marketWatch.indicatorsTimer) {
      clearInterval(marketWatch.indicatorsTimer);
      marketWatch.indicatorsTimer = null;
    }
    if (state.activeTab !== "marketwatch") return;
    marketWatch.indicatorsTimer = setInterval(function () {
      if (state.activeTab !== "marketwatch") {
        resetMarketWatchIndicatorsTimer();
        return;
      }
      refreshMarketWatchIndicators();
    }, MW_INDICATORS_POLL_MS);
  }

  function setActiveMarketWatchItem(symbol) {
    var target = String(symbol || "").trim().toUpperCase();
    for (var i = 0; i < marketWatch.watchItems.length; i++) {
      var item = marketWatch.watchItems[i];
      item.el.classList.toggle("is-active", item.symbol === target);
    }
  }

  function initializeMarketWatchList() {
    var items = document.querySelectorAll(".marketwatch-item");
    marketWatch.watchItems = [];
    marketWatch.watchListContainer = null;
    for (var i = 0; i < items.length; i++) {
      var el = items[i];
      var symbol = marketWatchGetSymbolFromItem(el);
      if (!symbol) continue;
      if (!marketWatch.watchListContainer) marketWatch.watchListContainer = el.parentNode;
      marketWatch.watchItems.push({
        el: el,
        symbol: symbol,
        star: el.querySelector(".marketwatch-star"),
        order: i
      });
    }
    marketWatchRenderIndicators();
  }

  function renderMarketWatchList() {
    if (!marketWatch.watchItems.length || !marketWatch.watchListContainer) return;
    var query = hasValue(els.marketWatchSearch && els.marketWatchSearch.value)
      ? String(els.marketWatchSearch.value).trim().toUpperCase()
      : "";

    var visible = [];
    for (var i = 0; i < marketWatch.watchItems.length; i++) {
      var item = marketWatch.watchItems[i];
      var isFav = isMarketWatchFavorite(item.symbol);
      setMarketWatchStarAppearance(item.star, isFav);
      var matches = !query || item.symbol.indexOf(query) >= 0;
      item.el.hidden = !matches;
      if (matches) visible.push(item);
    }

    visible.sort(function (a, b) {
      var aFav = isMarketWatchFavorite(a.symbol) ? 1 : 0;
      var bFav = isMarketWatchFavorite(b.symbol) ? 1 : 0;
      if (aFav !== bFav) return bFav - aFav;
      return a.order - b.order;
    });

    for (var j = 0; j < visible.length; j++) {
      marketWatch.watchListContainer.appendChild(visible[j].el);
    }
    marketWatchRenderIndicators();
  }

  function refreshMarketWatchByCurrentMode(symbol, tf) {
    var activeMode = marketWatchGetActiveMode();
    if (activeMode === "LIVE") startMarketWatchLive(symbol, tf);
    else loadMarketHistory(symbol, tf);
  }

  function bindMarketWatchEvents() {
    loadMarketWatchFavorites();
    initializeMarketWatchList();
    renderMarketWatchList();
    refreshMarketWatchIndicators({ force: true });
    bindMarketDrawToolbarEvents();
    bindMarketDrawHostWheelGuard();
    bindMarketDrawHostPointerGuard();

    if (els.marketWatchSearch) {
      els.marketWatchSearch.addEventListener("input", function () {
        renderMarketWatchList();
      });
    }

    if (marketWatch.watchListContainer) {
      marketWatch.watchListContainer.addEventListener("click", function (event) {
        var target = event.target || event.srcElement;
        var itemNode = marketWatchFindItemNode(target);
        if (!itemNode) return;
        var symbol = marketWatchGetSymbolFromItem(itemNode);
        var starNode = marketWatchFindStarNode(target);

        if (starNode) {
          event.preventDefault();
          event.stopPropagation();
          marketWatchDebugLog("[MW][CLICK][FAVORITE]", symbol);
          toggleMarketWatchFavorite(symbol);
          return;
        }

        marketWatchDebugLog("[MW][CLICK][SYMBOL]", symbol);
        marketDrawClearSelection();
        setActiveMarketWatchItem(symbol);
        if (els.marketWatchSymbol) els.marketWatchSymbol.value = symbol;
        refreshMarketWatchByCurrentMode(symbol, marketWatchGetActiveTf());
      });
    }

    if (els.marketWatchSymbol) {
      els.marketWatchSymbol.addEventListener("change", function () {
        var symbol = String(els.marketWatchSymbol.value || "EURUSD").toUpperCase();
        marketDrawClearSelection();
        setActiveMarketWatchItem(symbol);
        refreshMarketWatchByCurrentMode(symbol, marketWatchGetActiveTf());
      });
    }

    if (els.marketWatchTfButtons && els.marketWatchTfButtons.length) {
      for (var i = 0; i < els.marketWatchTfButtons.length; i++) {
        els.marketWatchTfButtons[i].addEventListener("click", function (event) {
          var tf = String(event.currentTarget.getAttribute("data-mw-tf") || "M1").toUpperCase();
          marketWatchSetActiveButton(els.marketWatchTfButtons, "data-mw-tf", tf);
          marketDrawClearSelection();
          refreshMarketWatchByCurrentMode(
            els.marketWatchSymbol ? els.marketWatchSymbol.value : marketWatch.symbol,
            tf
          );
        });
      }
    }

    if (els.marketWatchModeButtons && els.marketWatchModeButtons.length) {
      for (var j = 0; j < els.marketWatchModeButtons.length; j++) {
        els.marketWatchModeButtons[j].addEventListener("click", function (event) {
          var mode = String(event.currentTarget.getAttribute("data-mw-mode") || "HISTORY").toUpperCase();
          marketWatchSetActiveButton(els.marketWatchModeButtons, "data-mw-mode", mode);
          marketDrawClearSelection();
          var symbol = els.marketWatchSymbol ? els.marketWatchSymbol.value : marketWatch.symbol;
          var tf = marketWatchGetActiveTf();
          if (mode === "LIVE") startMarketWatchLive(symbol, tf);
          else loadMarketHistory(symbol, tf);
        });
      }
    }

    if (els.marketWatchReset) {
      els.marketWatchReset.addEventListener("click", function () {
        if (!marketWatch.chart) return;
        marketWatchDebugLog("[MW][CLICK][RESET]");
        marketDrawClearSelection();
        if (marketWatchModeIsLive()) marketWatchSetAutoFollow(true, { scrollNow: true });
        applyMarketWatchDefaultZoom(marketWatch.lastCandleCount, { mode: marketWatch.mode || marketWatchGetActiveMode() });
      });
    }

    if (els.marketWatchGoLive) {
      els.marketWatchGoLive.addEventListener("click", function () {
        if (!marketWatchModeIsLive()) return;
        marketWatchSetAutoFollow(true, { scrollNow: true });
        setMarketWatchStatus("LIVE " + marketWatch.symbol + " " + marketWatch.tf + " | following latest");
      });
    }

    if (els.marketWatchSnapshot) {
      els.marketWatchSnapshot.addEventListener("click", function () {
        marketWatchDebugLog("[MW][CLICK][SNAPSHOT]");
        takeMarketWatchSnapshot();
      });
    }
    marketWatchSyncAutoFollowUI();
  }

  function activateMarketWatchTab() {
    if (!ensureMarketWatchChart()) return;
    renderMarketWatchList();
    marketWatchSyncAutoFollowUI();
    resetMarketWatchIndicatorsTimer();
    refreshMarketWatchIndicators({ force: !marketWatch.indicatorsLoadedOnce });
    requestAnimationFrame(function () {
      resizeMarketWatchChart();
      var viewMode = String(marketWatch.mode || marketWatchGetActiveMode() || "HISTORY").toUpperCase();
      if (!(viewMode === "LIVE" && !marketWatch.isAutoFollow)) {
        applyMarketWatchDefaultZoom(marketWatch.lastCandleCount, { mode: viewMode });
      }
    });
    var symbol = els.marketWatchSymbol ? String(els.marketWatchSymbol.value || marketWatch.symbol || "EURUSD").toUpperCase() : "EURUSD";
    var tf = marketWatchGetActiveTf();
    setActiveMarketWatchItem(symbol);
    marketWatchSyncNextCandleCountdown(null, { useStateCandles: true, restart: true });
    marketDrawSyncContext();
    marketDrawScheduleRender();

    var activeMode = marketWatchGetActiveMode();
    if (activeMode === "LIVE") {
      if (!marketWatch.liveTimer || marketWatch.symbol !== symbol || marketWatch.tf !== tf || marketWatch.mode !== "LIVE") {
        startMarketWatchLive(symbol, tf);
      }
      return;
    }

    if (marketWatch.liveTimer) stopMarketWatchLivePolling();
    if (marketWatch.symbol !== symbol || marketWatch.tf !== tf || !marketWatch.candles.length || marketWatch.mode !== "HISTORY") {
      loadMarketHistory(symbol, tf);
      return;
    }
  }

  function getStatusLabel(status) {
    var st = String(status || "").toUpperCase();
    return st || "--";
  }

  function getCloseReason(value) {
    if (!hasValue(value)) return { label: "--", kind: "neutral" };
    var raw = String(value).trim();
    var upper = raw.toUpperCase();
    if (upper.indexOf("SL") >= 0 || upper.indexOf("STOP") >= 0) {
      return { label: "SL", kind: "sl" };
    }
    if (upper.indexOf("TP") >= 0 || upper.indexOf("TAKE") >= 0) {
      return { label: "TP", kind: "tp" };
    }
    if (upper.indexOf("BE") >= 0 || upper.indexOf("BREAK") >= 0) {
      return { label: "BE", kind: "be" };
    }
    return { label: raw, kind: "neutral" };
  }

  function renderDashboard() {
    var stat = state.stats || {};
    setKpiValue(els.kpiTotalProfit, stat.total_profit, 2, "");
    setKpiValue(els.kpiWinRate, stat.win_rate, 2, "%");

    if (els.kpiProfitFactor) {
      var pf = Number(stat.profit_factor);
      els.kpiProfitFactor.textContent = fmt(stat.profit_factor, 2);
      els.kpiProfitFactor.className = "kpi-value";
      if (!isNaN(pf) && isFinite(pf)) {
        if (pf < 1) {
          els.kpiProfitFactor.className += " is-warning";
        } else if (pf >= 1) {
          els.kpiProfitFactor.className += " is-positive";
        }
      }
    }

    safeSetText(els.statTotalTrades, stat.total_trades);
    safeSetText(els.statOpenTrades, stat.open_trades);
    safeSetText(els.statClosedTrades, stat.closed_trades);
    setStatValue(els.statAvgWin, stat.average_win);
    setStatValue(els.statAvgLoss, stat.average_loss);
    setStatValue(els.statBestTrade, stat.best_trade);
    setStatValue(els.statWorstTrade, stat.worst_trade);

    renderDashboardTrades();
    renderSparkline();
  }

  function renderDashboardTrades() {
    if (!els.dashboardTradesBody) return;
    var trades = state.trades.slice(0, 10);
    if (!trades.length) {
      els.dashboardTradesBody.innerHTML = ``;
      if (els.dashboardTradesEmpty) els.dashboardTradesEmpty.classList.remove("is-hidden");
      if (els.dashboardTradesScroll) els.dashboardTradesScroll.classList.add("is-hidden");
      return;
    }
    if (els.dashboardTradesEmpty) els.dashboardTradesEmpty.classList.add("is-hidden");
    if (els.dashboardTradesScroll) els.dashboardTradesScroll.classList.remove("is-hidden");

    var rows = [];
    for (var i = 0; i < trades.length; i++) {
      var t = trades[i] || {};
      var profitRaw = pickValue(t, ["profit"]);
      var profitNum = hasValue(profitRaw) ? Number(profitRaw) : null;
      var profitClass = "profit";
      var profitSymbol = "";
      if (profitNum !== null && !isNaN(profitNum) && isFinite(profitNum)) {
        profitClass += profitNum >= 0 ? " is-positive" : " is-negative";
        profitSymbol = profitNum >= 0 ? "\u25B2" : "\u25BC";
      }
      var closeReason = pickValue(t, ["close_reason", "exit_reason"]);
      var closeBadge = getCloseReason(closeReason);
      var status = getStatusLabel(t.status);
      var statusClass = status === "OPEN" ? "pill pill-open" : "pill pill-closed";
      var closeTime = t.close_time || t.open_time || "--";
      rows.push(`
        <tr>
          <td class="col-num">${esc(t.ticket || "--")}</td>
          <td class="col-center">${esc(t.symbol || "--")}</td>
          <td class="col-center">${esc(t.direction || "--")}</td>
          <td class="col-time">${esc(closeTime)}</td>
          <td class="col-num ${profitClass}">${esc(profitSymbol)} ${fmt(profitRaw, 2)}</td>
          <td class="col-center"><span class="badge ${closeBadge.kind}">${esc(closeBadge.label)}</span></td>
          <td class="col-center"><span class="${statusClass}">${esc(status)}</span></td>
        </tr>
      `);
    }
    els.dashboardTradesBody.innerHTML = rows.join(``);
  }

  function renderSparkline() {
    if (!els.equitySparkline) return;
    var series = buildEquitySeries(state.trades);
    if (series.length < 2) {
      els.equitySparkline.innerHTML = ``;
      if (els.equitySparklineEmpty) els.equitySparklineEmpty.classList.remove("is-hidden");
      return;
    }
    if (els.equitySparklineEmpty) els.equitySparklineEmpty.classList.add("is-hidden");
    renderLineChart(els.equitySparkline, series, {
      stroke: "#3fe0c5",
      fill: "rgba(63, 224, 197, 0.12)"
    });
  }

  function buildEquitySeries(trades) {
    var points = [];
    var items = [];
    for (var i = 0; i < trades.length; i++) {
      var t = trades[i] || {};
      var profitRaw = pickValue(t, ["profit"]);
      if (!hasValue(profitRaw)) continue;
      var profit = Number(profitRaw);
      if (!isNaN(profit) && isFinite(profit)) {
        items.push({
          profit: profit,
          time: parseTradeDate(t.close_time) || parseTradeDate(t.created_at) || parseTradeDate(t.open_time),
          index: i
        });
      }
    }
    if (!items.length) return points;
    items.sort(function (a, b) {
      if (a.time && b.time) return a.time.getTime() - b.time.getTime();
      if (a.time && !b.time) return -1;
      if (!a.time && b.time) return 1;
      return a.index - b.index;
    });
    var cumulative = 0;
    for (var j = 0; j < items.length; j++) {
      cumulative += items[j].profit;
      points.push(cumulative);
    }
    return points;
  }
  function renderTradesTable() {
    if (!els.tradesTableBody) return;
    rebuildTradesById(state.trades);
    var filtered = applyTradeFilters(state.trades);
    filtered = filterTradesByDateRange(filtered);
    filtered = applyTradesSort(filtered);
    var scrollTop = 0;
    if (els.tradesTableScroll) scrollTop = els.tradesTableScroll.scrollTop;

    if (!filtered.length) {
      els.tradesTableBody.innerHTML = ``;
      if (els.tradesTableEmpty) els.tradesTableEmpty.classList.remove("is-hidden");
    } else {
      if (els.tradesTableEmpty) els.tradesTableEmpty.classList.add("is-hidden");
    }

    var mode = String(state.tradesViewMode || "flat");
    if (mode !== "day" && mode !== "session") mode = "flat";

    if (mode === "flat") {
      var rows = [];
      for (var i = 0; i < filtered.length; i++) {
        rows.push(buildTradeRowHtml(filtered[i] || {}));
      }
      els.tradesTableBody.innerHTML = rows.join(``);
    } else {
      var groups = mode === "day" ? groupTradesByDay(filtered) : groupTradesBySession(filtered);
      els.tradesTableBody.innerHTML = renderTradesGrouped(groups, mode);
    }
    if (state.activeTab === "trades" && els.tradesTableScroll) {
      els.tradesTableScroll.scrollTop = scrollTop;
    }
    state.needsTradesRender = false;
  }

  function applyTradeFilters(trades) {
    var statusFilter = els.statusFilter ? els.statusFilter.value : "ALL";
    var searchValue = els.searchInput ? els.searchInput.value.trim().toLowerCase() : "";
    var closeReasonFilter = els.closeReasonFilter ? els.closeReasonFilter.value : "ALL";
    var setupFilter = els.setupFilter ? els.setupFilter.value : "ALL";

    return trades.filter(function (t) {
      var status = String(t.status || "").toUpperCase();
      if (statusFilter !== "ALL" && status !== statusFilter) return false;
      if (searchValue) {
        var symbol = String(t.symbol || "").toLowerCase();
        var ticket = String(t.ticket || "").toLowerCase();
        if (symbol.indexOf(searchValue) === -1 && ticket.indexOf(searchValue) === -1) {
          return false;
        }
      }
      if (closeReasonFilter !== "ALL") {
        var closeRaw = pickValue(t, ["close_reason", "exit_reason"]);
        var closeLabel = getCloseReason(closeRaw).label.toUpperCase();
        if (closeLabel !== closeReasonFilter.toUpperCase()) return false;
      }
      if (setupFilter !== "ALL") {
        var setupRaw = pickValue(t, ["setup", "setup_result"]);
        if (String(setupRaw || "").toUpperCase() !== setupFilter.toUpperCase()) return false;
      }
      return true;
    });
  }

  function updateFilterOptions(trades) {
    if (!els.closeReasonFilter || !els.setupFilter) return;
    var closeReasons = {};
    var setups = {};
    for (var i = 0; i < trades.length; i++) {
      var t = trades[i] || {};
      var closeRaw = pickValue(t, ["close_reason", "exit_reason"]);
      if (hasValue(closeRaw)) {
        var closeLabel = getCloseReason(closeRaw).label;
        if (closeLabel !== "--") closeReasons[closeLabel] = true;
      }
      var setupRaw = pickValue(t, ["setup", "setup_result"]);
      if (hasValue(setupRaw)) setups[String(setupRaw)] = true;
    }

    var closeList = Object.keys(closeReasons).sort();
    var setupList = Object.keys(setups).sort();

    populateSelect(els.closeReasonFilter, closeList, "All");
    populateSelect(els.setupFilter, setupList, "All");

    toggleFilterWrap(els.closeReasonFilterWrap, closeList.length > 0);
    toggleFilterWrap(els.setupFilterWrap, setupList.length > 0);
  }

  function populateSelect(selectEl, values, allLabel) {
    if (!selectEl) return;
    var current = selectEl.value || "ALL";
    var options = [`<option value="ALL">${esc(allLabel)}</option>`];
    for (var i = 0; i < values.length; i++) {
      options.push(`<option value="${esc(values[i])}">${esc(values[i])}</option>`);
    }
    selectEl.innerHTML = options.join(``);
    if (current !== "ALL" && values.indexOf(current) >= 0) {
      selectEl.value = current;
    } else {
      selectEl.value = "ALL";
    }
    selectEl.disabled = values.length === 0;
  }

  function toggleFilterWrap(el, show) {
    if (!el) return;
    if (show) {
      el.classList.remove("is-hidden");
    } else {
      el.classList.add("is-hidden");
    }
  }
  /* ═══════════════════════════════════════════════════════════════
     ApexCharts-based Analytics Tab
     ═══════════════════════════════════════════════════════════════ */
  function parseNewsTimeUtc(value) {
    if (!hasValue(value)) return null;
    var raw = String(value).trim();
    if (!raw) return null;
    var normalized = raw.replace(" ", "T");
    if (!/[zZ]$/.test(normalized) && !/[+-]\d{2}:\d{2}$/.test(normalized)) {
      normalized += "Z";
    }
    var dt = new Date(normalized);
    if (!isNaN(dt.getTime())) return dt;
    return null;
  }

  function formatNewsTimeLocal(value) {
    var dt = parseNewsTimeUtc(value);
    if (!dt) return "--";
    try {
      return dt.toLocaleString(undefined, {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      });
    } catch (err) {
      return dt.toISOString();
    }
  }

  function normalizeNewsStatus(value) {
    var v = String(value || "all").toLowerCase();
    if (v === "upcoming" || v === "released") return v;
    return "all";
  }

  function normalizeNewsImportance(value) {
    var num = parseInt(value, 10);
    if (isNaN(num) || !isFinite(num)) num = 0;
    if (num < 0) num = 0;
    if (num > 2) num = 2;
    return num;
  }

  function normalizeNewsCurrencyCsv(value) {
    if (!hasValue(value)) return "";
    var parts = String(value).split(",");
    var out = [];
    var seen = {};
    for (var i = 0; i < parts.length; i++) {
      var token = String(parts[i] || "").trim().toUpperCase();
      if (!token) continue;
      if (seen[token]) continue;
      seen[token] = true;
      out.push(token);
    }
    return out.join(",");
  }

  function syncNewsFilterUiFromState() {
    var filters = state.newsFilters || {};
    var status = normalizeNewsStatus(filters.status);
    if (els.newsStatusButtons && els.newsStatusButtons.length) {
      for (var i = 0; i < els.newsStatusButtons.length; i++) {
        var btn = els.newsStatusButtons[i];
        var btnStatus = normalizeNewsStatus(btn.getAttribute("data-news-status"));
        btn.classList.toggle("is-active", btnStatus === status);
      }
    }
    if (els.newsDateFrom) els.newsDateFrom.value = hasValue(filters.from) ? String(filters.from) : "";
    if (els.newsDateTo) els.newsDateTo.value = hasValue(filters.to) ? String(filters.to) : "";
    if (els.newsCurrencyInput) els.newsCurrencyInput.value = hasValue(filters.currency) ? String(filters.currency) : "";
    if (els.newsMinImportance) els.newsMinImportance.value = String(normalizeNewsImportance(filters.minImportance));
  }

  function buildNewsQuery(offset) {
    var filters = state.newsFilters || {};
    var parts = [];
    parts.push("limit=" + encodeURIComponent(state.newsLimit));
    parts.push("offset=" + encodeURIComponent(offset || 0));
    parts.push("status=" + encodeURIComponent(normalizeNewsStatus(filters.status)));
    parts.push("min_importance=" + encodeURIComponent(normalizeNewsImportance(filters.minImportance)));

    var from = hasValue(filters.from) ? String(filters.from).trim() : "";
    var to = hasValue(filters.to) ? String(filters.to).trim() : "";
    if (from) parts.push("from=" + encodeURIComponent(from));
    if (to) parts.push("to=" + encodeURIComponent(to));

    var currency = normalizeNewsCurrencyCsv(filters.currency);
    if (currency) parts.push("currency=" + encodeURIComponent(currency));

    return "?" + parts.join("&");
  }

  function getNewsImpactMeta(importance) {
    var lvl = normalizeNewsImportance(importance);
    if (lvl >= 2) return { label: "High", cls: "impact-high" };
    if (lvl === 1) return { label: "Medium", cls: "impact-medium" };
    return { label: "Low", cls: "impact-low" };
  }

  function getNewsStatusMeta(status) {
    var normalized = normalizeNewsStatus(status);
    if (normalized === "released") return { label: "Released", cls: "news-released" };
    return { label: "Upcoming", cls: "news-upcoming" };
  }

  function formatNewsValue(value) {
    return hasValue(value) ? String(value) : "--";
  }

  function mergeNewsItems(existing, incoming) {
    var out = Array.isArray(existing) ? existing.slice(0) : [];
    var seen = {};
    for (var i = 0; i < out.length; i++) {
      var uid = hasValue(out[i] && out[i].event_uid) ? String(out[i].event_uid) : ("idx:" + i);
      seen[uid] = true;
    }
    for (var j = 0; j < incoming.length; j++) {
      var item = incoming[j] || {};
      var key = hasValue(item.event_uid) ? String(item.event_uid) : ("new:" + j + ":" + out.length);
      if (seen[key]) continue;
      seen[key] = true;
      out.push(item);
    }
    return out;
  }

  function renderNewsLastUpdated() {
    if (!els.newsLastUpdated) return;
    var source = state.newsLastUpdatedAt;
    if (!hasValue(source)) {
      els.newsLastUpdated.textContent = "--";
      return;
    }
    els.newsLastUpdated.textContent = formatNewsTimeLocal(source);
  }

  function buildNewsDetailsRowHtml(item) {
    return (
      '<div class="news-details-wrap">'
      + '<div class="news-details-grid">'
      + '<div class="news-details-item"><span class="label">Title</span><span class="value">' + esc(formatNewsValue(item.title)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Event UID</span><span class="value">' + esc(formatNewsValue(item.event_uid)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Time (UTC)</span><span class="value">' + esc(formatNewsValue(item.time_utc)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Source</span><span class="value">' + esc(formatNewsValue(item.source)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Actual</span><span class="value">' + esc(formatNewsValue(item.actual)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Forecast</span><span class="value">' + esc(formatNewsValue(item.forecast)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Previous</span><span class="value">' + esc(formatNewsValue(item.previous)) + '</span></div>'
      + '<div class="news-details-item"><span class="label">Status</span><span class="value">' + esc(formatNewsValue(item.status)) + '</span></div>'
      + '</div>'
      + '</div>'
    );
  }

  function renderNewsTable() {
    if (!els.newsTableBody) return;
    var items = Array.isArray(state.newsItems) ? state.newsItems : [];
    var rows = [];
    for (var i = 0; i < items.length; i++) {
      var item = items[i] || {};
      var uid = hasValue(item.event_uid) ? String(item.event_uid) : ("row-" + i);
      var impact = getNewsImpactMeta(item.importance);
      var status = getNewsStatusMeta(item.status);
      var expanded = state.newsExpandedUid === uid;

      rows.push(
        '<tr class="news-row' + (expanded ? ' is-expanded' : '') + '" data-news-uid="' + esc(uid) + '">'
        + '<td class="news-time">' + esc(formatNewsTimeLocal(item.time_utc)) + '</td>'
        + '<td class="news-currency">' + esc(formatNewsValue(item.currency)) + '</td>'
        + '<td>' + esc(formatNewsValue(item.title)) + '</td>'
        + '<td><span class="badge ' + impact.cls + '">' + esc(impact.label) + '</span></td>'
        + '<td>' + esc(formatNewsValue(item.actual)) + '</td>'
        + '<td>' + esc(formatNewsValue(item.forecast)) + '</td>'
        + '<td>' + esc(formatNewsValue(item.previous)) + '</td>'
        + '<td><span class="badge ' + status.cls + '">' + esc(status.label) + '</span></td>'
        + '</tr>'
      );

      if (expanded) {
        rows.push('<tr class="news-details-row"><td colspan="8">' + buildNewsDetailsRowHtml(item) + '</td></tr>');
      }
    }

    els.newsTableBody.innerHTML = rows.join("");

    if (els.newsTableEmpty) {
      els.newsTableEmpty.classList.toggle("is-hidden", items.length > 0);
    }
    if (els.newsTableScroll) {
      els.newsTableScroll.classList.toggle("is-hidden", items.length === 0);
    }

    if (els.newsLoadMoreBtn) {
      var hasMore = items.length < Number(state.newsTotal || 0);
      els.newsLoadMoreBtn.classList.toggle("is-hidden", !hasMore);
      els.newsLoadMoreBtn.disabled = !!state.newsLoading;
    }
    if (els.newsCountInfo) {
      els.newsCountInfo.textContent = "Showing " + items.length + " / " + Number(state.newsTotal || 0);
    }
    renderNewsLastUpdated();
  }

  function refreshNewsHealth() {
    requestJson("GET", "/api/news/health", function (err, data) {
      if (!err && data && data.ok === true && hasValue(data.last_updated_at)) {
        state.newsLastUpdatedAt = data.last_updated_at;
      }
      renderNewsLastUpdated();
    });
  }

  function refreshNewsData(resetList) {
    if (state.newsLoading) return;
    var reset = resetList !== false;
    if (reset) {
      state.newsOffset = 0;
      state.newsItems = [];
      state.newsExpandedUid = null;
    }

    var offset = reset ? 0 : Number(state.newsOffset || 0);
    state.newsLoading = true;
    if (els.newsRefreshBtn) els.newsRefreshBtn.disabled = true;
    if (els.newsLoadMoreBtn) els.newsLoadMoreBtn.disabled = true;

    requestJson("GET", "/api/news" + buildNewsQuery(offset), function (err, data) {
      state.newsLoading = false;
      if (els.newsRefreshBtn) els.newsRefreshBtn.disabled = false;

      if (err || !data || data.ok !== true) {
        renderNewsTable();
        return;
      }

      var incoming = Array.isArray(data.items) ? data.items : [];
      if (reset) {
        state.newsItems = incoming.slice(0);
      } else {
        state.newsItems = mergeNewsItems(state.newsItems, incoming);
      }
      state.newsTotal = Number(data.total || 0);
      state.newsOffset = state.newsItems.length;
      state.newsLoadedOnce = true;

      if (hasValue(incoming[0] && incoming[0].updated_at)) {
        state.newsLastUpdatedAt = incoming[0].updated_at;
      }
      renderNewsTable();
      refreshNewsHealth();
    });
  }

  function loadMoreNews() {
    if (state.newsLoading) return;
    if (state.newsItems.length >= Number(state.newsTotal || 0)) return;
    refreshNewsData(false);
  }

  function findNewsRow(node) {
    while (node) {
      if (node.getAttribute && node.getAttribute("data-news-uid")) return node;
      node = node.parentNode;
    }
    return null;
  }

  var _apexCharts = { equity: null, drawdown: null, winHour: null, dist: null, dailyPl: null };
  var _analyticsLoaded = false;
  var _analyticsDataStale = true;
  var _analyticsLastFetchTs = 0;
  var _analyticsFetching = false;
  var _analyticsThrottleMs = 60000;
  var _analyticsThrottleTimer = null;
  var _analyticsLastResults = null;
  var _analyticsPendingFetch = false;
  var _analyticsPendingForceRecreate = false;

  var APEX_COMMON = {
    chart: {
      background: "transparent",
      toolbar: { show: false },
      fontFamily: "Segoe UI, Trebuchet MS, Helvetica Neue, Arial, sans-serif",
      animations: { enabled: true, easing: "easeinout", speed: 400 }
    },
    theme: { mode: "dark", palette: "palette1" },
    grid: {
      borderColor: "rgba(112,170,202,0.08)",
      strokeDashArray: 3,
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } }
    },
    stroke: { curve: "smooth", width: 2.5 },
    tooltip: {
      theme: "dark",
      style: { fontSize: "12px" }
    },
    xaxis: {
      labels: { style: { colors: "#6f8798", fontSize: "10px" } },
      axisBorder: { show: false },
      axisTicks: { show: false }
    },
    yaxis: {
      labels: { style: { colors: "#6f8798", fontSize: "10px" } }
    }
  };

  function pad2(n) {
    return n < 10 ? "0" + n : String(n);
  }

  function formatDateUtcYmd(d) {
    return d.getUTCFullYear() + "-" + pad2(d.getUTCMonth() + 1) + "-" + pad2(d.getUTCDate());
  }

  function normalizeRange(range) {
    if (!range) return null;
    var from = hasValue(range.from) ? String(range.from).trim() : "";
    var to = hasValue(range.to) ? String(range.to).trim() : "";
    if (!from && !to) return null;
    // If only one side is provided, keep it as-is (backend will treat missing side as open ended).
    if (from && to && from > to) {
      var tmp = from;
      from = to;
      to = tmp;
    }
    return { from: from || null, to: to || null };
  }

  function buildRangeQuery(range) {
    var r = normalizeRange(range);
    if (!r) return "";
    var parts = [];
    if (r.from) parts.push("from=" + encodeURIComponent(r.from));
    if (r.to) parts.push("to=" + encodeURIComponent(r.to));
    return parts.length ? "?" + parts.join("&") : "";
  }

  function defaultAnalyticsRangeLast7Utc() {
    var now = new Date();
    var today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    var start = new Date(today.getTime());
    start.setUTCDate(start.getUTCDate() - 6);
    return { from: formatDateUtcYmd(start), to: formatDateUtcYmd(today) };
  }

  function showAnalyticsEmpty(emptyEl, show, message) {
    if (!emptyEl) return;
    if (show && hasValue(message)) {
      emptyEl.textContent = String(message);
    }
    emptyEl.classList.toggle("is-hidden", !show);
  }

  function getAnalyticsNoTradesHint() {
    // If a filter is active, avoid "No trades yet" and clarify the scope.
    return normalizeRange(state.analyticsRange) ? "No closed trades in selected period" : null;
  }

  function destroyApexChart(key) {
    if (_apexCharts[key]) {
      try { _apexCharts[key].destroy(); } catch (e) {}
      _apexCharts[key] = null;
    }
  }

  /**
   * renderAnalytics: called ONLY when Analytics tab is activated.
   * If charts already exist and data is fresh, this is a no-op.
   */
  function renderAnalytics() {
    if (typeof ApexCharts === "undefined") return;
    if (state.activeTab !== "analytics") return;
    var now = Date.now();
    var chartsExist = _apexCharts.equity || _apexCharts.drawdown || _apexCharts.winHour || _apexCharts.dist || _apexCharts.dailyPl;
    if (chartsExist && !_analyticsDataStale && (now - _analyticsLastFetchTs < _analyticsThrottleMs)) {
      return;
    }
    fetchAnalyticsData(false);
  }

  /**
   * Force-refresh analytics (e.g. from refresh button).
   */
  function refreshAnalyticsManual() {
    _analyticsDataStale = true;
    fetchAnalyticsData(false);
  }

  function fetchAnalyticsData(forceRecreate) {
    if (_analyticsFetching) {
      _analyticsPendingFetch = true;
      if (forceRecreate) _analyticsPendingForceRecreate = true;
      return;
    }
    _analyticsFetching = true;
    var done = 0;
    var results = {};
    var endpoints = ["equity_curve", "drawdown", "winrate_by_hour", "winloss_distribution", "daily_pl"];
    var qs = buildRangeQuery(state.analyticsRange);
    for (var i = 0; i < endpoints.length; i++) {
      (function (ep) {
        requestJson("GET", "/api/stats/" + ep + qs, function (err, data) {
          results[ep] = err ? null : data;
          done++;
          if (done === 5) {
            _analyticsFetching = false;
            _analyticsLastFetchTs = Date.now();
            _analyticsDataStale = false;
            _analyticsLastResults = results;
            applyAnalyticsCharts(results, forceRecreate);
            if (_analyticsPendingFetch) {
              var pendingForce = _analyticsPendingForceRecreate;
              _analyticsPendingFetch = false;
              _analyticsPendingForceRecreate = false;
              setTimeout(function () {
                fetchAnalyticsData(pendingForce);
              }, 0);
            }
          }
        });
      })(endpoints[i]);
    }
  }

  function applyAnalyticsCharts(data, forceRecreate) {
    var isUpdate = _analyticsLoaded && !forceRecreate;
    renderEquityChart(data.equity_curve, isUpdate);
    renderDrawdownChart(data.drawdown, isUpdate);
    renderWinHourChart(data.winrate_by_hour, isUpdate);
    renderDistributionChart(data.winloss_distribution, isUpdate);
    renderDailyPlChart(data.daily_pl, isUpdate);
    _analyticsLoaded = true;
  }

  function startAnalyticsThrottle() {
    stopAnalyticsThrottle();
    _analyticsThrottleTimer = setInterval(function () {
      if (state.activeTab === "analytics" && _analyticsDataStale) {
        fetchAnalyticsData(false);
      }
    }, _analyticsThrottleMs);
  }

  function stopAnalyticsThrottle() {
    if (_analyticsThrottleTimer) {
      clearInterval(_analyticsThrottleTimer);
      _analyticsThrottleTimer = null;
    }
  }

  /* ── 1) Equity Curve ─────────────────────────────────────── */
  function buildEquityApexOpts(data, height, forModal) {
    var series = (data && data.series) || [];
    if (series.length < 2) return null;

    var categories = [];
    var equityData = [];
    for (var i = 0; i < series.length; i++) {
      categories.push(series[i].label || "");
      equityData.push(series[i].equity);
    }

    var xaxis = {
      categories: categories,
      tickAmount: Math.min(8, categories.length),
      labels: { rotate: -35, rotateAlways: false, style: { colors: "#6f8798", fontSize: "10px" } }
    };
    var seriesData = equityData;
    if (forModal) {
      // Modal uses numeric x so we can reliably drive pan/zoom with xaxis min/max.
      var labels = categories.slice(0);
      seriesData = [];
      for (var j = 0; j < equityData.length; j++) seriesData.push({ x: j, y: equityData[j] });
      xaxis = {
        type: "numeric",
        min: 0,
        max: Math.max(0, labels.length - 1),
        tickAmount: Math.min(8, labels.length),
        labels: {
          rotate: -35,
          rotateAlways: false,
          style: { colors: "#6f8798", fontSize: "10px" },
          formatter: function (v) {
            var idx = Math.round(Number(v));
            return labels[idx] || "";
          }
        }
      };
    }

    return mergeApexOpts({
      chart: { type: "area", height: height || 280 },
      series: [{ name: "Cumulative P/L", data: seriesData }],
      xaxis: xaxis,
      yaxis: {
        labels: {
          formatter: function (v) { return "€" + (v >= 0 ? "" : "") + v.toFixed(1); },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "\u20ac Profit", style: { color: "#6f8798", fontSize: "11px" } }
      },
      colors: ["#56b6ff"],
      fill: {
        type: "gradient",
        gradient: { shadeIntensity: 1, opacityFrom: 0.35, opacityTo: 0.05, stops: [0, 95, 100] }
      },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var pt = series[idx] || {};
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">' + esc(pt.label || "") + '</div>'
            + '<div><b>Trade P/L:</b> €' + (pt.profit >= 0 ? "+" : "") + pt.profit.toFixed(2) + '</div>'
            + '<div><b>Cumulative:</b> €' + (pt.equity >= 0 ? "+" : "") + pt.equity.toFixed(2) + '</div>'
            + '</div>';
        }
      },
      markers: { size: 0, hover: { size: 5 } }
    });
  }

  function createDrawdownChart(_targetEl, data, cfg) {
    cfg = cfg || {};
    var mode = cfg.mode === "expanded" ? "expanded" : "compact";
    var height = hasValue(cfg.height) ? Number(cfg.height) : null;
    if (!isFinite(height) || height <= 0) height = 280;
    var forModal = cfg.forModal === true;
    return buildDrawdownApexOpts(data, height, forModal, mode);
  }

  function buildDrawdownApexOpts(data, height, forModal, sizeMode) {
    var series = (data && data.series) || [];
    if (series.length < 2) return null;

    var maxDdIdx = (data && data.max_dd_idx) || 0;
    var maxDdAbs = (data && data.max_dd_abs) || 0;
    var maxDdPct = (data && data.max_dd_pct) || 0;

    var categories = [];
    var ddData = [];
    for (var i = 0; i < series.length; i++) {
      categories.push(series[i].label || "");
      ddData.push(-series[i].drawdown);
    }

    // chartSizeMode flag:
    // - "expanded" (modal): use external rail overlay (DOM) + right gutter space
    // - "compact"  (card): show top-right badge (HTML overlay), no in-plot marker/annotation
    var mode = String(sizeMode || (forModal ? "expanded" : "compact"));
    if (mode !== "expanded") mode = "compact";

    // No in-plot annotations in either mode; compact uses an HTML badge, expanded uses an external rail.
    var annotations = [];
    var pointAnnotations = [];

    var xaxis = {
      categories: categories,
      tickAmount: Math.min(8, categories.length),
      labels: { rotate: -35, rotateAlways: false, style: { colors: "#6f8798", fontSize: "10px" } }
    };
    var seriesData = ddData;
    if (forModal) {
      // Modal uses numeric x so we can reliably drive pan/zoom with xaxis min/max.
      var labels = categories.slice(0);
      seriesData = [];
      for (var j = 0; j < ddData.length; j++) seriesData.push({ x: j, y: ddData[j] });
      xaxis = {
        type: "numeric",
        min: 0,
        max: Math.max(0, labels.length - 1),
        tickAmount: Math.min(8, labels.length),
        labels: {
          rotate: -35,
          rotateAlways: false,
          style: { colors: "#6f8798", fontSize: "10px" },
          formatter: function (v) {
            var idx = Math.round(Number(v));
            return labels[idx] || "";
          }
        }
      };
    }

    return mergeApexOpts({
      chart: { type: "area", height: height || 280 },
      series: [{ name: "Drawdown", data: seriesData }],
      // Expanded mode reserves a right gutter for the external Max DD rail.
      grid: mode === "expanded"
        ? { padding: { top: 18, right: 120, bottom: 56, left: 18 } }
        : { padding: { top: 12, right: 18, bottom: 42, left: 18 } },
      xaxis: xaxis,
      yaxis: {
        labels: {
          formatter: function (v) { return "€" + v.toFixed(1); },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "€ Drawdown", style: { color: "#6f8798", fontSize: "11px" } },
        max: 0
      },
      colors: ["#ff6b6b"],
      fill: {
        type: "gradient",
        gradient: { shadeIntensity: 1, opacityFrom: 0.35, opacityTo: 0.05, stops: [0, 95, 100] }
      },
      annotations: {
        position: "front",
        xaxis: annotations,
        points: pointAnnotations
      },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var pt = series[idx] || {};
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">' + esc(pt.label || "") + '</div>'
            + '<div><b>Equity:</b> €' + pt.equity.toFixed(2) + '</div>'
            + '<div><b>Drawdown:</b> €' + pt.drawdown.toFixed(2) + ' (' + pt.drawdown_pct.toFixed(1) + '%)</div>'
            + '<div style="margin-top:4px;border-top:1px solid rgba(112,170,202,0.15);padding-top:4px;color:#9db3c4;font-size:11px">'
            + 'Max DD: €' + maxDdAbs.toFixed(2) + ' (' + maxDdPct.toFixed(1) + '%)</div>'
            + '</div>';
        }
      },
      // Disable marker dots; last-point overlap issues tend to come from markers/annotations.
      markers: { size: 0, hover: { size: 0 } }
    });
  }

  function buildWinHourApexOpts(data, height, forModal) {
    var hours = (data && data.hours) || [];
    var hasData = false;
    for (var i = 0; i < hours.length; i++) { if (hours[i].total > 0) { hasData = true; break; } }
    if (!hasData) return null;

    var MIN_TRADES = 3;
    var categories = [];
    var winRates = [];
    var barColors = [];
    var bestIdx = -1, bestRate = -1, worstIdx = -1, worstRate = 101;
    for (var j = 0; j < hours.length; j++) {
      var h = hours[j];
      categories.push(h.label);
      winRates.push(h.winrate);
      if (h.total >= MIN_TRADES) {
        if (h.winrate > bestRate) { bestRate = h.winrate; bestIdx = j; }
        if (h.winrate < worstRate) { worstRate = h.winrate; worstIdx = j; }
      }
    }
    for (var k = 0; k < hours.length; k++) {
      if (k === bestIdx) barColors.push("#2fd48a");
      else if (k === worstIdx) barColors.push("#ff6b6b");
      else barColors.push("rgba(86, 182, 255, 0.65)");
    }

    var pointAnnotations = [];
    if (bestIdx >= 0) {
      pointAnnotations.push({
        x: forModal ? bestIdx : categories[bestIdx],
        y: winRates[bestIdx],
        marker: { size: 0 },
        label: {
          text: "Best: " + bestRate.toFixed(0) + "%",
          borderColor: "#2fd48a",
          offsetY: -8,
          style: { color: "#fff", background: "#2fd48a", fontSize: "10px", padding: { left: 5, right: 5, top: 2, bottom: 2 } }
        }
      });
    }
    if (worstIdx >= 0) {
      pointAnnotations.push({
        x: forModal ? worstIdx : categories[worstIdx],
        y: winRates[worstIdx],
        marker: { size: 0 },
        label: {
          text: "Worst: " + worstRate.toFixed(0) + "%",
          borderColor: "#ff6b6b",
          offsetY: -8,
          style: { color: "#fff", background: "#ff6b6b", fontSize: "10px", padding: { left: 5, right: 5, top: 2, bottom: 2 } }
        }
      });
    }

    var xaxis = {
      categories: categories,
      labels: { rotate: -45, rotateAlways: true, style: { colors: "#6f8798", fontSize: "9px" } },
      title: { text: "Hour (UTC)", style: { color: "#6f8798", fontSize: "11px" } }
    };
    var seriesData = winRates;
    if (forModal) {
      var labels = categories.slice(0);
      seriesData = [];
      for (var m = 0; m < winRates.length; m++) seriesData.push({ x: m, y: winRates[m] });
      xaxis = {
        type: "numeric",
        min: 0,
        max: Math.max(0, labels.length - 1),
        tickAmount: Math.min(12, labels.length),
        labels: {
          rotate: -45,
          rotateAlways: true,
          style: { colors: "#6f8798", fontSize: "9px" },
          formatter: function (v) {
            var idx = Math.round(Number(v));
            return labels[idx] || "";
          }
        },
        title: { text: "Hour (UTC)", style: { color: "#6f8798", fontSize: "11px" } }
      };
    }

    return mergeApexOpts({
      chart: { type: "bar", height: height || 280 },
      series: [{ name: "Win Rate", data: seriesData }],
      plotOptions: {
        bar: {
          borderRadius: 4,
          columnWidth: "60%",
          distributed: true
        }
      },
      colors: barColors,
      legend: { show: false },
      xaxis: xaxis,
      yaxis: {
        min: 0,
        max: 100,
        tickAmount: 5,
        labels: {
          formatter: function (v) { return v.toFixed(0) + "%"; },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "Win Rate %", style: { color: "#6f8798", fontSize: "11px" } }
      },
      annotations: { points: pointAnnotations },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var h = hours[idx] || {};
          var badge = "";
          if (idx === bestIdx) badge = '<span style="color:#2fd48a;font-weight:bold"> ★ Best</span>';
          if (idx === worstIdx) badge = '<span style="color:#ff6b6b;font-weight:bold"> ★ Worst</span>';
          var noTrades = h.total === 0;
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">Hour: ' + esc(h.label || "") + badge + '</div>'
            + (noTrades
              ? '<div style="color:#6f8798">No trades in this hour</div>'
              : '<div><b>Win Rate:</b> ' + h.winrate.toFixed(1) + '%</div>'
                + '<div><b>Wins / Total:</b> ' + h.wins + ' / ' + h.total + '</div>'
                + (h.total < MIN_TRADES ? '<div style="color:#f3b65e;font-size:11px">⚠ Low sample (&lt;' + MIN_TRADES + ' trades)</div>' : ''))
            + '</div>';
        }
      }
    });
  }

  function buildDistributionApexOpts(data, height, forModal) {
    var bins = (data && data.bins) || [];
    var totalTrades = (data && data.total) || 0;
    if (!bins.length || totalTrades < 1) return null;

    var categories = [];
    var winCounts = [];
    var lossCounts = [];
    for (var i = 0; i < bins.length; i++) {
      categories.push(bins[i].range);
      winCounts.push(bins[i].wins);
      lossCounts.push(bins[i].losses);
    }

    var xaxis = {
      categories: categories,
      labels: { rotate: -40, rotateAlways: true, style: { colors: "#6f8798", fontSize: "9px" } },
      title: { text: "Profit Range (€)", style: { color: "#6f8798", fontSize: "11px" } }
    };
    var winsData = winCounts;
    var lossData = lossCounts;
    if (forModal) {
      // Modal uses numeric x so we can reliably drive pan/zoom with xaxis min/max.
      var labels = categories.slice(0);
      winsData = [];
      lossData = [];
      for (var j = 0; j < labels.length; j++) {
        winsData.push({ x: j, y: winCounts[j] });
        lossData.push({ x: j, y: lossCounts[j] });
      }
      xaxis = {
        type: "numeric",
        min: 0,
        max: Math.max(0, labels.length - 1),
        tickAmount: Math.min(10, labels.length),
        labels: {
          rotate: -40,
          rotateAlways: true,
          style: { colors: "#6f8798", fontSize: "9px" },
          formatter: function (v) {
            var idx = Math.round(Number(v));
            return labels[idx] || "";
          }
        },
        title: { text: "Profit Range (€)", style: { color: "#6f8798", fontSize: "11px" } }
      };
    }

    return mergeApexOpts({
      chart: { type: "bar", height: height || 280, stacked: true },
      series: [
        { name: "Wins", data: winsData },
        { name: "Losses", data: lossData }
      ],
      plotOptions: {
        bar: { borderRadius: 3, columnWidth: "65%" }
      },
      colors: ["#2fd48a", "#ff6b6b"],
      xaxis: xaxis,
      yaxis: {
        labels: {
          formatter: function (v) { return Math.round(v).toString(); },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "Trade Count", style: { color: "#6f8798", fontSize: "11px" } }
      },
      legend: {
        position: "top",
        horizontalAlign: "right",
        labels: { colors: "#9db3c4" },
        fontSize: "11px",
        markers: { width: 10, height: 10, radius: 3 }
      },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var b = bins[idx] || {};
          var pct = totalTrades > 0 ? ((b.total / totalTrades) * 100).toFixed(1) : "0";
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">Range: €' + esc(b.range || "") + '</div>'
            + '<div style="color:#2fd48a"><b>Wins:</b> ' + b.wins + '</div>'
            + '<div style="color:#ff6b6b"><b>Losses:</b> ' + b.losses + '</div>'
            + '<div><b>Total:</b> ' + b.total + ' (' + pct + '% of all trades)</div>'
            + '</div>';
        }
      }
    });
  }

  function buildDailyPlApexOpts(data, height, targetEl, forModal) {
    var days = (data && data.days) || [];
    if (!days.length) return null;

    function computeDailyBarLayout(count, targetEl) {
      // ApexCharts `columnWidth` is percentage of category width; when count is small, categories are huge.
      // Convert a max bar px constraint into a bounded percentage for stable visuals.
      var w = 900;
      try {
        if (targetEl && targetEl.clientWidth && targetEl.clientWidth > 0) w = targetEl.clientWidth;
      } catch (e) {}

      var perCat = w / Math.max(1, count);
      var MAX_BAR_PX = 54;
      var MIN_BAR_PX = 22;

      // Prefer a fixed-ish px cap, but avoid overly thin bars on smaller containers.
      var desiredPx = MAX_BAR_PX;
      if (perCat * 0.6 < desiredPx) desiredPx = perCat * 0.6;
      if (desiredPx < MIN_BAR_PX) desiredPx = MIN_BAR_PX;

      var pct = (desiredPx / perCat) * 100;
      if (!isFinite(pct) || pct <= 0) pct = 60;
      if (pct < 10) pct = 10;
      if (pct > 70) pct = 70;

      var pad = 0;
      if (count < 5) {
        // Extra breathing room so 1-4 bars don't look like they "float" edge-to-edge.
        // 1 -> 140, 2 -> 120, 3 -> 100, 4 -> 80
        pad = 60 + (5 - count) * 20;
      }

      return { columnWidth: Math.round(pct) + "%", paddingLR: pad };
    }

    var categories = [];
    var pl = [];
    for (var i = 0; i < days.length; i++) {
      categories.push(days[i].label || days[i].day || "");
      pl.push(days[i].profit || 0);
    }

    var layout = computeDailyBarLayout(days.length, targetEl || null);

    var xaxis = {
      categories: categories,
      tickAmount: Math.min(10, categories.length),
      labels: { rotate: -35, rotateAlways: false, style: { colors: "#6f8798", fontSize: "10px" } },
      title: { text: "Day (UTC)", style: { color: "#6f8798", fontSize: "11px" } }
    };
    var seriesData = pl;
    if (forModal) {
      // Modal uses numeric x so we can reliably drive pan/zoom with xaxis min/max.
      var labels = categories.slice(0);
      seriesData = [];
      for (var j = 0; j < pl.length; j++) seriesData.push({ x: j, y: pl[j] });
      xaxis = {
        type: "numeric",
        min: 0,
        max: Math.max(0, labels.length - 1),
        tickAmount: Math.min(10, labels.length),
        labels: {
          rotate: -35,
          rotateAlways: false,
          style: { colors: "#6f8798", fontSize: "10px" },
          formatter: function (v) {
            var idx = Math.round(Number(v));
            return labels[idx] || "";
          }
        },
        title: { text: "Day (UTC)", style: { color: "#6f8798", fontSize: "11px" } }
      };
    }

    return mergeApexOpts({
      chart: { type: "bar", height: height || 280 },
      series: [{ name: "Daily P/L", data: seriesData }],
      plotOptions: { bar: { borderRadius: 4, columnWidth: layout.columnWidth } },
      colors: ["rgba(86, 182, 255, 0.75)"],
      grid: { padding: { left: layout.paddingLR, right: layout.paddingLR } },
      xaxis: xaxis,
      yaxis: {
        labels: {
          formatter: function (v) { return "€" + v.toFixed(1); },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "€ Profit", style: { color: "#6f8798", fontSize: "11px" } }
      },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var d = days[idx] || {};
          var p = Number(d.profit || 0);
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">Day: ' + esc(d.day || d.label || "") + '</div>'
            + '<div><b>Total P/L:</b> €' + (p >= 0 ? "+" : "") + p.toFixed(2) + '</div>'
            + (hasValue(d.trades) ? '<div><b>Trades:</b> ' + d.trades + '</div>' : '')
            + '</div>';
        }
      }
    });
  }

  function renderEquityChart(data, isUpdate) {
    var el = els.apexEquityChart;
    var emptyEl = els.analyticsEquityEmpty;
    if (!el) return;
    var series = (data && data.series) || [];
    if (series.length < 2) {
      destroyApexChart("equity");
      showAnalyticsEmpty(emptyEl, true, getAnalyticsNoTradesHint());
      return;
    }
    showAnalyticsEmpty(emptyEl, false);

    var categories = [];
    var equityData = [];
    for (var i = 0; i < series.length; i++) {
      categories.push(series[i].label || "");
      equityData.push(series[i].equity);
    }

    /* Fast path: chart exists, only push new data */
    if (isUpdate && _apexCharts.equity) {
      _apexCharts.equity.updateSeries([{ data: equityData }], true);
      return;
    }

    var opts = mergeApexOpts({
      chart: { type: "area", height: 280 },
      series: [{ name: "Cumulative P/L", data: equityData }],
      xaxis: {
        categories: categories,
        tickAmount: Math.min(8, categories.length),
        labels: { rotate: -35, rotateAlways: false, style: { colors: "#6f8798", fontSize: "10px" } }
      },
      yaxis: {
        labels: {
          formatter: function (v) { return "€" + (v >= 0 ? "" : "") + v.toFixed(1); },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "€ Profit", style: { color: "#6f8798", fontSize: "11px" } }
      },
      colors: ["#56b6ff"],
      fill: {
        type: "gradient",
        gradient: { shadeIntensity: 1, opacityFrom: 0.35, opacityTo: 0.05, stops: [0, 95, 100] }
      },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var pt = series[idx] || {};
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">' + esc(pt.label || "") + '</div>'
            + '<div><b>Trade P/L:</b> €' + (pt.profit >= 0 ? "+" : "") + pt.profit.toFixed(2) + '</div>'
            + '<div><b>Cumulative:</b> €' + (pt.equity >= 0 ? "+" : "") + pt.equity.toFixed(2) + '</div>'
            + '</div>';
        }
      },
      markers: { size: 0, hover: { size: 5 } }
    });

    if (_apexCharts.equity) {
      _apexCharts.equity.updateOptions(opts, false, false);
    } else {
      _apexCharts.equity = new ApexCharts(el, opts);
      _apexCharts.equity.render();
    }
  }

  /* ── 2) Drawdown ─────────────────────────────────────────── */
  function renderDrawdownChart(data, isUpdate) {
    var el = els.apexDrawdownChart;
    var emptyEl = els.analyticsDrawdownEmpty;
    if (!el) return;
    var series = (data && data.series) || [];
    if (series.length < 2) {
      destroyApexChart("drawdown");
      showAnalyticsEmpty(emptyEl, true, getAnalyticsNoTradesHint());
      if (els.ddMaxBadge) els.ddMaxBadge.classList.add("is-hidden");
      return;
    }
    showAnalyticsEmpty(emptyEl, false);

    var maxDdAbs = (data && data.max_dd_abs) || 0;
    var maxDdPct = (data && data.max_dd_pct) || 0;
    if (els.ddMaxBadge) {
      var badgeText = maxDdAbs > 0
        ? ("Max DD: \u20ac" + Number(maxDdAbs).toFixed(2) + " (" + Number(maxDdPct).toFixed(1) + "%)")
        : "";
      if (badgeText) {
        els.ddMaxBadge.textContent = badgeText;
        els.ddMaxBadge.classList.remove("is-hidden");
      } else {
        els.ddMaxBadge.classList.add("is-hidden");
      }
    }

    // Small card view always uses compact mode (no in-plot MaxDD marker).
    var opts = createDrawdownChart(el, data, { mode: "compact", height: 280, forModal: false });
    if (!opts) return;

    /* Fast path: chart exists, only push new data */
    if (isUpdate && _apexCharts.drawdown) {
      _apexCharts.drawdown.updateSeries(opts.series, true);
      return;
    }

    if (_apexCharts.drawdown) {
      _apexCharts.drawdown.updateOptions(opts, false, false);
    } else {
      _apexCharts.drawdown = new ApexCharts(el, opts);
      _apexCharts.drawdown.render();
    }
  }

  /* ── 3) Win Rate by Hour ─────────────────────────────────── */
  function renderWinHourChart(data, isUpdate) {
    var el = els.apexWinHourChart;
    var emptyEl = els.analyticsWinHourEmpty;
    if (!el) return;
    var hours = (data && data.hours) || [];
    var hasData = false;
    for (var i = 0; i < hours.length; i++) { if (hours[i].total > 0) { hasData = true; break; } }
    if (!hasData) {
      destroyApexChart("winHour");
      showAnalyticsEmpty(emptyEl, true, getAnalyticsNoTradesHint());
      return;
    }
    showAnalyticsEmpty(emptyEl, false);

    var MIN_TRADES = 3;
    var categories = [];
    var winRates = [];
    var barColors = [];
    var bestIdx = -1, bestRate = -1, worstIdx = -1, worstRate = 101;
    for (var j = 0; j < hours.length; j++) {
      var h = hours[j];
      categories.push(h.label);
      winRates.push(h.winrate);
      if (h.total >= MIN_TRADES) {
        if (h.winrate > bestRate) { bestRate = h.winrate; bestIdx = j; }
        if (h.winrate < worstRate) { worstRate = h.winrate; worstIdx = j; }
      }
    }
    for (var k = 0; k < hours.length; k++) {
      if (k === bestIdx) barColors.push("#2fd48a");
      else if (k === worstIdx) barColors.push("#ff6b6b");
      else barColors.push("rgba(86, 182, 255, 0.65)");
    }

    /* Fast path: chart exists, only push new data */
    if (isUpdate && _apexCharts.winHour) {
      _apexCharts.winHour.updateSeries([{ data: winRates }], true);
      return;
    }

    var pointAnnotations = [];
    if (bestIdx >= 0) {
      pointAnnotations.push({
        x: categories[bestIdx],
        y: winRates[bestIdx],
        marker: { size: 0 },
        label: {
          text: "Best: " + bestRate.toFixed(0) + "%",
          borderColor: "#2fd48a",
          offsetY: -8,
          style: { color: "#fff", background: "#2fd48a", fontSize: "10px", padding: { left: 5, right: 5, top: 2, bottom: 2 } }
        }
      });
    }
    if (worstIdx >= 0) {
      pointAnnotations.push({
        x: categories[worstIdx],
        y: winRates[worstIdx],
        marker: { size: 0 },
        label: {
          text: "Worst: " + worstRate.toFixed(0) + "%",
          borderColor: "#ff6b6b",
          offsetY: -8,
          style: { color: "#fff", background: "#ff6b6b", fontSize: "10px", padding: { left: 5, right: 5, top: 2, bottom: 2 } }
        }
      });
    }

    var opts = mergeApexOpts({
      chart: { type: "bar", height: 280 },
      series: [{ name: "Win Rate", data: winRates }],
      plotOptions: {
        bar: {
          borderRadius: 4,
          columnWidth: "60%",
          distributed: true
        }
      },
      colors: barColors,
      legend: { show: false },
      xaxis: {
        categories: categories,
        labels: { rotate: -45, rotateAlways: true, style: { colors: "#6f8798", fontSize: "9px" } },
        title: { text: "Hour (UTC)", style: { color: "#6f8798", fontSize: "11px" } }
      },
      yaxis: {
        min: 0,
        max: 100,
        tickAmount: 5,
        labels: {
          formatter: function (v) { return v.toFixed(0) + "%"; },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "Win Rate %", style: { color: "#6f8798", fontSize: "11px" } }
      },
      annotations: { points: pointAnnotations },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var h = hours[idx] || {};
          var badge = "";
          if (idx === bestIdx) badge = '<span style="color:#2fd48a;font-weight:bold"> ★ Best</span>';
          if (idx === worstIdx) badge = '<span style="color:#ff6b6b;font-weight:bold"> ★ Worst</span>';
          var noTrades = h.total === 0;
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">Hour: ' + esc(h.label || "") + badge + '</div>'
            + (noTrades
              ? '<div style="color:#6f8798">No trades in this hour</div>'
              : '<div><b>Win Rate:</b> ' + h.winrate.toFixed(1) + '%</div>'
                + '<div><b>Wins / Total:</b> ' + h.wins + ' / ' + h.total + '</div>'
                + (h.total < MIN_TRADES ? '<div style="color:#f3b65e;font-size:11px">⚠ Low sample (&lt;' + MIN_TRADES + ' trades)</div>' : ''))
            + '</div>';
        }
      }
    });

    if (_apexCharts.winHour) {
      _apexCharts.winHour.updateOptions(opts, false, false);
    } else {
      _apexCharts.winHour = new ApexCharts(el, opts);
      _apexCharts.winHour.render();
    }
  }

  /* ── 4) Win/Loss Distribution ────────────────────────────── */
  function renderDistributionChart(data, isUpdate) {
    var el = els.apexDistChart;
    var emptyEl = els.analyticsHistogramEmpty;
    if (!el) return;
    var bins = (data && data.bins) || [];
    var totalTrades = (data && data.total) || 0;
    if (!bins.length || totalTrades < 1) {
      destroyApexChart("dist");
      showAnalyticsEmpty(emptyEl, true, getAnalyticsNoTradesHint());
      if (els.analyticsHistogramNote) els.analyticsHistogramNote.classList.add("is-hidden");
      return;
    }
    showAnalyticsEmpty(emptyEl, false);

    if (els.analyticsHistogramNote) {
      var sparse = totalTrades > 0 && totalTrades < 10;
      els.analyticsHistogramNote.classList.toggle("is-hidden", !sparse);
    }

    var categories = [];
    var winCounts = [];
    var lossCounts = [];
    for (var i = 0; i < bins.length; i++) {
      categories.push(bins[i].range);
      winCounts.push(bins[i].wins);
      lossCounts.push(bins[i].losses);
    }

    /* Fast path: chart exists, only push new data */
    if (isUpdate && _apexCharts.dist) {
      _apexCharts.dist.updateSeries([
        { data: winCounts },
        { data: lossCounts }
      ], true);
      return;
    }

    var opts = mergeApexOpts({
      chart: { type: "bar", height: 280, stacked: true },
      series: [
        { name: "Wins", data: winCounts },
        { name: "Losses", data: lossCounts }
      ],
      plotOptions: {
        bar: { borderRadius: 3, columnWidth: "65%" }
      },
      colors: ["#2fd48a", "#ff6b6b"],
      xaxis: {
        categories: categories,
        labels: { rotate: -40, rotateAlways: true, style: { colors: "#6f8798", fontSize: "9px" } },
        title: { text: "Profit Range (€)", style: { color: "#6f8798", fontSize: "11px" } }
      },
      yaxis: {
        labels: {
          formatter: function (v) { return Math.round(v).toString(); },
          style: { colors: "#6f8798", fontSize: "10px" }
        },
        title: { text: "Trade Count", style: { color: "#6f8798", fontSize: "11px" } }
      },
      legend: {
        position: "top",
        horizontalAlign: "right",
        labels: { colors: "#9db3c4" },
        fontSize: "11px",
        markers: { width: 10, height: 10, radius: 3 }
      },
      tooltip: {
        custom: function (_ref) {
          var idx = _ref.dataPointIndex;
          var b = bins[idx] || {};
          var pct = totalTrades > 0 ? ((b.total / totalTrades) * 100).toFixed(1) : "0";
          return '<div style="padding:8px 12px;font-size:12px;line-height:1.6">'
            + '<div style="color:#9db3c4;font-size:11px">Range: €' + esc(b.range || "") + '</div>'
            + '<div style="color:#2fd48a"><b>Wins:</b> ' + b.wins + '</div>'
            + '<div style="color:#ff6b6b"><b>Losses:</b> ' + b.losses + '</div>'
            + '<div><b>Total:</b> ' + b.total + ' (' + pct + '% of all trades)</div>'
            + '</div>';
        }
      }
    });

    if (_apexCharts.dist) {
      _apexCharts.dist.updateOptions(opts, false, false);
    } else {
      _apexCharts.dist = new ApexCharts(el, opts);
      _apexCharts.dist.render();
    }
  }

  /* â”€â”€ 5) Daily P/L â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
  function renderDailyPlChart(data, isUpdate) {
    var el = els.apexDailyPlChart;
    var emptyEl = els.analyticsDailyPlEmpty;
    if (!el) return;

    var opts = buildDailyPlApexOpts(data, 280, el, false);
    if (!opts) {
      destroyApexChart("dailyPl");
      showAnalyticsEmpty(emptyEl, true, getAnalyticsNoTradesHint());
      return;
    }
    showAnalyticsEmpty(emptyEl, false);

    if (isUpdate && _apexCharts.dailyPl) {
      _apexCharts.dailyPl.updateOptions(opts, false, false);
      _apexCharts.dailyPl.updateSeries(opts.series, true);
      return;
    }

    if (_apexCharts.dailyPl) {
      _apexCharts.dailyPl.updateOptions(opts, false, false);
      return;
    }
    _apexCharts.dailyPl = new ApexCharts(el, opts);
    _apexCharts.dailyPl.render();
  }

  function mergeApexOpts(custom) {
    var merged = {};
    var keys = Object.keys(APEX_COMMON);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (typeof APEX_COMMON[k] === "object" && !Array.isArray(APEX_COMMON[k]) && custom[k] && typeof custom[k] === "object" && !Array.isArray(custom[k])) {
        merged[k] = {};
        var subKeys = Object.keys(APEX_COMMON[k]);
        for (var j = 0; j < subKeys.length; j++) merged[k][subKeys[j]] = APEX_COMMON[k][subKeys[j]];
        var cKeys = Object.keys(custom[k]);
        for (var m = 0; m < cKeys.length; m++) merged[k][cKeys[m]] = custom[k][cKeys[m]];
      } else {
        merged[k] = custom[k] !== undefined ? custom[k] : APEX_COMMON[k];
      }
    }
    var extraKeys = Object.keys(custom);
    for (var n = 0; n < extraKeys.length; n++) {
      if (merged[extraKeys[n]] === undefined) merged[extraKeys[n]] = custom[extraKeys[n]];
    }
    return merged;
  }

  // Chart registry for modal rendering.
  var charts = new Map(); // key: chart key, value: { title, getDataFn(range, cb), buildOptsFn(data) }

  var _chartModalActiveKey = null;
  var _chartModalApex = null;
  var _chartModalDebounceTimer = null;
  var _chartModalReqToken = 0;
  var _chartModalCloseTimer = null;
  var _chartModalInteractive = null;
  var _chartModalDrawdownRail = null;
  var _chartModalDrawdownRailMeta = null;
  var _chartModalResizeTimer = null;

  function destroyChartModalInteractivity() {
    if (_chartModalInteractive && _chartModalInteractive.destroy) {
      try { _chartModalInteractive.destroy(); } catch (e) {}
    }
    _chartModalInteractive = null;
  }

  function destroyChartModalRail() {
    _chartModalDrawdownRailMeta = null;
    if (_chartModalDrawdownRail && _chartModalDrawdownRail.parentNode) {
      try { _chartModalDrawdownRail.parentNode.removeChild(_chartModalDrawdownRail); } catch (e) {}
    }
    _chartModalDrawdownRail = null;
    // Remove compact fallback badge if present.
    if (els.chartModalChart) {
      var b = els.chartModalChart.querySelector(".chart-badge.chart-badge-modal[data-dd-badge='1']");
      if (b && b.parentNode) {
        try { b.parentNode.removeChild(b); } catch (e2) {}
      }
    }
  }

  function ensureDrawdownRail(container) {
    if (_chartModalDrawdownRail && _chartModalDrawdownRail.parentNode === container) return _chartModalDrawdownRail;
    destroyChartModalRail();
    if (!container) return null;
    var rail = document.createElement("div");
    rail.className = "dd-rail";
    rail.innerHTML = '<div class="dd-rail-line"></div><div class="dd-rail-pill"><span class="dd-rail-text"></span></div>';
    container.appendChild(rail);
    _chartModalDrawdownRail = rail;
    return rail;
  }

  function ensureDrawdownModalBadge(container) {
    if (!container) return null;
    var existing = container.querySelector(".chart-badge.chart-badge-modal[data-dd-badge='1']");
    if (existing) return existing;
    var b = document.createElement("div");
    b.className = "chart-badge chart-badge-modal is-hidden";
    b.setAttribute("data-dd-badge", "1");
    container.appendChild(b);
    return b;
  }

  function computeApexPlotBox(chartInstance, fallbackEl) {
    var g = chartInstance && chartInstance.w && chartInstance.w.globals ? chartInstance.w.globals : null;
    if (g && isFinite(g.translateX) && isFinite(g.translateY) && isFinite(g.gridWidth) && isFinite(g.gridHeight)) {
      return { left: g.translateX, top: g.translateY, width: g.gridWidth, height: g.gridHeight };
    }
    // Fallback: approximate full container.
    var w = 800, h = 520;
    try {
      if (fallbackEl && fallbackEl.clientWidth) w = fallbackEl.clientWidth;
      if (fallbackEl && fallbackEl.clientHeight) h = fallbackEl.clientHeight;
    } catch (e) {}
    return { left: 0, top: 0, width: w, height: h };
  }

  function syncDrawdownRail() {
    if (_chartModalActiveKey !== "drawdown") return;
    if (!_chartModalApex || !_chartModalDrawdownRailMeta || !els.chartModalChart) return;
    var meta = _chartModalDrawdownRailMeta;

    var plot = computeApexPlotBox(_chartModalApex, els.chartModalChart);
    var wantCompact = meta && String(meta.mode || "") === "compact";
    var hasSpaceForRail = !wantCompact && (plot && isFinite(plot.width) ? plot.width >= 520 : true);

    var badge = ensureDrawdownModalBadge(els.chartModalChart);
    if (badge) {
      badge.textContent = meta.text || "";
      badge.classList.toggle("is-hidden", hasSpaceForRail);
    }

    if (!hasSpaceForRail) {
      if (_chartModalDrawdownRail) _chartModalDrawdownRail.style.display = "none";
      return;
    }

    var rail = ensureDrawdownRail(els.chartModalChart);
    if (!rail) return;
    rail.style.display = "";

    rail.style.top = Math.max(0, plot.top) + "px";
    rail.style.height = Math.max(0, plot.height) + "px";

    // Position pill by Y value (align with max DD point).
    var g = _chartModalApex.w && _chartModalApex.w.globals ? _chartModalApex.w.globals : null;
    var minY = g && isFinite(g.minY) ? g.minY : null;
    var maxY = g && isFinite(g.maxY) ? g.maxY : null;

    var pill = rail.querySelector(".dd-rail-pill");
    var textEl = rail.querySelector(".dd-rail-text");
    if (textEl) textEl.textContent = meta.text || "";

    if (!pill || minY === null || maxY === null || maxY === minY) return;
    var y = meta.yValue;
    var t = (maxY - y) / (maxY - minY);
    if (!isFinite(t)) t = 0.5;
    t = Math.max(0, Math.min(1, t));

    var yPx = plot.top + t * plot.height;
    var pillH = 128;
    var top = yPx - pillH / 2;
    var minTop = plot.top + 6;
    var maxTop = plot.top + plot.height - pillH - 6;
    if (top < minTop) top = minTop;
    if (top > maxTop) top = maxTop;
    pill.style.top = Math.round(top - plot.top) + "px";
  }

  function makeChartInteractive(chartInstance, opts) {
    opts = opts || {};
    var enable = opts.enablePanZoom === true;
    var el = chartInstance && chartInstance.el ? chartInstance.el : null;
    if (!el) return { reset: function () {}, destroy: function () {} };

    // Only in expanded (modal) mode.
    if (!enable) return { reset: function () {}, destroy: function () {} };

    var initialXaxis = null;
    var initialYaxis = null;
    try {
      initialXaxis = JSON.parse(JSON.stringify(chartInstance.w && chartInstance.w.config && chartInstance.w.config.xaxis ? chartInstance.w.config.xaxis : {}));
      initialYaxis = JSON.parse(JSON.stringify(chartInstance.w && chartInstance.w.config && chartInstance.w.config.yaxis ? chartInstance.w.config.yaxis : {}));
    } catch (e) {
      initialXaxis = chartInstance.w && chartInstance.w.config ? chartInstance.w.config.xaxis : {};
      initialYaxis = chartInstance.w && chartInstance.w.config ? chartInstance.w.config.yaxis : {};
    }

    function getSeriesMinMaxY() {
      var min = null, max = null;
      var s = (chartInstance.w && chartInstance.w.config && chartInstance.w.config.series) || [];
      for (var i = 0; i < s.length; i++) {
        var data = (s[i] && s[i].data) || [];
        for (var j = 0; j < data.length; j++) {
          var v = data[j];
          var y = null;
          if (typeof v === "number") y = v;
          else if (v && typeof v === "object" && hasValue(v.y)) y = Number(v.y);
          if (y === null || isNaN(y) || !isFinite(y)) continue;
          if (min === null || y < min) min = y;
          if (max === null || y > max) max = y;
        }
      }
      if (min === null || max === null) return { min: null, max: null };
      if (min === max) {
        min -= 1;
        max += 1;
      }
      // Add a bit of padding so chips/markers stay inside.
      var pad = (max - min) * 0.06;
      return { min: min - pad, max: max + pad };
    }

    function getCurrentXMinMax() {
      var g = chartInstance.w && chartInstance.w.globals;
      var minX = g && typeof g.minX === "number" && isFinite(g.minX) ? g.minX : null;
      var maxX = g && typeof g.maxX === "number" && isFinite(g.maxX) ? g.maxX : null;
      if (minX !== null && maxX !== null) return { min: minX, max: maxX };
      // Fallback: try numeric index range.
      var labels = (g && g.labels) || [];
      if (labels && labels.length) return { min: 0, max: labels.length - 1 };
      return { min: null, max: null };
    }

    var baseY = getSeriesMinMaxY();
    var baseX = getCurrentXMinMax();
    if (baseX.min === null || baseX.max === null) {
      // Can't drive zoom without a working x-range; still allow y pan/zoom.
      baseX = { min: 0, max: 1 };
    }

    var isDragging = false;
    var dragStart = null;
    var cursorDown = "grabbing";
    var cursorUp = "grab";

    // rAF throttle: Apex updateOptions is expensive; we only want 1 update per frame.
    var rafPending = false;
    var pendingView = null;

    function flushView() {
      rafPending = false;
      if (!pendingView) return;
      var next = pendingView;
      pendingView = null;
      try {
        chartInstance.updateOptions(next, false, false, false);
      } catch (e) {}
      if (opts.onAfterView) {
        try { opts.onAfterView(); } catch (e2) {}
      }
    }

    function scheduleView(xMin, xMax, yMin, yMax) {
      var next = {};
      if (typeof xMin === "number" && typeof xMax === "number") next.xaxis = { min: xMin, max: xMax };
      if (typeof yMin === "number" && typeof yMax === "number") next.yaxis = { min: yMin, max: yMax };
      pendingView = next;
      if (rafPending) return;
      rafPending = true;
      requestAnimationFrame(flushView);
    }

    function reset() {
      try {
        chartInstance.updateOptions({ xaxis: initialXaxis || {}, yaxis: initialYaxis || {} }, false, false);
      } catch (e) {}
    }

    function clamp(v, lo, hi) {
      return Math.max(lo, Math.min(hi, v));
    }

    function onWheel(ev) {
      if (!isChartModalOpen()) return;
      ev.preventDefault();
      ev.stopPropagation();

      var rect = el.getBoundingClientRect();
      var fx = rect.width > 0 ? (ev.clientX - rect.left) / rect.width : 0.5;
      var fy = rect.height > 0 ? (ev.clientY - rect.top) / rect.height : 0.5;
      fx = clamp(fx, 0, 1);
      fy = clamp(fy, 0, 1);

      var curX = getCurrentXMinMax();
      if (curX.min === null || curX.max === null) curX = baseX;
      var xRange = Math.max(1e-6, curX.max - curX.min);

      var curYMin = null, curYMax = null;
      var g = chartInstance.w && chartInstance.w.globals;
      if (g && typeof g.minY === "number" && typeof g.maxY === "number" && isFinite(g.minY) && isFinite(g.maxY)) {
        curYMin = g.minY;
        curYMax = g.maxY;
      } else if (baseY.min !== null && baseY.max !== null) {
        curYMin = baseY.min;
        curYMax = baseY.max;
      }
      var yRange = curYMin !== null && curYMax !== null ? Math.max(1e-6, curYMax - curYMin) : null;

      var zoomIn = (ev.deltaY || 0) < 0;
      var factor = zoomIn ? 0.84 : 1.19;

      var cx = curX.min + fx * xRange;
      var newXRange = xRange * factor;
      var newXMin = cx - fx * newXRange;
      var newXMax = newXMin + newXRange;

      // Clamp to base x-range.
      var baseMin = baseX.min, baseMax = baseX.max;
      if (newXMin < baseMin) { newXMax += (baseMin - newXMin); newXMin = baseMin; }
      if (newXMax > baseMax) { newXMin -= (newXMax - baseMax); newXMax = baseMax; }
      newXMin = clamp(newXMin, baseMin, baseMax);
      newXMax = clamp(newXMax, baseMin, baseMax);

      var newYMin = null, newYMax = null;
      if (yRange !== null) {
        var cy = curYMin + (1 - fy) * yRange;
        var newYRange = yRange * factor;
        newYMin = cy - (1 - fy) * newYRange;
        newYMax = newYMin + newYRange;
        if (baseY.min !== null && baseY.max !== null) {
          if (newYMin < baseY.min) { newYMax += (baseY.min - newYMin); newYMin = baseY.min; }
          if (newYMax > baseY.max) { newYMin -= (newYMax - baseY.max); newYMax = baseY.max; }
          newYMin = clamp(newYMin, baseY.min, baseY.max);
          newYMax = clamp(newYMax, baseY.min, baseY.max);
        }
      }

      scheduleView(newXMin, newXMax, newYMin, newYMax);
    }

    function onMouseDown(ev) {
      if (!isChartModalOpen()) return;
      if (ev.button !== 0) return;
      ev.preventDefault();
      isDragging = true;
      try { el.setPointerCapture && el.setPointerCapture(ev.pointerId); } catch (e) {}
      var rect = el.getBoundingClientRect();
      var curX = getCurrentXMinMax();
      if (curX.min === null || curX.max === null) curX = baseX;
      var g = chartInstance.w && chartInstance.w.globals;
      var curYMin = null, curYMax = null;
      if (g && typeof g.minY === "number" && typeof g.maxY === "number" && isFinite(g.minY) && isFinite(g.maxY)) {
        curYMin = g.minY; curYMax = g.maxY;
      } else if (baseY.min !== null && baseY.max !== null) {
        curYMin = baseY.min; curYMax = baseY.max;
      }
      dragStart = {
        x: ev.clientX,
        y: ev.clientY,
        rect: rect,
        xMin: curX.min,
        xMax: curX.max,
        yMin: curYMin,
        yMax: curYMax
      };
      el.style.cursor = cursorDown;
    }

    function onMouseMove(ev) {
      if (!isDragging || !dragStart) return;
      ev.preventDefault();
      var dx = ev.clientX - dragStart.x;
      var dy = ev.clientY - dragStart.y;
      var w = Math.max(1, dragStart.rect.width);
      var h = Math.max(1, dragStart.rect.height);

      var xRange = dragStart.xMax - dragStart.xMin;
      var yRange = dragStart.yMin !== null && dragStart.yMax !== null ? (dragStart.yMax - dragStart.yMin) : null;

      var shiftX = -dx / w * xRange;
      var newXMin = dragStart.xMin + shiftX;
      var newXMax = dragStart.xMax + shiftX;

      var baseMin = baseX.min, baseMax = baseX.max;
      if (newXMin < baseMin) { newXMax += (baseMin - newXMin); newXMin = baseMin; }
      if (newXMax > baseMax) { newXMin -= (newXMax - baseMax); newXMax = baseMax; }
      newXMin = clamp(newXMin, baseMin, baseMax);
      newXMax = clamp(newXMax, baseMin, baseMax);

      var newYMin = null, newYMax = null;
      if (yRange !== null) {
        var shiftY = dy / h * yRange;
        newYMin = dragStart.yMin + shiftY;
        newYMax = dragStart.yMax + shiftY;
        if (baseY.min !== null && baseY.max !== null) {
          if (newYMin < baseY.min) { newYMax += (baseY.min - newYMin); newYMin = baseY.min; }
          if (newYMax > baseY.max) { newYMin -= (newYMax - baseY.max); newYMax = baseY.max; }
          newYMin = clamp(newYMin, baseY.min, baseY.max);
          newYMax = clamp(newYMax, baseY.min, baseY.max);
        }
      }

      scheduleView(newXMin, newXMax, newYMin, newYMax);
    }

    function onMouseUp(_ev) {
      if (!isDragging) return;
      isDragging = false;
      dragStart = null;
      el.style.cursor = cursorUp;
    }

    // pointer events cover mouse + touch; we rely on left button semantics for desktop.
    el.style.cursor = cursorUp;
    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("pointerdown", onMouseDown);
    window.addEventListener("pointermove", onMouseMove);
    window.addEventListener("pointerup", onMouseUp);
    window.addEventListener("pointercancel", onMouseUp);

    return {
      reset: reset,
      destroy: function () {
        rafPending = false;
        pendingView = null;
        try { el.removeEventListener("wheel", onWheel, { passive: false }); } catch (e) { try { el.removeEventListener("wheel", onWheel); } catch (e2) {} }
        try { el.removeEventListener("pointerdown", onMouseDown); } catch (e3) {}
        try { window.removeEventListener("pointermove", onMouseMove); } catch (e4) {}
        try { window.removeEventListener("pointerup", onMouseUp); } catch (e5) {}
        try { window.removeEventListener("pointercancel", onMouseUp); } catch (e6) {}
        try { el.style.cursor = ""; } catch (e7) {}
      }
    };
  }

  function initChartRegistry() {
    if (charts && charts.size) return;

    charts.set("equity_curve", {
      title: "Equity Curve",
      getDataFn: function (range, cb) {
        requestJson("GET", "/api/stats/equity_curve" + buildRangeQuery(range), cb);
      },
      buildOptsFn: function (data) { return buildEquityApexOpts(data, 520, true); }
    });

    charts.set("drawdown", {
      title: "Drawdown",
      getDataFn: function (range, cb) {
        requestJson("GET", "/api/stats/drawdown" + buildRangeQuery(range), cb);
      },
      buildOptsFn: function (data, ctx) {
        var mode = ctx && ctx.mode ? String(ctx.mode) : "expanded";
        return createDrawdownChart(null, data, { mode: mode, height: 520, forModal: true });
      }
    });

    charts.set("winrate_by_hour", {
      title: "Win Rate By Hour",
      getDataFn: function (range, cb) {
        requestJson("GET", "/api/stats/winrate_by_hour" + buildRangeQuery(range), cb);
      },
      buildOptsFn: function (data) { return buildWinHourApexOpts(data, 520, true); }
    });

    charts.set("winloss_distribution", {
      title: "Win / Loss Distribution",
      getDataFn: function (range, cb) {
        requestJson("GET", "/api/stats/winloss_distribution" + buildRangeQuery(range), cb);
      },
      buildOptsFn: function (data) { return buildDistributionApexOpts(data, 520, true); }
    });

    charts.set("daily_pl", {
      title: "Daily P/L",
      getDataFn: function (range, cb) {
        requestJson("GET", "/api/stats/daily_pl" + buildRangeQuery(range), cb);
      },
      buildOptsFn: function (data) { return buildDailyPlApexOpts(data, 520, els.chartModalChart, true); }
    });
  }

  function isChartModalOpen() {
    return !!(els.chartModal && !els.chartModal.classList.contains("is-hidden"));
  }

  function destroyModalApexChart() {
    if (_chartModalApex) {
      try { _chartModalApex.destroy(); } catch (e) {}
      _chartModalApex = null;
    }
    if (els.chartModalChart) els.chartModalChart.innerHTML = "";
  }

  function showChartModalEmpty(show, message) {
    if (!els.chartModalEmpty) return;
    if (hasValue(message)) {
      els.chartModalEmpty.textContent = String(message);
    } else {
      els.chartModalEmpty.textContent = normalizeRange(getModalRangeFromInputs())
        ? "No closed trades in selected period"
        : "No closed trades yet";
    }
    els.chartModalEmpty.classList.toggle("is-hidden", !show);
  }

  function setChartModalTitle(text) {
    if (!els.chartModalTitle) return;
    els.chartModalTitle.textContent = hasValue(text) ? String(text) : "Chart";
  }

  function getModalRangeFromInputs() {
    var from = els.chartModalFrom ? els.chartModalFrom.value : "";
    var to = els.chartModalTo ? els.chartModalTo.value : "";
    return normalizeRange({ from: from, to: to });
  }

  function setModalRangeInputs(range) {
    var r = normalizeRange(range);
    if (els.chartModalFrom) els.chartModalFrom.value = r && r.from ? r.from : "";
    if (els.chartModalTo) els.chartModalTo.value = r && r.to ? r.to : "";
  }

  function applyAnalyticsRangeGlobally(range) {
    state.analyticsRange = normalizeRange(range);
    _analyticsDataStale = true;
    fetchAnalyticsData(false);
  }

  function fetchAndRenderModalChart(key, range) {
    initChartRegistry();
    var entry = charts.get(key);
    if (!entry || !els.chartModalChart) return;

    if (typeof ApexCharts === "undefined") {
      showChartModalEmpty(true, "Chart library not loaded");
      return;
    }

    destroyModalApexChart();
    destroyChartModalInteractivity();
    destroyChartModalRail();
    showChartModalEmpty(false);

    var token = ++_chartModalReqToken;
    entry.getDataFn(range, function (err, data) {
      if (token !== _chartModalReqToken) return;
      if (_chartModalActiveKey !== key) return;

      if (err || !data) {
        console.warn("Modal chart fetch failed", err || data);
        showChartModalEmpty(true, "No closed trades in selected period");
        return;
      }

      var ctx = null;
      if (key === "drawdown") {
        var w = 0;
        try { w = els.chartModalChart && els.chartModalChart.clientWidth ? els.chartModalChart.clientWidth : 0; } catch (e0) {}
        // Pre-render mode selection: if modal is narrow, don't reserve the right rail gutter.
        var mode = w > 0 && w < 720 ? "compact" : "expanded";
        ctx = { mode: mode };
      }

      var opts = entry.buildOptsFn(data, ctx);
      if (!opts) {
        showChartModalEmpty(true, "No closed trades in selected period");
        return;
      }

      // Drawdown modal uses an external "rail" marker for max DD.
      if (key === "drawdown") {
        var abs = (data && data.max_dd_abs) || 0;
        var pct = (data && data.max_dd_pct) || 0;
        var idx = (data && data.max_dd_idx) || 0;
        var series = (data && data.series) || [];
        var yValue = null;
        if (idx >= 0 && idx < series.length) {
          // Modal series is negative values (drawdown rendered as negative).
          yValue = -Number(series[idx].drawdown || 0);
        }
        _chartModalDrawdownRailMeta = {
          text: "Max DD: €" + Number(abs || 0).toFixed(2) + " (" + Number(pct || 0).toFixed(1) + "%)",
          yValue: yValue,
          mode: ctx && ctx.mode ? String(ctx.mode) : "expanded"
        };
      } else {
        _chartModalDrawdownRailMeta = null;
      }

      // Modal pan/zoom should feel immediate; disable chart animations in expanded view.
      opts.chart = opts.chart || {};
      opts.chart.animations = { enabled: false };

      try {
        _chartModalApex = new ApexCharts(els.chartModalChart, opts);
        _chartModalApex.render();
        // Enable pan/zoom only in expanded (modal) view.
        _chartModalInteractive = makeChartInteractive(_chartModalApex, { enablePanZoom: true, onAfterView: syncDrawdownRail });
        syncDrawdownRail();
      } catch (e) {
        console.error("Modal chart render failed", e);
        showChartModalEmpty(true, "No data in selected range");
      }
    });
  }

  function openChartModal(key) {
    if (!els.chartModal) return;
    initChartRegistry();
    var entry = charts.get(key);
    if (!entry) return;

    // Avoid stacked modals.
    if (isTradeModalOpen()) closeTradeModal();

    if (_chartModalCloseTimer) {
      clearTimeout(_chartModalCloseTimer);
      _chartModalCloseTimer = null;
    }

    _chartModalActiveKey = key;
    if (els.chartModalApplyGlobal) els.chartModalApplyGlobal.checked = false;

    setChartModalTitle(entry.title);
    setModalRangeInputs(state.analyticsRange);

    els.chartModal.classList.remove("is-hidden");
    // Trigger transitions.
    requestAnimationFrame(function () {
      if (els.chartModal) els.chartModal.classList.add("is-open");
      syncBodyModalOpen();
    });
    syncBodyModalOpen();

    fetchAndRenderModalChart(key, getModalRangeFromInputs());

    if (els.chartModalClose) {
      try { els.chartModalClose.focus(); } catch (e) {}
    }
  }

  function closeChartModal() {
    if (!els.chartModal) return;
    if (!isChartModalOpen()) return;

    // Invalidate any in-flight modal requests.
    _chartModalReqToken++;
    els.chartModal.classList.remove("is-open");
    syncBodyModalOpen();

    if (_chartModalResizeTimer) {
      clearTimeout(_chartModalResizeTimer);
      _chartModalResizeTimer = null;
    }

    if (_chartModalCloseTimer) clearTimeout(_chartModalCloseTimer);
    _chartModalCloseTimer = setTimeout(function () {
      if (!els.chartModal) return;
      els.chartModal.classList.add("is-hidden");
      syncBodyModalOpen();
      destroyChartModalInteractivity();
      destroyChartModalRail();
      destroyModalApexChart();
      showChartModalEmpty(false);
      _chartModalActiveKey = null;
    }, 170);
  }

  function applyModalRange(immediate) {
    if (!_chartModalActiveKey) return;
    if (_chartModalDebounceTimer) {
      clearTimeout(_chartModalDebounceTimer);
      _chartModalDebounceTimer = null;
    }

    var range = getModalRangeFromInputs();
    fetchAndRenderModalChart(_chartModalActiveKey, range);

    if (els.chartModalApplyGlobal && els.chartModalApplyGlobal.checked) {
      applyAnalyticsRangeGlobally(range);
    }
  }

  function debounceModalApply(ms) {
    if (_chartModalDebounceTimer) clearTimeout(_chartModalDebounceTimer);
    _chartModalDebounceTimer = setTimeout(function () {
      applyModalRange(false);
    }, ms || 200);
  }

  function applyModalPreset(presetKey) {
    var now = new Date();
    // Use UTC dates (labels in UI say UTC, and backend uses close_time which is treated as UTC in analytics charts).
    var today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));

    function addDays(d, delta) {
      var x = new Date(d.getTime());
      x.setUTCDate(x.getUTCDate() + delta);
      return x;
    }

    if (presetKey === "today") {
      setModalRangeInputs({ from: formatDateUtcYmd(today), to: formatDateUtcYmd(today) });
    } else if (presetKey === "last7") {
      setModalRangeInputs({ from: formatDateUtcYmd(addDays(today, -6)), to: formatDateUtcYmd(today) });
    } else if (presetKey === "mtd") {
      var start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
      setModalRangeInputs({ from: formatDateUtcYmd(start), to: formatDateUtcYmd(today) });
    } else if (presetKey === "last30") {
      setModalRangeInputs({ from: formatDateUtcYmd(addDays(today, -29)), to: formatDateUtcYmd(today) });
    } else if (presetKey === "ytd") {
      var y = new Date(Date.UTC(today.getUTCFullYear(), 0, 1));
      setModalRangeInputs({ from: formatDateUtcYmd(y), to: formatDateUtcYmd(today) });
    } else if (presetKey === "all") {
      setModalRangeInputs(null);
    } else {
      return;
    }

    applyModalRange(true);
  }

  function initChartModal() {
    if (!els.chartModal) return;
    initChartRegistry();

    if (els.chartModalClose) els.chartModalClose.onclick = closeChartModal;
    if (els.chartModalBackdrop) els.chartModalBackdrop.onclick = closeChartModal;
    if (els.chartModalApply) els.chartModalApply.onclick = function () { applyModalRange(true); };
    if (els.chartModalResetView) {
      els.chartModalResetView.onclick = function () {
        if (_chartModalInteractive && _chartModalInteractive.reset) _chartModalInteractive.reset();
      };
    }
    if (els.chartModalReset) {
      els.chartModalReset.onclick = function () {
        if (els.chartModalFrom) els.chartModalFrom.value = "";
        if (els.chartModalTo) els.chartModalTo.value = "";
        applyModalRange(true);
      };
    }

    if (els.chartModalFrom) {
      els.chartModalFrom.addEventListener("input", function () {
        debounceModalApply(200);
      });
    }
    if (els.chartModalTo) {
      els.chartModalTo.addEventListener("input", function () {
        debounceModalApply(200);
      });
    }

    if (els.chartModalPresets && els.chartModalPresets.length) {
      for (var i = 0; i < els.chartModalPresets.length; i++) {
        (function (btn) {
          btn.onclick = function () {
            applyModalPreset(btn.getAttribute("data-preset"));
          };
        })(els.chartModalPresets[i]);
      }
    }

    window.addEventListener("resize", function () {
      if (!isChartModalOpen()) return;
      if (_chartModalActiveKey !== "drawdown") return;
      if (_chartModalResizeTimer) clearTimeout(_chartModalResizeTimer);
      _chartModalResizeTimer = setTimeout(function () {
        if (!isChartModalOpen()) return;
        if (_chartModalActiveKey !== "drawdown") return;
        var w = 0;
        try { w = els.chartModalChart && els.chartModalChart.clientWidth ? els.chartModalChart.clientWidth : 0; } catch (e0) {}
        var mode = w > 0 && w < 720 ? "compact" : "expanded";
        var cur = _chartModalDrawdownRailMeta && _chartModalDrawdownRailMeta.mode ? String(_chartModalDrawdownRailMeta.mode) : "expanded";
        if (mode !== cur) {
          fetchAndRenderModalChart("drawdown", getModalRangeFromInputs());
        } else {
          syncDrawdownRail();
        }
      }, 180);
    });

    document.addEventListener("keydown", function (e) {
      if (!isChartModalOpen()) return;
      // If another modal is on top, let it handle ESC.
      if (isTradeModalOpen()) return;
      var key = e.key || e.keyCode;
      if (key === "Escape" || key === "Esc" || key === 27) {
        e.preventDefault();
        closeChartModal();
      }
    });

    var cards = document.querySelectorAll(".analytics-card[data-chart-key]");
    for (var c = 0; c < cards.length; c++) {
      (function (card) {
        var key = card.getAttribute("data-chart-key");
        card.addEventListener("click", function () {
          openChartModal(key);
        });
        card.addEventListener("keydown", function (ev) {
          var k = ev.key || ev.keyCode;
          if (k === "Enter" || k === " " || k === 13 || k === 32) {
            ev.preventDefault();
            openChartModal(key);
          }
        });
      })(cards[c]);
    }
  }

  function fmtOrZero(value, digits) {
    var text = fmt(value, digits);
    return text === "--" ? "0" : text;
  }

  function setStatusBadge(el, status) {
    if (!el) return;
    var st = String(status || "OK").toUpperCase();
    var cls = "status-badge";
    if (st === "WARNING") cls += " status-warning";
    else if (st === "BREACH") cls += " status-breach";
    else cls += " status-ok";
    el.className = cls;
    el.textContent = st;
  }

  function renderRisk() {
    var summary = state.riskSummary || {};
    var days = state.riskDays && Array.isArray(state.riskDays.days) ? state.riskDays.days : [];

    var dailyRemaining = hasValue(summary.daily_loss_remaining) ? summary.daily_loss_remaining : 0;
    var maxRemaining = hasValue(summary.max_loss_remaining) ? summary.max_loss_remaining : 0;
    var profitRemaining = hasValue(summary.profit_target_remaining) ? summary.profit_target_remaining : 0;
    var tradingDays = hasValue(summary.trading_days_count) ? summary.trading_days_count : days.length;
    var noTrades = Number(tradingDays) <= 0;

    if (els.riskDailyRemaining) els.riskDailyRemaining.textContent = fmtOrZero(dailyRemaining, 2);
    if (els.riskMaxRemaining) els.riskMaxRemaining.textContent = fmtOrZero(maxRemaining, 2);
    if (els.riskProfitRemaining) els.riskProfitRemaining.textContent = fmtOrZero(profitRemaining, 2);
    if (els.riskTradingDays) els.riskTradingDays.textContent = fmtOrZero(tradingDays, 0);

    if (els.riskDailyMeta) {
      var dailyUsed = fmtOrZero(summary.daily_loss_used, 2);
      var dailyLimit = fmtOrZero(summary.daily_loss_limit, 2);
      els.riskDailyMeta.textContent = "Used " + dailyUsed + " / " + dailyLimit;
    }
    if (els.riskMaxMeta) {
      var maxUsed = fmtOrZero(summary.max_loss_used, 2);
      var maxLimit = fmtOrZero(summary.max_loss_limit, 2);
      els.riskMaxMeta.textContent = "Used " + maxUsed + " / " + maxLimit;
    }
    if (els.riskProfitMeta) {
      var profitTotal = fmtOrZero(summary.pnl_total, 2);
      var profitTarget = fmtOrZero(summary.profit_target, 2);
      els.riskProfitMeta.textContent = "Progress " + profitTotal + " / " + profitTarget;
    }
    if (els.riskTradingDaysMeta) {
      var dayLabel = noTrades ? "No closed trades yet" : "Closed-trade days";
      els.riskTradingDaysMeta.textContent = dayLabel;
    }

    setStatusBadge(els.riskStatusBadge, summary.status || "OK");
    if (els.riskStatusDetail) {
      var dailyPct = fmtOrZero(summary.daily_loss_pct_used, 1);
      var maxPct = fmtOrZero(summary.max_loss_pct_used, 1);
      els.riskStatusDetail.textContent = "Daily " + dailyPct + "%, Max " + maxPct + "% used";
    }

    if (els.riskEmptyNote) {
      els.riskEmptyNote.classList.toggle("is-hidden", !noTrades);
    }
  }

  function renderSystemStatus(status, isLoading) {
    var data = status || {};
    var orch = data.orchestrator || {};
    var ok = orch.ok === true ? true : (orch.ok === false ? false : null);
    var orchLabel = ok === true ? "ONLINE" : (ok === false ? "OFFLINE" : "UNKNOWN");
    var pillClass = ok === true ? "pill pill-open" : (ok === false ? "pill pill-closed" : "pill");
    var orchUrl = hasValue(orch.url) ? String(orch.url) : "--";
    var httpStatus = hasValue(orch.http) ? String(orch.http) : "";
    var errorText = hasValue(orch.error) ? String(orch.error) : "";

    if (els.sysOrchStatus) {
      var extra = [];
      if (httpStatus) {
        extra.push(`<div class="metric-label">HTTP</div>`);
        extra.push(`<div class="metric-value muted">${esc(httpStatus)}</div>`);
      }
      if (errorText) {
        extra.push(`<div class="metric-label">Error</div>`);
        extra.push(`<div class="metric-value muted">${esc(errorText)}</div>`);
      }
      els.sysOrchStatus.innerHTML = `
        <div class="${pillClass}">${esc(orchLabel)}</div>
        <div class="metric-label">URL</div>
        <div class="metric-value muted">${esc(orchUrl)}</div>
        ${extra.join(``)}
      `;
    }

    if (els.sysHeartbeat) {
      var heartbeat = hasValue(orch.last_heartbeat) ? orch.last_heartbeat : data.last_heartbeat;
      els.sysHeartbeat.textContent = hasValue(heartbeat) ? heartbeat : "--";
    }
    if (els.sysEaVersion) {
      var eaValue = pickValue(data, ["ea_version", "eaVersion"]);
      if (hasValue(eaValue)) {
        els.sysEaVersion.textContent = eaValue;
      } else if (isLoading) {
        var currentText = els.sysEaVersion.textContent || "";
        if (currentText === "\u2014" || currentText === "--" || currentText === "") {
          els.sysEaVersion.textContent = "\u2026";
        }
      } else if (!isLoading) {
        els.sysEaVersion.textContent = "\u2014";
      }
    }
    if (els.sysEaName) {
      var eaName = pickValue(data, ["ea_name", "eaName"]);
      if (hasValue(eaName)) {
        els.sysEaName.textContent = "EA: " + eaName;
      } else if (!isLoading) {
        els.sysEaName.textContent = "\u2014";
      }
    }
    if (els.sysMt5Build) {
      var mt5Build = pickValue(data, ["mt5_build", "mt5Build", "build"]);
      if (hasValue(mt5Build)) {
        els.sysMt5Build.textContent = "MT5 build: " + mt5Build;
      } else if (!isLoading) {
        els.sysMt5Build.textContent = "\u2014";
      }
    }
    if (els.sysEaUpdated) {
      var updated = pickValue(data, ["ea_version_updated_at", "updated_at", "build_time", "buildTime"]);
      if (hasValue(updated)) {
        els.sysEaUpdated.textContent = "Updated: " + updated;
      } else if (!isLoading) {
        els.sysEaUpdated.textContent = "\u2014";
      }
    }
    if (els.sysActiveSymbols) {
      var symbols = Array.isArray(data.active_symbols) ? data.active_symbols : [];
      if (!symbols.length) {
        els.sysActiveSymbols.textContent = "--";
      } else {
        var pills = [];
        for (var j = 0; j < symbols.length; j++) {
          pills.push(`<span class="pill">${esc(symbols[j])}</span>`);
        }
        els.sysActiveSymbols.innerHTML = pills.join(``);
      }
    }
    if (hasValue(data.logs_cleared_at)) {
      var clearedMs = Date.parse(data.logs_cleared_at);
      if (!isNaN(clearedMs)) {
        if (!state.systemLogsClearedAt || clearedMs > state.systemLogsClearedAt) {
          state.systemLogsClearedAt = clearedMs;
          state.systemLogsCleared = true;
        }
      }
    }
    renderSystemLogs(data.logs);
  }

  function formatLogTimestampForLine(date) {
    var pad = function (num, size) {
      var s = String(num);
      while (s.length < size) s = "0" + s;
      return s;
    };
    return (
      date.getFullYear() +
      "-" +
      pad(date.getMonth() + 1, 2) +
      "-" +
      pad(date.getDate(), 2) +
      " " +
      pad(date.getHours(), 2) +
      ":" +
      pad(date.getMinutes(), 2) +
      ":" +
      pad(date.getSeconds(), 2) +
      "," +
      pad(date.getMilliseconds(), 3)
    );
  }

  function simulateLogEntry() {
    var now = new Date();
    var baseId = "dev-" + Date.now() + "-" + Math.random().toString(16).slice(2);
    var entries = [];
    var heartbeat = {
      id: baseId + "-hb",
      timestamp: now.toISOString(),
      type: "heartbeat",
      message: "Simulated heartbeat log",
      method: "GET",
      path: "/health",
      status: 200
    };
    var preAllow = {
      id: baseId + "-allow",
      timestamp: new Date(now.getTime() + 200).toISOString(),
      type: "pre_trade_allow",
      message: "Simulated pre_trade allow",
      method: "POST",
      path: "/pre_trade",
      status: 200,
      allow: true,
      reason: "ok"
    };
    var preDeny = {
      id: baseId + "-deny",
      timestamp: new Date(now.getTime() + 400).toISOString(),
      type: "pre_trade_deny",
      message: "Simulated pre_trade deny",
      method: "POST",
      path: "/pre_trade",
      status: 200,
      allow: false,
      reason: "blocked"
    };
    entries.push(heartbeat, preAllow, preDeny);
    if (!state.systemStatus) state.systemStatus = {};
    var logs = Array.isArray(state.systemStatus.logs) ? state.systemStatus.logs.slice() : [];
    logs = logs.concat(entries);
    state.systemStatus.logs = logs;
    state.systemLogsCleared = false;
    renderSystemLogs(logs);
  }

  function ensureSystemLogButtons() {
    var copyBtn = els.copyLogsBtn || document.getElementById("copyLogsBtn");
    if (!copyBtn || !copyBtn.parentNode) return;

    var clearBtn = document.getElementById("clearLogsBtn");
    if (!clearBtn) {
      clearBtn = document.createElement("button");
      clearBtn.id = "clearLogsBtn";
      clearBtn.className = "btn btn-ghost";
      clearBtn.type = "button";
      clearBtn.textContent = "Clear logs";
      copyBtn.parentNode.appendChild(clearBtn);
    }
    if (!clearBtn.getAttribute("data-bound")) {
      clearBtn.addEventListener("click", clearSystemLogs);
      clearBtn.setAttribute("data-bound", "true");
    }

    var simBtn = document.getElementById("simulateLogBtn");
    if (!simBtn && isDevMode()) {
      simBtn = document.createElement("button");
      simBtn.id = "simulateLogBtn";
      simBtn.className = "btn btn-ghost";
      simBtn.type = "button";
      simBtn.textContent = "Simulate log";
      copyBtn.parentNode.appendChild(simBtn);
    }
    if (simBtn && !simBtn.getAttribute("data-bound")) {
      simBtn.addEventListener("click", simulateLogEntry);
      simBtn.setAttribute("data-bound", "true");
    }
  }

  function renderSystemLogs(rawLogs) {
    if (!els.sysLogs) return;
    ensureSystemLogButtons();
    var logs = Array.isArray(rawLogs) ? rawLogs.slice() : [];
    var devMode = isDevMode();
    logs = filterLogsAfterBaseline(logs, state.systemLogsClearedAt);
    var hasLogs = logs.length > 0;
    if (hasLogs) state.systemLogsCleared = false;
    if (devMode) console.log("SYSTEM LOGS COUNT:", logs.length);
    if (!logs.length) {
      logs = devMode && !state.systemLogsCleared ? getDevMockLogs() : ["No logs available"];
    } else if (devMode && !state.systemLogsCleared) {
      logs = logs.concat(getDevMockLogs());
    }
    var isPlaceholder = logs.length === 1 && typeof logs[0] === "string" && logs[0].indexOf("No logs available") >= 0;
    var entries = sortEntriesByTimestamp(aggregateHeartbeatEntries(buildLogEntries(logs)));
    if (entries.length > MAX_SYSTEM_LOGS) entries = entries.slice(0, MAX_SYSTEM_LOGS);
    state.systemLogDisplayLines = buildLogCopyLinesFromEntries(entries);
    var latestIndex = -1;
    var latestTs = null;
    var anyTs = false;
    for (var li = 0; li < entries.length; li++) {
      var entryTs = parseLogTimestamp(
        (entries[li] && (entries[li].lastSeenAt || (entries[li].normalized && entries[li].normalized.timestamp))) || null
      );
      if (entryTs) {
        anyTs = true;
        if (!latestTs || entryTs > latestTs) {
          latestTs = entryTs;
          latestIndex = li;
        }
      }
    }
    if (!anyTs && entries.length) latestIndex = 0;
    var latestEntry = latestIndex >= 0 ? entries[latestIndex] : null;
    var latestKey = latestEntry ? deriveLogKey(latestEntry, latestIndex) : null;
    var latestMs = latestTs ? latestTs.getTime() : null;
    var shouldHighlight = false;
    if (!isPlaceholder && latestEntry && latestKey) {
      if (latestKey !== state.systemLogLastKey) {
        shouldHighlight = true;
      } else if (typeof latestMs === "number" && (!state.systemLogLastTs || latestMs > state.systemLogLastTs)) {
        shouldHighlight = true;
      }
    }
    if (shouldHighlight) {
      setSystemLogHighlight(latestKey, latestMs);
    }
    var highlightActive = hasValue(state.systemLogHighlightKey) && Date.now() < state.systemLogHighlightUntil;
    var rows = [];
    for (var i = 0; i < entries.length; i++) {
      var entry = entries[i];
      var normalized = entry.normalized || {};
      var classification = entry.classification || { severity: "neutral", label: "LOG" };
      var severity = normalizeSeverity(classification.severity);
      var label = classification.label || "LOG";
      if (label === "HEARTBEAT" && entry.count > 1) {
        label = "HEARTBEAT (x" + entry.count + ")";
      }
      var timestamp = hasValue(entry.lastSeenAt) ? entry.lastSeenAt : (hasValue(normalized.timestamp) ? normalized.timestamp : "--");
      var key = deriveLogKey(entry, i);
      var isHighlighted = highlightActive && key === state.systemLogHighlightKey;

      var main = "";
      if (hasValue(normalized.endpoint)) main = String(normalized.endpoint);
      else if (normalized.method && normalized.path) main = normalized.method + " " + normalized.path;
      else if (hasValue(normalized.rawText)) main = String(normalized.rawText);
      else if (hasValue(normalized.reason)) main = String(normalized.reason);
      else main = "Log entry";

      var bodyParts = [];
      var mainClass = hasValue(normalized.endpoint) || (normalized.method && normalized.path) ? "logMain" : "logMain logRaw";
      bodyParts.push(`<span class="${mainClass}">${esc(main)}</span>`);
      if (hasValue(normalized.status)) {
        bodyParts.push(`<span class="logMeta">HTTP ${esc(normalized.status)}</span>`);
      }
      if (normalized.allow !== null && normalized.allow !== undefined) {
        var allowText = normalized.allow === true ? "allow: true" : (normalized.allow === false ? "allow: false" : ("allow: " + String(normalized.allow)));
        bodyParts.push(`<span class="logMeta">${esc(allowText)}</span>`);
      }
      if (hasValue(normalized.reason) && String(normalized.reason) !== main) {
        bodyParts.push(`<span class="logMeta">reason: ${esc(normalized.reason)}</span>`);
      }

      rows.push(`
        <div class="logRow sev-${severity}${isHighlighted ? " logPulse" : ""}" data-key="${esc(key)}">
          <div class="logBar"></div>
          <div class="logContent">
            <div class="logHead">
              <span class="badge">${esc(label)}</span>
              <span class="logTime">${esc(timestamp)}</span>
            </div>
            <div class="logBody">
              ${bodyParts.join("")}
            </div>
          </div>
        </div>
      `);
    }
    els.sysLogs.innerHTML = rows.join(``);
  }

  function renderSystem() {
    renderSystemStatus(state.systemStatus || {}, state.systemStatusLoading);
    renderOrchPanel();
  }

  function refreshSystemStatus() {
    state.systemStatusLoading = true;
    renderSystemStatus(state.systemStatus || {}, true);
    requestJson("GET", "/system/status", function (err, data) {
      if (err) {
        var fallback = {
          orchestrator: {
            url: "",
            ok: false,
            http: null,
            error: err,
            last_heartbeat: (state.systemStatus && state.systemStatus.orchestrator && state.systemStatus.orchestrator.last_heartbeat) || (state.systemStatus && state.systemStatus.last_heartbeat) || null
          },
          last_heartbeat: (state.systemStatus && state.systemStatus.last_heartbeat) || null,
          ea_version: (state.systemStatus && state.systemStatus.ea_version) || null,
          ea_name: (state.systemStatus && state.systemStatus.ea_name) || null,
          mt5_build: (state.systemStatus && state.systemStatus.mt5_build) || null,
          ea_version_updated_at: (state.systemStatus && state.systemStatus.ea_version_updated_at) || null,
          build_time: (state.systemStatus && state.systemStatus.build_time) || null,
          active_symbols: (state.systemStatus && state.systemStatus.active_symbols) || [],
          logs: (state.systemStatus && state.systemStatus.logs) || ["No logs available"]
        };
        state.systemStatus = fallback;
        state.systemStatusLoading = false;
        renderSystemStatus(fallback, false);
        return;
      }
      console.log("system/status", data);
      if (data && Array.isArray(data.logs) && data.logs.length > MAX_SYSTEM_LOGS) {
        data.logs = data.logs.slice(-MAX_SYSTEM_LOGS);
      }
      state.systemStatus = data || {};
      state.systemStatusLoading = false;
      renderSystemStatus(state.systemStatus, false);
    });
  }

  function resetSystemStatusTimer() {
    if (systemStatusTimer) {
      clearInterval(systemStatusTimer);
      systemStatusTimer = null;
    }
    // Poll only while the System tab is active to avoid flooding logs with /system/status calls.
    if (state.activeTab !== "system") return;
    var intervalMs = getSystemStatusPollIntervalMs();
    systemStatusTimer = setInterval(function () {
      if (state.activeTab !== "system") {
        resetSystemStatusTimer();
        return;
      }
      refreshSystemStatus();
      refreshOrchPanel();
    }, intervalMs);
  }

  function refreshRiskData() {
    requestJson("GET", "/risk_ftmo/summary", function (err, data) {
      if (err) {
        state.riskSummary = state.riskSummary || {};
        renderRisk();
        return;
      }
      state.riskSummary = data || {};
      renderRisk();
    });

    requestJson("GET", "/risk_ftmo/days", function (err, data) {
      if (err) {
        state.riskDays = { days: [] };
        renderRisk();
        return;
      }
      state.riskDays = data || { days: [] };
      renderRisk();
    });
  }

  function renderAll() {
    updateFilterOptions(state.trades);
    renderDashboard();
    renderTradesTable();
    if (state.newsLoadedOnce || state.activeTab === "news") {
      renderNewsTable();
    }
    _analyticsDataStale = true;
    renderRisk();
    state.needsTradesRender = false;
    updateDiagnostics();
  }

  function buildDrawdownSeries(series) {
    var peak = series[0] || 0;
    var dd = [];
    for (var i = 0; i < series.length; i++) {
      var value = series[i];
      if (value > peak) peak = value;
      dd.push(peak - value);
    }
    return dd;
  }

  function buildHistogram(trades) {
    var values = [];
    for (var i = 0; i < trades.length; i++) {
      var profitRaw = pickValue(trades[i], ["profit"]);
      if (!hasValue(profitRaw)) continue;
      var profit = Number(profitRaw);
      if (!isNaN(profit) && isFinite(profit)) values.push(profit);
    }
    if (values.length < 5) return [];
    values.sort(function (a, b) { return a - b; });
    var min = values[0];
    var max = values[values.length - 1];
    if (min === max) max = min + 1;
    var bins = 6;
    var step = (max - min) / bins;
    var counts = [];
    for (var b = 0; b < bins; b++) counts[b] = 0;
    for (var j = 0; j < values.length; j++) {
      var idx = Math.min(bins - 1, Math.floor((values[j] - min) / step));
      counts[idx] += 1;
    }
    return counts;
  }

  function buildWinRateByHour(trades) {
    var buckets = [];
    var totalCount = 0;
    for (var i = 0; i < 24; i++) buckets.push({ wins: 0, total: 0 });
    for (var j = 0; j < trades.length; j++) {
      var t = trades[j] || {};
      var time = parseTradeDate(t.close_time) || parseTradeDate(t.open_time);
      if (!time) continue;
      var hour = time.getHours();
      var profitRaw = pickValue(t, ["profit"]);
      if (!hasValue(profitRaw)) continue;
      var profit = Number(profitRaw);
      if (isNaN(profit) || !isFinite(profit)) continue;
      buckets[hour].total += 1;
      totalCount += 1;
      if (profit > 0) buckets[hour].wins += 1;
    }
    if (totalCount === 0) return [];
    var result = [];
    for (var k = 0; k < buckets.length; k++) {
      if (buckets[k].total > 0) {
        result.push(buckets[k].wins / buckets[k].total);
      } else {
        result.push(0);
      }
    }
    return result;
  }

  function renderLineChart(svgEl, series, colors, emptyEl) {
    if (!svgEl) return;
    var width = svgEl.viewBox.baseVal.width || 260;
    var height = svgEl.viewBox.baseVal.height || 180;
    var min = Math.min.apply(null, series);
    var max = Math.max.apply(null, series);
    if (min === max) {
      min -= 1;
      max += 1;
    }
    var path = "";
    for (var i = 0; i < series.length; i++) {
      var x = (i / (series.length - 1)) * width;
      var y = height - ((series[i] - min) / (max - min)) * height;
      path += (i === 0 ? "M" : "L") + x.toFixed(2) + " " + y.toFixed(2) + " ";
    }
    if (svgEl.getAttribute("data-path") === path) return;
    svgEl.setAttribute("data-path", path);
    var segments = [];
    if (colors && colors.fill) {
      segments.push(`<path d="${path} L ${width} ${height} L 0 ${height} Z" fill="${colors.fill}" stroke="none"></path>`);
    }
    segments.push(`<path d="${path}" fill="none" stroke="${colors && colors.stroke ? colors.stroke : "#56b6ff"}" stroke-width="2"></path>`);
    svgEl.innerHTML = segments.join(``);
    if (emptyEl) emptyEl.classList.add("is-hidden");
  }

  function clearChart(svgEl, emptyEl) {
    if (!svgEl) return;
    svgEl.innerHTML = ``;
    svgEl.removeAttribute("data-path");
    if (emptyEl) emptyEl.classList.remove("is-hidden");
  }

  function renderHistogramChart(svgEl, values, emptyEl) {
    if (!svgEl) return;
    var width = svgEl.viewBox.baseVal.width || 260;
    var height = svgEl.viewBox.baseVal.height || 180;
    var max = Math.max.apply(null, values) || 1;
    var barWidth = width / values.length;
    var bars = [];
    for (var i = 0; i < values.length; i++) {
      var barHeight = (values[i] / max) * (height - 20);
      var x = i * barWidth + 6;
      var y = height - barHeight - 6;
      var w = Math.max(6, barWidth - 12);
      bars.push(`<rect x="${x.toFixed(2)}" y="${y.toFixed(2)}" width="${w.toFixed(2)}" height="${barHeight.toFixed(2)}" rx="3" fill="rgba(63, 224, 197, 0.6)"></rect>`);
    }
    svgEl.innerHTML = bars.join(``);
    if (emptyEl) emptyEl.classList.add("is-hidden");
  }

  function renderBarChart(svgEl, values, emptyEl) {
    if (!svgEl) return;
    var width = svgEl.viewBox.baseVal.width || 260;
    var height = svgEl.viewBox.baseVal.height || 180;
    var barWidth = width / values.length;
    var gutter = Math.min(6, barWidth * 0.25);
    var bars = [];
    for (var i = 0; i < values.length; i++) {
      var barHeight = Math.max(4, values[i] * (height - gutter * 2));
      var x = i * barWidth + gutter;
      var y = height - barHeight - gutter;
      var w = Math.max(2, barWidth - gutter * 2);
      bars.push(`<rect x="${x.toFixed(2)}" y="${y.toFixed(2)}" width="${w.toFixed(2)}" height="${barHeight.toFixed(2)}" rx="3" fill="rgba(86, 182, 255, 0.6)"></rect>`);
    }
    svgEl.innerHTML = bars.join(``);
    if (emptyEl) emptyEl.classList.add("is-hidden");
  }
  function refreshData() {
    if (state.isRefreshing) return;
    state.isRefreshing = true;

    requestJson("GET", "/trades/stats", function (statsErr, statsData) {
      if (statsErr) {
        if (els.lastUpdated) els.lastUpdated.textContent = "Error";
        state.isRefreshing = false;
        return;
      }

      requestJson("GET", "/trades?limit=200", function (tradesErr, tradesData) {
        state.isRefreshing = false;
        if (tradesErr) {
          if (els.lastUpdated) els.lastUpdated.textContent = "Error";
          return;
        }

        state.stats = statsData && statsData.statistics ? statsData.statistics : {};
        state.trades = tradesData && tradesData.trades ? tradesData.trades : [];
        state.lastUpdated = new Date();
        updateHeader();
        renderAll();
      });
    });
  }

  function deleteOneTrade(tradeId, ticket) {
    var label = ticket ? ("ticket " + ticket) : ("id " + tradeId);
    if (!confirm("Delete trade (" + label + ")?")) return;

    var endpoint = tradeId ? ("/trades/" + encodeURIComponent(tradeId)) : ("/trades/ticket/" + encodeURIComponent(ticket));
    requestJson("DELETE", endpoint, function (err) {
      if (err) {
        alert("Delete failed: " + err);
        return;
      }
      refreshData();
    });
  }

  function deleteAllTrades() {
    var check = prompt("Type DELETE to remove all trades:");
    if (check !== "DELETE") return;

    requestJson("DELETE", "/trades/delete_all", function (err) {
      if (err) {
        alert("Delete failed: " + err);
        return;
      }
      refreshData();
    });
  }

  function exportCsv() {
    requestJson("POST", "/trades/export/csv/save", function (err, data) {
      if (err) {
        alert("Export failed: " + err);
        return;
      }
      alert(`CSV saved:
${data.file_path}
Rows: ${data.rows}`);
    });
  }

  function findDeleteButton(node) {
    while (node) {
      if (node.className && String(node.className).indexOf("delete-one-btn") >= 0) return node;
      node = node.parentNode;
    }
    return null;
  }

  function findGroupToggle(node) {
    while (node) {
      if (node.getAttribute && node.getAttribute("data-group-toggle") === "1") return node;
      node = node.parentNode;
    }
    return null;
  }

  function findTradeRow(node) {
    while (node) {
      if (node.getAttribute && node.getAttribute("data-trade-id")) return node;
      node = node.parentNode;
    }
    return null;
  }

  function bindEvents() {
    if (els.refreshBtn) els.refreshBtn.onclick = refreshData;
    if (els.exportCsvBtn) els.exportCsvBtn.onclick = exportCsv;
    if (els.deleteAllBtn) els.deleteAllBtn.onclick = deleteAllTrades;

    if (els.toolsDropdownBtn) {
      els.toolsDropdownBtn.onclick = function (event) {
        event.preventDefault();
        event.stopPropagation();
        toggleToolsDropdown();
      };
    }
    if (els.toolsDropdownMenu) {
      els.toolsDropdownMenu.onclick = function (event) {
        var node = event.target;
        while (node && node !== els.toolsDropdownMenu && !node.getAttribute("data-tools-action")) {
          node = node.parentNode;
        }
        if (!node || node === els.toolsDropdownMenu) return;
        var action = String(node.getAttribute("data-tools-action") || "").toLowerCase();
        if (action === "notes") {
          openNotesModal();
        } else if (action === "calculator") {
          openCalcModal();
        }
      };
    }
    document.addEventListener("click", function (event) {
      if (!isToolsDropdownOpen()) return;
      if (!els.toolsDropdown || !els.toolsDropdown.contains(event.target)) {
        closeToolsDropdown();
      }
    });
    document.addEventListener("keydown", function (event) {
      var key = event.key || event.keyCode;
      var keyLower = String(event.key || "").toLowerCase();
      var isEscape = key === "Escape" || key === "Esc" || key === 27;
      if (isNotesModalOpen()) {
        if ((event.ctrlKey || event.metaKey) && keyLower === "s") {
          event.preventDefault();
          saveSelectedNote(true);
          return;
        }
        if (isEscape) {
          event.preventDefault();
          closeNotesModal();
          return;
        }
      }
      if (isCalcModalOpen()) {
        if (isEscape) {
          event.preventDefault();
          closeCalcModal();
          return;
        }
      }
      if (isToolsDropdownOpen() && isEscape) {
        event.preventDefault();
        closeToolsDropdown();
      }
    });

    var analyticsRefreshBtn = document.getElementById("analyticsRefreshBtn");
    if (analyticsRefreshBtn) analyticsRefreshBtn.onclick = refreshAnalyticsManual;

    if (els.statusFilter) {
      els.statusFilter.onchange = function () {
        if (state.activeTab === "trades") renderTradesTable();
      };
    }
    if (els.closeReasonFilter) {
      els.closeReasonFilter.onchange = function () {
        if (state.activeTab === "trades") renderTradesTable();
      };
    }
    if (els.setupFilter) {
      els.setupFilter.onchange = function () {
        if (state.activeTab === "trades") renderTradesTable();
      };
    }
    if (els.searchInput) {
      els.searchInput.addEventListener("input", function () {
        if (searchTimer) clearTimeout(searchTimer);
        searchTimer = setTimeout(function () {
          if (state.activeTab === "trades") renderTradesTable();
        }, 150);
      });
    }

    if (els.viewMode) {
      els.viewMode.onchange = function () {
        var v = String(els.viewMode.value || "flat");
        if (v !== "day" && v !== "session") v = "flat";
        state.tradesViewMode = v;
        if (state.activeTab === "trades") renderTradesTable();
      };
    }

    if (els.dateField) {
      els.dateField.onchange = function () {
        state.tradesDateField = els.dateField.value === "close_time" ? "close_time" : "open_time";
        if (state.activeTab === "trades") renderTradesTable();
      };
    }
    if (els.dateFrom) {
      els.dateFrom.onchange = function () {
        state.tradesDateFrom = els.dateFrom.value || "";
        if (state.activeTab === "trades") renderTradesTable();
      };
    }
    if (els.dateTo) {
      els.dateTo.onchange = function () {
        state.tradesDateTo = els.dateTo.value || "";
        if (state.activeTab === "trades") renderTradesTable();
      };
    }
    if (els.dateClear) {
      els.dateClear.onclick = function () {
        state.tradesDateField = "open_time";
        state.tradesDateFrom = "";
        state.tradesDateTo = "";
        syncTradesDateFilterUiFromState();
        if (state.activeTab === "trades") renderTradesTable();
      };
    }

    if (els.newsStatusButtons && els.newsStatusButtons.length) {
      for (var n = 0; n < els.newsStatusButtons.length; n++) {
        els.newsStatusButtons[n].addEventListener("click", function (event) {
          var status = normalizeNewsStatus(event.currentTarget.getAttribute("data-news-status"));
          state.newsFilters.status = status;
          syncNewsFilterUiFromState();
          refreshNewsData(true);
        });
      }
    }
    if (els.newsDateFrom) {
      els.newsDateFrom.onchange = function () {
        state.newsFilters.from = els.newsDateFrom.value || "";
        refreshNewsData(true);
      };
    }
    if (els.newsDateTo) {
      els.newsDateTo.onchange = function () {
        state.newsFilters.to = els.newsDateTo.value || "";
        refreshNewsData(true);
      };
    }
    if (els.newsCurrencyInput) {
      var applyNewsCurrency = function () {
        state.newsFilters.currency = normalizeNewsCurrencyCsv(els.newsCurrencyInput.value || "");
        if (els.newsCurrencyInput) els.newsCurrencyInput.value = state.newsFilters.currency;
        refreshNewsData(true);
      };
      els.newsCurrencyInput.addEventListener("blur", applyNewsCurrency);
      els.newsCurrencyInput.addEventListener("keydown", function (ev) {
        if ((ev.key || ev.keyCode) === "Enter" || (ev.key || ev.keyCode) === 13) {
          ev.preventDefault();
          applyNewsCurrency();
        }
      });
    }
    if (els.newsMinImportance) {
      els.newsMinImportance.onchange = function () {
        state.newsFilters.minImportance = normalizeNewsImportance(els.newsMinImportance.value);
        refreshNewsData(true);
      };
    }
    if (els.newsRefreshBtn) {
      els.newsRefreshBtn.onclick = function () {
        refreshNewsData(true);
      };
    }
    if (els.newsLoadMoreBtn) {
      els.newsLoadMoreBtn.onclick = function () {
        loadMoreNews();
      };
    }
    if (els.newsTableBody) {
      els.newsTableBody.onclick = function (event) {
        event = event || window.event;
        var target = event.target || event.srcElement;
        var row = findNewsRow(target);
        if (!row) return;
        var uid = row.getAttribute("data-news-uid");
        if (!uid) return;
        state.newsExpandedUid = state.newsExpandedUid === uid ? null : uid;
        renderNewsTable();
      };
    }

    if (els.tradesTableBody) {
      els.tradesTableBody.onclick = function (event) {
        event = event || window.event;
        var target = event.target || event.srcElement;

        var toggle = findGroupToggle(target);
        if (toggle) {
          var mode = toggle.getAttribute("data-group-mode") || state.tradesViewMode || "flat";
          var key = toggle.getAttribute("data-group-key") || "Unknown";
          toggleTradesGroupOpen(mode, key);
          renderTradesTable();
          return;
        }

        var btn = findDeleteButton(target);
        if (btn) {
          deleteOneTrade(btn.getAttribute("data-id"), btn.getAttribute("data-ticket"));
          return;
        }

        var row = findTradeRow(target);
        if (row) {
          var tradeId = row.getAttribute("data-trade-id");
          if (tradeId) openTradeModal(tradeId);
          return;
        }
      };
    }

    // Trades sorting (Open Time / Close Time)
    var sortHeaders = document.querySelectorAll("[data-sort-col]");
    for (var i = 0; i < sortHeaders.length; i++) {
      (function (th) {
        var col = th.getAttribute("data-sort-col");
        th.addEventListener("click", function () {
          cycleTradesSort(col);
          if (state.activeTab === "trades") renderTradesTable();
        });
        th.addEventListener("keydown", function (ev) {
          var k = ev.key || ev.keyCode;
          if (k === "Enter" || k === " " || k === 13 || k === 32) {
            ev.preventDefault();
            cycleTradesSort(col);
            if (state.activeTab === "trades") renderTradesTable();
          }
        });
      })(sortHeaders[i]);
    }
    updateTradesSortIndicators();
    syncTradesDateFilterUiFromState();
    syncTradesViewModeUiFromState();
    syncNewsFilterUiFromState();

    if (els.copyLogsBtn && els.sysLogs) {
      els.copyLogsBtn.onclick = function () {
        copySystemLogs();
      };
    }

    if (els.orchRefreshBtn) {
      els.orchRefreshBtn.onclick = function () {
        refreshOrchPanel();
      };
    }
    if (els.orchSaveBtn) {
      els.orchSaveBtn.onclick = function () {
        saveOrchConfig();
      };
    }
    if (els.orchApiKeyInput) {
      var persistOrchKeyInput = function () {
        persistOrchApiKey(els.orchApiKeyInput.value);
      };
      els.orchApiKeyInput.addEventListener("change", persistOrchKeyInput);
      els.orchApiKeyInput.addEventListener("blur", persistOrchKeyInput);
    }
    if (els.orchDecisionsBody) {
      els.orchDecisionsBody.onclick = function (event) {
        var node = event.target;
        while (node && node !== els.orchDecisionsBody && !node.getAttribute("data-orch-decision-key")) {
          node = node.parentNode;
        }
        if (!node || node === els.orchDecisionsBody) return;
        var key = node.getAttribute("data-orch-decision-key");
        if (!hasValue(key)) return;
        if (state.orchPanel.expandedDecisionKey === key) {
          state.orchPanel.expandedDecisionKey = null;
        } else {
          state.orchPanel.expandedDecisionKey = key;
        }
        renderOrchDecisionsTable();
      };
    }

    bindMarketWatchEvents();
    initChartModal();
    initTradeModal();
    initNotesModal();
    initCalcModal();
    ensureSystemLogButtons();
  }

  function copyToClipboard(text) {
    return new Promise(function (resolve) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard
          .writeText(text)
          .then(function () {
            resolve(true);
          })
          .catch(function () {
            resolve(fallbackCopy(text));
          });
        return;
      }
      resolve(fallbackCopy(text));
    });
  }

  function fallbackCopy(text) {
    var textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "absolute";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);
    textarea.select();
    var ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (err) {
      ok = false;
    }
    document.body.removeChild(textarea);
    return ok;
  }

  function buildLogCopyLines(logs) {
    var out = [];
    if (!Array.isArray(logs)) return out;
    for (var i = 0; i < logs.length; i++) {
      var item = logs[i];
      if (item === null || item === undefined) continue;
      if (typeof item === "object") {
        try {
          out.push(JSON.stringify(item, null, 2));
        } catch (err) {
          out.push(String(item));
        }
      } else {
        out.push(String(item));
      }
    }
    return out;
  }

  function flashButtonLabel(btn, label, ms) {
    if (!btn) return;
    var original = btn.getAttribute("data-label") || btn.textContent;
    btn.setAttribute("data-label", original);
    btn.textContent = label;
    if (state.copyLogsTimer) clearTimeout(state.copyLogsTimer);
    state.copyLogsTimer = setTimeout(function () {
      btn.textContent = original;
    }, ms || 1200);
  }

  function copySystemLogs() {
    var lines = Array.isArray(state.systemLogDisplayLines) ? state.systemLogDisplayLines : [];
    var text = lines.join("\n");
    if (!hasValue(text) && els.sysLogs) {
      text = els.sysLogs.textContent || "";
    }
    if (!hasValue(text)) text = "";
    var btn = els.copyLogsBtn || document.getElementById("copyLogsBtn");
    copyToClipboard(text).then(function (ok) {
      if (ok) {
        flashButtonLabel(btn, "Copied", 1200);
      } else {
        flashButtonLabel(btn, "Copy failed", 1400);
      }
    });
  }

  function clearSystemLogs() {
    var confirmed = window.confirm("Clear System Logs?");
    if (!confirmed) return;
    requestJsonWithBody("POST", "/logs/clear", {}, function (err, data) {
      if (err || !data || data.ok !== true) {
        console.warn("Clear logs failed", err || data);
        return;
      }
      var clearedMs = Date.parse(data.cleared_at || "");
      if (isNaN(clearedMs)) clearedMs = Date.now();
      if (!state.systemStatus) state.systemStatus = {};
      state.systemStatus.logs = [];
      state.systemLogDisplayLines = [];
      state.systemLogsCleared = true;
      state.systemLogsClearedAt = clearedMs;
      state.systemLogLastKey = null;
      state.systemLogLastTs = null;
      state.systemLogHighlightKey = null;
      state.systemLogHighlightUntil = 0;
      if (state.systemLogHighlightTimer) {
        clearTimeout(state.systemLogHighlightTimer);
        state.systemLogHighlightTimer = null;
      }
      renderSystemLogs([]);
    });
  }

  /* ── Session Badge ───────────────────────────────────────── */
  var SESSION_CLASSES = ["sess-asia", "sess-london", "sess-overlap", "sess-ny"];

  function getSessionInfoUtc(now) {
    if (!now) now = new Date();
    var h = now.getUTCHours();
    var m = now.getUTCMinutes();
    var t = h * 60 + m;
    // Ranges in UTC minutes: ASIA 22:00-07:00, LONDON 07:00-12:00, OVERLAP 12:00-16:00, NY 16:00-22:00
    if (t >= 1320 || t < 420) {
      return { key: "asia", label: "ASIA", range: "22:00 – 07:00 UTC", cls: "sess-asia" };
    }
    if (t >= 420 && t < 720) {
      return { key: "london", label: "LONDON", range: "07:00 – 12:00 UTC", cls: "sess-london" };
    }
    if (t >= 720 && t < 960) {
      return { key: "overlap", label: "LONDON \u2194 NY", range: "12:00 – 16:00 UTC", cls: "sess-overlap" };
    }
    return { key: "ny", label: "NEW YORK", range: "16:00 – 22:00 UTC", cls: "sess-ny" };
  }

  function updateSessionBadge() {
    try {
      var badge = document.getElementById("sessionBadge");
      var valueEl = document.getElementById("sessionValue");
      if (!badge || !valueEl) return;
      var now = new Date();
      var info = getSessionInfoUtc(now);
      valueEl.textContent = info.label;
      for (var i = 0; i < SESSION_CLASSES.length; i++) {
        badge.classList.remove(SESSION_CLASSES[i]);
      }
      badge.classList.add(info.cls);
      var hh = String(now.getUTCHours()).length < 2 ? "0" + now.getUTCHours() : String(now.getUTCHours());
      var mm = String(now.getUTCMinutes()).length < 2 ? "0" + now.getUTCMinutes() : String(now.getUTCMinutes());
      badge.title = info.label + "  (" + info.range + ")\nNow: " + hh + ":" + mm + " UTC";
    } catch (e) {
      var fallback = document.getElementById("sessionValue");
      if (fallback) fallback.textContent = "\u2014";
    }
  }

  function initApp() {
    cacheEls();
    neutralizeOverlays();
    initTabs();
    // Default analytics scope: last 7 days (UTC), so empty states are "in selected period" instead of "no trades yet".
    if (!normalizeRange(state.analyticsRange)) {
      state.analyticsRange = defaultAnalyticsRangeLast7Utc();
    }
    window.addEventListener("resize", function () {
      requestAnimationFrame(updateTabUnderline);
      if (state.activeTab === "analytics") {
        var keys = ["equity", "drawdown", "winHour", "dist", "dailyPl"];
        for (var k = 0; k < keys.length; k++) {
          if (_apexCharts[keys[k]]) {
            try { _apexCharts[keys[k]].resize(); } catch (e) {}
          }
        }
      }
      if (state.activeTab === "marketwatch") {
        resizeMarketWatchChart();
      }
    });
    bindEvents();
    syncOrchApiKeyInputFromStorage();
    applyOrchConfigToControls(state.orchPanel.config || normalizeOrchConfig(null));
    renderOrchPanel();
    refreshData();
    refreshRiskData();
    setInterval(refreshData, 5000);
    resetSystemStatusTimer();
    setInterval(refreshRiskData, 5000);
    updateSessionBadge();
    setInterval(updateSessionBadge, 30000);
  }

  function safeInit() {
    try {
      initApp();
      console.log("INIT OK");
      setJsStatus("OK");
    } catch (e) {
      console.error("INIT FAILED", e);
      setJsStatus("FAIL");
      showFatalError(e);
    }
  }

  window.addEventListener("DOMContentLoaded", safeInit);
})();
