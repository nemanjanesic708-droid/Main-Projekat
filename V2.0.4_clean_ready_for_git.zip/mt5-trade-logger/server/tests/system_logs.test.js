const assert = require("assert");

function hasValue(value) {
  return !(value === null || value === undefined || (typeof value === "string" && value.trim() === ""));
}

function parseTradeDate(value) {
  if (!hasValue(value)) return null;
  var raw = String(value).trim();
  var normalized = raw.replace(/\./g, "-").replace("T", " ");
  if (normalized.length === 16) normalized += ":00";
  var parsed = new Date(normalized);
  if (!isNaN(parsed.getTime())) return parsed;
  return null;
}

function parseLogTimestamp(value) {
  if (!hasValue(value)) return null;
  var raw = String(value).trim();
  if (!raw) return null;
  var cleaned = raw.replace(",", ".");
  if (cleaned.indexOf("T") === -1 && cleaned.indexOf(" ") >= 0) {
    cleaned = cleaned.replace(" ", "T");
  }
  var parsed = new Date(cleaned);
  if (!isNaN(parsed.getTime())) return parsed;
  var noMs = raw.split(",")[0];
  return parseTradeDate(noMs);
}

function classifyLog(log) {
  var path = hasValue(log.path) ? String(log.path) : "";
  var rawText = hasValue(log.rawText) ? String(log.rawText) : "";
  var pathLower = path.toLowerCase();
  var rawLower = stripAnsi(rawText).toLowerCase();
  var eventType = hasValue(log.event_type) ? String(log.event_type).toLowerCase() : "";

  var isPreTrade = eventType.indexOf("pre_trade") >= 0
    || eventType.indexOf("pretrade") >= 0
    || pathLower.indexOf("/pre_trade") >= 0
    || pathLower.indexOf("pretrade") >= 0
    || rawLower.indexOf("/pre_trade") >= 0
    || rawLower.indexOf("pre_trade") >= 0
    || rawLower.indexOf("pretrade") >= 0;
  if (isPreTrade) {
    if (log.allow === true) return { severity: "success", label: "ALLOW" };
    if (log.allow === false) return { severity: "danger", label: "DENY" };
    return { severity: "neutral", label: "PRE_TRADE" };
  }

  var isHeartbeat = eventType.indexOf("heartbeat") >= 0
    || pathLower.indexOf("/health") >= 0
    || rawLower.indexOf("/health") >= 0
    || rawLower.indexOf("heartbeat") >= 0;
  if (isHeartbeat) return { severity: "neutral", label: "HEARTBEAT" };

  var isTradeOpenMarker = rawLower.indexOf("trade_open ok") >= 0 || rawLower.indexOf("trade open ok") >= 0;
  var isTradeCloseMarker = rawLower.indexOf("trade_close ok") >= 0 || rawLower.indexOf("trade close ok") >= 0;
  var isTradeOpenPath = pathLower.indexOf("/trades/add") >= 0
    || pathLower.indexOf("/trade/open") >= 0
    || pathLower.indexOf("/trade_open") >= 0
    || pathLower.indexOf("/v1/trade_open") >= 0;
  var isTradeClosePath = pathLower.indexOf("/trades/close") >= 0
    || pathLower.indexOf("/trade/close") >= 0
    || pathLower.indexOf("/trade_close") >= 0
    || pathLower.indexOf("/v1/trade_close") >= 0;

  if (isTradeOpenMarker) return { severity: "success", label: "OPEN" };
  if (isTradeCloseMarker) return { severity: "success", label: "CLOSE" };

  if (isTradeOpenPath || isTradeClosePath) {
    var st = typeof log.status === "number" ? log.status : null;
    if (st !== null && st >= 400) return { severity: "danger", label: isTradeOpenPath ? "OPEN" : "CLOSE" };
    if (st !== null && st >= 200 && st < 300) return { severity: "success", label: isTradeOpenPath ? "OPEN" : "CLOSE" };
    return { severity: "neutral", label: isTradeOpenPath ? "OPEN" : "CLOSE" };
  }

  if (typeof log.status === "number" && log.status >= 400) {
    var errLabel = hasValue(log.endpoint) ? String(log.endpoint) : "HTTP_ERROR";
    return { severity: "danger", label: errLabel };
  }

  var label = hasValue(log.endpoint) ? String(log.endpoint) : "LOG";
  return { severity: "neutral", label: label };
}

function stripAnsi(text) {
  if (!hasValue(text)) return text;
  try {
    return String(text).replace(/\u001b\[[0-9;]*m/g, "");
  } catch (e) {
    return String(text);
  }
}

function filterLogsAfterBaseline(logs, baselineMs) {
  if (!Array.isArray(logs) || !baselineMs) return logs;
  var out = [];
  for (var i = 0; i < logs.length; i++) {
    var ts = parseLogTimestamp(logs[i].timestamp || logs[i].time || logs[i].ts || null);
    if (!ts) continue;
    if (ts.getTime() >= baselineMs) out.push(logs[i]);
  }
  return out;
}

function sortEntriesByTimestamp(entries) {
  if (!Array.isArray(entries)) return entries;
  return entries.slice().sort(function (a, b) {
    var ta = parseLogTimestamp((a && (a.lastSeenAt || (a.normalized && a.normalized.timestamp))) || null);
    var tb = parseLogTimestamp((b && (b.lastSeenAt || (b.normalized && b.normalized.timestamp))) || null);
    if (ta && tb) return tb.getTime() - ta.getTime();
    if (ta && !tb) return -1;
    if (!ta && tb) return 1;
    return 0;
  });
}

// --- Tests ---
// Mapping event_type -> severity/color
{
  const allow = classifyLog({ event_type: "pre_trade", allow: true });
  assert.strictEqual(allow.severity, "success");
  assert.strictEqual(allow.label, "ALLOW");

  const deny = classifyLog({ path: "/pre_trade", allow: false });
  assert.strictEqual(deny.severity, "danger");
  assert.strictEqual(deny.label, "DENY");

  const hb = classifyLog({ event_type: "heartbeat" });
  assert.strictEqual(hb.severity, "neutral");
  assert.strictEqual(hb.label, "HEARTBEAT");
}

// Trade endpoints + explicit OK markers
{
  const openOk = classifyLog({ path: "/trades/add", status: 201, endpoint: "POST /trades/add" });
  assert.strictEqual(openOk.severity, "success");
  assert.strictEqual(openOk.label, "OPEN");

  const closeOk = classifyLog({ path: "/trades/close", status: 200, endpoint: "POST /trades/close" });
  assert.strictEqual(closeOk.severity, "success");
  assert.strictEqual(closeOk.label, "CLOSE");

  const openFail = classifyLog({ path: "/trades/add", status: 400, endpoint: "POST /trades/add" });
  assert.strictEqual(openFail.severity, "danger");

  const marker = classifyLog({ rawText: "2026-02-09 12:00:00,000 [INFO] trade_logger: TRADE_OPEN OK trade_uid=x pos_id=1 ticket=2" });
  assert.strictEqual(marker.severity, "success");
  assert.strictEqual(marker.label, "OPEN");
}

// Clear baseline filter
{
  const logs = [
    { timestamp: "2026-02-06T10:00:00Z" },
    { timestamp: "2026-02-06T10:00:02Z" },
  ];
  const baseline = Date.parse("2026-02-06T10:00:01Z");
  const filtered = filterLogsAfterBaseline(logs, baseline);
  assert.strictEqual(filtered.length, 1);
  assert.strictEqual(filtered[0].timestamp, "2026-02-06T10:00:02Z");
}

// Sorting by timestamp (desc)
{
  const entries = [
    { normalized: { timestamp: "2026-02-06T10:00:00Z" } },
    { normalized: { timestamp: "2026-02-06T10:00:05Z" } },
    { normalized: { timestamp: "2026-02-06T09:59:59Z" } },
  ];
  const sorted = sortEntriesByTimestamp(entries);
  assert.strictEqual(sorted[0].normalized.timestamp, "2026-02-06T10:00:05Z");
  assert.strictEqual(sorted[2].normalized.timestamp, "2026-02-06T09:59:59Z");
}

console.log("system_logs.test.js: OK");
