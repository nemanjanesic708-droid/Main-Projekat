"""
Dodaje nove trejdove u bazu i pravi backup
"""
import sqlite3
from datetime import datetime
from auto_backup import create_backup

DB_PATH = 'database/trades.db'

def add_new_trades():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Novi trejdovi
    new_trades = [
        (361227903, 'EURUSD', 0.28, 'BUY', '2025-12-03 15:18:50', 1.16735, 
         '2025-12-03 16:03:19', 1.16631, -24.97, 'CLOSED'),
        
        (361159901, 'EURUSD', 0.36, 'BUY', '2025-12-03 12:13:14', 1.16543, 
         '2025-12-03 15:18:00', 1.16728, 57.00, 'CLOSED'),
        
        (360659074, 'EURUSD', 0.34, 'BUY', '2025-12-02 14:00:00', 1.16119, 
         '2025-12-02 17:11:02', 1.16059, -17.58, 'CLOSED'),
    ]
    
    for trade in new_trades:
        try:
            cursor.execute('''
                INSERT INTO trades (ticket, symbol, lot_size, direction, open_time, open_price,
                                  close_time, close_price, profit, status, stop_loss, take_profit, 
                                  magic_number, comment)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, '')
            ''', trade)
            print(f"✓ Dodato: #{trade[0]} {trade[1]} {trade[3]} profit={trade[8]}")
        except sqlite3.IntegrityError:
            print(f"⚠ Trejd #{trade[0]} već postoji")
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ Dodato {len(new_trades)} novih trejdova!")
    
    # Kreiraj backup nakon dodavanja
    print("\n📦 Kreiranje backup-a...")
    create_backup()

if __name__ == "__main__":
    add_new_trades()
