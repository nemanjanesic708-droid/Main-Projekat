import os
import sqlite3
from datetime import datetime, timedelta, timezone


PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(PROJECT_ROOT, "database", "trades.db")
DT_FORMAT = "%Y-%m-%d %H:%M:%S"


def ensure_schema(cursor):
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS economic_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_uid TEXT NOT NULL UNIQUE,
            time_utc TEXT NOT NULL,
            currency TEXT NOT NULL,
            title TEXT NOT NULL,
            importance INTEGER NOT NULL DEFAULT 0,
            actual TEXT,
            forecast TEXT,
            previous TEXT,
            status TEXT NOT NULL DEFAULT 'upcoming',
            source TEXT NOT NULL DEFAULT 'mt5_calendar',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )


def main():
    now = datetime.now(timezone.utc).replace(microsecond=0)
    sample = [
        {
            "event_uid": f"seed:usd_cpi:{int((now + timedelta(hours=2)).timestamp())}",
            "time_utc": (now + timedelta(hours=2)).strftime(DT_FORMAT),
            "currency": "USD",
            "title": "US CPI (YoY)",
            "importance": 2,
            "actual": None,
            "forecast": "3.1",
            "previous": "3.3",
            "status": "upcoming",
        },
        {
            "event_uid": f"seed:eur_ecb:{int((now - timedelta(hours=3)).timestamp())}",
            "time_utc": (now - timedelta(hours=3)).strftime(DT_FORMAT),
            "currency": "EUR",
            "title": "ECB Rate Decision",
            "importance": 2,
            "actual": "4.50",
            "forecast": "4.50",
            "previous": "4.50",
            "status": "released",
        },
        {
            "event_uid": f"seed:gbp_gdp:{int((now + timedelta(days=1)).timestamp())}",
            "time_utc": (now + timedelta(days=1)).strftime(DT_FORMAT),
            "currency": "GBP",
            "title": "UK GDP (QoQ)",
            "importance": 1,
            "actual": None,
            "forecast": "0.2",
            "previous": "0.1",
            "status": "upcoming",
        },
    ]

    rows = [
        (
            item["event_uid"],
            item["time_utc"],
            item["currency"],
            item["title"],
            item["importance"],
            item["actual"],
            item["forecast"],
            item["previous"],
            item["status"],
            "seed_script",
        )
        for item in sample
    ]

    with sqlite3.connect(DB_PATH, timeout=10) as conn:
        cursor = conn.cursor()
        ensure_schema(cursor)
        cursor.executemany(
            """
            INSERT INTO economic_events (
                event_uid,
                time_utc,
                currency,
                title,
                importance,
                actual,
                forecast,
                previous,
                status,
                source,
                updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(event_uid) DO UPDATE SET
                time_utc = excluded.time_utc,
                currency = excluded.currency,
                title = excluded.title,
                importance = excluded.importance,
                actual = excluded.actual,
                forecast = excluded.forecast,
                previous = excluded.previous,
                status = excluded.status,
                source = excluded.source,
                updated_at = CURRENT_TIMESTAMP
            """,
            rows,
        )
        conn.commit()

    print(f"Seeded {len(rows)} economic events into {DB_PATH}")


if __name__ == "__main__":
    main()
