import sqlite3

DB_PATH = 'C:/Users/XEON/Desktop/mt5-trade-logger/database/trades.db'

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# Dodaj test trejdove
test_trades = [
    (123456, "EURUSD", 0.1, "BUY", "2025-12-03 10:00:00", 1.08500, "2025-12-03 11:00:00", 1.08750, 25.00, "CLOSED", 1.08000, 1.09000, 12345, "Test 1"),
    (123457, "GBPUSD", 0.2, "SELL", "2025-12-03 12:00:00", 1.27500, "2025-12-03 13:00:00", 1.27300, 40.00, "CLOSED", 1.28000, 1.27000, 12345, "Test 2"),
    (123458, "USDJPY", 0.15, "BUY", "2025-12-03 14:00:00", 150.50, "2025-12-03 15:00:00", 150.20, -15.00, "CLOSED", 150.00, 151.00, 12345, "Test 3"),
    (123459, "EURJPY", 0.1, "SELL", "2025-12-03 16:00:00", 162.50, None, None, None, "OPEN", 163.00, 162.00, 12345, "Test 4"),
    (123460, "AUDUSD", 0.3, "BUY", "2025-12-03 08:00:00", 0.65500, "2025-12-03 09:00:00", 0.65300, -30.00, "CLOSED", 0.65000, 0.66000, 12345, "Test 5"),
]

for trade in test_trades:
    try:
        cursor.execute('''
            INSERT INTO trades 
            (ticket, symbol, lot_size, direction, open_time, open_price, 
             close_time, close_price, profit, status, stop_loss, take_profit, 
             magic_number, comment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', trade)
    except:
        print(f"Trejd {trade[0]} već postoji ili greška")

conn.commit()
conn.close()

print("Test podaci dodati u bazu!")
