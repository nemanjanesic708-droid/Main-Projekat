import sqlite3

DB_PATH = 'database/trades.db'

# Ručno ažuriranje za nove tikete
manual_update = {
    362449373: {
        'symbol': 'EURUSD',
        'lot_size': 0.28,
        'direction': 'Buy',
        'close_time': '2025.12.10 19:52:35',
        'close_price': 1.16588,
        'profit': 58.12,
        'status': 'CLOSED'
    },
    362508648: {
        'symbol': 'EURUSD',
        'lot_size': 0.12,
        'direction': 'Buy',
        'close_time': '2025.12.10 21:59:26',
        'close_price': 1.16779,
        'profit': 18.60,
        'status': 'CLOSED'
    }
}

for ticket, data in manual_update.items():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE trades
        SET status = ?, symbol = ?, lot_size = ?, direction = ?, close_time = ?, close_price = ?, profit = ?
        WHERE ticket = ?
    ''', (data['status'], data['symbol'], data['lot_size'], data['direction'], data['close_time'], data['close_price'], data['profit'], ticket))
    conn.commit()
    conn.close()
    print(f"✓ Trejd #{ticket} ručno ažuriran u bazi.")
import sqlite3

DB_PATH = 'database/trades.db'

# Tiketi koje želiš da zatvoriš (svi osim 362449373)
tickets_to_close = [
    362423179,
    362291000,
    362278702,
    362111831
]

conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

for ticket in tickets_to_close:

    # Ručno definisani podaci za svaki tiket

    trade_data = {
        362111831: {
            'symbol': 'EURUSD',
            'lot_size': 0.27,
            'direction': 'Buy',
            'close_time': '2025.12.08 16:51:31',
            'profit': -25.50,
            'status': 'CLOSED'
        },
        362278702: {
            'symbol': 'EURUSD',
            'lot_size': 0.31,
            'direction': 'Buy',
            'close_time': '2025.12.09 10:07:13',
            'profit': -26.38,
            'status': 'CLOSED'
        },
        362291000: {
            'symbol': 'EURUSD',
            'lot_size': 0.34,
            'direction': 'Buy',
            'close_time': '2025.12.09 14:07:39',
            'profit': -25.42,
            'status': 'CLOSED'
        },
        362423179: {
            'symbol': 'EURUSD',
            'lot_size': 0.31,
            'direction': 'Buy',
            'close_time': '2025.12.10 10:35:18',
            'profit': 50.80,
            'status': 'CLOSED'
        }
    }

    data = trade_data[ticket]
    # Closed price podaci
    closed_prices = {
        362111831: 1.16450,
        362278702: 1.16341,
        362291000: 1.16360,
        362423179: 1.16548
    }

    cursor.execute('''
        UPDATE trades
        SET status = ?, symbol = ?, lot_size = ?, direction = ?, close_time = ?, profit = ?, close_price = ?
        WHERE ticket = ?
    ''', (data['status'], data['symbol'], data['lot_size'], data['direction'], data['close_time'], data['profit'], closed_prices[ticket], ticket))
    print(f"✓ Trejd #{ticket} ručno ažuriran u bazi.")

conn.commit()
conn.close()
print("✅ Svi odabrani trejdovi su zatvoreni u bazi.")
