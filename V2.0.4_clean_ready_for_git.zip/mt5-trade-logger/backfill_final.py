# -*- coding: utf-8 -*-
"""
Finalni Brzi Backfill - Ubaci samo 6 missing trade-ova iz 8.-9. Jana
"""

import sqlite3
import openpyxl

DB_PATH = 'database/trades.db'
XLSX_PATH = r'C:\mnt\data\ReportHistory-1512255861.xlsx'

# 6 Missing trade-ova (ispravljeni podaci)
MISSING_TRADES = [
    {
        'open_time': '2026.01.08 13:15:00',
        'symbol': 'EURUSD',
        'lot_size': 0.46,
        'direction': 'SELL',
        'open_price': 1.16764,
        'close_time': '2026.01.08 15:48:07',
        'close_price': 1.16623,
        'stop_loss': 1.16828,
        'take_profit': 1.16624,
        'profit': 55.62
    },
    {
        'open_time': '2026.01.08 15:48:07',
        'symbol': 'EURUSD',
        'lot_size': 0.53,
        'direction': 'SELL',
        'open_price': 1.16622,
        'close_time': '2026.01.08 17:12:42',
        'close_price': 1.16677,
        'stop_loss': 1.16724,
        'take_profit': 1.16475,
        'profit': -24.98
    },
    {
        'open_time': '2026.01.08 17:48:13',
        'symbol': 'EURUSD',
        'lot_size': 0.37,
        'direction': 'SELL',
        'open_price': 1.16650,
        'close_time': '2026.01.08 19:29:34',
        'close_price': 1.16475,
        'stop_loss': 1.16723,
        'take_profit': 1.16387,
        'profit': 55.59
    },
    {
        'open_time': '2026.01.09 07:00:00',
        'symbol': 'EURUSD',
        'lot_size': 0.68,
        'direction': 'SELL',
        'open_price': 1.16543,
        'close_time': '2026.01.09 09:18:47',
        'close_price': 1.16446,
        'stop_loss': 1.16609,
        'take_profit': 1.16268,
        'profit': 56.64
    },
    {
        'open_time': '2026.01.09 09:20:53',
        'symbol': 'EURUSD',
        'lot_size': 0.75,
        'direction': 'SELL',
        'open_price': 1.16434,
        'close_time': '2026.01.09 09:57:36',
        'close_price': 1.16474,
        'stop_loss': 1.16531,
        'take_profit': 1.16175,
        'profit': -25.76
    },
    {
        'open_time': '2026.01.09 11:20:57',
        'symbol': 'EURUSD',
        'lot_size': 0.45,
        'direction': 'SELL',
        'open_price': 1.16456,
        'close_time': '2026.01.09 15:30:08',
        'close_price': 1.16307,
        'stop_loss': 1.16551,
        'take_profit': 1.16142,
        'profit': 57.65
    }
]

def main():
    print("="*80)
    print("FINALNI BACKFILL - 6 MISSING TRADE-OVA")
    print("="*80)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Pronađi max ticket i max trade_index
    cursor.execute("SELECT COALESCE(MAX(ticket), 0) FROM trades")
    max_ticket = cursor.fetchone()[0]
    
    cursor.execute("SELECT COALESCE(MAX(trade_index), 0) FROM trades")
    max_idx = cursor.fetchone()[0]
    
    print(f"\n[1] Pronašao max ticket: {max_ticket}, max trade_index: {max_idx}")
    
    # Pronađi template red
    cursor.execute("SELECT * FROM trades ORDER BY id LIMIT 1")
    template_cols = [d[0] for d in cursor.description]
    template_vals = cursor.fetchone()
    template = dict(zip(template_cols, template_vals))
    
    print(f"[2] Kreiram template sa {len(template)} polja")
    
    # Počni transakciju
    cursor.execute("BEGIN TRANSACTION")
    
    try:
        # Prebrojim PRE
        cursor.execute("SELECT COUNT(*), COALESCE(SUM(profit), 0) FROM trades")
        count_before, profit_before = cursor.fetchone()
        
        print(f"\n[3] PRE backfill-a: {count_before} trade-ova, profit: {profit_before:.2f}")
        
        # Ubacim sve 6 trade-ova
        total_inserted = 0
        for i, mt in enumerate(MISSING_TRADES):
            new_ticket = max_ticket + i + 1
            new_idx = max_idx + i + 1
            
            # Pripremi red sa template vrednostima
            row = template.copy()
            
            # Prebriši core polja
            row['id'] = None  # Auto-increment
            row['ticket'] = new_ticket
            row['trade_index'] = new_idx
            row['symbol'] = mt['symbol']
            row['lot_size'] = mt['lot_size']
            row['direction'] = mt['direction']
            row['open_time'] = mt['open_time']
            row['open_price'] = mt['open_price']
            row['close_time'] = mt['close_time']
            row['close_price'] = mt['close_price']
            row['profit'] = mt['profit']
            row['status'] = 'CLOSED'
            row['stop_loss'] = mt['stop_loss']
            row['take_profit'] = mt['take_profit']
            row['entry_price'] = mt['open_price']
            row['exit_price'] = mt['close_price']
            row['timestamp'] = mt['open_time']
            row['setup_result'] = 'win' if mt['profit'] > 0 else 'loss'
            row['exit_reason'] = 'take_profit' if mt['profit'] > 0 else 'stop_loss'
            row['profit_r'] = mt['profit'] / 10.0
            row['comment'] = f"Backfill from MT5 report (missing trade #{i+1})"
            row['created_at'] = None  # Current timestamp
            
            # Napravi SQL - samo kolone koje su ne-None
            cols = []
            vals = []
            for col, val in row.items():
                if val is not None or col == 'id' or col == 'created_at':
                    cols.append(col)
                    vals.append(val)
            
            placeholders = ','.join(['?'] * len(cols))
            sql = f"INSERT INTO trades ({','.join(cols)}) VALUES ({placeholders})"
            
            cursor.execute(sql, vals)
            total_inserted += 1
            print(f"    ✓ Trade {i+1}: {mt['open_time'][:10]:10s} | {mt['symbol']:6s} | Profit: {mt['profit']:7.2f}")
        
        # Prebrojim POSLE
        cursor.execute("SELECT COUNT(*), COALESCE(SUM(profit), 0) FROM trades")
        count_after, profit_after = cursor.fetchone()
        
        # Verify
        rows_added = count_after - count_before
        profit_added = profit_after - profit_before
        expected_profit = sum(t['profit'] for t in MISSING_TRADES)
        
        print(f"\n[4] POSLE backfill-a: {count_after} trade-ova, profit: {profit_after:.2f}")
        
        if rows_added == 6 and abs(profit_added - expected_profit) < 0.01:
            print(f"\n✓ USPEŠAN BACKFILL!")
            print(f"   Redova ubačeno: {rows_added}")
            print(f"   Profit dodato: {profit_added:.2f} (očekivano {expected_profit:.2f})")
            print(f"   Trade-ovi: {count_before} → {count_after}")
            print(f"   Profit: {profit_before:.2f} → {profit_after:.2f}")
            
            cursor.execute("COMMIT")
            print(f"\n✓ TRANSAKCIJA COMMITTED!")
        else:
            print(f"\n✗ GREŠKA VERIFIK!")
            print(f"   Očekivano 6, ubačeno {rows_added}")
            print(f"   Očekivano +{expected_profit:.2f}, dobijeno +{profit_added:.2f}")
            cursor.execute("ROLLBACK")
            print("   ROLLBACK!")
    
    except Exception as e:
        print(f"\n✗ GREŠKA: {e}")
        cursor.execute("ROLLBACK")
        import traceback
        traceback.print_exc()
    
    conn.close()
    print("\n" + "="*80)

if __name__ == '__main__':
    main()
