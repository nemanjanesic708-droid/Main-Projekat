-- ============================================================================
-- BACKFILL MISSING TRADES - SQL Script
-- ============================================================================
-- 
-- Alternativni pristup: Ako preference ručni SQL umesto Python-a
-- NAPOMENA: Ovo je template; vrednosti se moraju ručno popuniti iz MT5 xlsx-a
--
-- ============================================================================

BEGIN TRANSACTION;

-- Step 1: Proverim broj redova PRE
SELECT COUNT(*) as trades_before FROM trades;

-- Step 2: Proverim sumu profita PRE
SELECT SUM(profit) as profit_before FROM trades;

-- Step 3: Pronađi max trade_index za sekvencijalno dodeljenje
SELECT MAX(trade_index) as max_idx FROM trades;

-- Step 4: Pronađi max ticket
SELECT MAX(ticket) as max_ticket FROM trades;

-- ============================================================================
-- TEMPLATE RED ZA INSERT (koristi prvi red iz baze kao template)
-- ============================================================================

-- Pronađi template red (prvi red)
SELECT * FROM trades LIMIT 1;

-- ============================================================================
-- INSERT MISSING TRADES
-- ============================================================================
-- 
-- Evo 6 missing trade-ova sa hardcodovane vrednostima
-- Zameni TEMPLATE_VALUE_XXX sa stvarnim vrednostima iz MT5 xlsx-a
--

-- Trade #1 (8. Jan)
INSERT INTO trades (
    ticket, symbol, lot_size, direction, open_time, open_price, close_time, close_price,
    profit, status, stop_loss, take_profit, magic_number, trade_index, comment,
    entry_tf, timestamp, day_of_week, hour, session_active,
    ema_fast_20, ema_slow_100, ema_fast_above_slow, ema_fast_slope, ema_slow_slope,
    price_vs_fast_ema, price_vs_slow_ema, trend_direction,
    pullback_ema_20, price_distance_from_pullback_ema, pullback_valid, pullback_depth_pips,
    donchian_high, donchian_low, donchian_range,
    price_vs_don_high, price_vs_don_low, donchian_breakout, don_buffer_pips,
    adx_value, adx_above_min, di_plus, di_minus, trend_strength,
    atr_value, atr_pips, atr_above_min, atr_percent_of_price,
    risk_mode, risk_percent, sl_multiplier, tp_multiplier,
    calculated_sl_pips, calculated_tp_pips, rr_ratio, spread_points, spread_ok,
    one_entry_per_bar_pass, session_hour, session_allowed,
    daily_loss_percent, consecutive_losses, equity_dd_percent,
    risk_block_active, risk_block_reason, signal_type, allow_longs, allow_shorts,
    filters_passed_count, filters_failed_count, final_decision, skip_reason,
    entry_price, bid, ask, bar_time_entry_tf, bar_time_trend_tf,
    exit_price, exit_reason, profit_r, duration_seconds,
    max_floating_profit, max_floating_dd, setup_result, trend_tf
) VALUES (
    8, 'EURUSD', 0.10, 'BUY', '2026-01-08 10:00:00', 1.0850, '2026-01-08 12:00:00', 1.0875,
    25.00, 'CLOSED', 1.0800, 1.0925, 270001, 5, 'Backfill from MT5 (missing trade #1)',
    'H1', '2026-01-08 10:00:00', 'Wednesday', 10, 1,
    1.0850, 1.0820, 1, 0.0001, 0.0001, 0.0, 0.003, 'UPTREND',
    1.0835, 0.0015, 1, 0.5,
    1.0880, 1.0800, 0.008,
    1, -1, 1, 1.5,
    25.0, 1, 15.0, 12.0, 'STRONG',
    0.0050, 5.0, 1, 0.005,
    'PERCENT', 0.25, 1.2, 2.2,
    0.005, 0.011, 2.2, 2.0, 1,
    1, 10, 1,
    2.0, 0, 0.0,
    0, NULL, 'DONCHIAN', 1, 1,
    2, 0, 'TRADE', NULL,
    1.0850, 1.0850, 1.0851, '2026-01-08 10:00', '2026-01-08 10:00',
    1.0875, 'take_profit', 2.50, 7200,
    3.5, 0.2, 'win', 'H4'
);

-- Trade #2 (8. Jan)
-- INSERT INTO trades (...) VALUES (...);

-- Trade #3 (9. Jan)
-- INSERT INTO trades (...) VALUES (...);

-- Trade #4 (9. Jan)
-- INSERT INTO trades (...) VALUES (...);

-- Trade #5 (9. Jan)
-- INSERT INTO trades (...) VALUES (...);

-- Trade #6 (9. Jan)
-- INSERT INTO trades (...) VALUES (...);

-- ============================================================================
-- VERIFIKACIJA
-- ============================================================================

-- Proveri broj redova POSLE
SELECT COUNT(*) as trades_after FROM trades;

-- Proveri sumu profita POSLE
SELECT SUM(profit) as profit_after FROM trades;

-- Pronađi duplikate po ticket-u (trebalo bi biti 0)
SELECT ticket, COUNT(*) as cnt FROM trades GROUP BY ticket HAVING cnt > 1;

-- Prikaži sve nove trade-ove (poslednje 6)
SELECT timestamp, symbol, entry_price, exit_price, profit, setup_result
FROM trades
ORDER BY open_time DESC
LIMIT 6;

-- ============================================================================
-- COMMIT TRANSACTION
-- ============================================================================

COMMIT;

-- Ako bilo šta pođe po zlu, koristi:
-- ROLLBACK;
