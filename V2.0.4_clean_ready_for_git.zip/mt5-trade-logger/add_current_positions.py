"""
Manuelno dodaje trenutno otvorene pozicije u bazu
Koristite ovu skriptu da dodate pozicije koje su vec otvorene
"""
import sqlite3
from datetime import datetime

DB_PATH = 'database/trades.db'

def add_manual_open_positions():
    """Dodaje manuelno otvorene pozicije"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    print("=== Dodavanje trenutno otvorenih pozicija ===\n")
    
    # Unesite vase trenutno otvorene pozicije ovde
    open_positions = [
        {
            'ticket': 361807214,
            'symbol': 'EURUSD',
            'lot_size': 0.34,
            'direction': 'BUY',
            'open_time': '2025-12-05 08:00:00',
            'open_price': 1.16591,
            'stop_loss': 0,
            'take_profit': 0,
            'magic_number': 0,
            'comment': ''
        },
        # Dodajte vise pozicija ovde ako treba
    ]
    
    for pos in open_positions:
        try:
            cursor.execute('''
                INSERT INTO trades (ticket, symbol, lot_size, direction, open_time, open_price,
                                  status, stop_loss, take_profit, magic_number, comment,
                                  close_time, close_price, profit)
                VALUES (?, ?, ?, ?, ?, ?, 'OPEN', ?, ?, ?, ?, NULL, NULL, NULL)
            ''', (pos['ticket'], pos['symbol'], pos['lot_size'], pos['direction'],
                  pos['open_time'], pos['open_price'], pos['stop_loss'], pos['take_profit'],
                  pos['magic_number'], pos['comment']))
            
            print(f"✓ Dodato: #{pos['ticket']} {pos['symbol']} {pos['direction']} {pos['lot_size']}")
        except sqlite3.IntegrityError:
            print(f"⚠ Pozicija #{pos['ticket']} vec postoji u bazi")
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ Procesuirano {len(open_positions)} pozicija!")
    print("\nOsvezite Dashboard da vidite promene!")

if __name__ == "__main__":
    add_manual_open_positions()
