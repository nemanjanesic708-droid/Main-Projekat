import sqlite3


def print_table_info(cursor, table_name):
    print(f"\n=== PRAGMA table_info({table_name}) ===")
    cursor.execute(f"PRAGMA table_info({table_name})")
    rows = cursor.fetchall()
    if not rows:
        print("(table missing or no columns)")
        return
    for row in rows:
        print(row)


conn = sqlite3.connect("database/trades.db")
cur = conn.cursor()

print_table_info(cur, "trades")
print_table_info(cur, "v2_snapshots")
print_table_info(cur, "v2_decisions")

conn.close()
