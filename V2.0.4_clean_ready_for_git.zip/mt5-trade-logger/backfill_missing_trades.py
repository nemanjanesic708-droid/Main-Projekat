# -*- coding: utf-8 -*-
"""
Backfill Missing Trades - Učitaj MT5 xlsx i DB csv, pronađi missing trade-ove i ubaci ih u SQLite bez duplikata.
"""

import pandas as pd
import sqlite3
import os
from datetime import datetime

# Paths
DB_PATH = os.path.join(os.path.dirname(__file__), 'database', 'trades.db')
MT5_XLSX = '/mnt/data/ReportHistory-1512255861.xlsx'  # MT5 report
DB_CSV = '/mnt/data/trades_20260111_112455.csv'       # DB export

def load_mt5_positions():
    """Učita Positions tabelu iz MT5 xlsx fajla"""
    print("[1] Učitavam MT5 xlsx report...")
    try:
        # MT5 report ima custom format - Red 6 je header, Red 7+ su podaci
        df = pd.read_excel(MT5_XLSX, sheet_name=0, header=6)
        
        # Očisti NaN kolone (Unnamed i prazne kolone)
        df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
        df = df.dropna(how='all', axis=1)
        
        # Ukloni redove sa NaN vrednostima u važnim kolonama
        df = df.dropna(subset=['Time', 'Symbol', 'Price'])
        
        # Filtriraj redove - samo oni sa ciframa u Price koloni
        df = df[df['Price'].apply(lambda x: isinstance(x, (int, float)) or (isinstance(x, str) and x.replace('.', '').replace('-', '').isdigit()))]
        
        print(f"    Učitano {len(df)} redova iz MT5")
        print(f"    Kolone: {list(df.columns)}")
        print(f"    Primeri redova:")
        for idx, row in df.head(3).iterrows():
            print(f"      {row.get('Time', 'N/A')} | {row.get('Symbol', 'N/A')} | Price: {row.get('Price', 'N/A')}")
        
        return df
    except Exception as e:
        print(f"    GREŠKA pri učitavanju MT5: {e}")
        import traceback
        traceback.print_exc()
        return None

def load_db_trades():
    """Učita existing trade-ove iz SQLite baze"""
    print("\n[2] Učitavam postojeće trade-ove iz baze...")
    try:
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Proverim da li tabela postoji
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='trades';")
        if not cursor.fetchone():
            print("    GREŠKA: Tabela 'trades' ne postoji u bazi!")
            conn.close()
            return None, None
        
        # Učitaj sve trade-ove
        cursor.execute("SELECT * FROM trades ORDER BY open_time")
        trades = cursor.fetchall()
        
        # Konvertuj u DataFrame
        if trades:
            df_db = pd.DataFrame([dict(row) for row in trades])
            print(f"    Učitano {len(df_db)} redova iz baze")
        else:
            df_db = pd.DataFrame()
            print(f"    Baza je prazna")
        
        # Pronađi max trade_index za sekvencijalno dodeljenje
        cursor.execute("SELECT MAX(trade_index) as max_idx FROM trades")
        max_idx_row = cursor.fetchone()
        max_idx = max_idx_row['max_idx'] if max_idx_row['max_idx'] else 0
        
        # Pronađi max ticket
        cursor.execute("SELECT MAX(ticket) as max_ticket FROM trades")
        max_ticket_row = cursor.fetchone()
        max_ticket = max_ticket_row['max_ticket'] if max_ticket_row['max_ticket'] else 0
        
        conn.close()
        
        return df_db, {'max_idx': max_idx, 'max_ticket': max_ticket}
    except Exception as e:
        print(f"    GREŠKA pri učitavanju baze: {e}")
        return None, None

def extract_key(row, source='mt5'):
    """Pravi match ključ: Timestamp + Symbol + Entry Price + Profit"""
    if source == 'mt5':
        # MT5 kolone: Time (not open_time), Symbol, Price (not open_price), Profit
        timestamp = str(row.get('Time', '')).strip()
        symbol = str(row.get('Symbol', '')).strip()
        entry_price = float(row.get('Price', 0))
        profit = float(row.get('Profit', 0))
    else:  # DB
        timestamp = str(row.get('timestamp', '')).strip()
        symbol = str(row.get('symbol', '')).strip()
        entry_price = float(row.get('entry_price', 0))
        profit = float(row.get('profit', 0))
    
    # Zaokruži entry_price na 5 decimala i profit na 2 decimale za poređenje
    key = f"{timestamp}|{symbol}|{entry_price:.5f}|{profit:.2f}"
    return key

def find_missing_trades(df_mt5, df_db):
    """Pronađi trade-ove koji su u MT5 ali nisu u bazi"""
    print("\n[3] Pronalažim missing trade-ove...")
    
    if df_mt5 is None or df_db is None or len(df_db) == 0:
        print("    GREŠKA: Ne mogu da poredim - nema podataka")
        return None
    
    # Kreiraj set ključeva iz baze
    db_keys = set()
    for _, row in df_db.iterrows():
        key = extract_key(row, source='db')
        db_keys.add(key)
    
    print(f"    Ključevi u bazi: {len(db_keys)}")
    
    # Pronađi missing trade-ove
    missing = []
    for _, row in df_mt5.iterrows():
        key = extract_key(row, source='mt5')
        if key not in db_keys:
            missing.append(row)
    
    print(f"    Pronađeno MISSING trade-ova: {len(missing)}")
    
    if missing:
        print("\n    Missing trade-ovi:")
        for i, trade in enumerate(missing, 1):
            # MT5 kolone
            time_val = trade.get('Time', 'N/A')
            symbol = trade.get('Symbol', 'N/A')
            price = trade.get('Price', 0)
            profit = trade.get('Profit', 0)
            print(f"      {i}. {time_val} | {symbol} | "
                  f"Entry: {float(price):.5f} | Profit: {float(profit):.2f}")
    
    return missing

def get_template_row(df_db):
    """Pronađi prvi red u bazi kao template za safe defaults"""
    if df_db is None or len(df_db) == 0:
        return None
    return df_db.iloc[0]

def prepare_insert_values(missing_trades, df_db, max_idx, max_ticket):
    """Pripremi vrednosti za INSERT"""
    print("\n[4] Priprema vrednosti za INSERT...")
    
    template = get_template_row(df_db)
    if template is None:
        print("    GREŠKA: Nema template reda u bazi!")
        return None
    
    insert_rows = []
    cumulative_profit = 0.0
    
    for i, trade in enumerate(missing_trades):
        new_idx = max_idx + i + 1
        new_ticket = max_ticket + i + 1
        
        # MT5 kolone: Time, Symbol, Price, Time.1, Price.1, Type, Volume, S/L, T/P, Commission, Profit
        open_time = trade.get('Time')
        symbol = str(trade.get('Symbol', '')).strip()
        lot_size = float(trade.get('Volume', 0))
        open_price = float(trade.get('Price', 0))
        close_time = trade.get('Time.1')
        close_price = float(trade.get('Price.1', 0))
        stop_loss = float(trade.get('S / L', 0))
        take_profit = float(trade.get('T / P', 0))
        profit = float(trade.get('Profit', 0))
        trade_type = str(trade.get('Type', 'buy')).upper()
        
        # Izračunaj dodatne vrednosti
        profit_r = profit / 10.0
        setup_result = 'win' if profit > 0 else 'loss'
        exit_reason = 'take_profit' if profit > 0 else 'stop_loss'
        
        # Day of week i Hour iz Timestamp-a
        try:
            dt = pd.to_datetime(open_time)
            day_of_week = dt.strftime('%A')
            hour = dt.hour
            timestamp = dt.strftime('%Y-%m-%d %H:%M:%S')
            bar_time_entry = dt.strftime('%Y-%m-%d %H:%M')
            bar_time_trend = dt.strftime('%Y-%m-%d %H:00')
        except:
            day_of_week = ''
            hour = 0
            timestamp = str(open_time)
            bar_time_entry = ''
            bar_time_trend = ''
        
        # Pripremi red sa svim poljima
        row_dict = {
            'ticket': new_ticket,
            'symbol': symbol,
            'lot_size': lot_size,
            'direction': trade_type,
            'open_time': timestamp,
            'open_price': open_price,
            'close_time': close_time,
            'close_price': close_price,
            'profit': profit,
            'status': 'CLOSED',
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'magic_number': template.get('magic_number', 0),
            'trade_index': new_idx,
            'comment': f"Backfill from MT5 report (missing trade #{i+1})",
            'entry_tf': template.get('entry_tf', 'H1'),
            'timestamp': timestamp,
            'day_of_week': day_of_week,
            'hour': hour,
            'session_active': template.get('session_active', 1),
            'ema_fast_20': template.get('ema_fast_20'),
            'ema_slow_100': template.get('ema_slow_100'),
            'ema_fast_above_slow': template.get('ema_fast_above_slow'),
            'ema_fast_slope': template.get('ema_fast_slope'),
            'ema_slow_slope': template.get('ema_slow_slope'),
            'price_vs_fast_ema': template.get('price_vs_fast_ema'),
            'price_vs_slow_ema': template.get('price_vs_slow_ema'),
            'trend_direction': template.get('trend_direction'),
            'pullback_ema_20': template.get('pullback_ema_20'),
            'price_distance_from_pullback_ema': template.get('price_distance_from_pullback_ema'),
            'pullback_valid': template.get('pullback_valid'),
            'pullback_depth_pips': template.get('pullback_depth_pips'),
            'donchian_high': template.get('donchian_high'),
            'donchian_low': template.get('donchian_low'),
            'donchian_range': template.get('donchian_range'),
            'price_vs_don_high': template.get('price_vs_don_high'),
            'price_vs_don_low': template.get('price_vs_don_low'),
            'donchian_breakout': template.get('donchian_breakout'),
            'don_buffer_pips': template.get('don_buffer_pips'),
            'adx_value': template.get('adx_value'),
            'adx_above_min': template.get('adx_above_min'),
            'di_plus': template.get('di_plus'),
            'di_minus': template.get('di_minus'),
            'trend_strength': template.get('trend_strength'),
            'atr_value': template.get('atr_value'),
            'atr_pips': template.get('atr_pips'),
            'atr_above_min': template.get('atr_above_min'),
            'atr_percent_of_price': template.get('atr_percent_of_price'),
            'risk_mode': template.get('risk_mode'),
            'risk_percent': template.get('risk_percent'),
            'sl_multiplier': template.get('sl_multiplier'),
            'tp_multiplier': template.get('tp_multiplier'),
            'calculated_sl_pips': template.get('calculated_sl_pips'),
            'calculated_tp_pips': template.get('calculated_tp_pips'),
            'rr_ratio': template.get('rr_ratio'),
            'spread_points': template.get('spread_points'),
            'spread_ok': template.get('spread_ok'),
            'one_entry_per_bar_pass': template.get('one_entry_per_bar_pass'),
            'session_hour': template.get('session_hour'),
            'session_allowed': template.get('session_allowed'),
            'daily_loss_percent': template.get('daily_loss_percent'),
            'consecutive_losses': template.get('consecutive_losses'),
            'equity_dd_percent': template.get('equity_dd_percent'),
            'risk_block_active': template.get('risk_block_active'),
            'risk_block_reason': template.get('risk_block_reason'),
            'signal_type': template.get('signal_type'),
            'allow_longs': template.get('allow_longs'),
            'allow_shorts': template.get('allow_shorts'),
            'filters_passed_count': template.get('filters_passed_count'),
            'filters_failed_count': template.get('filters_failed_count'),
            'final_decision': template.get('final_decision'),
            'skip_reason': template.get('skip_reason'),
            'entry_price': open_price,
            'bid': template.get('bid'),
            'ask': template.get('ask'),
            'bar_time_entry_tf': bar_time_entry,
            'bar_time_trend_tf': bar_time_trend,
            'exit_price': close_price,
            'exit_reason': exit_reason,
            'profit_r': profit_r,
            'duration_seconds': 0,
            'max_floating_profit': template.get('max_floating_profit'),
            'max_floating_dd': template.get('max_floating_dd'),
            'setup_result': setup_result,
            'trend_tf': template.get('trend_tf', 'H4'),
        }
        
        insert_rows.append(row_dict)
        cumulative_profit += profit
    
    print(f"    Priprema gotova: {len(insert_rows)} redova za insert")
    print(f"    Kumulativni profit: {cumulative_profit:.2f}")
    
    return insert_rows

def insert_trades(insert_rows):
    """Ubaci trade-ove u bazu sa transakcijom"""
    print("\n[5] Ubacujem trade-ove u bazu...")
    
    if not insert_rows:
        print("    Nema redova za insert!")
        return False, 0
    
    try:
        conn = sqlite3.connect(DB_PATH, timeout=10)
        cursor = conn.cursor()
        
        # Počni transakciju
        cursor.execute("BEGIN TRANSACTION")
        
        # Proverim broj redova PRE
        cursor.execute("SELECT COUNT(*) as cnt FROM trades")
        count_before = cursor.fetchone()[0]
        
        # Proverim sumu profita PRE
        cursor.execute("SELECT SUM(profit) as total FROM trades")
        result = cursor.fetchone()[0]
        profit_before = result if result else 0.0
        
        # Ubaci sve redove
        inserted_count = 0
        for row in insert_rows:
            columns = list(row.keys())
            placeholders = ','.join(['?'] * len(columns))
            values = list(row.values())
            
            sql = f"INSERT INTO trades ({', '.join(columns)}) VALUES ({placeholders})"
            
            cursor.execute(sql, values)
            inserted_count += 1
        
        # Commit transakcije
        conn.commit()
        
        # Proverim broj redova POSLE
        cursor.execute("SELECT COUNT(*) as cnt FROM trades")
        count_after = cursor.fetchone()[0]
        
        # Proverim sumu profita POSLE
        cursor.execute("SELECT SUM(profit) as total FROM trades")
        result = cursor.fetchone()[0]
        profit_after = result if result else 0.0
        
        conn.close()
        
        print(f"    ✓ Uspešno ubačeno: {inserted_count} redova")
        print(f"    Redovi PRE: {count_before}, POSLE: {count_after} (razlika: +{count_after - count_before})")
        print(f"    Profit PRE: {profit_before:.2f}, POSLE: {profit_after:.2f} (razlika: +{profit_after - profit_before:.2f})")
        
        return True, inserted_count
    
    except Exception as e:
        print(f"    GREŠKA pri insert-u: {e}")
        try:
            conn.rollback()
            conn.close()
        except:
            pass
        return False, 0

def verify_insert(insert_rows):
    """Verifikuj da nema duplikata i da je sve OK"""
    print("\n[6] Verifikacija...")
    
    try:
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Proveri duplikate po ticket-u
        cursor.execute("SELECT ticket, COUNT(*) as cnt FROM trades GROUP BY ticket HAVING cnt > 1")
        duplicates = cursor.fetchall()
        
        if duplicates:
            print(f"    ⚠ UPOZORENJE: Pronađeni duplikati po ticket-u!")
            for dup in duplicates:
                print(f"      Ticket {dup['ticket']}: {dup['cnt']} redova")
        else:
            print(f"    ✓ Nema duplikata po ticket-u")
        
        # Prikaži sve ubačene trade-ove
        print("\n    Ubačeni trade-ovi:")
        print("    " + "-" * 80)
        print(f"    {'Timestamp':<20} | {'Symbol':<8} | {'Entry Price':<12} | {'Exit Price':<12} | {'Profit':<10}")
        print("    " + "-" * 80)
        
        for row in insert_rows:
            print(f"    {row['timestamp']:<20} | {row['symbol']:<8} | {row['entry_price']:<12.5f} | {row['exit_price']:<12.5f} | {row['profit']:<10.2f}")
        
        print("    " + "-" * 80)
        
        conn.close()
        return True
    
    except Exception as e:
        print(f"    GREŠKA pri verifikaciji: {e}")
        return False

def main():
    """Glavni backfill proces"""
    print("=" * 80)
    print("BACKFILL MISSING TRADES - MT5 xlsx -> SQLite")
    print("=" * 80)
    
    # 1. Učitaj MT5 xlsx
    df_mt5 = load_mt5_positions()
    if df_mt5 is None:
        print("\n[GREŠKA] Ne mogu da učitam MT5 fajl!")
        return False
    
    # 2. Učitaj DB
    df_db, db_stats = load_db_trades()
    if df_db is None:
        print("\n[GREŠKA] Ne mogu da učitam bazu!")
        return False
    
    # 3. Pronađi missing trade-ove
    missing_trades = find_missing_trades(df_mt5, df_db)
    if missing_trades is None or len(missing_trades) == 0:
        print("\n[INFO] Nema missing trade-ova!")
        return True
    
    # 4. Pripremi vrednosti
    insert_rows = prepare_insert_values(missing_trades, df_db, db_stats['max_idx'], db_stats['max_ticket'])
    if insert_rows is None:
        print("\n[GREŠKA] Ne mogu da pripremim vrednosti za insert!")
        return False
    
    # 5. Ubaci trade-ove
    success, count = insert_trades(insert_rows)
    if not success:
        print("\n[GREŠKA] Neuspešan insert!")
        return False
    
    # 6. Verifikuj
    if not verify_insert(insert_rows):
        print("\n[UPOZORENJE] Verifikacija nije prošla!")
        return False
    
    print("\n" + "=" * 80)
    print("✓ BACKFILL ZAVRŠEN USPEŠNO!")
    print(f"  Ubačeno: {count} trade-ova")
    print("=" * 80)
    
    return True

if __name__ == '__main__':
    main()
