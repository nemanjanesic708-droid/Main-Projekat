# -*- coding: utf-8 -*-
"""
Brzi Backfill - Ubaci samo 6 missing trade-ova iz 8.-9. Jana
"""

import sqlite3
import openpyxl
from datetime import datetime

DB_PATH = 'database/trades.db'
XLSX_PATH = r'C:\mnt\data\ReportHistory-1512255861.xlsx'

def main():
    print("="*80)
    print("BRZI BACKFILL - 6 MISSING TRADE-OVA (8.-9. JAN)")
    print("="*80)
    
    # Otvorim Excel
    print("\n[1] Čitam Excel...")
    wb = openpyxl.load_workbook(XLSX_PATH)
    ws = wb.active
    
    missing_trades = []
    for row_idx in range(8, ws.max_row+1):
        time_cell = ws.cell(row=row_idx, column=1).value
        if not time_cell:
            break
        
        # Proverim da li je red validan
        symbol = ws.cell(row=row_idx, column=3).value
        entry_price = ws.cell(row=row_idx, column=6).value
        profit = ws.cell(row=row_idx, column=13).value
        
        # Filtriraj - samo validni redovi sa 8.-9. Jan i sa brojevima
        time_str = str(time_cell)
        if not ('2026.01.08' in time_str or '2026.01.09' in time_str):
            continue
        if not symbol or not entry_price or profit is None:
            continue
        
        try:
            _ = float(entry_price)
            _ = float(profit)
        except:
            continue
        
        trade_type = ws.cell(row=row_idx, column=4).value
        volume = ws.cell(row=row_idx, column=5).value
        sl = ws.cell(row=row_idx, column=7).value
        tp = ws.cell(row=row_idx, column=8).value
        close_time = ws.cell(row=row_idx, column=9).value
        close_price = ws.cell(row=row_idx, column=10).value
        commission = ws.cell(row=row_idx, column=11).value
        swap = ws.cell(row=row_idx, column=12).value
        
        missing_trades.append({
            'Time': time_str,
            'Symbol': symbol,
            'Type': trade_type,
            'Volume': volume,
            'Price': entry_price,
            'S / L': sl,
            'T / P': tp,
            'Time.1': str(close_time),
            'Price.1': close_price,
            'Commission': commission,
            'Swap': swap,
            'Profit': profit
        })
    
    print(f"    Pronašao {len(missing_trades)} trade-ova iz 8.-9. Jana")
    
    # Prikaži trade-ove
    print("\n[2] Missing trade-ovi:")
    total_profit = 0
    for i, t in enumerate(missing_trades, 1):
        print(f"    {i}. {t['Time'][:16]:16s} | {t['Symbol']:6s} | Entry: {float(t['Price']):8.5f} | Profit: {float(t['Profit']):7.2f}")
        total_profit += float(t['Profit'])
    
    print(f"\n    Total profit missing: {total_profit:.2f}")
    
    # Ubaci u bazu
    print("\n[3] Ubacujem u bazu...")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Pronađi max trade_index i max ticket
    cursor.execute("SELECT COALESCE(MAX(trade_index), 0) FROM trades")
    max_idx = cursor.fetchone()[0]
    
    cursor.execute("SELECT COALESCE(MAX(ticket), 0) FROM trades")
    max_ticket = cursor.fetchone()[0]
    
    # Pronađi template red
    cursor.execute("SELECT * FROM trades LIMIT 1")
    cols = [d[0] for d in cursor.description]
    cursor.execute("SELECT * FROM trades LIMIT 1")
    template_row = dict(zip(cols, cursor.fetchone()))
    
    # Počni transakciju
    cursor.execute("BEGIN TRANSACTION")
    
    try:
        # Prebrojim PRE
        cursor.execute("SELECT COUNT(*), COALESCE(SUM(profit), 0) FROM trades")
        count_before, profit_before = cursor.fetchone()
        
        # Ubacim trade-ove
        inserted = 0
        for i, trade in enumerate(missing_trades):
            new_idx = max_idx + i + 1
            new_ticket = max_ticket + i + 1
            
            # Pripremi row
            row = template_row.copy()
            
            row['ticket'] = new_ticket
            row['trade_index'] = new_idx
            row['symbol'] = trade['Symbol']
            row['lot_size'] = float(trade['Volume'])
            row['direction'] = trade['Type'].upper()
            row['open_time'] = trade['Time']
            row['open_price'] = float(trade['Price'])
            row['close_time'] = trade['Time.1']
            row['close_price'] = float(trade['Price.1'])
            row['stop_loss'] = float(trade['S / L'])
            row['take_profit'] = float(trade['T / P'])
            row['profit'] = float(trade['Profit'])
            row['status'] = 'CLOSED'
            row['commission'] = float(trade['Commission']) if trade['Commission'] else 0
            row['swap'] = float(trade['Swap']) if trade['Swap'] else 0
            row['entry_price'] = float(trade['Price'])
            row['exit_price'] = float(trade['Price.1'])
            row['timestamp'] = trade['Time']
            
            # Izračunaj result
            row['setup_result'] = 'win' if row['profit'] > 0 else 'loss'
            row['exit_reason'] = 'take_profit' if row['profit'] > 0 else 'stop_loss'
            row['profit_r'] = row['profit'] / 10.0
            row['comment'] = f"Backfill from MT5 report (missing trade #{i+1})"
            
            # Napravi SQL
            cols_to_insert = [k for k, v in row.items() if v is not None]
            placeholders = ','.join(['?'] * len(cols_to_insert))
            values = [row[k] for k in cols_to_insert]
            
            sql = f"INSERT INTO trades ({','.join(cols_to_insert)}) VALUES ({placeholders})"
            cursor.execute(sql, values)
            inserted += 1
        
        # Prebrojim POSLE
        cursor.execute("SELECT COUNT(*), COALESCE(SUM(profit), 0) FROM trades")
        count_after, profit_after = cursor.fetchone()
        
        # Verify
        rows_added = count_after - count_before
        profit_added = profit_after - profit_before
        
        if rows_added == 6 and abs(profit_added - total_profit) < 0.01:
            print(f"    ✓ Ubačeno {rows_added} trade-ova")
            print(f"    ✓ Profit dodano: {profit_added:.2f}")
            print(f"\n    REZULTAT:")
            print(f"      Ukupno trade-ova: {count_before} → {count_after}")
            print(f"      Ukupni profit: {profit_before:.2f} → {profit_after:.2f}")
            
            cursor.execute("COMMIT")
            print("\n    ✓ TRANSAKCIJA COMMITTED!")
        else:
            print(f"    ✗ GREŠKA: Očekivano 6 redova, dobio {rows_added}")
            print(f"    ✗ Očekivano +{total_profit:.2f}, dobio {profit_added:.2f}")
            cursor.execute("ROLLBACK")
            print("    ROLLBACK!")
    
    except Exception as e:
        print(f"    ✗ GREŠKA: {e}")
        cursor.execute("ROLLBACK")
        import traceback
        traceback.print_exc()
    
    conn.close()
    print("\n" + "="*80)

if __name__ == '__main__':
    main()
