"""
Automatski backup baze podataka na kraju svakog dana
Čuva se u backups/ folder sa datumom u imenu
"""
import sqlite3
import shutil
import os
from datetime import datetime
import schedule
import time

DB_PATH = 'database/trades.db'
BACKUP_DIR = 'backups'

def create_backup():
    """Kreira backup baze podataka"""
    try:
        # Kreiraj backups folder ako ne postoji
        if not os.path.exists(BACKUP_DIR):
            os.makedirs(BACKUP_DIR)
        
        # Ime backup fajla sa datumom i vremenom
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        backup_filename = f"trades_backup_{timestamp}.db"
        backup_path = os.path.join(BACKUP_DIR, backup_filename)
        
        # Kopiraj bazu
        shutil.copy2(DB_PATH, backup_path)
        
        print(f"✅ Backup kreiran: {backup_filename}")
        
        # Obriši stare backup-e (čuvaj samo poslednjih 30 dana)
        cleanup_old_backups(30)
        
        return True
    except Exception as e:
        print(f"❌ Greška pri backup-u: {e}")
        return False

def cleanup_old_backups(days_to_keep=30):
    """Briše backup-e starije od N dana"""
    try:
        if not os.path.exists(BACKUP_DIR):
            return
        
        current_time = time.time()
        days_in_seconds = days_to_keep * 24 * 60 * 60
        
        for filename in os.listdir(BACKUP_DIR):
            if filename.startswith('trades_backup_') and filename.endswith('.db'):
                filepath = os.path.join(BACKUP_DIR, filename)
                file_age = current_time - os.path.getmtime(filepath)
                
                if file_age > days_in_seconds:
                    os.remove(filepath)
                    print(f"🗑️ Obrisan stari backup: {filename}")
    except Exception as e:
        print(f"⚠️ Greška pri čišćenju starih backup-a: {e}")

def schedule_daily_backup():
    """Zakazuje backup svaki dan u 23:59"""
    # Backup svaki dan u 23:59
    schedule.every().day.at("23:59").do(create_backup)
    
    print("🕒 Automatski backup zakazan za 23:59 svaki dan")
    print("📁 Backup-i se čuvaju u: backups/")
    print("🔄 Stariji od 30 dana se automatski brišu")
    print("\n💡 Pritisnite Ctrl+C da zaustavite servis\n")
    
    # Kreiraj odmah prvi backup
    print("Kreiranje inicijalnog backup-a...")
    create_backup()
    
    # Pokreni zakazivanje
    while True:
        schedule.run_pending()
        time.sleep(60)  # Proveri svakih 60 sekundi

if __name__ == "__main__":
    schedule_daily_backup()
