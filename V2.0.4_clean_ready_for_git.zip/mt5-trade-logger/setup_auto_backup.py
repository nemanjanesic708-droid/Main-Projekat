"""
Dodaje auto backup u Windows Startup
"""
import os
import sys

def add_backup_to_startup():
    """Dodaje backup servis u Windows Startup"""
    try:
        import win32com.client
        
        startup_folder = os.path.join(
            os.environ['APPDATA'],
            'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'
        )
        
        bat_path = os.path.join(os.path.dirname(__file__), 'start_auto_backup.bat')
        shortcut_name = 'MT5 Trade Logger Auto Backup.lnk'
        shortcut_path = os.path.join(startup_folder, shortcut_name)
        
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = bat_path
        shortcut.WorkingDirectory = os.path.dirname(__file__)
        shortcut.IconLocation = os.path.join(os.path.dirname(__file__), 'app_icon.ico')
        shortcut.Description = "MT5 Trade Logger Auto Backup - Runs at 23:59 daily"
        shortcut.WindowStyle = 7  # Minimized
        shortcut.save()
        
        print(f"✅ Auto backup dodat u Startup!")
        print(f"📂 Lokacija: {shortcut_path}")
        print(f"⏰ Backup će se automatski pokretati pri startovanju računara")
        print(f"🕒 Backup se izvršava svaki dan u 23:59")
        print(f"📁 Backup-i se čuvaju u: backups/")
        print(f"🔄 Stariji od 30 dana se automatski brišu")
        
        return True
        
    except Exception as e:
        print(f"❌ Greška: {e}")
        return False

if __name__ == "__main__":
    add_backup_to_startup()
