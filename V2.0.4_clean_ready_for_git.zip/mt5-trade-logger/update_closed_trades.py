"""
Ažurira zatvorene trejdove sa close price i profit
"""
import sqlite3

DB_PATH = 'database/trades.db'

def update_closed_trades():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    updates = [
        (361664906, 1.16568, -25.48),
        (361538406, 1.16748, -6.51),
        (361496244, 1.16808, 56.16),
    ]
    
    for ticket, close_price, profit in updates:
        cursor.execute('''
            UPDATE trades 
            SET close_price = ?, profit = ?, status = 'CLOSED'
            WHERE ticket = ?
        ''', (close_price, profit, ticket))
        print(f"✓ Ažuriran trejd #{ticket}: close_price={close_price}, profit={profit}")
    
    conn.commit()
    conn.close()
    
    print("\n✅ Sve ažurirano! Osvežite Dashboard.")

if __name__ == "__main__":
    update_closed_trades()
