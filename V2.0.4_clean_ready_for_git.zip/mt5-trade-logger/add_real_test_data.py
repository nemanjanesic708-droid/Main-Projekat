"""
Dodaje test podatke sa profit/loss vrednostima za testiranje dijagrama
"""
import sqlite3
from datetime import datetime, timedelta

DB_PATH = 'database/trades.db'

def add_test_trades_with_profit():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Trenutno vreme
    now = datetime.now()
    
    # Test trejdovi sa profit/loss
    test_trades = [
        # Dobitni trejdovi
        (100001, 'EURUSD', 0.10, 'BUY', (now - timedelta(hours=5)).strftime('%Y-%m-%d %H:%M:%S'),
         1.10500, (now - timedelta(hours=2)).strftime('%Y-%m-%d %H:%M:%S'), 1.10650, 15.00, 'CLOSED', 0, 0, 0, ''),
        
        (100002, 'GBPUSD', 0.15, 'SELL', (now - timedelta(hours=6)).strftime('%Y-%m-%d %H:%M:%S'),
         1.27500, (now - timedelta(hours=3)).strftime('%Y-%m-%d %H:%M:%S'), 1.27200, 45.00, 'CLOSED', 0, 0, 0, ''),
        
        (100003, 'USDJPY', 0.20, 'BUY', (now - timedelta(hours=4)).strftime('%Y-%m-%d %H:%M:%S'),
         149.500, (now - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S'), 149.800, 60.00, 'CLOSED', 0, 0, 0, ''),
        
        # Gubitni trejdovi
        (100004, 'EURJPY', 0.12, 'SELL', (now - timedelta(hours=7)).strftime('%Y-%m-%d %H:%M:%S'),
         163.200, (now - timedelta(hours=4)).strftime('%Y-%m-%d %H:%M:%S'), 163.500, -36.00, 'CLOSED', 0, 0, 0, ''),
        
        (100005, 'AUDUSD', 0.08, 'BUY', (now - timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S'),
         0.65500, (now - timedelta(hours=5)).strftime('%Y-%m-%d %H:%M:%S'), 0.65200, -24.00, 'CLOSED', 0, 0, 0, ''),
        
        # Otvoreni trejdovi
        (100006, 'EURUSD', 0.25, 'BUY', now.strftime('%Y-%m-%d %H:%M:%S'),
         1.10700, None, None, None, 'OPEN', 1.10200, 1.11200, 0, ''),
        
        (100007, 'GBPUSD', 0.18, 'SELL', (now - timedelta(minutes=30)).strftime('%Y-%m-%d %H:%M:%S'),
         1.27600, None, None, None, 'OPEN', 1.28100, 1.27100, 0, ''),
    ]
    
    for trade in test_trades:
        cursor.execute('''
            INSERT INTO trades (ticket, symbol, lot_size, direction, open_time, open_price,
                              close_time, close_price, profit, status, stop_loss, take_profit,
                              magic_number, comment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', trade)
    
    conn.commit()
    conn.close()
    
    print(f"✅ Dodato {len(test_trades)} test trejdova!")
    print("   - 3 BUY trejda (profit: €120)")
    print("   - 2 SELL trejda (profit: €45, loss: €60)")
    print("   - 2 otvorena trejda")
    print("\nSada možete testirati dijagrame!")

if __name__ == "__main__":
    add_test_trades_with_profit()
