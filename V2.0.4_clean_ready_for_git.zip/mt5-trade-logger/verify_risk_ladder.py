import argparse
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from typing import Iterable, Optional


DB_PATH_DEFAULT = "database/trades.db"


def _parse_dt(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    s = str(s).strip()
    for fmt in ("%Y.%m.%d %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    return None


def _norm_level(level: Optional[str]) -> Optional[str]:
    if level is None:
        return None
    lvl = str(level).strip().upper()
    return lvl if lvl in ("L1", "L2", "L3") else None


def _norm_close_reason(reason: Optional[str]) -> Optional[str]:
    if reason is None:
        return None
    r = str(reason).strip().upper()
    if r in ("TP", "SL"):
        return r
    return r or None


def _step_up(level: str) -> str:
    if level == "L1":
        return "L2"
    if level == "L2":
        return "L3"
    return "L3"


@dataclass
class TradeRow:
    id: int
    account_id: str
    ticket: Optional[int]
    position_id: Optional[int]
    symbol: str
    open_time: Optional[str]
    close_reason: Optional[str]
    status: Optional[str]
    risk_level: Optional[str]

    @property
    def open_day(self) -> Optional[str]:
        dt = _parse_dt(self.open_time)
        return dt.strftime("%Y-%m-%d") if dt else None


def _fetch_rows(conn: sqlite3.Connection, account_id: Optional[str], limit: int) -> list[TradeRow]:
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    where = []
    args: list[object] = []
    if account_id:
        where.append("account_id = ?")
        args.append(account_id)
    where_sql = ("WHERE " + " AND ".join(where)) if where else ""

    # Order by id (insertion order) to reflect the ladder decisions at trade OPEN time.
    sql = (
        "SELECT id, account_id, ticket, position_id, symbol, open_time, close_reason, status, risk_level "
        f"FROM trades {where_sql} "
        "ORDER BY id DESC LIMIT ?"
    )
    args.append(int(limit))
    rows = cur.execute(sql, args).fetchall()
    # Return ascending order for processing.
    out: list[TradeRow] = []
    for r in reversed(rows):
        out.append(
            TradeRow(
                id=int(r["id"]),
                account_id=str(r["account_id"]) if r["account_id"] is not None else "UNKNOWN",
                ticket=r["ticket"],
                position_id=r["position_id"],
                symbol=str(r["symbol"]) if r["symbol"] is not None else "UNKNOWN",
                open_time=r["open_time"],
                close_reason=r["close_reason"],
                status=r["status"],
                risk_level=r["risk_level"],
            )
        )
    return out


def _group_by_account(rows: Iterable[TradeRow]) -> dict[str, list[TradeRow]]:
    grouped: dict[str, list[TradeRow]] = {}
    for r in rows:
        grouped.setdefault(r.account_id, []).append(r)
    return grouped


def verify_rows(rows: list[TradeRow], daily_reset: bool, strict_start_l1: bool) -> int:
    mismatches = 0
    # Risk ladder is per symbol: keep independent expected state per symbol.
    expected_by_symbol: dict[str, str] = {}
    prev_day_by_symbol: dict[str, Optional[str]] = {}
    anchored_by_symbol: dict[str, bool] = {}

    for r in rows:
        sym = (r.symbol or "UNKNOWN").strip() or "UNKNOWN"
        expected_by_symbol.setdefault(sym, "L1")
        prev_day_by_symbol.setdefault(sym, None)
        anchored_by_symbol.setdefault(sym, strict_start_l1)

        # Daily reset applies BEFORE the first trade of a new day.
        if daily_reset:
            day = r.open_day
            prev_day = prev_day_by_symbol[sym]
            if day and prev_day and day != prev_day:
                expected_by_symbol[sym] = "L1"
            if day:
                prev_day_by_symbol[sym] = day

        actual = _norm_level(r.risk_level)
        if actual is None:
            # Ignore rows that don't carry risk_level (older data / non-EA inserts).
            continue

        # When inspecting a truncated history window, we may start mid-ladder. In relaxed mode,
        # anchor the baseline at the first observed level to avoid false mismatches. Daily resets
        # are still enforced (trade opens on a new day must be L1).
        if not anchored_by_symbol[sym]:
            expected_by_symbol[sym] = actual
            anchored_by_symbol[sym] = True

        expected = expected_by_symbol[sym]
        ok = actual == expected
        if not ok:
            mismatches += 1

        close_reason = _norm_close_reason(r.close_reason)
        status = (str(r.status).strip().upper() if r.status is not None else "")

        print(
            "id={id} open_time={open_time} sym={sym} status={status} close_reason={cr} risk_level={lvl} expected={exp} {verdict}".format(
                id=r.id,
                open_time=r.open_time or "n/a",
                sym=sym,
                status=status or "n/a",
                cr=close_reason or "n/a",
                lvl=actual,
                exp=expected,
                verdict=("OK" if ok else "MISMATCH"),
            )
        )

        # Advance ladder state based on CLOSE reason (only when trade is closed).
        if status == "CLOSED":
            if close_reason == "TP":
                expected_by_symbol[sym] = _step_up(expected_by_symbol[sym])
            elif close_reason == "SL":
                expected_by_symbol[sym] = "L1"

    return mismatches


def main() -> int:
    p = argparse.ArgumentParser(
        description="Verify per-symbol Risk Ladder transitions from trades.db risk_level + close_reason."
    )
    p.add_argument("--db", default=DB_PATH_DEFAULT, help="Path to SQLite DB (default: database/trades.db)")
    p.add_argument("--account", default=None, help="Filter by account_id")
    p.add_argument("--limit", type=int, default=200, help="How many most-recent rows to inspect (default: 200)")
    p.add_argument(
        "--no-daily-reset",
        action="store_true",
        help="Ignore daily reset when computing expected ladder state",
    )
    p.add_argument(
        "--strict-start-l1",
        action="store_true",
        help="Require the first observed trade in the inspected window to be L1 (useful for acceptance tests after reset).",
    )
    args = p.parse_args()

    conn = sqlite3.connect(args.db)
    try:
        rows = _fetch_rows(conn, args.account, args.limit)
    finally:
        conn.close()

    if not rows:
        print("No rows found.")
        return 2

    if args.account:
        print(f"Account: {args.account}")
        mismatches = verify_rows(
            rows,
            daily_reset=(not args.no_daily_reset),
            strict_start_l1=args.strict_start_l1,
        )
        if mismatches:
            print(f"FAIL mismatches={mismatches}")
            return 1
        print("PASS")
        return 0

    grouped = _group_by_account(rows)
    total_mismatches = 0
    for account_id, acc_rows in grouped.items():
        print(f"\nAccount: {account_id}")
        total_mismatches += verify_rows(
            acc_rows,
            daily_reset=(not args.no_daily_reset),
            strict_start_l1=args.strict_start_l1,
        )

    if total_mismatches:
        print(f"\nFAIL mismatches={total_mismatches}")
        return 1
    print("\nPASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
