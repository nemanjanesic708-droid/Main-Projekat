#!/bin/bash
# Backfill Wrapper - Pokretanje celog procesa

set -e  # Exit on error

echo ""
echo "================================================================================"
echo "BACKFILL MISSING TRADES - Automated Wrapper"
echo "================================================================================"
echo ""

# Check virtual environment
if [ ! -d ".venv" ]; then
    echo "✗ Virtual environment not found!"
    echo "  Please run: python -m venv .venv"
    exit 1
fi

# Activate virtual environment
echo "[1/4] Activating virtual environment..."
source .venv/bin/activate 2>/dev/null || source .venv/Scripts/activate 2>/dev/null
echo "✓ Virtual environment activated"

# Install dependencies
echo ""
echo "[2/4] Installing dependencies..."
pip install -q pandas openpyxl 2>/dev/null || pip install pandas openpyxl
echo "✓ Dependencies installed"

# Run tests
echo ""
echo "[3/4] Running pre-flight checks..."
python backfill_test.py
test_result=$?

if [ $test_result -ne 0 ]; then
    echo ""
    echo "✗ Pre-flight checks failed!"
    exit 1
fi

# Run backfill
echo ""
echo "[4/4] Running backfill..."
python backfill_missing_trades.py
backfill_result=$?

if [ $backfill_result -ne 0 ]; then
    echo ""
    echo "✗ Backfill failed!"
    exit 1
fi

echo ""
echo "================================================================================"
echo "✓ BACKFILL COMPLETED SUCCESSFULLY!"
echo "================================================================================"
echo ""

# Deactivate virtual environment
deactivate

exit 0
