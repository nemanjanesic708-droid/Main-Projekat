import os
import sys
import shutil

def add_to_startup():
    """Dodaje server u Windows Startup folder"""
    try:
        # Pronađi Startup folder
        startup_folder = os.path.join(
            os.environ['APPDATA'],
            'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'
        )
        
        # Putanja do bat fajla
        bat_path = os.path.join(os.path.dirname(__file__), 'start_server_silent.bat')
        
        # Ime prečice u Startup folderu
        shortcut_name = 'MT5 Trade Logger Server.lnk'
        shortcut_path = os.path.join(startup_folder, shortcut_name)
        
        # Kreiraj prečicu koristeći win32com
        import win32com.client
        
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = bat_path
        shortcut.WorkingDirectory = os.path.dirname(__file__)
        shortcut.IconLocation = os.path.join(os.path.dirname(__file__), 'app_icon.ico')
        shortcut.Description = "MT5 Trade Logger Server - Auto Start"
        shortcut.WindowStyle = 7  # Minimized window
        shortcut.save()
        
        print(f"✅ Server dodat u Startup!")
        print(f"📂 Lokacija: {shortcut_path}")
        print(f"🔄 Server će se automatski pokrenuti pri sledećem startovanju računara")
        print(f"\nAko želite da uklonite auto-start, obrišite fajl:")
        print(f"   {shortcut_path}")
        
        return True
        
    except Exception as e:
        print(f"❌ Greška: {e}")
        return False

def remove_from_startup():
    """Uklanja server iz Windows Startup foldera"""
    try:
        startup_folder = os.path.join(
            os.environ['APPDATA'],
            'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'
        )
        
        shortcut_path = os.path.join(startup_folder, 'MT5 Trade Logger Server.lnk')
        
        if os.path.exists(shortcut_path):
            os.remove(shortcut_path)
            print("✅ Server uklonjen iz Startup-a")
            return True
        else:
            print("ℹ️ Server nije bio u Startup-u")
            return False
            
    except Exception as e:
        print(f"❌ Greška: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == 'remove':
        remove_from_startup()
    else:
        add_to_startup()
