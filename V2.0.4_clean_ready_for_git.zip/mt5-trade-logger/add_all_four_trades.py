"""
Dodaje sve 4 trejda u bazu sa kompletnim podacima
"""
import sqlite3

DB_PATH = 'database/trades.db'

def add_all_trades():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Prvo obrišimo sve
    cursor.execute('DELETE FROM trades')
    
    # Dodaj sve 4 trejda
    trades = [
        # Otvoreni trejd
        (361807214, 'EURUSD', 0.34, 'BUY', '2025-12-05 08:00:00', 1.16591, None, None, None, 'OPEN'),
        
        # Zatvoreni trejdovi
        (361664906, 'EURUSD', 0.22, 'BUY', '2025-12-04 17:00:00', 1.16698, '2025-12-05 07:30:27', 1.16568, -25.48, 'CLOSED'),
        (361538406, 'EURUSD', 0.11, 'BUY', '2025-12-04 10:53:06', 1.16812, '2025-12-05 07:30:27', 1.16748, -6.51, 'CLOSED'),
        (361496244, 'EURUSD', 0.32, 'BUY', '2025-12-04 08:00:01', 1.16598, '2025-12-05 07:30:27', 1.16808, 56.16, 'CLOSED'),
    ]
    
    for trade in trades:
        cursor.execute('''
            INSERT INTO trades (ticket, symbol, lot_size, direction, open_time, open_price,
                              close_time, close_price, profit, status, stop_loss, take_profit, 
                              magic_number, comment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, '')
        ''', trade)
        print(f"✓ Dodato: #{trade[0]} {trade[1]} {trade[3]} status={trade[9]} profit={trade[8]}")
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ Dodato {len(trades)} trejdova!")

if __name__ == "__main__":
    add_all_trades()
