import os
import sys
import glob

# ── Stale-shortcut names to remove before creating the canonical one ──
_OLD_SHORTCUT_NAMES = [
    "MT5 Trade Logger GUI.lnk",
    "MT5 Trade Logger V2.lnk",
    "MT5_Trade_Logger.lnk",
    "MT5_Trade_Logger_V2.lnk",
]

_CANONICAL_NAME = "MT5 Trade Logger.lnk"


def _remove_stale_shortcuts(desktop: str) -> None:
    """Delete any old/duplicate MT5 Trade Logger shortcuts from the Desktop."""
    for name in _OLD_SHORTCUT_NAMES:
        path = os.path.join(desktop, name)
        if os.path.isfile(path):
            try:
                os.remove(path)
                print(f"  Removed stale shortcut: {name}")
            except OSError:
                pass


def create_desktop_shortcut():
    try:
        import win32com.client
        
        desktop = os.path.join(os.environ['USERPROFILE'], 'Desktop')

        # 1) Remove any old/duplicate shortcuts
        _remove_stale_shortcuts(desktop)

        shortcut_path = os.path.join(desktop, _CANONICAL_NAME)
        
        # Koristi pythonw.exe umesto python.exe (bez CMD prozora)
        target = sys.executable.replace('python.exe', 'pythonw.exe')
        script_path = os.path.join(os.path.dirname(__file__), 'trade_logger_gui.py')
        icon_path = os.path.join(os.path.dirname(__file__), 'app_icon.ico')
        working_dir = os.path.dirname(__file__)
        
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(shortcut_path)
        shortcut.Targetpath = target
        shortcut.Arguments = f'"{script_path}"'
        shortcut.WorkingDirectory = working_dir
        shortcut.IconLocation = icon_path
        shortcut.Description = "MT5 Trade Logger Dashboard"
        shortcut.save()
        
        print(f"Desktop prečica kreirana: {shortcut_path}")
        return True
    except ImportError:
        print("pywin32 nije instaliran. Instaliraj sa: pip install pywin32")
        return False
    except Exception as e:
        print(f"Greška pri kreiranju prečice: {e}")
        return False

if __name__ == "__main__":
    create_desktop_shortcut()
