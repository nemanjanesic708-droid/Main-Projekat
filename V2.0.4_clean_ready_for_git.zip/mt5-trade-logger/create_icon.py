from PIL import Image, ImageDraw, ImageFont
import os

# Kreiraj ikonicu 256x256
size = 256
img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

# Pozadina - plavi gradient krug
center = size // 2
radius = size // 2 - 10

# Nacrtaj krug
draw.ellipse([10, 10, size-10, size-10], fill='#5e81ac', outline='#88c0d0', width=8)

# Nacrtaj bar chart ikonu (3 bara)
bar_width = 30
bar_spacing = 15
start_x = 50
base_y = size - 50

# Bar 1 (nizak)
draw.rectangle([start_x, base_y - 40, start_x + bar_width, base_y], 
               fill='#bf616a', outline='#ffffff', width=3)

# Bar 2 (srednji)
draw.rectangle([start_x + bar_width + bar_spacing, base_y - 80, 
                start_x + 2*bar_width + bar_spacing, base_y], 
               fill='#ebcb8b', outline='#ffffff', width=3)

# Bar 3 (visok)
draw.rectangle([start_x + 2*(bar_width + bar_spacing), base_y - 120, 
                start_x + 3*bar_width + 2*bar_spacing, base_y], 
               fill='#a3be8c', outline='#ffffff', width=3)

# Sacuvaj kao PNG
icon_path = os.path.join(os.path.dirname(__file__), 'app_icon.png')
img.save(icon_path, 'PNG')

# Kreiraj .ico fajl (Windows ikonica sa vise velicina)
icon_sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
ico_images = []

for icon_size in icon_sizes:
    resized = img.resize(icon_size, Image.Resampling.LANCZOS)
    ico_images.append(resized)

ico_path = os.path.join(os.path.dirname(__file__), 'app_icon.ico')
ico_images[0].save(ico_path, format='ICO', sizes=[(img.size[0], img.size[1]) for img in ico_images])

print(f"Ikonica kreirana: {icon_path}")
print(f"Windows .ico fajl kreiran: {ico_path}")
