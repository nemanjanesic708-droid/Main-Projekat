# PowerShell skripta za automatsko pronalaženje i kopiranje TrendPortfolio_v2_fix_sync.mq5 iz svih MT5 terminala
$found = $false
$dest = "C:\Users\XEON\Desktop\mt5-trade-logger\TrendPortfolio_v2_fix_sync.mq5"
$roots = Get-ChildItem "$env:APPDATA\MetaQuotes\Terminal" -Directory
foreach ($root in $roots) {
    $src = Join-Path $root.FullName "MQL5\Experts\TrendPortfolio_v2_fix_sync.mq5"
    if (Test-Path $src) {
        Copy-Item -Path $src -Destination $dest -Force
        Write-Host "Fajl pronađen i kopiran iz: $src"
        $found = $true
        break
    }
}
if (-not $found) {
    Write-Host "Fajl nije pronađen ni u jednom terminal folderu."
}
