"""
Ažurira zatvoreni trejd #361807214 i pravi backup
"""
import sqlite3
from auto_backup import create_backup

DB_PATH = 'database/trades.db'

def update_closed_trade():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Ažuriraj trejd #361807214
    cursor.execute('''
        UPDATE trades 
        SET close_time = ?, 
            close_price = ?, 
            profit = ?, 
            status = 'CLOSED'
        WHERE ticket = ?
    ''', ('2025-12-05 11:08:56', 1.16505, -25.10, 361807214))
    
    conn.commit()
    conn.close()
    
    print("✓ Ažuriran trejd #361807214")
    print("  Close Time: 2025-12-05 11:08:56")
    print("  Close Price: 1.16505")
    print("  Profit: -€25.10")
    print("  Status: CLOSED")
    
    # Kreiraj backup
    print("\n📦 Kreiranje backup-a...")
    create_backup()
    
    print("\n✅ Sve završeno! Osvežite Dashboard.")

if __name__ == "__main__":
    update_closed_trade()
