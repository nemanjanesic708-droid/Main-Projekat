"""
Test skripta za proveru servera i slanje test podataka
"""

import requests
import json
from datetime import datetime

SERVER_URL = "http://localhost:5000"


def test_health():
    """Testiranje health endpointa"""
    print("\n" + "="*60)
    print("TEST: Health Check")
    print("="*60)
    
    try:
        response = requests.get(f"{SERVER_URL}/health")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"GREŠKA: {e}")
        return False


def test_open_trade():
    """Testiranje logovanja otvaranja trejda"""
    print("\n" + "="*60)
    print("TEST: Logovanje Otvaranja Trejda")
    print("="*60)
    
    data = {
        "ticket": 123456789,
        "symbol": "EURUSD",
        "lot_size": 0.1,
        "direction": "BUY",
        "open_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "open_price": 1.08500,
        "stop_loss": 1.08000,
        "take_profit": 1.09000,
        "magic_number": 123456,
        "comment": "Test trejd"
    }
    
    try:
        response = requests.post(
            f"{SERVER_URL}/trade/open",
            json=data,
            headers={"Content-Type": "application/json"}
        )
        print(f"Status Code: {response.status_code}")
        print(f"Request Data: {json.dumps(data, indent=2)}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code in [200, 201]
    except Exception as e:
        print(f"GREŠKA: {e}")
        return False


def test_close_trade():
    """Testiranje logovanja zatvaranja trejda"""
    print("\n" + "="*60)
    print("TEST: Logovanje Zatvaranja Trejda")
    print("="*60)
    
    data = {
        "ticket": 123456789,
        "close_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "close_price": 1.08750,
        "profit": 25.00
    }
    
    try:
        response = requests.post(
            f"{SERVER_URL}/trade/close",
            json=data,
            headers={"Content-Type": "application/json"}
        )
        print(f"Status Code: {response.status_code}")
        print(f"Request Data: {json.dumps(data, indent=2)}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"GREŠKA: {e}")
        return False


def test_get_trades():
    """Testiranje preuzimanja svih trejdova"""
    print("\n" + "="*60)
    print("TEST: Preuzimanje Svih Trejdova")
    print("="*60)
    
    try:
        response = requests.get(f"{SERVER_URL}/trades")
        print(f"Status Code: {response.status_code}")
        data = response.json()
        print(f"Broj trejdova: {data.get('count', 0)}")
        
        if data.get('trades'):
            print("\nPrvih 3 trejda:")
            for trade in data['trades'][:3]:
                print(f"  - Ticket: {trade['ticket']}, Symbol: {trade['symbol']}, Status: {trade['status']}")
        
        return response.status_code == 200
    except Exception as e:
        print(f"GREŠKA: {e}")
        return False


def test_statistics():
    """Testiranje statistike"""
    print("\n" + "="*60)
    print("TEST: Statistika")
    print("="*60)
    
    try:
        response = requests.get(f"{SERVER_URL}/trades/stats")
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"GREŠKA: {e}")
        return False


def run_all_tests():
    """Pokretanje svih testova"""
    print("\n" + "="*60)
    print("MT5 TRADE LOGGER - TEST SUITE")
    print("="*60)
    
    tests = [
        ("Health Check", test_health),
        ("Open Trade", test_open_trade),
        ("Close Trade", test_close_trade),
        ("Get Trades", test_get_trades),
        ("Statistics", test_statistics)
    ]
    
    results = []
    for name, test_func in tests:
        result = test_func()
        results.append((name, result))
    
    # Rezime
    print("\n" + "="*60)
    print("REZIME TESTOVA")
    print("="*60)
    for name, result in results:
        status = "✓ PROŠAO" if result else "✗ PALA"
        print(f"{name:<20} {status}")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    print("="*60)
    print(f"Rezultat: {passed}/{total} testova prošlo")
    print("="*60)


if __name__ == "__main__":
    run_all_tests()
