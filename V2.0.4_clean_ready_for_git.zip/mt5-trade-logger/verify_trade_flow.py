import argparse
import os
import shutil
import sqlite3
from datetime import datetime, timedelta

from server.trade_logger import app, DB_PATH, init_database


BACKUP_DIR = os.path.join(os.path.dirname(__file__), "backups")


def backup_db():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"trades_pretest_{stamp}.db")
    shutil.copy2(DB_PATH, backup_path)
    return backup_path


def fetch_trade(ticket):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM trades WHERE ticket = ? ORDER BY id DESC LIMIT 1", (ticket,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def main():
    parser = argparse.ArgumentParser(description="Verify open/close payload mapping into SQLite.")
    parser.add_argument("--reset-all", action="store_true", help="Delete all rows from trades before test.")
    args = parser.parse_args()

    init_database()
    backup = backup_db()
    print(f"[1] Backup created: {backup}")

    ticket = int(datetime.now().strftime("%y%m%d%H%M%S"))
    position_id = ticket + 99
    open_time = datetime.utcnow() - timedelta(minutes=3)
    close_time = open_time + timedelta(minutes=2, seconds=17)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    if args.reset_all:
        cur.execute("DELETE FROM trades")
        print("[2] trades table reset done.")
    cur.execute("DELETE FROM trades WHERE ticket = ? OR position_id = ?", (ticket, position_id))
    conn.commit()
    conn.close()

    open_payload = {
        "ticket": ticket,
        "position_id": position_id,
        "symbol": "EURUSD",
        "direction": "BUY",
        "lot": 0.03,
        "account_id": "acc-test-001",
        "timeframe": "M15",
        "magic": 777001,
        "risk_level": "L2",
        "open_time": open_time.strftime("%Y.%m.%d %H:%M:%S"),
        "open_price": 1.08765,
        "spread_points": 12,
        "setup": "TREND_PULLBACK",
        "status": "OPEN",
    }

    close_payload = {
        "ticket": ticket,
        "position_id": position_id,
        "close_time": close_time.strftime("%Y.%m.%d %H:%M:%S"),
        "close_price": 1.08810,
        "profit": 13.75,
        "close_reason": "TP",
        "profit_r": 1.83,
        "max_float_profit": 19.2,
        "max_float_dd": -4.8,
    }

    with app.test_client() as client:
        open_resp = client.post("/v1/trade_open", json=open_payload)
        print(f"[3] POST /v1/trade_open -> {open_resp.status_code} {open_resp.get_json()}")
        close_resp = client.post("/v1/trade_close", json=close_payload)
        print(f"[4] POST /v1/trade_close -> {close_resp.status_code} {close_resp.get_json()}")

    row = fetch_trade(ticket)
    if not row:
        raise RuntimeError("Trade row not found after open/close flow.")

    checks = {
        "status": row.get("status") == "CLOSED",
        "account_id": row.get("account_id") == "acc-test-001",
        "timeframe": row.get("timeframe") == "M15",
        "risk_level": row.get("risk_level") == "L2",
        "duration_sec": row.get("duration_sec") is not None or row.get("duration_seconds") is not None,
        "close_reason": row.get("close_reason") == "TP",
        "max_float_profit": row.get("max_float_profit") is not None or row.get("max_floating_profit") is not None,
        "max_float_dd": row.get("max_float_dd") is not None or row.get("max_floating_dd") is not None,
        "setup": row.get("setup") == "TREND_PULLBACK" or row.get("setup_result") == "TREND_PULLBACK",
    }

    print("[5] DB row snapshot:")
    fields = [
        "id",
        "ticket",
        "position_id",
        "symbol",
        "direction",
        "lot",
        "lot_size",
        "account_id",
        "timeframe",
        "open_time",
        "close_time",
        "duration_sec",
        "duration_seconds",
        "profit",
        "profit_r",
        "close_reason",
        "risk_level",
        "spread_points",
        "max_float_profit",
        "max_float_dd",
        "setup",
        "status",
    ]
    for field in fields:
        print(f"  - {field}: {row.get(field)}")

    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        raise RuntimeError(f"Verification failed for: {', '.join(failed)}")

    print("[6] Verification PASSED.")


if __name__ == "__main__":
    main()
