import os
import shutil
import sqlite3
from datetime import datetime


ROOT_DIR = os.path.dirname(os.path.dirname(__file__))
DB_PATH = os.path.join(ROOT_DIR, "database", "trades.db")
BACKUP_DIR = os.path.join(ROOT_DIR, "backups")

MIGRATION_COLUMNS = {
    "trade_uid": "TEXT",
    "position_id": "INTEGER",
    "lot": "REAL",
    "account_id": "TEXT",
    "timeframe": "TEXT",
    "magic": "INTEGER",
    "duration_sec": "INTEGER",
    "close_reason": "TEXT",
    "max_float_profit": "REAL",
    "max_float_dd": "REAL",
    "setup": "TEXT",
    "updated_at": "TEXT",
    "created_at": "TEXT",
}

INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_trades_ticket ON trades(ticket)",
    "CREATE INDEX IF NOT EXISTS idx_trades_close_time ON trades(close_time)",
    "CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status)",
    "CREATE INDEX IF NOT EXISTS idx_trades_position_id ON trades(position_id)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_trade_uid ON trades(trade_uid)",
]


def backup_database():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"trades_schema_backup_{timestamp}.db")
    shutil.copy2(DB_PATH, backup_path)
    return backup_path


def get_columns(cursor):
    cursor.execute("PRAGMA table_info(trades)")
    return {row[1] for row in cursor.fetchall()}


def migrate():
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    backup_path = backup_database()
    print(f"Backup created: {backup_path}")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Ensure base table exists first (if DB is empty/new).
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket INTEGER UNIQUE,
            trade_uid TEXT UNIQUE,
            symbol TEXT,
            direction TEXT,
            lot_size REAL,
            open_time TEXT,
            close_time TEXT,
            profit REAL,
            status TEXT DEFAULT 'OPEN',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    existing_columns = get_columns(cursor)
    if "id" not in existing_columns:
        print("WARNING: Missing PK column 'id'. SQLite cannot add AUTOINCREMENT PK with ALTER TABLE.")

    for column, ddl in MIGRATION_COLUMNS.items():
        if column in existing_columns:
            print(f"Skip existing column: {column}")
            continue
        cursor.execute(f"ALTER TABLE trades ADD COLUMN {column} {ddl}")
        print(f"Added column: {column}")

    cursor.execute("UPDATE trades SET created_at = COALESCE(created_at, CURRENT_TIMESTAMP)")
    cursor.execute("UPDATE trades SET updated_at = COALESCE(updated_at, CURRENT_TIMESTAMP)")
    cursor.execute("UPDATE trades SET status = COALESCE(NULLIF(TRIM(status), ''), 'OPEN')")

    for stmt in INDEXES:
        cursor.execute(stmt)

    conn.commit()
    conn.close()
    print("Schema migration done.")


if __name__ == "__main__":
    migrate()
