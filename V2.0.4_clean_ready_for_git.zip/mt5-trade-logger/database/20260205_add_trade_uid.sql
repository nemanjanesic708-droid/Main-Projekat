-- Add stable trade_uid for idempotent trade logging
ALTER TABLE trades ADD COLUMN trade_uid TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_trade_uid ON trades(trade_uid);
