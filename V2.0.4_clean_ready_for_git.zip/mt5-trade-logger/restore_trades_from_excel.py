"""
Restore trades from Excel file to database
Čita trades iz Excel fajla (MT5 Trade History Report format) i unosi ih u bazu
"""

import sqlite3
import openpyxl
import os

# Putanje
DESKTOP = os.path.expanduser("~\\Desktop")
EXCEL_FILE = os.path.join(DESKTOP, "ubaci u bazu.xlsx")
DB_PATH = os.path.join(os.path.dirname(__file__), "database", "trades.db")

def load_trades_from_excel():
    """Učitaj sve trades iz Excel fajla (MT5 Trade History Report)"""
    if not os.path.exists(EXCEL_FILE):
        print(f"❌ Excel fajl nije pronađen: {EXCEL_FILE}")
        return []
    
    try:
        wb = openpyxl.load_workbook(EXCEL_FILE)
        ws = wb.active
        
        trades = []
        
        # Pronađi "Positions" sekciju
        # Row 6: "Positions" label
        # Row 7: Headers
        # Row 8+: Data redovi
        
        # Pronađi početak Positions sekcije
        data_start = None
        for row_idx in range(1, ws.max_row + 1):
            if ws.cell(row_idx, 1).value == "Positions":
                data_start = row_idx + 2  # Preskči label red i header red
                break
        
        if data_start is None:
            print("❌ Nije pronađena 'Positions' sekcija u Excel fajlu")
            return []
        
        print(f"✓ Pronađena 'Positions' sekcija")
        
        # Pronađi gde se završava Positions sekcija
        data_end = ws.max_row
        for row_idx in range(data_start, ws.max_row + 1):
            first_cell = ws.cell(row_idx, 1).value
            if first_cell in ["Orders", "Deals", "Open Positions", "Market Price", "Commission", "Balance:"]:
                data_end = row_idx
                break
        
        print(f"✓ Čitam redove {data_start} do {data_end - 1}")
        
        # Čitaj sve redove sa podacima - direktno po indeksu kolone
        # Headers (Row 7): Time(1), Position(2), Symbol(3), Type(4), Volume(5), Price(6), S/L(7), T/P(8), Time(9), Price(10), Commission(11), Swap(12), Profit(13)
        
        for row_idx in range(data_start, data_end):
            # Preskoči prazne redove
            if ws.cell(row_idx, 2).value is None:  # Position kolona
                continue
            
            try:
                # Direktno čitaj po indeksu kolone
                open_time = ws.cell(row_idx, 1).value  # Col 1: Time
                position_id = ws.cell(row_idx, 2).value  # Col 2: Position
                symbol = ws.cell(row_idx, 3).value  # Col 3: Symbol
                direction = ws.cell(row_idx, 4).value  # Col 4: Type
                volume = ws.cell(row_idx, 5).value  # Col 5: Volume
                open_price = ws.cell(row_idx, 6).value  # Col 6: Price (open)
                sl = ws.cell(row_idx, 7).value  # Col 7: S/L
                tp = ws.cell(row_idx, 8).value  # Col 8: T/P
                close_time = ws.cell(row_idx, 9).value  # Col 9: Time (close)
                close_price = ws.cell(row_idx, 10).value  # Col 10: Price (close)
                commission = ws.cell(row_idx, 11).value  # Col 11: Commission
                swap = ws.cell(row_idx, 12).value  # Col 12: Swap
                profit = ws.cell(row_idx, 13).value  # Col 13: Profit
                
                # Validiraj position_id
                if isinstance(position_id, (int, float)):
                    trade = {
                        'open_time': open_time,
                        'position_id': position_id,
                        'symbol': symbol,
                        'direction': direction,
                        'volume': volume,
                        'open_price': open_price,
                        'sl': sl,
                        'tp': tp,
                        'close_time': close_time,
                        'close_price': close_price,
                        'commission': commission,
                        'swap': swap,
                        'profit': profit
                    }
                    trades.append(trade)
            except Exception as e:
                print(f"⚠ Greška pri parsiranju reda {row_idx}: {e}")
                continue
        
        print(f"✓ Učitano {len(trades)} trades iz Excel fajla")
        return trades
    
    except Exception as e:
        print(f"❌ Greška pri čitanju Excel fajla: {e}")
        import traceback
        traceback.print_exc()
        return []

def insert_trades_to_db(trades):
    """Unesi trades u bazu"""
    if not trades:
        print("❌ Nema trades za unošenje")
        return False
    
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        inserted = 0
        skipped = 0
        
        for idx, trade in enumerate(trades):
            try:
                # Prikupi podatke iz trade dictionaryja
                ticket = int(trade['position_id'])
                symbol = str(trade['symbol']).upper()
                direction = str(trade['direction']).upper()
                
                lot_size = float(trade['volume'])
                open_price = float(trade['open_price'])
                open_time = str(trade['open_time']) if trade['open_time'] else ''
                
                close_time = str(trade['close_time']) if trade['close_time'] else open_time
                close_price = float(trade['close_price']) if trade['close_price'] else open_price
                
                commission = float(trade['commission']) if trade['commission'] else 0.0
                swap = float(trade['swap']) if trade['swap'] else 0.0
                profit = float(trade['profit']) if trade['profit'] else 0.0
                
                status = 'CLOSED'
                
                # Unesi u bazu (bez commission i swap jer ne postoje u tabeli)
                cursor.execute("""
                    INSERT INTO trades (
                        ticket, symbol, lot_size, direction, open_time, open_price,
                        close_time, close_price, profit, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    ticket, symbol, lot_size, direction, open_time, open_price,
                    close_time, close_price, profit, status
                ))
                inserted += 1
                
            except Exception as e:
                print(f"⚠ Greška pri unosu trade-a {idx+1}: {e}")
                skipped += 1
                continue
        
        conn.commit()
        conn.close()
        
        print(f"✓ Uspešno uneseno {inserted} trades u bazu")
        if skipped > 0:
            print(f"⚠ Preskočeno {skipped} trades zbog greške")
        return True
    
    except Exception as e:
        print(f"❌ Greška pri unosu trades-a u bazu: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    print("=" * 60)
    print("RESTORE TRADES FROM EXCEL")
    print("=" * 60)
    print(f"Excel fajl: {EXCEL_FILE}")
    print(f"Baza podataka: {DB_PATH}")
    print()
    
    # Učitaj trades iz Excel-a
    trades = load_trades_from_excel()
    if not trades:
        return
    
    # Prikaži pregled
    print(f"\nPregled prvog trade-a:")
    if trades:
        first = trades[0]
        print(f"  Ticket: {first.get('position_id')}")
        print(f"  Symbol: {first.get('symbol')}")
        print(f"  Direction: {first.get('direction')}")
        print(f"  Volume: {first.get('volume')}")
        print(f"  Open Price: {first.get('open_price')}")
        print(f"  Close Price: {first.get('close_price')}")
        print(f"  Profit: {first.get('profit')}")
    
    # Unesi u bazu
    print()
    if insert_trades_to_db(trades):
        print("✓ Restore je uspešno završen!")
    else:
        print("❌ Greška pri restore-u")

if __name__ == "__main__":
    main()
