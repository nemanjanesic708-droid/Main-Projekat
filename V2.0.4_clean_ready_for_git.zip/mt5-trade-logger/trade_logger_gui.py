import os
import socket
import subprocess
import sys
import time
import traceback
from urllib.request import urlopen

import webview


ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
SERVER_SCRIPT = os.path.join(ROOT_DIR, "server", "trade_logger.py")
ICON_PATH = os.path.join(ROOT_DIR, "app_icon.ico")
PREFERRED_PORTS = [5000, 5001, 5002]
LOG_DIR = os.path.join(ROOT_DIR, "logs")
CRASH_LOG = os.path.join(LOG_DIR, "gui_crash.log")


def server_is_running(url: str) -> bool:
    try:
        with urlopen(url, timeout=2) as response:
            return response.status == 200
    except Exception:
        return False


def log_exception(context: str, exc: Exception) -> None:
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(CRASH_LOG, "a", encoding="utf-8") as handle:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        handle.write(f"{timestamp} [{context}] {type(exc).__name__}: {exc}\n")
        traceback.print_exc(file=handle)
        handle.write("\n")


def wait_for_endpoint(url: str, attempts: int = 5, delay_seconds: int = 4) -> bool:
    for _ in range(attempts):
        if server_is_running(url):
            return True
        time.sleep(delay_seconds)
    return False


def is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        try:
            sock.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def find_ephemeral_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def first_available_port() -> int:
    for port in PREFERRED_PORTS:
        if is_port_free(port):
            return port
    return find_ephemeral_port()


def start_server(port: int) -> None:
    if not is_port_free(port):
        raise RuntimeError(f"Port {port} is already in use. Cannot start local server.")

    health_url = f"http://127.0.0.1:{port}/health"

    if not os.path.exists(SERVER_SCRIPT):
        raise FileNotFoundError(f"Server script not found: {SERVER_SCRIPT}")

    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NO_WINDOW

    env = os.environ.copy()
    env["PORT"] = str(port)
    env["HOST"] = "127.0.0.1"

    subprocess.Popen(
        [sys.executable, SERVER_SCRIPT],
        cwd=ROOT_DIR,
        env=env,
        creationflags=creationflags,
    )

    for _ in range(30):
        if server_is_running(health_url):
            return
        time.sleep(0.5)

    raise RuntimeError(f"Trade Logger server did not start on time (port {port}).")


def set_window_icon(icon_path: str) -> None:
    """Set the window icon on Windows using ctypes (works with EdgeChromium)."""
    if os.name != "nt" or not os.path.isfile(icon_path):
        return
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        GCL_HICON = -14
        GCL_HICONSM = -34
        ICON_BIG = 1
        ICON_SMALL = 0
        WM_SETICON = 0x0080
        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x0010
        LR_DEFAULTSIZE = 0x0040

        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return

        # Load large icon (32×32 / 48×48 for Alt-Tab)
        h_icon_big = user32.LoadImageW(
            0, icon_path, IMAGE_ICON, 48, 48, LR_LOADFROMFILE
        )
        # Load small icon (16×16 for title bar)
        h_icon_sm = user32.LoadImageW(
            0, icon_path, IMAGE_ICON, 16, 16, LR_LOADFROMFILE
        )

        if h_icon_big:
            user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, h_icon_big)
        if h_icon_sm:
            user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, h_icon_sm)
    except Exception:
        pass  # non-critical – icon just won't change


def main() -> None:
    port = first_available_port()
    start_server(port)

    app_url = f"http://127.0.0.1:{port}/"
    stats_url = f"http://127.0.0.1:{port}/trades/stats"

    if not wait_for_endpoint(stats_url, attempts=5, delay_seconds=4):
        raise RuntimeError("Trade stats endpoint not ready. Server may be down.")

    window = webview.create_window(
        title="MT5 Trade Logger",
        url=app_url,
        width=1280,
        height=820,
        min_size=(900, 600),
    )

    def _on_shown():
        """Set native window icon once the window is visible."""
        time.sleep(0.3)
        set_window_icon(ICON_PATH)

    window.events.shown += _on_shown

    try:
        webview.start(debug=True, gui="edgechromium")
        return
    except Exception as exc:
        log_exception("webview_start_edgechromium", exc)

    try:
        webview.start(debug=True, gui="qt")
        return
    except Exception as exc:
        log_exception("webview_start_qt", exc)
        print("WebView2 Runtime is required to run this app on Windows.", file=sys.stderr)
        print("Install Microsoft Edge WebView2 Runtime and try again.", file=sys.stderr)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        log_exception("gui_crash", exc)
        print("GUI startup failed. Check logs/gui_crash.log for details.", file=sys.stderr)
