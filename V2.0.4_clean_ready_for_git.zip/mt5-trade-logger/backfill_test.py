#!/usr/bin/env python3
"""
Backfill Helper - Testiranje i verifikacija pre punog backfill-a
Koristi ovo da vidiš šta će biti ubačeno BEZ stvarnog insert-a
"""

import pandas as pd
import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), 'database', 'trades.db')
MT5_XLSX = '/mnt/data/ReportHistory-1512255861.xlsx'
DB_CSV = '/mnt/data/trades_20260111_112455.csv'

def test_connection():
    """Testira konekciju na bazu"""
    print("=" * 80)
    print("TEST 1: Database Connection")
    print("=" * 80)
    
    try:
        conn = sqlite3.connect(DB_PATH, timeout=10)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) as cnt FROM trades")
        count = cursor.fetchone()[0]
        print(f"✓ Database connection OK")
        print(f"✓ Total trades in DB: {count}")
        
        # Prikaži sve kolone
        cursor.execute("PRAGMA table_info(trades)")
        cols = cursor.fetchall()
        print(f"\n✓ Available columns ({len(cols)}):")
        for i, col in enumerate(cols, 1):
            print(f"  {i:2d}. {col[1]:<30} ({col[2]})")
        
        conn.close()
        return True
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_xlsx_load():
    """Testira učitavanje MT5 xlsx"""
    print("\n" + "=" * 80)
    print("TEST 2: Load MT5 Excel Report")
    print("=" * 80)
    
    try:
        if not os.path.exists(MT5_XLSX):
            print(f"✗ File not found: {MT5_XLSX}")
            return False
        
        xls = pd.ExcelFile(MT5_XLSX)
        print(f"✓ Excel file found")
        print(f"✓ Available sheets: {xls.sheet_names}")
        
        # Pokušaj da učitaš Positions
        if 'Positions' in xls.sheet_names:
            df = pd.read_excel(MT5_XLSX, sheet_name='Positions')
            print(f"✓ 'Positions' sheet found")
        else:
            print(f"✗ 'Positions' sheet not found, trying first sheet...")
            df = pd.read_excel(MT5_XLSX, sheet_name=0)
        
        print(f"✓ Loaded {len(df)} rows")
        print(f"✓ Columns: {list(df.columns)}")
        
        # Prikaži prvi red
        print(f"\n✓ Sample row:")
        print(df.iloc[0])
        
        return True, df
    except Exception as e:
        print(f"✗ Error: {e}")
        return False, None

def test_csv_load():
    """Testira učitavanje DB CSV"""
    print("\n" + "=" * 80)
    print("TEST 3: Load DB CSV Export")
    print("=" * 80)
    
    try:
        if not os.path.exists(DB_CSV):
            print(f"✗ File not found: {DB_CSV}")
            return False
        
        df = pd.read_csv(DB_CSV)
        print(f"✓ CSV file found")
        print(f"✓ Loaded {len(df)} rows")
        print(f"✓ Columns: {list(df.columns)}")
        
        # Prikaži prvi red
        print(f"\n✓ Sample row:")
        print(df.iloc[0])
        
        return True, df
    except Exception as e:
        print(f"✗ Error: {e}")
        return False, None

def test_matching(df_mt5, df_db):
    """Testira pronalaženje matching trade-ova"""
    print("\n" + "=" * 80)
    print("TEST 4: Trade Matching")
    print("=" * 80)
    
    if df_mt5 is None or df_db is None:
        print("✗ Missing data for matching")
        return False
    
    def extract_key(row, source='mt5'):
        if source == 'mt5':
            timestamp = str(row.get('open_time', '')).strip()
            symbol = str(row.get('symbol', '')).strip()
            entry_price = float(row.get('open_price', 0))
            profit = float(row.get('profit', 0))
        else:
            timestamp = str(row.get('timestamp', '')).strip()
            symbol = str(row.get('symbol', '')).strip()
            entry_price = float(row.get('entry_price', 0))
            profit = float(row.get('profit', 0))
        
        return f"{timestamp}|{symbol}|{entry_price:.5f}|{profit:.2f}"
    
    # Kreiraj set ključeva iz baze
    db_keys = set()
    for _, row in df_db.iterrows():
        key = extract_key(row, source='db')
        db_keys.add(key)
    
    print(f"✓ DB keys: {len(db_keys)}")
    
    # Pronađi matching i missing
    matching = []
    missing = []
    
    for _, row in df_mt5.iterrows():
        key = extract_key(row, source='mt5')
        if key in db_keys:
            matching.append(row)
        else:
            missing.append(row)
    
    print(f"✓ Matching trades: {len(matching)}")
    print(f"✓ Missing trades: {len(missing)}")
    
    if missing:
        print(f"\n✓ Missing trades details:")
        for i, trade in enumerate(missing, 1):
            print(f"  {i}. {trade.get('open_time')} | {trade.get('symbol')} | "
                  f"Entry: {trade.get('open_price'):.5f} | Profit: {trade.get('profit'):.2f}")
        
        total_missing_profit = sum(float(t.get('profit', 0)) for t in missing)
        print(f"\n✓ Total missing profit: {total_missing_profit:.2f}")
    
    return True

def test_defaults():
    """Testira pronalaženje template red-a"""
    print("\n" + "=" * 80)
    print("TEST 5: Template Row (Safe Defaults)")
    print("=" * 80)
    
    try:
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM trades LIMIT 1")
        template = cursor.fetchone()
        
        if template:
            print(f"✓ Template row found")
            print(f"\n✓ Sample default values:")
            for i, col in enumerate(['magic_number', 'entry_tf', 'trend_tf', 
                                     'session_active', 'risk_mode', 'risk_percent'], 1):
                try:
                    val = template[col]
                    print(f"  {col}: {val}")
                except:
                    print(f"  {col}: (not available)")
        else:
            print(f"✗ No template row found (DB is empty?)")
        
        conn.close()
        return True
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def main():
    print("\n")
    print("#" * 80)
    print("# BACKFILL HELPER - Pre-flight Checks")
    print("#" * 80)
    print("\n")
    
    # Test 1: Database
    if not test_connection():
        print("\n✗ STOP: Fix database connection first!")
        return
    
    # Test 2: Excel
    success, df_mt5 = test_xlsx_load()
    if not success:
        print("\n✗ STOP: Fix Excel file loading first!")
        return
    
    # Test 3: CSV
    success, df_db = test_csv_load()
    if not success:
        print("\n✗ STOP: Fix CSV file loading first!")
        return
    
    # Test 4: Matching
    if not test_matching(df_mt5, df_db):
        print("\n✗ STOP: Fix trade matching first!")
        return
    
    # Test 5: Defaults
    if not test_defaults():
        print("\n✗ STOP: Fix template row first!")
        return
    
    print("\n" + "=" * 80)
    print("✓ ALL TESTS PASSED!")
    print("=" * 80)
    print("\nYou can now run: python backfill_missing_trades.py")
    print("\n")

if __name__ == '__main__':
    main()
