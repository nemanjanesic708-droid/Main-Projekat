"""
Dodaje trejdove iz slike u bazu
"""
import sqlite3

DB_PATH = 'database/trades.db'

def add_trades_from_screenshot():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    trades = [
        (361807214, 'EURUSD', 0.34, 'BUY', '2025-12-05 08:00:00', 1.16591, '2025-12-05 07:30:27', 'CLOSED'),
        (361664906, 'EURUSD', 0.22, 'BUY', '2025-12-04 17:00:00', 1.16698, '2025-12-05 07:30:27', 'CLOSED'),
        (361538406, 'EURUSD', 0.11, 'BUY', '2025-12-04 10:53:06', 1.16812, '2025-12-05 07:30:27', 'CLOSED'),
        (361496244, 'EURUSD', 0.32, 'BUY', '2025-12-04 08:00:01', 1.16598, '2025-12-05 07:30:27', 'CLOSED'),
    ]
    
    for trade in trades:
        cursor.execute('''
            INSERT INTO trades (ticket, symbol, lot_size, direction, open_time, open_price, 
                              close_time, status, close_price, profit, stop_loss, take_profit, 
                              magic_number, comment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, '')
        ''', trade)
    
    conn.commit()
    conn.close()
    
    print(f"✅ Dodato {len(trades)} trejdova u bazu!")

if __name__ == "__main__":
    add_trades_from_screenshot()
