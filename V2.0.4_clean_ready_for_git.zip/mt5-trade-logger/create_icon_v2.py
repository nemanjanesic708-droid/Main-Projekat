"""
MT5 Trade Logger V2 – Icon Generator
=====================================
Generates a high-quality dark-theme icon at 1024×1024 then exports
app_icon.png  (1024 source)
app_icon.ico  (16, 24, 32, 48, 64, 128, 256 – 256 PNG-compressed)

Design:  rounded dark square  ·  ascending bar-chart  ·  equity-curve line
         teal glow border  ·  no text  ·  matches V2 dark dashboard theme
"""

import math
import os
import io
import struct
from PIL import Image, ImageDraw, ImageFilter


def _build_ico(master_img, sizes, out_path):
    """
    Build an ICO file manually from a master RGBA image.
    Sizes <= 48 are stored as BMP; sizes > 48 as embedded PNG (better quality).
    """
    entries = []  # (width, height, raw_bytes)
    for s in sizes:
        frame = master_img.resize((s, s), Image.Resampling.LANCZOS).convert("RGBA")
        if s > 48:
            # Store as PNG (better quality, smaller file for large sizes)
            buf = io.BytesIO()
            frame.save(buf, format="PNG")
            entries.append((s, s, buf.getvalue()))
        else:
            # Store as BMP (BITMAPINFOHEADER + pixel data + AND mask)
            w, h = s, s
            pixels = frame.load()
            # BITMAPINFOHEADER (40 bytes)
            bih = struct.pack(
                "<IiiHHIIiiII",
                40,          # biSize
                w,           # biWidth
                h * 2,       # biHeight (doubled for ICO: XOR + AND)
                1,           # biPlanes
                32,          # biBitCount
                0,           # biCompression (BI_RGB)
                0,           # biSizeImage (can be 0 for BI_RGB)
                0, 0,        # biXPelsPerMeter, biYPelsPerMeter
                0, 0,        # biClrUsed, biClrImportant
            )
            # Pixel data: bottom-up, BGRA
            pixel_data = bytearray()
            for y in range(h - 1, -1, -1):
                for x in range(w):
                    r, g, b, a = pixels[x, y]
                    pixel_data.extend([b, g, r, a])
            # AND mask: 1-bit per pixel, rows padded to 4 bytes
            and_row_bytes = ((w + 31) // 32) * 4
            and_mask = bytearray(and_row_bytes * h)  # all zeros = fully opaque
            raw = bih + bytes(pixel_data) + bytes(and_mask)
            entries.append((w, h, raw))

    # ICO file structure
    n = len(entries)
    header = struct.pack("<HHH", 0, 1, n)  # reserved=0, type=1 (ICO), count
    dir_size = 6 + n * 16
    offset = dir_size
    directory = bytearray()
    data_blobs = bytearray()

    for w, h, raw in entries:
        bw = 0 if w >= 256 else w
        bh = 0 if h >= 256 else h
        directory.extend(struct.pack(
            "<BBBBHHII",
            bw, bh,  # width, height (0 means 256)
            0,        # color palette count
            0,        # reserved
            1,        # color planes
            32,       # bits per pixel
            len(raw), # data size
            offset,   # offset from beginning of file
        ))
        data_blobs.extend(raw)
        offset += len(raw)

    with open(out_path, "wb") as f:
        f.write(header)
        f.write(bytes(directory))
        f.write(bytes(data_blobs))

# ── Palette (pulled from app CSS variables) ────────────────────────────
BG_OUTER   = (12, 14, 18)        # --bg-0
BG_INNER   = (18, 21, 27)        # --bg-1
BORDER     = (45, 212, 191)      # --accent  teal
GRID_LINE  = (35, 40, 50)        # subtle grid
BAR_COLORS = [
    (239,  68,  68),              # red   (loss-ish)
    (245, 158,  11),              # amber (middle)
    (234, 179,   8),              # yellow
    (34, 197,  94),               # green (profit)
    (16, 185, 129),               # emerald
]
CURVE_CLR  = (45, 212, 191)      # teal equity curve
GLOW_CLR   = (45, 212, 191, 55)  # translucent glow


SZ = 1024  # master canvas


def rounded_rect_mask(size, radius):
    """Return an L-mode mask with a rounded rectangle."""
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    return mask


def draw_icon(sz=SZ):
    canvas = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)

    pad  = int(sz * 0.04)          # outer padding for glow room
    r    = int(sz * 0.18)          # corner radius
    inner = sz - 2 * pad

    # ── 1.  Outer glow layer ──────────────────────────────────────────
    glow = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.rounded_rectangle(
        [pad - 6, pad - 6, pad + inner + 5, pad + inner + 5],
        radius=r + 4,
        fill=(*BORDER, 50),
    )
    glow = glow.filter(ImageFilter.GaussianBlur(radius=int(sz * 0.025)))
    canvas = Image.alpha_composite(canvas, glow)
    draw = ImageDraw.Draw(canvas)  # get fresh draw after composite

    # ── 2.  Dark background rounded rect ──────────────────────────────
    draw.rounded_rectangle(
        [pad, pad, pad + inner - 1, pad + inner - 1],
        radius=r,
        fill=(*BG_INNER, 255),
        outline=(*BORDER, 140),
        width=max(2, int(sz * 0.005)),
    )

    # ── 3.  Interior metrics ──────────────────────────────────────────
    chart_left   = pad + int(inner * 0.14)
    chart_right  = pad + int(inner * 0.88)
    chart_top    = pad + int(inner * 0.16)
    chart_bottom = pad + int(inner * 0.82)
    chart_w = chart_right - chart_left
    chart_h = chart_bottom - chart_top

    # ── 4.  Subtle horizontal grid lines ──────────────────────────────
    for i in range(1, 5):
        y = chart_bottom - int(chart_h * i / 5)
        draw.line([(chart_left, y), (chart_right, y)],
                  fill=(*GRID_LINE, 80), width=max(1, int(sz * 0.002)))

    # ── 5.  Bars ──────────────────────────────────────────────────────
    n_bars  = 5
    gap_frac = 0.28           # fraction of slot used as gap
    slot_w  = chart_w / n_bars
    bar_w   = int(slot_w * (1 - gap_frac))
    gap     = int(slot_w * gap_frac)

    # Heights as fraction of chart_h – ascending pattern
    heights = [0.22, 0.38, 0.30, 0.55, 0.82]

    bar_tops = []
    for i, h_frac in enumerate(heights):
        x0 = chart_left + int(i * slot_w + gap / 2)
        x1 = x0 + bar_w
        bar_h = int(chart_h * h_frac)
        y0 = chart_bottom - bar_h
        y1 = chart_bottom

        color = BAR_COLORS[i]

        # Gradient-ish effect: draw bar + slightly lighter top stripe
        draw.rounded_rectangle(
            [x0, y0, x1, y1],
            radius=max(2, int(sz * 0.012)),
            fill=(*color, 230),
        )

        # Highlight top portion
        hl_h = max(2, int(bar_h * 0.18))
        lighter = tuple(min(255, c + 45) for c in color)
        draw.rounded_rectangle(
            [x0 + 1, y0, x1 - 1, y0 + hl_h],
            radius=max(2, int(sz * 0.010)),
            fill=(*lighter, 180),
        )

        bar_tops.append((x0 + bar_w // 2, y0))   # center-top for curve

    # ── 6.  Equity-curve line over bars ───────────────────────────────
    # Smooth curve through bar tops with some offset upward
    pts = []
    for i, (cx, cy) in enumerate(bar_tops):
        pts.append((cx, cy - int(chart_h * 0.04)))

    # Draw thicker glow line first
    if len(pts) >= 2:
        curve_glow = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
        cg_draw = ImageDraw.Draw(curve_glow)
        cg_draw.line(pts, fill=(*CURVE_CLR, 50), width=max(4, int(sz * 0.014)), joint="curve")
        curve_glow = curve_glow.filter(ImageFilter.GaussianBlur(radius=int(sz * 0.008)))
        canvas = Image.alpha_composite(canvas, curve_glow)
        draw = ImageDraw.Draw(canvas)

        # Sharp main line
        draw.line(pts, fill=(*CURVE_CLR, 220), width=max(2, int(sz * 0.006)), joint="curve")

        # Dots at each point
        dot_r = max(2, int(sz * 0.010))
        for px, py in pts:
            draw.ellipse(
                [px - dot_r, py - dot_r, px + dot_r, py + dot_r],
                fill=(*CURVE_CLR, 255),
                outline=(255, 255, 255, 120),
                width=max(1, int(sz * 0.002)),
            )

        # Arrow-head on last point pointing up-right
        last_x, last_y = pts[-1]
        prev_x, prev_y = pts[-2]
        angle = math.atan2(last_y - prev_y, last_x - prev_x)
        arr_len = int(sz * 0.035)
        for side in [-1, 1]:
            a = angle + math.pi + side * 0.45
            ax = last_x + int(arr_len * math.cos(a))
            ay = last_y + int(arr_len * math.sin(a))
            draw.line([(last_x, last_y), (ax, ay)],
                      fill=(*CURVE_CLR, 220),
                      width=max(2, int(sz * 0.005)))

    # ── 7.  Baseline ─────────────────────────────────────────────────
    draw.line(
        [(chart_left, chart_bottom), (chart_right, chart_bottom)],
        fill=(*BORDER, 100),
        width=max(1, int(sz * 0.003)),
    )

    return canvas


def main():
    root = os.path.dirname(os.path.abspath(__file__))

    print("Generating 1024×1024 master icon …")
    master = draw_icon(SZ)

    # Save high-res PNG
    png_path = os.path.join(root, "app_icon.png")
    master.save(png_path, "PNG")
    print(f"  ✔ {png_path}")

    # Generate ICO with all required sizes
    ico_sizes = [16, 24, 32, 48, 64, 128, 256]
    ico_path = os.path.join(root, "app_icon.ico")

    # Pillow's ICO save is unreliable for multi-frame, so build the ICO manually
    _build_ico(master, ico_sizes, ico_path)
    print(f"  ✔ {ico_path}  ({', '.join(f'{s}×{s}' for s in ico_sizes)})")

    # Copy ICO to static for favicon
    import shutil
    static_ico = os.path.join(root, "server", "static", "favicon.ico")
    shutil.copy2(ico_path, static_ico)
    print(f"  ✔ {static_ico}")

    # Also save a 32×32 PNG for web favicon
    favicon_path = os.path.join(root, "server", "static", "favicon.png")
    fav = master.resize((32, 32), Image.Resampling.LANCZOS)
    fav.save(favicon_path, "PNG")
    print(f"  ✔ {favicon_path}")

    # And a 180×180 for apple-touch / high-dpi
    touch_path = os.path.join(root, "server", "static", "icon-180.png")
    touch = master.resize((180, 180), Image.Resampling.LANCZOS)
    touch.save(touch_path, "PNG")
    print(f"  ✔ {touch_path}")

    print("\nDone – icon V2 generated.")


if __name__ == "__main__":
    main()
