import requests

url = "http://127.0.0.1:5000/trades/add"
headers = {"Content-Type": "application/json"}
data = {
    "symbol": "EURUSD",
    "lot_size": 0.1,  # Required field
    "direction": "BUY",  # Required field
    "open_time": "2025-12-19 12:00:00",  # Required field
    "open_price": 1.085,  # Required field
    "status": "OPEN",  # Required field
    "magic_number": 123456,
    "trend_tf": "H1",
    "entry_tf": "M15",
    "timestamp": "2025-12-19 12:00:00",
    "day_of_week": "Friday",
    "hour": 12,
    "session_active": 1,
    "ema_fast_20": 1.085,
    "ema_slow_100": 1.080,
    "ema_fast_above_slow": 1,
    "ema_fast_slope": 0.01,
    "ema_slow_slope": 0.005,
    "price_vs_fast_ema": 0.002,
    "price_vs_slow_ema": 0.003,
    "trend_direction": "UP",
    "pullback_ema_20": 1.084,
    "price_distance_from_pullback_ema": 0.001,
    "pullback_valid": 1,
    "pullback_depth_pips": 10,
    "donchian_high": 1.09,
    "donchian_low": 1.07,
    "donchian_range": 0.02,
    "price_vs_don_high": 1,
    "price_vs_don_low": 0,
    "donchian_breakout": 1,
    "don_buffer_pips": 1.5,
    "adx_value": 25,
    "adx_above_min": 1,
    "di_plus": 20,
    "di_minus": 10,
    "trend_strength": "strong",
    "atr_value": 0.0015,
    "atr_pips": 15,
    "atr_above_min": 1,
    "atr_percent_of_price": 0.1,
    "risk_mode": "auto",
    "risk_percent": 0.25,
    "sl_multiplier": 1.2,
    "tp_multiplier": 2.4,
    "calculated_sl_pips": 12,
    "calculated_tp_pips": 24,
    "rr_ratio": 2.0,
    # ...existing code...
    "spread_points": 10,
    "spread_ok": 1,
    "one_entry_per_bar_pass": 1,
    "session_hour": 12,
    "session_allowed": 1,
    "daily_loss_percent": 0.5,
    "consecutive_losses": 0,
    "equity_dd_percent": 0.0,
    "risk_block_active": 0,
    "risk_block_reason": "",
    "signal_type": "breakout",
    "allow_longs": 1,
    "allow_shorts": 1,
    "filters_passed_count": 5,
    "filters_failed_count": 0,
    "final_decision": "open",
    "skip_reason": "",
    "entry_price": 1.085,
    "exit_price": None,
    "exit_reason": None,
    "profit": None,
    "profit_r": None,
    "duration_seconds": None,
    "max_floating_profit": None,
    "max_floating_dd": None,
    "setup_result": None
}

response = requests.post(url, json=data, headers=headers)
print("Status code:", response.status_code)
print("Response:", response.text)
