"""
Skripta za ažuriranje statusa zatvorenih trejdova
Zatvara sve OPEN trejdove koji više ne postoje kao otvorene pozicije
"""
import sqlite3
from datetime import datetime

DB_PATH = 'database/trades.db'

def close_finished_trades():
    """Zatvara sve trejdove koji su označeni kao OPEN ali su već zatvoreni"""
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    cursor = conn.cursor()
    
    # Uzmi sve OPEN trejdove
    cursor.execute('SELECT ticket, symbol, open_time FROM trades WHERE status = ?', ('OPEN',))
    open_trades = cursor.fetchall()
    
    print(f"Pronađeno {len(open_trades)} otvorenih trejdova u bazi")
    
    # Za svaki trejd, postavi status na CLOSED sa trenutnim vremenom
    # (pošto ne znamo tačno vreme zatvaranja)
    for ticket, symbol, open_time in open_trades:
        close_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Postavi profit na 0 jer ne znamo pravi profit
        cursor.execute('''
            UPDATE trades 
            SET status = ?, 
                close_time = ?, 
                close_price = 0,
                profit = 0
            WHERE ticket = ?
        ''', ('CLOSED', close_time, ticket))
        
        print(f"✓ Zatvoren trejd #{ticket} ({symbol})")
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ Ažurirano {len(open_trades)} trejdova")
    print("Napomena: Trejdovi su označeni kao zatvoreni sa profit=0")
    print("Novi trejdovi će se pravilno logovati sa pravim podacima!")

if __name__ == "__main__":
    close_finished_trades()
