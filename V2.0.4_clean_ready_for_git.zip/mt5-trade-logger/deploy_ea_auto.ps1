# Deploy EA + local includes from this repo into the active MT5 Terminal(s).
#
# Copies:
# - TrendPortfolio_v2_fix_sync.mq5
# - TradeLogger.mqh
# - potencijalni.mqh
#
# into the same folder where an existing TrendPortfolio_v2_fix_sync.mq5 is found under:
#   %APPDATA%\MetaQuotes\Terminal\*\MQL5\Experts\**
#
# If you have multiple terminals, it will deploy to all matches.

$ErrorActionPreference = "Stop"

$srcDir = $PSScriptRoot
$files = @(
  "TrendPortfolio_v2_fix_sync.mq5",
  "TradeLogger.mqh",
  "potencijalni.mqh"
)

foreach ($f in $files) {
  $p = Join-Path $srcDir $f
  if (-not (Test-Path $p)) {
    Write-Host "Missing source file: $p"
    exit 2
  }
}

$terminalRoot = Join-Path $env:APPDATA "MetaQuotes\\Terminal"
if (-not (Test-Path $terminalRoot)) {
  Write-Host "MT5 Terminal root not found: $terminalRoot"
  exit 3
}

$matches = @()
Get-ChildItem -Path $terminalRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
  $experts = Join-Path $_.FullName "MQL5\\Experts"
  if (-not (Test-Path $experts)) { return }
  $found = Get-ChildItem -Path $experts -Recurse -Filter "TrendPortfolio_v2_fix_sync.mq5" -File -ErrorAction SilentlyContinue
  if ($found) { $matches += $found }
}

if ($matches.Count -eq 0) {
  Write-Host "No existing TrendPortfolio_v2_fix_sync.mq5 found under: $terminalRoot"
  Write-Host "Open MetaEditor once and compile any copy of the EA, then re-run this script."
  exit 4
}

foreach ($m in $matches) {
  $destDir = Split-Path -Parent $m.FullName
  Write-Host "Deploying to: $destDir"
  foreach ($f in $files) {
    $src = Join-Path $srcDir $f
    $dst = Join-Path $destDir $f
    Copy-Item -Path $src -Destination $dst -Force
  }
  Write-Host "OK: $($m.FullName)"
}

Write-Host ("Done. Deployed to {0} location(s)." -f $matches.Count)

