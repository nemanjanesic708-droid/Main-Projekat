import sqlite3
import os

db_path = "database/trades.db"
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Create trades table
cursor.execute('''
CREATE TABLE trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket INTEGER UNIQUE NOT NULL,
    symbol TEXT NOT NULL,
    type TEXT NOT NULL,
    volume REAL NOT NULL,
    open_price REAL NOT NULL,
    open_time TEXT NOT NULL,
    close_price REAL DEFAULT NULL,
    close_time TEXT DEFAULT NULL,
    profit REAL DEFAULT NULL,
    status TEXT DEFAULT 'open',
    comment TEXT DEFAULT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)
''')

# Create indices
cursor.execute('CREATE INDEX idx_ticket ON trades(ticket)')
cursor.execute('CREATE INDEX idx_symbol ON trades(symbol)')
cursor.execute('CREATE INDEX idx_status ON trades(status)')
cursor.execute('CREATE INDEX idx_open_time ON trades(open_time)')

conn.commit()
conn.close()
print(f"✓ Nova baza kreirana: {db_path}")
