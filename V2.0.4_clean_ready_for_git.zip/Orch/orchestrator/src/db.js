﻿'use strict';

const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3');

let db;
let tradeSchema;

function resolveDbPath() {
  const raw = process.env.SQLITE_DB_PATH;
  if (!raw) {
    console.error('Missing SQLITE_DB_PATH');
    process.exit(1);
  }
  return path.isAbsolute(raw) ? raw : path.resolve(process.cwd(), raw);
}

function quoteIdent(name) {
  return `"${String(name).replace(/"/g, '""')}"`;
}

function ensureDb() {
  if (!db) {
    throw new Error('Database not initialized. Call initDb() first.');
  }
  return db;
}

function run(sql, params = []) {
  const conn = ensureDb();
  return new Promise((resolve, reject) => {
    conn.run(sql, params, function onRun(err) {
      if (err) return reject(err);
      return resolve({ changes: this.changes, lastID: this.lastID });
    });
  });
}

function get(sql, params = []) {
  const conn = ensureDb();
  return new Promise((resolve, reject) => {
    conn.get(sql, params, (err, row) => {
      if (err) return reject(err);
      return resolve(row);
    });
  });
}

function all(sql, params = []) {
  const conn = ensureDb();
  return new Promise((resolve, reject) => {
    conn.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      return resolve(rows);
    });
  });
}

function exec(sql) {
  const conn = ensureDb();
  return new Promise((resolve, reject) => {
    conn.exec(sql, (err) => {
      if (err) return reject(err);
      return resolve();
    });
  });
}

async function transaction(fn) {
  await run('BEGIN');
  try {
    const result = await fn();
    await run('COMMIT');
    return result;
  } catch (err) {
    await run('ROLLBACK');
    throw err;
  }
}

async function loadTradeSchema() {
  const rows = await all('PRAGMA table_info(trades)');
  if (!rows.length) {
    console.error('Missing required table: trades');
    process.exit(1);
  }

  const map = new Map();
  for (const row of rows) {
    map.set(String(row.name).toLowerCase(), row.name);
  }

  const has = (name) => map.has(String(name).toLowerCase());
  const col = (name) => map.get(String(name).toLowerCase());

  const requiredForOpen = ['ticket', 'symbol', 'direction', 'open_time', 'open_price', 'status'];
  const missingOpen = requiredForOpen.filter((name) => !has(name));

  const requiredForClose = ['ticket', 'close_time', 'close_price', 'profit'];
  const missingClose = requiredForClose.filter((name) => !has(name));

  const closeReasonColumn = has('close_reason')
    ? col('close_reason')
    : has('exit_reason')
      ? col('exit_reason')
      : null;

  if (!closeReasonColumn) {
    missingClose.push('close_reason/exit_reason');
  }

  if (missingOpen.length || missingClose.length) {
    const parts = [];
    if (missingOpen.length) parts.push(`missing for trade_open: ${missingOpen.join(', ')}`);
    if (missingClose.length) parts.push(`missing for trade_close/cooldown: ${missingClose.join(', ')}`);
    console.error(`Trades schema mismatch: ${parts.join(' | ')}`);
    process.exit(1);
  }

  let openWhere = null;
  if (has('is_open')) {
    openWhere = `${quoteIdent(col('is_open'))} = 1`;
  } else if (has('close_time')) {
    openWhere = `${quoteIdent(col('close_time'))} IS NULL`;
  } else if (has('close_reason')) {
    openWhere = `${quoteIdent(col('close_reason'))} IS NULL`;
  } else if (has('exit_reason')) {
    openWhere = `${quoteIdent(col('exit_reason'))} IS NULL`;
  }

  if (!openWhere) {
    console.error('Cannot detect open trades: missing is_open/close_time/close_reason/exit_reason columns.');
    process.exit(1);
  }

  tradeSchema = {
    columns: map,
    has,
    col,
    q: quoteIdent,
    openWhere,
    closeReasonColumn,
  };
}

function getTradeSchema() {
  if (!tradeSchema) {
    throw new Error('Trade schema not loaded. Call initDb() first.');
  }
  return tradeSchema;
}

function parseMaybeInt(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}

function normalizeScopeValue(value) {
  if (value === undefined || value === null) return '';
  return String(value).trim();
}

function qualifyOpenWhere(openWhere, alias = 't') {
  return String(openWhere).replace(/"([^"]+)"/g, `${alias}."$1"`);
}

function buildMapJoinClause(schema, mapAlias = 'm', tradeAlias = 't') {
  const ticketCol = schema.col('ticket');
  const idCol = schema.has('id') ? schema.col('id') : null;
  if (!idCol) {
    return `${tradeAlias}.${schema.q(ticketCol)} = ${mapAlias}.ticket`;
  }
  return `(
    (${mapAlias}.trade_row_id IS NOT NULL AND ${tradeAlias}.${schema.q(idCol)} = ${mapAlias}.trade_row_id)
    OR
    (${mapAlias}.trade_row_id IS NULL AND ${tradeAlias}.${schema.q(ticketCol)} = ${mapAlias}.ticket)
  )`;
}

function buildScopeFilter(schema, accountId, botId) {
  const accountValue = normalizeScopeValue(accountId);
  const botValue = normalizeScopeValue(botId);
  const params = [];
  const clauses = [];

  let mapClause = 'm.account_id = ?';
  params.push(accountValue);
  if (botValue) {
    mapClause += ' AND m.bot_id = ?';
    params.push(botValue);
  }
  clauses.push(`(${mapClause})`);

  if (schema.has('account_id')) {
    clauses.push(`(m.id IS NULL AND t.${schema.q(schema.col('account_id'))} = ?)`);
    params.push(accountValue);
  }

  return {
    whereSql: clauses.join(' OR '),
    params,
  };
}

function determineTradeResult(row, closeReasonColumn) {
  if (!row) return null;
  const profit = Number(row.profit);
  const reasonRaw = closeReasonColumn ? row[closeReasonColumn] : row.close_reason;
  const reason = String(reasonRaw || '').trim().toUpperCase();
  if (reason === 'SL') return 'loss';
  if (Number.isFinite(profit) && profit > 0) return 'win';
  if (Number.isFinite(profit) && profit < 0) return 'loss';
  if (Number.isFinite(profit) && profit === 0) return 'breakeven';
  return null;
}

async function getDailyMetrics({ accountId, botId, cooldownMin = 0 }) {
  const schema = getTradeSchema();
  const openTimeCol = schema.col('open_time');
  const closeTimeCol = schema.col('close_time');
  const profitCol = schema.col('profit');
  const closeReasonCol = schema.closeReasonColumn;

  const joinSql = buildMapJoinClause(schema, 'm', 't');
  const scope = buildScopeFilter(schema, accountId, botId);
  const openDayWindow =
    `datetime(t.${schema.q(openTimeCol)}) >= datetime('now', 'start of day') AND ` +
    `datetime(t.${schema.q(openTimeCol)}) < datetime('now', 'start of day', '+1 day')`;
  const closeDayWindow =
    `datetime(t.${schema.q(closeTimeCol)}) >= datetime('now', 'start of day') AND ` +
    `datetime(t.${schema.q(closeTimeCol)}) < datetime('now', 'start of day', '+1 day')`;
  const lossPredicate = closeReasonCol
    ? `(UPPER(COALESCE(t.${schema.q(closeReasonCol)}, '')) = 'SL' OR COALESCE(t.${schema.q(profitCol)}, 0) < 0)`
    : `COALESCE(t.${schema.q(profitCol)}, 0) < 0`;

  const dailyTradesRow = await get(
    `SELECT COUNT(*) AS cnt
     FROM trades t
     LEFT JOIN orch_trade_map m ON ${joinSql}
     WHERE (${scope.whereSql})
       AND t.${schema.q(openTimeCol)} IS NOT NULL
       AND ${openDayWindow}`,
    scope.params
  );

  const dailyLossesRow = await get(
    `SELECT COUNT(*) AS cnt
     FROM trades t
     LEFT JOIN orch_trade_map m ON ${joinSql}
     WHERE (${scope.whereSql})
       AND t.${schema.q(closeTimeCol)} IS NOT NULL
       AND ${closeDayWindow}
       AND ${lossPredicate}`,
    scope.params
  );

  const dayPnlRow = await get(
    `SELECT COALESCE(SUM(COALESCE(t.${schema.q(profitCol)}, 0)), 0) AS pnl
     FROM trades t
     LEFT JOIN orch_trade_map m ON ${joinSql}
     WHERE (${scope.whereSql})
       AND t.${schema.q(closeTimeCol)} IS NOT NULL
       AND ${closeDayWindow}`,
    scope.params
  );

  const openPositionsRow = await get(
    `SELECT COUNT(*) AS cnt
     FROM trades t
     LEFT JOIN orch_trade_map m ON ${joinSql}
     WHERE (${scope.whereSql})
       AND (${qualifyOpenWhere(schema.openWhere, 't')})`,
    scope.params
  );

  const lastClosedRow = await get(
    `SELECT t.${schema.q(profitCol)} AS profit,
            ${closeReasonCol ? `t.${schema.q(closeReasonCol)} AS close_reason` : `NULL AS close_reason`},
            t.${schema.q(closeTimeCol)} AS close_time
     FROM trades t
     LEFT JOIN orch_trade_map m ON ${joinSql}
     WHERE (${scope.whereSql})
       AND t.${schema.q(closeTimeCol)} IS NOT NULL
     ORDER BY datetime(t.${schema.q(closeTimeCol)}) DESC
     LIMIT 1`,
    scope.params
  );

  const recentClosedRows = await all(
    `SELECT t.${schema.q(profitCol)} AS profit,
            ${closeReasonCol ? `t.${schema.q(closeReasonCol)} AS close_reason` : `NULL AS close_reason`}
     FROM trades t
     LEFT JOIN orch_trade_map m ON ${joinSql}
     WHERE (${scope.whereSql})
       AND t.${schema.q(closeTimeCol)} IS NOT NULL
     ORDER BY datetime(t.${schema.q(closeTimeCol)}) DESC
     LIMIT 50`,
    scope.params
  );

  let currentLossStreak = 0;
  for (const row of recentClosedRows) {
    const result = determineTradeResult(row, 'close_reason');
    if (result !== 'loss') break;
    currentLossStreak += 1;
  }

  let cooldownRemainingSec = 0;
  let lastLossTime = null;
  if (parseMaybeInt(cooldownMin, 0) > 0) {
    const cooldownRow = await get(
      `SELECT (strftime('%s', t.${schema.q(closeTimeCol)}) + (? * 60) - strftime('%s', 'now')) AS remaining_sec,
              t.${schema.q(closeTimeCol)} AS last_loss_time
       FROM trades t
       LEFT JOIN orch_trade_map m ON ${joinSql}
       WHERE (${scope.whereSql})
         AND t.${schema.q(closeTimeCol)} IS NOT NULL
         AND ${lossPredicate}
       ORDER BY datetime(t.${schema.q(closeTimeCol)}) DESC
       LIMIT 1`,
      [parseMaybeInt(cooldownMin, 0), ...scope.params]
    );

    if (cooldownRow) {
      lastLossTime = cooldownRow.last_loss_time ?? null;
      const rawRemaining = Number(cooldownRow.remaining_sec);
      if (Number.isFinite(rawRemaining)) {
        cooldownRemainingSec = Math.max(0, Math.ceil(rawRemaining));
      }
    }
  }

  return {
    daily_trades_count: parseMaybeInt(dailyTradesRow?.cnt, 0),
    daily_losses_count: parseMaybeInt(dailyLossesRow?.cnt, 0),
    current_day_pnl: Number(dayPnlRow?.pnl || 0),
    open_positions_count: parseMaybeInt(openPositionsRow?.cnt, 0),
    last_trade_result: determineTradeResult(lastClosedRow, 'close_reason'),
    current_loss_streak: currentLossStreak,
    cooldown_remaining_sec: cooldownRemainingSec,
    last_loss_time: lastLossTime,
  };
}

async function initDb() {
  if (db) return db;

  const dbPath = resolveDbPath();
  if (!fs.existsSync(dbPath)) {
    console.error(`SQLite file not found: ${dbPath}`);
    process.exit(1);
  }

  await new Promise((resolve, reject) => {
    db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE, (err) => {
      if (err) return reject(err);
      return resolve();
    });
  });

  await exec('PRAGMA journal_mode = WAL;');
  await exec('PRAGMA busy_timeout = 5000;');

  await loadTradeSchema();

  const mapTable = await get("SELECT name FROM sqlite_master WHERE type='table' AND name='orch_trade_map'");
  if (!mapTable) {
    console.error('Missing required table: orch_trade_map. Run migrations to create it.');
    process.exit(1);
  }

  return db;
}

module.exports = {
  initDb,
  run,
  get,
  all,
  exec,
  transaction,
  getTradeSchema,
  getDailyMetrics,
};
