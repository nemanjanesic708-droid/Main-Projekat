﻿'use strict';

const { get } = require('./db');
const { extractCurrenciesFromSymbol } = require('./news');

function toInt(value, fallback) {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function toBool(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  const raw = String(value).trim().toLowerCase();
  if (!raw) return fallback;
  if (raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on') return true;
  if (raw === '0' || raw === 'false' || raw === 'no' || raw === 'off') return false;
  return fallback;
}

function clampImportance(value) {
  const parsed = toInt(value, 2);
  if (parsed < 0) return 0;
  if (parsed > 2) return 2;
  return parsed;
}

function formatDbUtc(value) {
  return value.toISOString().slice(0, 19).replace('T', ' ');
}

function parseDbUtc(value) {
  if (!value) return null;
  const raw = String(value).trim();
  if (!raw) return null;
  const withT = raw.includes('T') ? raw : raw.replace(' ', 'T');
  const asUtc = withT.endsWith('Z') ? withT : `${withT}Z`;
  const dt = new Date(asUtc);
  return Number.isFinite(dt.getTime()) ? dt : null;
}

function getNewsFilterConfig(overrides = {}) {
  const enabled = toBool(overrides.enabled ?? process.env.NEWS_FILTER_ENABLED, true);
  const minImportance = clampImportance(overrides.minImportance ?? process.env.NEWS_FILTER_MIN_IMPORTANCE);
  const beforeMin = Math.max(0, toInt(overrides.beforeMin ?? process.env.NEWS_FILTER_WINDOW_BEFORE_MIN, 15));
  const afterMin = Math.max(0, toInt(overrides.afterMin ?? process.env.NEWS_FILTER_WINDOW_AFTER_MIN, 15));
  return {
    enabled,
    min_importance: minImportance,
    window_before_min: beforeMin,
    window_after_min: afterMin,
  };
}

function fallbackSymbolCurrencies(symbol) {
  const raw = String(symbol || '').trim().toUpperCase();
  if (!raw) return [];
  const letters = raw.replace(/[^A-Z]/g, '');
  if (letters.length >= 6) {
    return [letters.slice(0, 3), letters.slice(3, 6)];
  }
  if (letters.length >= 3) {
    return [letters.slice(0, 3)];
  }
  return [];
}

function resolveSymbolCurrencies(symbol) {
  let currencies = [];
  try {
    currencies = extractCurrenciesFromSymbol(symbol);
  } catch (_err) {
    currencies = [];
  }
  if (!Array.isArray(currencies) || !currencies.length) {
    currencies = fallbackSymbolCurrencies(symbol);
  }
  const out = [];
  const seen = new Set();
  for (const value of currencies) {
    const token = String(value || '').trim().toUpperCase();
    if (!token) continue;
    if (seen.has(token)) continue;
    seen.add(token);
    out.push(token);
  }
  return out;
}

async function checkUpcomingNews(symbol, options = {}) {
  const cfg = getNewsFilterConfig(options.config || {});
  const now = options.now instanceof Date ? options.now : new Date();

  if (!cfg.enabled) {
    return { block: false, enabled: false };
  }

  const currencies = resolveSymbolCurrencies(symbol);
  if (!currencies.length) {
    return { block: false, enabled: true, currencies: [] };
  }

  const windowStart = new Date(now.getTime() - (cfg.window_before_min * 60 * 1000));
  const windowEnd = new Date(now.getTime() + (cfg.window_after_min * 60 * 1000));

  const placeholders = currencies.map(() => '?').join(', ');
  const sql = `
    SELECT time_utc, currency, title, importance, status
    FROM economic_events
    WHERE currency IN (${placeholders})
      AND importance >= ?
      AND time_utc BETWEEN ? AND ?
      AND status = 'upcoming'
    ORDER BY time_utc ASC
    LIMIT 1`;

  try {
    const row = await get(sql, [
      ...currencies,
      cfg.min_importance,
      formatDbUtc(windowStart),
      formatDbUtc(windowEnd),
    ]);

    if (!row) {
      return {
        block: false,
        enabled: true,
        currencies,
      };
    }

    const eventTime = parseDbUtc(row.time_utc);
    const minutesToEvent = eventTime
      ? Math.round((eventTime.getTime() - now.getTime()) / 60000)
      : null;

    return {
      block: true,
      enabled: true,
      reason: 'High impact news soon',
      event_time: eventTime ? eventTime.toISOString() : String(row.time_utc || ''),
      event_title: String(row.title || ''),
      event_currency: String(row.currency || ''),
      importance: Number(row.importance || 0),
      minutes_to_event: minutesToEvent,
      currencies,
    };
  } catch (err) {
    const message = String(err?.message || '').toLowerCase();
    if (message.includes('no such table: economic_events')) {
      return {
        block: false,
        enabled: true,
        error: 'economic_events_table_missing',
        currencies,
      };
    }
    throw err;
  }
}

module.exports = {
  getNewsFilterConfig,
  checkUpcomingNews,
};
