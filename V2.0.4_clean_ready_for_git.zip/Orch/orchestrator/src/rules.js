'use strict';

const { get, getTradeSchema } = require('./db');

const MAX_OPEN_POSITIONS = 1;
const SIMILAR_TIME_CANDIDATES = ['open_time', 'signal_time', 'entry_time', 'created_at', 'signal_timestamp'];

async function getOpenCount() {
  const tradeSchema = getTradeSchema();
  const row = await get(
    `SELECT COUNT(*) AS cnt FROM trades WHERE ${tradeSchema.openWhere}`
  );
  return row?.cnt || 0;
}

async function getTradesToday(accountId) {
  const row = await get(
    `SELECT COUNT(*) AS cnt
     FROM orch_trade_map
     WHERE account_id = ?
       AND datetime(created_at) >= datetime('now', 'start of day')
       AND datetime(created_at) < datetime('now', 'start of day', '+1 day')`,
    [accountId]
  );
  return row?.cnt || 0;
}

async function getCooldownRemainingSec(accountId, cooldownMin) {
  const tradeSchema = getTradeSchema();
  const closeTimeCol = tradeSchema.col('close_time');
  const reasonCol = tradeSchema.closeReasonColumn;
  const ticketCol = tradeSchema.col('ticket');
  const idCol = tradeSchema.has('id') ? tradeSchema.col('id') : null;

  let join = `JOIN trades t ON t.${tradeSchema.q(ticketCol)} = m.ticket`;
  if (idCol) {
    join = `JOIN trades t ON (m.trade_row_id IS NOT NULL AND t.${tradeSchema.q(idCol)} = m.trade_row_id)
      OR (m.trade_row_id IS NULL AND t.${tradeSchema.q(ticketCol)} = m.ticket)`;
  }

  const row = await get(
    `SELECT (strftime('%s', t.${tradeSchema.q(closeTimeCol)}) + (? * 60) - strftime('%s', 'now')) AS remaining_sec
     FROM orch_trade_map m
     ${join}
     WHERE m.account_id = ?
       AND t.${tradeSchema.q(reasonCol)} = 'SL'
       AND t.${tradeSchema.q(closeTimeCol)} IS NOT NULL
     ORDER BY t.${tradeSchema.q(closeTimeCol)} DESC
     LIMIT 1`,
    [cooldownMin, accountId]
  );

  const remaining = row?.remaining_sec;
  if (remaining === null || remaining === undefined) return 0;
  return Math.max(0, Math.ceil(Number(remaining)));
}

function resolveSimilarTimeExpr(tradeSchema) {
  const columns = SIMILAR_TIME_CANDIDATES
    .filter((name) => tradeSchema.has(name))
    .map((name) => tradeSchema.col(name));
  if (!columns.length) return null;
  const parts = columns.map((name) => `t.${tradeSchema.q(name)}`);
  return {
    expr: `COALESCE(${parts.join(', ')})`,
    columns,
  };
}

async function checkSimilarTradeRecent(db, tradeSchema, accountId, symbol, direction, timeframe, strategy, lookbackMin) {
  const result = {
    match: false,
    trade_id: null,
    ticket: null,
    position_id: null,
    similar_time: null,
  };

  const lookback = toInt(lookbackMin, 0);
  if (lookback <= 0) return result;

  const required = ['symbol', 'direction', 'timeframe', 'strategy'];
  const missing = required.filter((name) => !tradeSchema.has(name));
  if (missing.length) return { ...result, missing_columns: missing };

  const timeInfo = resolveSimilarTimeExpr(tradeSchema);
  if (!timeInfo) return { ...result, missing_columns: ['open_time/signal_time'] };

  const dbGet = typeof db === 'function' ? db : db?.get?.bind(db);
  if (!dbGet) {
    throw new Error('Invalid db handle for similarity check.');
  }

  const ticketCol = tradeSchema.col('ticket');
  const idCol = tradeSchema.has('id') ? tradeSchema.col('id') : null;
  let join = `JOIN trades t ON t.${tradeSchema.q(ticketCol)} = m.ticket`;
  if (idCol) {
    join = `JOIN trades t ON (m.trade_row_id IS NOT NULL AND t.${tradeSchema.q(idCol)} = m.trade_row_id)
      OR (m.trade_row_id IS NULL AND t.${tradeSchema.q(ticketCol)} = m.ticket)`;
  }

  const lookbackWindow = `-${lookback} minutes`;
  const row = await dbGet(
    `SELECT ${idCol ? `t.${tradeSchema.q(idCol)} AS trade_id,` : 'NULL AS trade_id,'}
            t.${tradeSchema.q(ticketCol)} AS ticket,
            m.position_id AS position_id,
            ${timeInfo.expr} AS similar_time
     FROM orch_trade_map m
     ${join}
     WHERE m.account_id = ?
       AND t.${tradeSchema.q(tradeSchema.col('symbol'))} = ?
       AND t.${tradeSchema.q(tradeSchema.col('direction'))} = ?
       AND t.${tradeSchema.q(tradeSchema.col('timeframe'))} = ?
       AND t.${tradeSchema.q(tradeSchema.col('strategy'))} = ?
       AND ${timeInfo.expr} IS NOT NULL
       AND datetime(${timeInfo.expr}) >= datetime('now', ?)
     ORDER BY datetime(${timeInfo.expr}) DESC
     LIMIT 1`,
    [accountId, symbol, direction, timeframe, strategy, lookbackWindow]
  );

  if (!row) return result;

  return {
    match: true,
    trade_id: row.trade_id ?? null,
    ticket: row.ticket ?? null,
    position_id: row.position_id ?? null,
    similar_time: row.similar_time ?? null,
  };
}

function toInt(value, fallback) {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

async function evaluatePreTrade({ accountId, symbol, direction, timeframe, strategy }) {
  const dailyLimit = toInt(process.env.DAILY_TRADE_LIMIT, 0);
  const cooldownMin = toInt(process.env.COOLDOWN_AFTER_SL_MIN, 0);
  const similarLookbackMin = toInt(process.env.SIMILAR_LOOKBACK_MIN, 180);

  const openCount = await getOpenCount();
  if (openCount >= MAX_OPEN_POSITIONS) {
    return { allow: false, reason: 'max_open_positions', similar_match: false };
  }

  if (cooldownMin > 0) {
    const remainingSec = await getCooldownRemainingSec(accountId, cooldownMin);
    if (remainingSec > 0) {
      return { allow: false, reason: 'cooldown_active', cooldown_sec: remainingSec, similar_match: false };
    }
  }

  let tradesToday = 0;
  if (dailyLimit > 0) {
    tradesToday = await getTradesToday(accountId);
    if (tradesToday >= dailyLimit) {
      return { allow: false, reason: 'daily_limit', similar_match: false };
    }
  }

  if (similarLookbackMin > 0) {
    const tradeSchema = getTradeSchema();
    const similar = await checkSimilarTradeRecent(
      get,
      tradeSchema,
      accountId,
      symbol,
      direction,
      timeframe,
      strategy,
      similarLookbackMin
    );
    if (similar.match) {
      const similarTradeId = similar.trade_id ?? similar.ticket ?? similar.position_id ?? null;
      return {
        allow: false,
        reason: 'similar_trade_recent',
        similar_match: true,
        similar_trade_id: similarTradeId,
        similar_time: similar.similar_time,
      };
    }
  }

  const maxTradesLeftToday = dailyLimit > 0 ? Math.max(dailyLimit - tradesToday, 0) : 0;

  return {
    allow: true,
    reason: 'ok',
    cooldown_sec: 0,
    max_trades_left_today: maxTradesLeftToday,
    similar_match: false,
  };
}

module.exports = {
  checkSimilarTradeRecent,
  evaluatePreTrade,
};
