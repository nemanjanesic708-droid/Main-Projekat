'use strict';

const {
  getEvents: providerGetEvents,
  getProviderMeta,
  normalizeImpact,
  parseTimestampMs,
} = require('./news/provider');

const IMPACT_RANK = {
  NONE: 0,
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3,
};

const DAILY_EVENT_CACHE = new Map();
const QUERY_CACHE = new Map();
const DEBUG_STATE = {
  last_fetch_time: null,
  last_fetch_key: null,
  last_fetch_count: 0,
  last_error: null,
  last_filtered: null,
  fetch_cache_hits: 0,
  query_cache_hits: 0,
};

const DEFAULT_SYMBOL_CURRENCY_MAP = {
  XAUUSD: ['USD'],
  XAGUSD: ['USD'],
  BTCUSD: ['USD'],
  ETHUSD: ['USD'],
  BTCUSDT: ['USDT'],
  ETHUSDT: ['USDT'],
};

const CRYPTO_BASES = new Set(['BTC', 'ETH', 'LTC', 'XRP', 'ADA', 'SOL', 'DOG', 'DOT', 'BNB', 'AVAX']);
const METAL_BASES = new Set(['XAU', 'XAG', 'XPT', 'XPD']);

function toInt(value, fallback) {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function toBool(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  const raw = String(value).trim().toLowerCase();
  if (!raw) return fallback;
  if (raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on') return true;
  if (raw === '0' || raw === 'false' || raw === 'no' || raw === 'off') return false;
  return fallback;
}

function normalizeImpactWithNone(value, fallback = 'NONE') {
  const raw = String(value || '').trim().toUpperCase();
  if (!raw) return fallback;
  if (raw === 'NONE') return 'NONE';
  const normalized = normalizeImpact(raw);
  return IMPACT_RANK[normalized] ? normalized : fallback;
}

function normalizeTimezone(value) {
  const raw = String(value || 'UTC').trim().toUpperCase();
  return raw === 'LOCAL' ? 'LOCAL' : 'UTC';
}

function uniqueUpper(values = []) {
  const out = [];
  const seen = new Set();
  for (const value of values) {
    const token = String(value || '').trim().toUpperCase();
    if (!token) continue;
    if (seen.has(token)) continue;
    seen.add(token);
    out.push(token);
  }
  return out;
}

function parseSymbolCurrencyMap(raw) {
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    const out = {};
    for (const key of Object.keys(parsed)) {
      const values = parsed[key];
      if (!Array.isArray(values)) continue;
      const normalized = uniqueUpper(values);
      if (normalized.length) {
        out[String(key).trim().toUpperCase()] = normalized;
      }
    }
    return out;
  } catch (err) {
    return {};
  }
}

function getRuntimeConfig(overrides = {}) {
  const providerMeta = getProviderMeta(overrides.providerMeta || {});
  const timezone = normalizeTimezone(overrides.timezone ?? process.env.NEWS_TZ ?? providerMeta.timezone ?? 'UTC');
  const minImpact = normalizeImpactWithNone(overrides.minImpact ?? process.env.NEWS_MIN_IMPACT ?? 'MEDIUM', 'MEDIUM');
  const cacheSec = Math.max(1, toInt(overrides.cacheSec ?? process.env.NEWS_CACHE_SEC, 60));
  const windowMin = Math.max(1, toInt(overrides.windowMin ?? process.env.NEWS_WINDOW_MIN, 30));
  const includeXauBase = toBool(overrides.includeXauBase ?? process.env.NEWS_INCLUDE_XAU_BASE, false);
  const includeCryptoBase = toBool(overrides.includeCryptoBase ?? process.env.NEWS_INCLUDE_CRYPTO_BASE, false);
  const customMap = parseSymbolCurrencyMap(overrides.symbolCurrencyMapRaw ?? process.env.NEWS_SYMBOL_CURRENCY_MAP);
  return {
    provider: providerMeta,
    timezone,
    cacheSec,
    windowMin,
    minImpact,
    includeXauBase,
    includeCryptoBase,
    symbolCurrencyMap: {
      ...DEFAULT_SYMBOL_CURRENCY_MAP,
      ...customMap,
    },
  };
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

function toDayKey(ms, timezone) {
  const date = new Date(ms);
  if (timezone === 'LOCAL') {
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
  }
  return date.toISOString().slice(0, 10);
}

function dayWindow(dayKey, timezone) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dayKey);
  if (!match) throw new Error(`Invalid day key: ${dayKey}`);
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  let startMs;
  if (timezone === 'LOCAL') {
    startMs = new Date(year, month - 1, day, 0, 0, 0, 0).getTime();
  } else {
    startMs = Date.UTC(year, month - 1, day, 0, 0, 0, 0);
  }
  const endMs = startMs + (24 * 60 * 60 * 1000) - 1;
  return {
    startMs,
    endMs,
    startTs: new Date(startMs).toISOString(),
    endTs: new Date(endMs).toISOString(),
  };
}

function listDayKeys(startMs, endMs, timezone) {
  const keys = [];
  let cursorMs = startMs;
  while (cursorMs <= endMs) {
    const key = toDayKey(cursorMs, timezone);
    if (!keys.includes(key)) keys.push(key);
    const win = dayWindow(key, timezone);
    cursorMs = win.endMs + 1;
  }
  return keys;
}

function parseSignalMs(signalTime, timezone) {
  const signalMs = parseTimestampMs(signalTime, timezone);
  if (!Number.isFinite(signalMs)) {
    throw new Error('invalid_signal_time');
  }
  return signalMs;
}

function normalizeEvent(event, index, timezone) {
  if (!event || typeof event !== 'object') return null;
  const tsMs = parseTimestampMs(event.ts, timezone);
  if (!Number.isFinite(tsMs)) return null;
  const currency = String(event.currency || '').trim().toUpperCase();
  if (!currency) return null;
  const impact = normalizeImpactWithNone(event.impact, 'LOW');
  const title = String(event.title || '').trim() || 'event';
  const idRaw = event.id;
  const id = idRaw === undefined || idRaw === null || idRaw === ''
    ? `${currency}-${tsMs}-${index}`
    : String(idRaw);
  return {
    ts: new Date(tsMs).toISOString(),
    currency,
    title,
    impact,
    id,
  };
}

function getMaxImpact(events = []) {
  let maxImpact = 'NONE';
  let maxRank = 0;
  for (const event of events) {
    const impact = normalizeImpactWithNone(event.impact, 'LOW');
    const rank = IMPACT_RANK[impact] || 0;
    if (rank > maxRank) {
      maxRank = rank;
      maxImpact = impact;
    }
  }
  return maxImpact;
}

function keepAboveMinImpact(events, minImpact) {
  const threshold = IMPACT_RANK[normalizeImpactWithNone(minImpact, 'MEDIUM')] || IMPACT_RANK.MEDIUM;
  return events.filter((event) => {
    const rank = IMPACT_RANK[normalizeImpactWithNone(event.impact, 'LOW')] || 0;
    return rank >= threshold;
  });
}

function buildResult({
  enabled,
  provider,
  hasNews,
  impact,
  minutesToNext,
  windowMin,
  events,
  currencies,
  providerError,
}) {
  return {
    enabled: !!enabled,
    provider,
    has_news: !!hasNews,
    impact: impact || 'NONE',
    minutes_to_next: Number.isFinite(minutesToNext) ? minutesToNext : null,
    window_min: windowMin,
    currencies: Array.isArray(currencies) ? currencies : [],
    events: Array.isArray(events) ? events : [],
    provider_error: providerError || null,
  };
}

function buildCacheKey({ providerName, dayKeys, currencies, windowMin, minImpact, signalMs, cacheSec }) {
  const bucketSec = Math.max(1, cacheSec);
  const bucket = Math.floor(signalMs / (bucketSec * 1000));
  return [
    providerName,
    dayKeys.join('~'),
    currencies.join(',') || 'ALL',
    `w${windowMin}`,
    `i${minImpact}`,
    `b${bucket}`,
  ].join('|');
}

function maybeTrimCaches() {
  const maxDaily = 256;
  const maxQuery = 1024;
  if (DAILY_EVENT_CACHE.size > maxDaily) {
    const keys = Array.from(DAILY_EVENT_CACHE.keys()).slice(0, DAILY_EVENT_CACHE.size - maxDaily);
    for (const key of keys) DAILY_EVENT_CACHE.delete(key);
  }
  if (QUERY_CACHE.size > maxQuery) {
    const keys = Array.from(QUERY_CACHE.keys()).slice(0, QUERY_CACHE.size - maxQuery);
    for (const key of keys) QUERY_CACHE.delete(key);
  }
}

function sanitizeSymbol(value) {
  const raw = String(value || '').trim().toUpperCase();
  if (!raw) return { raw: '', letters: '', six: '' };
  const letters = raw.replace(/[^A-Z]/g, '');
  return {
    raw,
    letters,
    six: letters.length >= 6 ? letters.slice(0, 6) : letters,
  };
}

function extractCurrenciesFromSymbol(symbol, options = {}) {
  const cfg = getRuntimeConfig(options);
  const parsed = sanitizeSymbol(symbol);
  const resolvedMap = cfg.symbolCurrencyMap || DEFAULT_SYMBOL_CURRENCY_MAP;

  const mapped = resolvedMap[parsed.raw] || resolvedMap[parsed.six];
  if (Array.isArray(mapped) && mapped.length) {
    return uniqueUpper(mapped);
  }

  if (parsed.six.length === 6) {
    const base = parsed.six.slice(0, 3);
    const quote = parsed.six.slice(3, 6);

    if (METAL_BASES.has(base) && !cfg.includeXauBase) {
      return uniqueUpper([quote]);
    }

    if (CRYPTO_BASES.has(base) && !cfg.includeCryptoBase) {
      return uniqueUpper([quote]);
    }

    return uniqueUpper([base, quote]);
  }

  if (parsed.letters.length >= 3) {
    return uniqueUpper([parsed.letters.slice(-3)]);
  }

  return [];
}

function resolveProviderClient(providerOverride, runtimeConfig) {
  if (providerOverride && typeof providerOverride.getEvents === 'function') {
    return {
      meta: {
        name: String(providerOverride.name || 'override').trim().toLowerCase() || 'override',
        enabled: providerOverride.enabled !== false,
        timezone: normalizeTimezone(providerOverride.timezone ?? runtimeConfig.timezone),
        disabled_reason: null,
      },
      getEvents: providerOverride.getEvents,
    };
  }

  const meta = runtimeConfig.provider;
  return {
    meta,
    getEvents: (query) => providerGetEvents(query),
  };
}

async function getDailyEvents({ dayKey, currencies, runtimeConfig, providerClient }) {
  const currencyKey = currencies.join(',') || 'ALL';
  const key = [providerClient.meta.name, providerClient.meta.timezone, dayKey, currencyKey].join('|');
  const now = Date.now();
  const ttlMs = runtimeConfig.cacheSec * 1000;
  const existing = DAILY_EVENT_CACHE.get(key);
  if (existing && now - existing.fetchedAtMs <= ttlMs) {
    DEBUG_STATE.fetch_cache_hits += 1;
    return existing.events;
  }

  const range = dayWindow(dayKey, providerClient.meta.timezone);
  try {
    const fetched = await providerClient.getEvents({
      startTs: range.startTs,
      endTs: range.endTs,
      currencies,
    });
    const normalized = Array.isArray(fetched)
      ? fetched.map((event, idx) => normalizeEvent(event, idx, providerClient.meta.timezone)).filter(Boolean)
      : [];
    DAILY_EVENT_CACHE.set(key, {
      fetchedAtMs: now,
      events: normalized,
      dayKey,
      currencies: currencies.slice(),
    });
    DEBUG_STATE.last_fetch_time = new Date(now).toISOString();
    DEBUG_STATE.last_fetch_key = key;
    DEBUG_STATE.last_fetch_count = normalized.length;
    DEBUG_STATE.last_error = null;
    maybeTrimCaches();
    return normalized;
  } catch (err) {
    DEBUG_STATE.last_error = {
      at: new Date(now).toISOString(),
      provider: providerClient.meta.name,
      message: String(err?.message || err || 'provider_error'),
      cache_key: key,
    };
    if (existing) {
      return existing.events;
    }
    throw err;
  }
}

async function fetchRangeEvents({ startMs, endMs, currencies, runtimeConfig, providerClient }) {
  const dayKeys = listDayKeys(startMs, endMs, providerClient.meta.timezone);
  const chunks = [];
  for (const dayKey of dayKeys) {
    const dayEvents = await getDailyEvents({
      dayKey,
      currencies,
      runtimeConfig,
      providerClient,
    });
    chunks.push(...dayEvents);
  }
  return chunks;
}

function minutesDiff(fromMs, toMs) {
  const diff = toMs - fromMs;
  if (diff <= 0) return 0;
  return Math.ceil(diff / 60000);
}

async function checkUpcomingNews(options = {}) {
  const runtimeConfig = getRuntimeConfig(options.runtimeConfig || {});
  const providerClient = resolveProviderClient(options.providerOverride, runtimeConfig);

  const windowMin = Math.max(1, toInt(options.window_min ?? runtimeConfig.windowMin, runtimeConfig.windowMin));
  const minImpact = normalizeImpactWithNone(options.min_impact ?? runtimeConfig.minImpact, runtimeConfig.minImpact);
  const signalMs = parseSignalMs(options.signal_time, providerClient.meta.timezone);
  const startMs = signalMs;
  const endMs = signalMs + (windowMin * 60 * 1000);

  const currencies = uniqueUpper(Array.isArray(options.currencies) && options.currencies.length
    ? options.currencies
    : extractCurrenciesFromSymbol(options.symbol, runtimeConfig));

  if (!providerClient.meta.enabled) {
    const disabledResult = buildResult({
      enabled: false,
      provider: providerClient.meta.name,
      hasNews: false,
      impact: 'NONE',
      minutesToNext: null,
      windowMin,
      events: [],
      currencies,
      providerError: null,
    });
    DEBUG_STATE.last_filtered = disabledResult;
    return disabledResult;
  }

  const dayKeys = listDayKeys(startMs, endMs, providerClient.meta.timezone);
  const queryKey = buildCacheKey({
    providerName: providerClient.meta.name,
    dayKeys,
    currencies,
    windowMin,
    minImpact,
    signalMs,
    cacheSec: runtimeConfig.cacheSec,
  });
  const ttlMs = runtimeConfig.cacheSec * 1000;
  const queryCached = QUERY_CACHE.get(queryKey);
  const now = Date.now();
  if (queryCached && now - queryCached.cachedAtMs <= ttlMs) {
    DEBUG_STATE.query_cache_hits += 1;
    DEBUG_STATE.last_filtered = queryCached.result;
    return queryCached.result;
  }

  let eventsRaw = [];
  let providerError = null;
  try {
    eventsRaw = await fetchRangeEvents({
      startMs,
      endMs,
      currencies,
      runtimeConfig,
      providerClient,
    });
  } catch (err) {
    providerError = String(err?.message || err || 'provider_error');
  }

  if (providerError) {
    const failOpenResult = buildResult({
      enabled: true,
      provider: providerClient.meta.name,
      hasNews: false,
      impact: 'NONE',
      minutesToNext: null,
      windowMin,
      events: [],
      currencies,
      providerError: providerError,
    });
    DEBUG_STATE.last_filtered = failOpenResult;
    QUERY_CACHE.set(queryKey, {
      cachedAtMs: now,
      result: failOpenResult,
    });
    maybeTrimCaches();
    return failOpenResult;
  }

  const inRange = eventsRaw
    .map((event, idx) => normalizeEvent(event, idx, providerClient.meta.timezone))
    .filter(Boolean)
    .filter((event) => {
      if (!currencies.length) return true;
      return currencies.includes(String(event.currency || '').toUpperCase());
    })
    .filter((event) => {
      const tsMs = parseTimestampMs(event.ts, providerClient.meta.timezone);
      return Number.isFinite(tsMs) && tsMs >= startMs && tsMs <= endMs;
    });

  const byImpact = keepAboveMinImpact(inRange, minImpact);
  const events = byImpact
    .sort((a, b) => parseTimestampMs(a.ts, providerClient.meta.timezone) - parseTimestampMs(b.ts, providerClient.meta.timezone))
    .map((event) => {
      const tsMs = parseTimestampMs(event.ts, providerClient.meta.timezone);
      return {
        ts: event.ts,
        minutes_from_now: minutesDiff(signalMs, tsMs),
        currency: event.currency,
        title: event.title,
        impact: event.impact,
      };
    });

  const hasNews = events.length > 0;
  const impact = hasNews ? getMaxImpact(events) : 'NONE';
  const nearestTs = hasNews ? parseTimestampMs(events[0].ts, providerClient.meta.timezone) : null;
  const minutesToNext = Number.isFinite(nearestTs) ? minutesDiff(signalMs, nearestTs) : null;

  const result = buildResult({
    enabled: true,
    provider: providerClient.meta.name,
    hasNews,
    impact,
    minutesToNext,
    windowMin,
    events,
    currencies,
    providerError: null,
  });

  QUERY_CACHE.set(queryKey, {
    cachedAtMs: now,
    result,
  });
  DEBUG_STATE.last_filtered = result;
  maybeTrimCaches();
  return result;
}

function getNewsDebugState() {
  const runtimeConfig = getRuntimeConfig();
  const todayKey = toDayKey(Date.now(), runtimeConfig.timezone);
  const todayPrefix = `|${runtimeConfig.timezone}|${todayKey}|`;
  let eventsTodayCount = 0;
  for (const [key, value] of DAILY_EVENT_CACHE.entries()) {
    if (!key.includes(todayPrefix)) continue;
    eventsTodayCount += Array.isArray(value?.events) ? value.events.length : 0;
  }
  return {
    provider: runtimeConfig.provider.name,
    enabled: runtimeConfig.provider.enabled,
    disabled_reason: runtimeConfig.provider.disabled_reason || null,
    timezone: runtimeConfig.timezone,
    cache_sec: runtimeConfig.cacheSec,
    min_impact: runtimeConfig.minImpact,
    window_min: runtimeConfig.windowMin,
    last_fetch_time: DEBUG_STATE.last_fetch_time,
    last_fetch_key: DEBUG_STATE.last_fetch_key,
    last_fetch_count: DEBUG_STATE.last_fetch_count,
    events_today_count: eventsTodayCount,
    fetch_cache_entries: DAILY_EVENT_CACHE.size,
    query_cache_entries: QUERY_CACHE.size,
    fetch_cache_hits: DEBUG_STATE.fetch_cache_hits,
    query_cache_hits: DEBUG_STATE.query_cache_hits,
    last_error: DEBUG_STATE.last_error,
    last_filtered: DEBUG_STATE.last_filtered,
  };
}

function resetNewsCacheForTests() {
  DAILY_EVENT_CACHE.clear();
  QUERY_CACHE.clear();
  DEBUG_STATE.last_fetch_time = null;
  DEBUG_STATE.last_fetch_key = null;
  DEBUG_STATE.last_fetch_count = 0;
  DEBUG_STATE.last_error = null;
  DEBUG_STATE.last_filtered = null;
  DEBUG_STATE.fetch_cache_hits = 0;
  DEBUG_STATE.query_cache_hits = 0;
}

module.exports = {
  IMPACT_RANK,
  extractCurrenciesFromSymbol,
  checkUpcomingNews,
  getNewsDebugState,
  resetNewsCacheForTests,
  normalizeImpactWithNone,
};
