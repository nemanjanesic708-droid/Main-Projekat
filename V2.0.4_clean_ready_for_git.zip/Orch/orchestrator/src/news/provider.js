'use strict';

const DEFAULT_TIMEOUT_MS = 7000;

function normalizeProviderName(value) {
  const raw = String(value || 'none').trim().toLowerCase();
  if (!raw) return 'none';
  if (raw === 'http' || raw === 'json' || raw === 'provider_http_json') return 'http_json';
  if (raw === 'mock') return 'mock';
  if (raw === 'none' || raw === 'off' || raw === 'disabled') return 'none';
  return raw;
}

function normalizeTimezone(value) {
  const raw = String(value || 'UTC').trim().toUpperCase();
  if (raw === 'LOCAL') return 'LOCAL';
  return 'UTC';
}

function normalizeImpact(value) {
  if (typeof value === 'number' && Number.isFinite(value)) {
    if (value >= 3) return 'HIGH';
    if (value >= 2) return 'MEDIUM';
    return 'LOW';
  }
  const raw = String(value || '').trim().toUpperCase();
  if (!raw) return 'LOW';
  if (raw === 'HIGH' || raw === 'H' || raw === '3' || raw.includes('HIGH') || raw.includes('RED')) return 'HIGH';
  if (raw === 'MEDIUM' || raw === 'MED' || raw === 'M' || raw === '2' || raw.includes('MED')) return 'MEDIUM';
  if (raw === 'LOW' || raw === 'L' || raw === '1' || raw.includes('LOW')) return 'LOW';
  return 'LOW';
}

function normalizeCurrency(value) {
  if (value === undefined || value === null) return null;
  const cleaned = String(value).trim().toUpperCase().replace(/[^A-Z]/g, '');
  if (!cleaned) return null;
  return cleaned;
}

function parseTimestampMs(value, tz = 'UTC') {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value > 1e12 ? Math.trunc(value) : Math.trunc(value * 1000);
  }
  const raw = String(value).trim();
  if (!raw) return null;

  if (/^\d+$/.test(raw)) {
    const asNum = Number(raw);
    if (Number.isFinite(asNum)) {
      return asNum > 1e12 ? Math.trunc(asNum) : Math.trunc(asNum * 1000);
    }
  }

  let isoCandidate = raw;
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
    isoCandidate = raw.replace(' ', 'T');
    if (tz === 'UTC') isoCandidate += 'Z';
  } else if (/^\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2}$/.test(raw)) {
    const normalized = raw.replace(/\./g, '-').replace(' ', 'T');
    isoCandidate = tz === 'UTC' ? `${normalized}Z` : normalized;
  } else if (tz === 'UTC' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(raw)) {
    isoCandidate = `${raw}Z`;
  }

  const ms = Date.parse(isoCandidate);
  return Number.isFinite(ms) ? ms : null;
}

function toIsoUtc(ms) {
  if (!Number.isFinite(ms)) return null;
  return new Date(ms).toISOString();
}

function normalizeEvent(raw, idx, tz) {
  if (!raw || typeof raw !== 'object') return null;
  const tsRaw = raw.ts ?? raw.time ?? raw.timestamp ?? raw.datetime ?? raw.date ?? null;
  const tsMs = parseTimestampMs(tsRaw, tz);
  if (!Number.isFinite(tsMs)) return null;

  const currency = normalizeCurrency(raw.currency ?? raw.ccy ?? raw.curr ?? raw.country ?? null);
  if (!currency) return null;

  const titleRaw = raw.title ?? raw.name ?? raw.event ?? raw.description ?? 'event';
  const title = String(titleRaw || '').trim() || 'event';
  const impact = normalizeImpact(raw.impact ?? raw.importance ?? raw.severity ?? raw.level);
  const idRaw = raw.id ?? raw.event_id ?? raw.uid ?? null;
  const id = idRaw === undefined || idRaw === null || idRaw === ''
    ? `${currency}-${tsMs}-${idx}`
    : String(idRaw);

  return {
    ts: toIsoUtc(tsMs),
    currency,
    title,
    impact,
    id,
  };
}

function normalizeAndSortEvents(events, tz) {
  if (!Array.isArray(events)) return [];
  return events
    .map((item, idx) => normalizeEvent(item, idx, tz))
    .filter(Boolean)
    .sort((a, b) => Date.parse(a.ts) - Date.parse(b.ts));
}

function parseMockEvents(raw, tz) {
  if (!raw) return [];
  let parsed = [];
  try {
    const json = JSON.parse(raw);
    parsed = Array.isArray(json) ? json : [];
  } catch (err) {
    throw new Error(`Invalid NEWS_PROVIDER_MOCK_EVENTS JSON: ${err.message}`);
  }
  return normalizeAndSortEvents(parsed, tz);
}

function getProviderMeta(overrides = {}) {
  const provider = normalizeProviderName(overrides.providerName ?? process.env.NEWS_PROVIDER ?? 'none');
  const apiUrl = String(overrides.apiUrl ?? process.env.NEWS_API_URL ?? '').trim();
  const apiKey = String(overrides.apiKey ?? process.env.NEWS_API_KEY ?? '').trim();
  const timezone = normalizeTimezone(overrides.timezone ?? process.env.NEWS_TZ ?? 'UTC');

  if (provider === 'none') {
    return {
      name: provider,
      enabled: false,
      timezone,
      apiUrl: '',
      apiKeySet: false,
      disabled_reason: 'provider_none',
    };
  }

  if (provider === 'http_json' && !apiUrl) {
    return {
      name: provider,
      enabled: false,
      timezone,
      apiUrl: '',
      apiKeySet: false,
      disabled_reason: 'missing_news_api_url',
    };
  }

  if (provider !== 'http_json' && provider !== 'mock') {
    return {
      name: provider,
      enabled: false,
      timezone,
      apiUrl,
      apiKeySet: Boolean(apiKey),
      disabled_reason: 'unsupported_provider',
    };
  }

  return {
    name: provider,
    enabled: true,
    timezone,
    apiUrl,
    apiKeySet: Boolean(apiKey),
    disabled_reason: null,
  };
}

function filterEventsByRangeAndCurrencies(events, startMs, endMs, currencies) {
  const currencySet = Array.isArray(currencies) && currencies.length
    ? new Set(currencies.map((item) => String(item || '').toUpperCase()).filter(Boolean))
    : null;

  return events.filter((event) => {
    const tsMs = Date.parse(event.ts);
    if (!Number.isFinite(tsMs)) return false;
    if (Number.isFinite(startMs) && tsMs < startMs) return false;
    if (Number.isFinite(endMs) && tsMs > endMs) return false;
    if (currencySet && !currencySet.has(String(event.currency || '').toUpperCase())) return false;
    return true;
  });
}

async function fetchHttpJsonEvents({ startTs, endTs, currencies }, meta, overrides = {}) {
  const url = new URL(meta.apiUrl);
  if (startTs) url.searchParams.set('start', String(startTs));
  if (endTs) url.searchParams.set('end', String(endTs));
  if (Array.isArray(currencies) && currencies.length) {
    url.searchParams.set('currencies', currencies.join(','));
  }

  const headers = {
    accept: 'application/json',
  };
  const apiKey = String(overrides.apiKey ?? process.env.NEWS_API_KEY ?? '').trim();
  if (apiKey) {
    headers['x-api-key'] = apiKey;
    headers.authorization = `Bearer ${apiKey}`;
  }

  const timeoutMsRaw = Number(overrides.timeoutMs ?? process.env.NEWS_HTTP_TIMEOUT_MS ?? DEFAULT_TIMEOUT_MS);
  const timeoutMs = Number.isFinite(timeoutMsRaw) && timeoutMsRaw > 0 ? Math.trunc(timeoutMsRaw) : DEFAULT_TIMEOUT_MS;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(url.toString(), {
      method: 'GET',
      headers,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }

  if (!response.ok) {
    throw new Error(`NEWS provider http_json returned ${response.status}`);
  }

  const payload = await response.json();
  const eventsRaw = Array.isArray(payload)
    ? payload
    : Array.isArray(payload?.events)
      ? payload.events
      : Array.isArray(payload?.data)
        ? payload.data
        : [];

  return normalizeAndSortEvents(eventsRaw, meta.timezone);
}

async function getEvents({ startTs, endTs, currencies } = {}, overrides = {}) {
  const meta = getProviderMeta(overrides);
  if (!meta.enabled) return [];

  const startMs = parseTimestampMs(startTs, meta.timezone);
  const endMs = parseTimestampMs(endTs, meta.timezone);

  if (meta.name === 'mock') {
    const mockRaw = overrides.mockEventsRaw ?? process.env.NEWS_PROVIDER_MOCK_EVENTS ?? '[]';
    const events = parseMockEvents(mockRaw, meta.timezone);
    return filterEventsByRangeAndCurrencies(events, startMs, endMs, currencies);
  }

  if (meta.name === 'http_json') {
    const events = await fetchHttpJsonEvents({ startTs, endTs, currencies }, meta, overrides);
    return filterEventsByRangeAndCurrencies(events, startMs, endMs, currencies);
  }

  return [];
}

module.exports = {
  getEvents,
  getProviderMeta,
  normalizeImpact,
  parseTimestampMs,
};
