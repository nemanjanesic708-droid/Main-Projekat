﻿'use strict';

const { get, all, getTradeSchema } = require('./db');

function toInt(value, fallback) {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function toFloat(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function toOptionalFloat(value) {
  if (value === undefined || value === null) return null;
  const raw = String(value).trim();
  if (!raw) return null;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

function toBool(value, fallback = false) {
  if (value === undefined || value === null) return fallback;
  const raw = String(value).trim().toLowerCase();
  if (!raw) return fallback;
  if (raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on') return true;
  if (raw === '0' || raw === 'false' || raw === 'no' || raw === 'off') return false;
  return fallback;
}

function normalizeMode(value) {
  const raw = String(value || '').trim().toUpperCase();
  if (raw === 'ADVISORY') return 'ADVISORY';
  if (raw === 'ENFORCE') return 'ENFORCE';
  return 'OFF';
}

function normalizeNewsImpact(value, fallback = 'NONE') {
  const raw = String(value || '').trim().toUpperCase();
  if (!raw) return fallback;
  if (raw === 'HIGH') return 'HIGH';
  if (raw === 'MEDIUM' || raw === 'MED') return 'MEDIUM';
  if (raw === 'LOW') return 'LOW';
  if (raw === 'NONE') return 'NONE';
  return fallback;
}

function pushUnique(list, value) {
  if (!value) return;
  if (!list.includes(value)) list.push(value);
}

function normalizeReason(reason, fallback = 'ok') {
  const raw = String(reason || '').trim();
  return raw || fallback;
}

function getMemoryConfig() {
  const mode = normalizeMode(process.env.MEMORY_FILTER_MODE);
  const riskL1Mult = toFloat(process.env.RISK_L1_MULT, 0.25);
  const riskL2Mult = toFloat(process.env.RISK_L2_MULT, 1.0);
  const newsProvider = String(process.env.NEWS_PROVIDER || 'none').trim().toLowerCase() || 'none';
  const newsWindowMin = Math.max(1, toInt(process.env.NEWS_WINDOW_MIN, 30));
  const newsCacheSec = Math.max(1, toInt(process.env.NEWS_CACHE_SEC, 60));
  const newsMinImpact = normalizeNewsImpact(process.env.NEWS_MIN_IMPACT, 'MEDIUM');
  const newsBlockHigh = toBool(process.env.NEWS_BLOCK_HIGH, true);
  const newsBlockMedium = toBool(process.env.NEWS_BLOCK_MEDIUM, false);
  const newsFailClosed = toBool(process.env.FAIL_CLOSED ?? process.env.NEWS_FAIL_CLOSED, false);
  return {
    mode,
    minSample: Math.max(1, toInt(process.env.MEMORY_MIN_SAMPLE, 30)),
    lastN: Math.max(1, toInt(process.env.MEMORY_LAST_N, 50)),
    winrateMin: toFloat(process.env.MEMORY_WINRATE_MIN, 0.35),
    badStreakWindow: Math.max(1, toInt(process.env.MEMORY_BAD_STREAK_WINDOW, 10)),
    badStreakLosses: Math.max(1, toInt(process.env.MEMORY_BAD_STREAK_LOSSES, 8)),
    lookbackDays: Math.max(0, toInt(process.env.MEMORY_LOOKBACK_DAYS, 0)),
    spreadOkMaxPoints: toOptionalFloat(process.env.SPREAD_OK_MAX_POINTS),
    atrBucketLow: toOptionalFloat(process.env.ATR_BUCKET_LOW) ?? 5,
    atrBucketHigh: toOptionalFloat(process.env.ATR_BUCKET_HIGH) ?? 15,
    adxBucket1: toOptionalFloat(process.env.ADX_BUCKET_1) ?? 20,
    adxBucket2: toOptionalFloat(process.env.ADX_BUCKET_2) ?? 30,
    dailyTradeLimit: Math.max(0, toInt(process.env.DAILY_TRADE_LIMIT, 0)),
    cooldownAfterSlMin: Math.max(0, toInt(process.env.COOLDOWN_AFTER_SL_MIN, 0)),
    maxOpenPositions: Math.max(1, toInt(process.env.MAX_OPEN_POSITIONS, 1)),
    advisoryHardGuards: toBool(process.env.ADVISORY_HARD_GUARDS, false),
    riskL1Mult: Number.isFinite(riskL1Mult) && riskL1Mult >= 0 ? riskL1Mult : 0.25,
    riskL2Mult: Number.isFinite(riskL2Mult) && riskL2Mult > 0 ? riskL2Mult : 1.0,
    newsProvider,
    newsWindowMin,
    newsCacheSec,
    newsMinImpact,
    newsBlockHigh,
    newsBlockMedium,
    newsFailClosed,
  };
}

function getLadderConfigSnapshot(config) {
  return {
    mode: config.mode,
    levels: {
      L0: { risk_multiplier: 0 },
      L1: { risk_multiplier: config.riskL1Mult },
      L2: { risk_multiplier: config.riskL2Mult },
    },
    thresholds: {
      memory_min_sample: config.minSample,
      memory_winrate_min: config.winrateMin,
      memory_bad_streak_window: config.badStreakWindow,
      memory_bad_streak_losses: config.badStreakLosses,
      memory_last_n: config.lastN,
      memory_lookback_days: config.lookbackDays,
      spread_ok_max_points: config.spreadOkMaxPoints,
      daily_trade_limit: config.dailyTradeLimit,
      cooldown_after_sl_min: config.cooldownAfterSlMin,
      max_open_positions: config.maxOpenPositions,
      advisory_hard_guards: !!config.advisoryHardGuards,
      news_provider: config.newsProvider,
      news_window_min: config.newsWindowMin,
      news_cache_sec: config.newsCacheSec,
      news_min_impact: config.newsMinImpact,
      news_block_high: !!config.newsBlockHigh,
      news_block_medium: !!config.newsBlockMedium,
      news_fail_closed: !!config.newsFailClosed,
    },
    guards: {
      hard: ['daily_limit', 'cooldown_active', 'max_open_positions', 'spread_wide'],
      news: ['news_high_upcoming', 'news_medium_upcoming'],
      memory_block_reason: 'memory_block',
    },
  };
}

function normalizeToken(value, fallback = 'UNKNOWN') {
  if (value === undefined || value === null) return fallback;
  const trimmed = String(value).trim();
  if (!trimmed) return fallback;
  return trimmed.toUpperCase().replace(/\s+/g, '_').replace(/\|/g, '_');
}

function normalizeTrendState(value, features = {}) {
  if (typeof value === 'string') {
    const upper = value.trim().toUpperCase();
    if (upper.includes('UP')) return 'UP';
    if (upper.includes('DOWN')) return 'DOWN';
    if (upper.includes('FLAT') || upper.includes('RANGE') || upper.includes('SIDE')) return 'FLAT';
  }
  if (typeof value === 'number') {
    if (value > 0) return 'UP';
    if (value < 0) return 'DOWN';
    return 'FLAT';
  }
  const emaFlag = features.ema_fast_above_slow;
  if (emaFlag === 1 || emaFlag === true) return 'UP';
  if (emaFlag === 0 || emaFlag === false) return 'DOWN';
  return 'UNKNOWN';
}

function extractHour(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'string') return null;
  const match = /\b(\d{2}):(\d{2}):(\d{2})\b/.exec(value);
  if (!match) return null;
  const hour = parseInt(match[1], 10);
  return Number.isFinite(hour) ? hour : null;
}

function bucketize(payload = {}, config = {}) {
  const features = payload.features && typeof payload.features === 'object' && !Array.isArray(payload.features)
    ? payload.features
    : {};

  const trendState = normalizeTrendState(features.trend_direction ?? features.trend_state, features);

  const adxVal = toOptionalFloat(features.adx_value);
  let adxBucket = 'UNKNOWN';
  if (Number.isFinite(adxVal)) {
    if (adxVal < config.adxBucket1) adxBucket = 'LT20';
    else if (adxVal < config.adxBucket2) adxBucket = '20_30';
    else adxBucket = 'GT30';
  }

  const atrVal = toOptionalFloat(features.atr_pips ?? features.atr_value ?? features.atr);
  let atrBucket = 'UNKNOWN';
  if (Number.isFinite(atrVal)) {
    if (atrVal < config.atrBucketLow) atrBucket = 'LOW';
    else if (atrVal < config.atrBucketHigh) atrBucket = 'MID';
    else atrBucket = 'HIGH';
  }

  let sessionBucket = 'UNKNOWN';
  const sessionTag = typeof features.session === 'string' ? features.session
    : typeof features.session_tag === 'string' ? features.session_tag
      : null;
  if (sessionTag) {
    const upper = sessionTag.trim().toUpperCase();
    if (upper.includes('ASIA')) sessionBucket = 'ASIA';
    else if (upper.includes('LONDON') || upper.includes('EU')) sessionBucket = 'LONDON';
    else if (upper.includes('NY') || upper.includes('NEW')) sessionBucket = 'NY';
  } else {
    const hour = extractHour(features.session_hour ?? features.hour ?? payload.signal_time ?? payload.signalTime);
    if (Number.isFinite(hour)) {
      if (hour >= 0 && hour <= 6) sessionBucket = 'ASIA';
      else if (hour <= 12) sessionBucket = 'LONDON';
      else if (hour <= 20) sessionBucket = 'NY';
      else sessionBucket = 'OFF';
    }
  }

  const spreadPoints = toOptionalFloat(features.spread_points);
  let spreadOk = null;
  if (features.spread_ok !== undefined && features.spread_ok !== null) {
    spreadOk = Number(features.spread_ok) === 1 || features.spread_ok === true;
  } else if (Number.isFinite(spreadPoints) && Number.isFinite(config.spreadOkMaxPoints)) {
    spreadOk = spreadPoints <= config.spreadOkMaxPoints;
  }
  const spreadBucket = spreadOk === null ? 'UNKNOWN' : (spreadOk ? 'OK' : 'WIDE');

  return {
    trend_state: trendState,
    adx_bucket: adxBucket,
    atr_bucket: atrBucket,
    session_bucket: sessionBucket,
    spread_bucket: spreadBucket,
  };
}

function buildRegimeSignature(payload = {}, buckets = {}) {
  const symbol = normalizeToken(payload.symbol);
  const timeframe = normalizeToken(payload.timeframe);
  const direction = normalizeToken(payload.direction);
  return [
    symbol,
    timeframe,
    direction,
    `TREND=${buckets.trend_state || 'UNKNOWN'}`,
    `ADX=${buckets.adx_bucket || 'UNKNOWN'}`,
    `ATR=${buckets.atr_bucket || 'UNKNOWN'}`,
    `SESSION=${buckets.session_bucket || 'UNKNOWN'}`,
    `SPREAD=${buckets.spread_bucket || 'UNKNOWN'}`,
  ].join('|');
}

function canonicalize(value) {
  if (Array.isArray(value)) {
    return value.map(canonicalize);
  }
  if (value && typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      out[key] = canonicalize(value[key]);
    }
    return out;
  }
  return value;
}

function canonicalJsonStringify(value) {
  return JSON.stringify(canonicalize(value));
}

async function getRegimeStats({ accountId, regimeSignature, config }) {
  const tradeSchema = getTradeSchema();
  const ticketCol = tradeSchema.col('ticket');
  const closeTimeCol = tradeSchema.col('close_time');
  const profitCol = tradeSchema.col('profit');

  const params = [accountId, regimeSignature];
  let where = `s.account_id = ? AND s.regime_signature = ? AND s.linked_ticket IS NOT NULL` +
    ` AND t.${tradeSchema.q(closeTimeCol)} IS NOT NULL` +
    ` AND t.${tradeSchema.q(profitCol)} IS NOT NULL`;

  if (config.lookbackDays > 0) {
    where += ` AND datetime(t.${tradeSchema.q(closeTimeCol)}) >= datetime('now', ?)`;
    params.push(`-${config.lookbackDays} days`);
  }

  const countRow = await get(
    `SELECT COUNT(*) AS cnt
     FROM v2_snapshots s
     JOIN trades t ON t.${tradeSchema.q(ticketCol)} = s.linked_ticket
     WHERE ${where}`,
    params
  );

  const limit = Math.max(1, config.lastN);
  const rows = await all(
    `SELECT t.${tradeSchema.q(profitCol)} AS profit,
            t.${tradeSchema.q(closeTimeCol)} AS close_time
     FROM v2_snapshots s
     JOIN trades t ON t.${tradeSchema.q(ticketCol)} = s.linked_ticket
     WHERE ${where}
     ORDER BY datetime(t.${tradeSchema.q(closeTimeCol)}) DESC
     LIMIT ?`,
    [...params, limit]
  );

  const nClosedTotal = countRow?.cnt ? Number(countRow.cnt) : 0;
  const nLast = rows.length;
  let wins = 0;
  let pnlSum = 0;
  for (const row of rows) {
    const profit = Number(row.profit);
    if (Number.isFinite(profit)) {
      pnlSum += profit;
      if (profit > 0) wins += 1;
    }
  }

  const winrate = nLast > 0 ? wins / nLast : 0;
  const avgPnl = nLast > 0 ? pnlSum / nLast : 0;
  const window = Math.max(1, config.badStreakWindow);
  const lossesLastWindow = rows.slice(0, window).filter((row) => Number(row.profit) <= 0).length;

  return {
    n_closed_total: nClosedTotal,
    n_last: nLast,
    winrate_last50: winrate,
    avg_pnl_last50: avgPnl,
    losses_last10: lossesLastWindow,
    last_close_time: rows[0]?.close_time ?? null,
  };
}

function evaluateMemoryDecision(stats, config) {
  if (stats.n_closed_total < config.minSample) {
    return { allow: true, decision: 'ALLOW', reason: 'insufficient_data', confidence: 'low' };
  }
  if (stats.winrate_last50 < config.winrateMin) {
    return { allow: false, decision: 'SKIP', reason: 'winrate_low', confidence: 'high' };
  }
  if (stats.avg_pnl_last50 < 0) {
    return { allow: false, decision: 'SKIP', reason: 'negative_expectancy', confidence: 'high' };
  }
  if (stats.losses_last10 >= config.badStreakLosses) {
    return { allow: false, decision: 'SKIP', reason: 'bad_streak', confidence: 'high' };
  }
  return { allow: true, decision: 'ALLOW', reason: 'ok', confidence: 'med' };
}

function extractSpreadState(features, config) {
  const payload = features && typeof features === 'object' && !Array.isArray(features)
    ? features
    : {};
  const spreadPoints = toOptionalFloat(payload.spread_points);
  let spreadOk = null;
  if (payload.spread_ok !== undefined && payload.spread_ok !== null) {
    spreadOk = Number(payload.spread_ok) === 1 || payload.spread_ok === true;
  } else if (Number.isFinite(spreadPoints) && Number.isFinite(config.spreadOkMaxPoints)) {
    spreadOk = spreadPoints <= config.spreadOkMaxPoints;
  }

  let spreadExceeded = false;
  if (Number.isFinite(config.spreadOkMaxPoints)) {
    if (spreadOk === false) spreadExceeded = true;
    if (Number.isFinite(spreadPoints) && spreadPoints > config.spreadOkMaxPoints) spreadExceeded = true;
  }

  return {
    spread_points: spreadPoints,
    spread_ok: spreadOk,
    spread_exceeded: spreadExceeded,
  };
}

function computeGuards({ limits, spreadState }) {
  const hardReasons = [];
  const dailyTradesCount = Math.max(0, Number(limits.daily_trades_count || 0));
  const cooldownRemainingSec = Math.max(0, Number(limits.cooldown_remaining_sec || 0));
  const openPositionsCount = Math.max(0, Number(limits.open_positions_count || 0));
  const dailyLimit = Math.max(0, Number(limits.daily_trade_limit || 0));
  const maxOpenPositions = Math.max(1, Number(limits.max_open_positions || 1));

  if (dailyLimit > 0 && dailyTradesCount >= dailyLimit) {
    pushUnique(hardReasons, 'daily_limit');
  }
  if (cooldownRemainingSec > 0) {
    pushUnique(hardReasons, 'cooldown_active');
  }
  if (openPositionsCount >= maxOpenPositions) {
    pushUnique(hardReasons, 'max_open_positions');
  }
  if (spreadState.spread_exceeded) {
    pushUnique(hardReasons, 'spread_wide');
  }

  return {
    hard_block: hardReasons.length > 0,
    hard_reasons: hardReasons,
    daily_limit_hit: dailyLimit > 0 && dailyTradesCount >= dailyLimit,
    cooldown_active: cooldownRemainingSec > 0,
    cooldown_remaining_sec: cooldownRemainingSec,
    max_open_positions_hit: openPositionsCount >= maxOpenPositions,
    spread_hard_fail: spreadState.spread_exceeded,
  };
}

function computeMemoryAdvice({ stats, dailyLossesCount, config, memoryDecision }) {
  const memoryReasons = [];
  const warnings = [];
  let recommendedRiskLevel = 'L2';

  if (stats.n_closed_total < config.minSample) {
    recommendedRiskLevel = 'L1';
    pushUnique(memoryReasons, 'insufficient_data');
  }

  if (dailyLossesCount >= 1) {
    recommendedRiskLevel = 'L1';
    pushUnique(memoryReasons, 'daily_losses_guard');
  }

  if (memoryDecision.decision === 'SKIP') {
    recommendedRiskLevel = 'L1';
    const skipReason = normalizeReason(memoryDecision.reason, 'memory_skip');
    pushUnique(memoryReasons, skipReason);
    pushUnique(warnings, skipReason);
  }

  return {
    recommended_risk_level: recommendedRiskLevel,
    memory_reasons: memoryReasons,
    memory_says_block: memoryDecision.decision === 'SKIP',
    warnings,
    confidence: memoryDecision.confidence || 'med',
  };
}

function getRiskMultiplier(riskLevel, config) {
  if (riskLevel === 'L1') return config.riskL1Mult;
  if (riskLevel === 'L2') return config.riskL2Mult;
  return 0;
}

function analyzeNews(news, config) {
  const state = {
    enabled: false,
    hasNews: false,
    impact: 'NONE',
    reasonCode: null,
    block: false,
    reduceRisk: false,
    providerError: null,
  };

  if (!news || typeof news !== 'object') return state;

  state.enabled = news.enabled !== false;
  state.providerError = typeof news.provider_error === 'string' && news.provider_error.trim()
    ? 'news_provider_error'
    : null;

  if (!state.enabled) return state;

  const impact = normalizeNewsImpact(news.impact, 'NONE');
  state.impact = impact;
  state.hasNews = news.has_news === true;

  if (!state.hasNews) return state;

  if (impact === 'HIGH') {
    state.reasonCode = 'news_high_upcoming';
    state.block = !!config.newsBlockHigh;
    state.reduceRisk = true;
    return state;
  }

  if (impact === 'MEDIUM') {
    state.reasonCode = 'news_medium_upcoming';
    state.block = !!config.newsBlockMedium;
    state.reduceRisk = true;
    return state;
  }

  return state;
}

function evaluateRiskLadder(stats = {}, dailyMetrics = {}, config = {}, modeInput, extra = {}) {
  const mode = normalizeMode(modeInput || config.mode);
  const memoryDecision = extra.memoryDecision || evaluateMemoryDecision(stats, config);
  const spreadState = extractSpreadState(extra.features || {}, config);
  const newsState = analyzeNews(extra.news, config);

  const dailyTradesCount = Math.max(0, Number(dailyMetrics.daily_trades_count || 0));
  const dailyLossesCount = Math.max(0, Number(dailyMetrics.daily_losses_count || 0));
  const openPositionsCount = Math.max(0, Number(dailyMetrics.open_positions_count || 0));
  const cooldownRemainingSec = Math.max(0, Number(dailyMetrics.cooldown_remaining_sec || 0));

  const limits = {
    daily_trade_limit: Math.max(0, Number(config.dailyTradeLimit || 0)),
    daily_trades_count: dailyTradesCount,
    cooldown_min: Math.max(0, Number(config.cooldownAfterSlMin || 0)),
    cooldown_remaining_sec: cooldownRemainingSec,
    max_open_positions: Math.max(1, Number(config.maxOpenPositions || 1)),
    open_positions_count: openPositionsCount,
  };

  if (mode === 'OFF') {
    return {
      allow: true,
      enforce: false,
      mode,
      reason: 'mode_off',
      confidence: 'low',
      risk_level: 'L2',
      risk_multiplier: config.riskL2Mult,
      reason_codes: ['mode_off'],
      warnings: [],
      limits,
      spread: spreadState,
    };
  }

  const guards = computeGuards({ limits, spreadState });
  const memoryAdvice = computeMemoryAdvice({
    stats,
    dailyLossesCount,
    config,
    memoryDecision,
  });

  const reasonCodes = [];
  const warnings = [];
  for (const reason of guards.hard_reasons) pushUnique(reasonCodes, reason);
  for (const reason of memoryAdvice.memory_reasons) pushUnique(reasonCodes, reason);
  for (const warning of memoryAdvice.warnings) pushUnique(warnings, warning);
  if (newsState.reasonCode) {
    pushUnique(reasonCodes, newsState.reasonCode);
    pushUnique(warnings, newsState.reasonCode);
  }
  if (newsState.providerError) {
    pushUnique(reasonCodes, newsState.providerError);
    pushUnique(warnings, newsState.providerError);
  }

  if (mode === 'ENFORCE') {
    if (guards.hard_block) {
      return {
        allow: false,
        enforce: true,
        mode,
        reason: 'hard_guard',
        confidence: 'high',
        risk_level: 'L0',
        risk_multiplier: 0,
        reason_codes: reasonCodes,
        warnings,
        limits,
        spread: spreadState,
      };
    }

    if (newsState.providerError && config.newsFailClosed) {
      return {
        allow: false,
        enforce: true,
        mode,
        reason: 'news_provider_error',
        confidence: 'high',
        risk_level: 'L0',
        risk_multiplier: 0,
        reason_codes: reasonCodes,
        warnings,
        limits,
        spread: spreadState,
      };
    }

    if (newsState.block && newsState.reasonCode) {
      return {
        allow: false,
        enforce: true,
        mode,
        reason: newsState.reasonCode,
        confidence: 'high',
        risk_level: 'L0',
        risk_multiplier: 0,
        reason_codes: reasonCodes,
        warnings,
        limits,
        spread: spreadState,
      };
    }

    if (memoryAdvice.memory_says_block) {
      return {
        allow: false,
        enforce: true,
        mode,
        reason: 'memory_block',
        confidence: memoryAdvice.confidence,
        risk_level: 'L0',
        risk_multiplier: 0,
        reason_codes: reasonCodes,
        warnings,
        limits,
        spread: spreadState,
      };
    }

    let riskLevel = memoryAdvice.recommended_risk_level === 'L1' ? 'L1' : 'L2';
    if (newsState.reduceRisk && riskLevel === 'L2') {
      riskLevel = 'L1';
    }
    if (riskLevel === 'L2') {
      pushUnique(reasonCodes, 'ok');
    }
    const reduceReason = newsState.reasonCode || 'reduce_risk';
    return {
      allow: true,
      enforce: true,
      mode,
      reason: riskLevel === 'L1'
        ? normalizeReason(memoryAdvice.memory_reasons[0], reduceReason)
        : 'ok',
      confidence: riskLevel === 'L1' && memoryAdvice.memory_reasons.includes('insufficient_data')
        ? 'low'
        : memoryAdvice.confidence,
      risk_level: riskLevel,
      risk_multiplier: getRiskMultiplier(riskLevel, config),
      reason_codes: reasonCodes,
      warnings,
      limits,
      spread: spreadState,
    };
  }

  const advisoryHardGuards = !!config.advisoryHardGuards;
  if (advisoryHardGuards && guards.hard_block) {
    return {
      allow: false,
      enforce: true,
      mode,
      reason: 'hard_guard',
      confidence: 'high',
      risk_level: 'L0',
      risk_multiplier: 0,
      reason_codes: reasonCodes,
      warnings,
      limits,
      spread: spreadState,
    };
  }

  const shouldReduceRisk = guards.hard_block
    || memoryAdvice.memory_says_block
    || memoryAdvice.recommended_risk_level === 'L1'
    || newsState.reduceRisk;

  if (shouldReduceRisk) {
    for (const reason of guards.hard_reasons) pushUnique(warnings, reason);
    for (const reason of memoryAdvice.memory_reasons) pushUnique(warnings, reason);
    if (newsState.reasonCode) pushUnique(warnings, newsState.reasonCode);
    return {
      allow: true,
      enforce: false,
      mode,
      reason: 'advisory_reduce_risk',
      confidence: memoryAdvice.memory_reasons.includes('insufficient_data') ? 'low' : memoryAdvice.confidence,
      risk_level: 'L1',
      risk_multiplier: config.riskL1Mult,
      reason_codes: reasonCodes,
      warnings,
      limits,
      spread: spreadState,
      recommended_action: 'reduce_risk',
    };
  }

  pushUnique(reasonCodes, 'ok');
  return {
    allow: true,
    enforce: false,
    mode,
    reason: 'ok',
    confidence: memoryAdvice.confidence,
    risk_level: 'L2',
    risk_multiplier: config.riskL2Mult,
    reason_codes: reasonCodes,
    warnings,
    limits,
    spread: spreadState,
  };
}

module.exports = {
  getMemoryConfig,
  getLadderConfigSnapshot,
  bucketize,
  buildRegimeSignature,
  canonicalJsonStringify,
  getRegimeStats,
  evaluateMemoryDecision,
  computeGuards,
  computeMemoryAdvice,
  evaluateRiskLadder,
};
