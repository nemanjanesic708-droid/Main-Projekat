﻿'use strict';
console.log('[ORCH] Server booted at', new Date().toISOString());
process.on('uncaughtException', (err) => {
  console.error('[FATAL] uncaughtException', err);
});

process.on('unhandledRejection', (err) => {
  console.error('[FATAL] unhandledRejection', err);
});

console.log('Orchestrator starting...');
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const crypto = require('crypto');
const { initDb, run, get, transaction, getTradeSchema, getDailyMetrics } = require('./db');
const { buildComment } = require('./tags');
const { evaluatePreTrade } = require('./rules');
const { checkUpcomingNews, getNewsDebugState } = require('./news');
const { checkUpcomingNews: checkDbUpcomingNews, getNewsFilterConfig } = require('./newsFilter');
const {
  getMemoryConfig,
  getLadderConfigSnapshot,
  bucketize,
  buildRegimeSignature,
  canonicalJsonStringify,
  getRegimeStats,
  evaluateMemoryDecision,
  evaluateRiskLadder,
} = require('./memory');
const pkg = require('../package.json');
const app = express();

app.disable('x-powered-by');
const PORT = parseInt(process.env.PORT || '8081', 10);
const HOST = (process.env.HOST || '0.0.0.0').trim() || '0.0.0.0';
const ENV_MODE = process.env.NODE_ENV || 'development';
const API_KEY = process.env.API_KEY ? String(process.env.API_KEY) : '';
const SQLITE_DB_PATH = process.env.SQLITE_DB_PATH ? String(process.env.SQLITE_DB_PATH) : '';
const LAST_REQUESTS_LIMIT = Math.max(1, parseInt(process.env.DEBUG_LAST_REQUESTS || '50', 10) || 50);
const VERSION = pkg.version || '0.0.0';
const STARTED_AT_MS = Date.now();
const ORCH_CONFIG_FILE = path.resolve(process.cwd(), process.env.ORCH_CONFIG_FILE || 'orch_config.json');
const ORCH_DECISIONS_LIMIT = 500;
const ORCH_DECISIONS_DEFAULT_LIMIT = 200;
const ORCH_WINDOW_LIMIT_MAX = 240;
let lastRequestUtc = null;
const orchDecisions = [];
const runtimeNewsDefaults = getNewsFilterConfig();
let orchRuntimeConfig = {
  enabled: true,
  news_filter_enabled: runtimeNewsDefaults.enabled !== false,
  news_min_importance: Math.max(0, Math.min(2, Number(runtimeNewsDefaults.min_importance || 2))),
  news_window_before_min: Math.max(0, Math.min(ORCH_WINDOW_LIMIT_MAX, Number(runtimeNewsDefaults.window_before_min || 15))),
  news_window_after_min: Math.max(0, Math.min(ORCH_WINDOW_LIMIT_MAX, Number(runtimeNewsDefaults.window_after_min || 15))),
};
const SAFE_BODY_FIELDS = [
  'bot_id',
  'account_id',
  'symbol',
  'direction',
  'timeframe',
  'ticket',
  'position_id',
  'snapshot_id',
];
const lastRequests = [];
const eaTelemetry = {
  last_ea_name: null,
  last_ea_version: null,
  last_seen_at: null,
  last_user_agent: null,
  last_remote_ip: null,
};

function resolveDbPath(raw) {
  if (!raw) return null;
  return path.isAbsolute(raw) ? raw : path.resolve(process.cwd(), raw);
}

function isDefaultApiKey(value) {
  if (!value) return true;
  const trimmed = String(value).trim();
  if (!trimmed) return true;
  const lower = trimmed.toLowerCase();
  return lower === 'change_me' || lower === 'changeme' || lower === 'default';
}

function getRemoteIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded.length) {
    return forwarded.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || req.ip || null;
}

function normalizeHeaderValue(value) {
  if (value === undefined || value === null) return null;
  const text = String(value).trim();
  return text ? text : null;
}

function captureEaTelemetry(req) {
  const nameHeader = normalizeHeaderValue(req.get('x-ea-name'));
  const versionHeader = normalizeHeaderValue(req.get('x-ea-version'));
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : null;
  const nameBody = body ? normalizeHeaderValue(body.ea_name || body.eaName) : null;
  const versionBody = body ? normalizeHeaderValue(body.ea_version || body.eaVersion) : null;
  const now = new Date().toISOString();
  eaTelemetry.last_seen_at = now;
  const userAgent = normalizeHeaderValue(req.get('user-agent'));
  if (userAgent) eaTelemetry.last_user_agent = userAgent;
  const remoteIp = getRemoteIp(req);
  if (remoteIp) eaTelemetry.last_remote_ip = remoteIp;
  if (nameHeader || nameBody) eaTelemetry.last_ea_name = nameHeader || nameBody;
  if (versionHeader || versionBody) eaTelemetry.last_ea_version = versionHeader || versionBody;
}

function buildBodySummary(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  const summary = {};
  for (const field of SAFE_BODY_FIELDS) {
    if (body[field] !== undefined) {
      summary[field] = body[field];
    }
  }
  return Object.keys(summary).length ? summary : null;
}

function pushLastRequest(entry) {
  lastRequests.push(entry);
  if (lastRequests.length > LAST_REQUESTS_LIMIT) {
    lastRequests.splice(0, lastRequests.length - LAST_REQUESTS_LIMIT);
  }
}
if (!API_KEY || !API_KEY.trim()) {
  console.warn(JSON.stringify({ status: 'warning', message: 'API_KEY is empty. Set API_KEY in environment.' }));
  console.error('Missing API_KEY');
  process.exit(1);
}
if (isDefaultApiKey(API_KEY)) {
  console.warn(JSON.stringify({ status: 'warning', message: 'API_KEY appears to be default/weak.' }));
}
if (!SQLITE_DB_PATH || !SQLITE_DB_PATH.trim()) {
  console.error('Missing SQLITE_DB_PATH');
  process.exit(1);
}
const RESOLVED_DB_PATH = resolveDbPath(SQLITE_DB_PATH);
const BASE_HOST = HOST === '0.0.0.0' ? '127.0.0.1' : HOST;
const BASE_URL = process.env.BASE_URL || `http://${BASE_HOST}:${PORT}`;
console.log(JSON.stringify({
  status: 'startup',
  env: ENV_MODE,
  port: PORT,
  host: HOST,
  base_url: BASE_URL,
  sqlite_db_path: RESOLVED_DB_PATH,
  last_requests_limit: LAST_REQUESTS_LIMIT,
  version: VERSION,
}));

app.use((req, res, next) => {
  const id = typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : crypto.randomBytes(16).toString('hex');
  req.requestId = id;
  res.setHeader('x-request-id', id);
  next();
});

app.use((req, res, next) => {
  const start = process.hrtime.bigint();
  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    const summary = req.method === 'POST' ? buildBodySummary(req.body) : null;
    const similarMatch = res.locals.similar_match === true;
    const entry = {
      timestamp: new Date().toISOString(),
      request_id: req.requestId,
      method: req.method,
      path: req.path,
      endpoint: `${req.method} ${req.path}`,
      status: res.statusCode,
      duration_ms: Math.round(durationMs),
      remote_ip: getRemoteIp(req),
      user_agent: req.get('user-agent') || null,
      allow: res.locals.allow,
      reason: res.locals.reason,
      risk_level: res.locals.risk_level || null,
      risk_multiplier: res.locals.risk_multiplier ?? null,
      similar_match: similarMatch,
    };
    const requiresAuthPath = req.path.startsWith('/v1') || req.path.startsWith('/v2') || req.path.startsWith('/api/orch');
    const authStatus = res.locals.auth_status
      || (requiresAuthPath
        ? (!req.header('x-api-key') ? 'missing' : (req.header('x-api-key') !== API_KEY ? 'invalid' : 'ok'))
        : null);
    if (authStatus === 'missing' || authStatus === 'invalid') {
      entry.auth = authStatus;
    }
    if (summary) {
      entry.body_summary = summary;
    }
    if (similarMatch) {
      entry.similar_trade_id = res.locals.similar_trade_id;
      entry.similar_time = res.locals.similar_time;
    }
    pushLastRequest(entry);
    lastRequestUtc = toIsoUtcNoMs(new Date());
    console.log(JSON.stringify(entry));
  });
  next();
});

app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => {
  try {
    captureEaTelemetry(req);
  } catch (err) {
    console.warn('[ORCH] telemetry capture failed', err);
  }
  next();
});


function fail(res, status, error, reason, extra) {
  res.locals.allow = false;
  res.locals.reason = reason || error;
  const payload = { ok: false, error };
  if (extra && typeof extra === 'object') {
    Object.assign(payload, extra);
  }
  return res.status(status).json(payload);
}

function requireFields(body, fields) {
  const missing = [];
  for (const field of fields) {
    const value = body[field];
    if (value === undefined || value === null || value === '') {
      missing.push(field);
    }
  }
  return missing;
}

function isDirection(value) {
  return value === 'BUY' || value === 'SELL';
}

function isCloseReason(value) {
  return value === 'TP' || value === 'SL' || value === 'MANUAL' || value === 'OTHER';
}

function normalizeTimeString(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  const match = /^(\d{4})\.(\d{2})\.(\d{2}) (\d{2}):(\d{2}):(\d{2})$/.exec(trimmed);
  if (!match) return null;
  return `${match[1]}-${match[2]}-${match[3]} ${match[4]}:${match[5]}:${match[6]}`;
}

function isFiniteNumber(value) {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function isIntegerLike(value) {
  if (typeof value === 'number') return Number.isInteger(value);
  if (typeof value === 'string' && /^\d+$/.test(value)) return true;
  return false;
}


function buildNewsFilterBlockResponse(decision) {
  return {
    allow: false,
    reason: 'News filter',
    details: {
      event: String(decision?.event_title || ''),
      time: decision?.event_time || null,
      minutes_to_event: decision?.minutes_to_event ?? null,
    },
  };
}

async function checkNewsBlockDecision(symbol) {
  try {
    const runtimeConfig = getOrchRuntimeConfig();
    const decision = await checkDbUpcomingNews(symbol, {
      config: {
        enabled: runtimeConfig.news_filter_enabled,
        minImportance: runtimeConfig.news_min_importance,
        beforeMin: runtimeConfig.news_window_before_min,
        afterMin: runtimeConfig.news_window_after_min,
      },
    });
    if (!decision || decision.block !== true) {
      return { block: false, decision };
    }

    const symbolText = String(symbol || '').trim().toUpperCase() || 'UNKNOWN';
    const title = String(decision.event_title || '').trim() || 'unknown';
    const minutes = decision.minutes_to_event === undefined || decision.minutes_to_event === null
      ? 'n/a'
      : String(decision.minutes_to_event);
    console.log('[ORCH][NEWS] BLOCK symbol=' + symbolText + ' event=' + title + ' minutes=' + minutes);

    return { block: true, decision };
  } catch (err) {
    console.warn('[ORCH][NEWS] check error', err?.message || err);
    return { block: false, decision: null, error: err };
  }
}


function toIsoUtcNoMs(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (!Number.isFinite(date.getTime())) return null;
  return date.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

function toIntSafe(value, fallback) {
  const parsed = parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function cloneOrchConfig(config) {
  return {
    enabled: config.enabled === true,
    news_filter_enabled: config.news_filter_enabled === true,
    news_min_importance: toIntSafe(config.news_min_importance, 2),
    news_window_before_min: toIntSafe(config.news_window_before_min, 15),
    news_window_after_min: toIntSafe(config.news_window_after_min, 15),
  };
}

function clampOrchConfig(config) {
  const next = cloneOrchConfig(config);
  if (next.news_min_importance < 0) next.news_min_importance = 0;
  if (next.news_min_importance > 2) next.news_min_importance = 2;
  if (next.news_window_before_min < 0) next.news_window_before_min = 0;
  if (next.news_window_before_min > ORCH_WINDOW_LIMIT_MAX) next.news_window_before_min = ORCH_WINDOW_LIMIT_MAX;
  if (next.news_window_after_min < 0) next.news_window_after_min = 0;
  if (next.news_window_after_min > ORCH_WINDOW_LIMIT_MAX) next.news_window_after_min = ORCH_WINDOW_LIMIT_MAX;
  return next;
}

function tryReadOrchConfigFile() {
  try {
    if (!fs.existsSync(ORCH_CONFIG_FILE)) return null;
    const raw = fs.readFileSync(ORCH_CONFIG_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    return parsed;
  } catch (err) {
    console.warn('[ORCH][CONFIG] read failed', err?.message || err);
    return null;
  }
}

function persistOrchConfig(config) {
  const payload = {
    enabled: config.enabled === true,
    news_filter_enabled: config.news_filter_enabled === true,
    news_min_importance: config.news_min_importance,
    news_window_before_min: config.news_window_before_min,
    news_window_after_min: config.news_window_after_min,
  };
  fs.writeFileSync(ORCH_CONFIG_FILE, JSON.stringify(payload, null, 2), 'utf8');
}

function validateOrchConfigPatch(patch, current) {
  const next = clampOrchConfig(current);
  const errors = [];

  if (Object.prototype.hasOwnProperty.call(patch, 'enabled')) {
    if (typeof patch.enabled !== 'boolean') errors.push('enabled must be boolean');
    else next.enabled = patch.enabled;
  }
  if (Object.prototype.hasOwnProperty.call(patch, 'news_filter_enabled')) {
    if (typeof patch.news_filter_enabled !== 'boolean') errors.push('news_filter_enabled must be boolean');
    else next.news_filter_enabled = patch.news_filter_enabled;
  }
  if (Object.prototype.hasOwnProperty.call(patch, 'news_min_importance')) {
    const value = Number(patch.news_min_importance);
    if (!Number.isInteger(value) || value < 0 || value > 2) errors.push('news_min_importance must be integer 0..2');
    else next.news_min_importance = value;
  }
  if (Object.prototype.hasOwnProperty.call(patch, 'news_window_before_min')) {
    const value = Number(patch.news_window_before_min);
    if (!Number.isInteger(value) || value < 0 || value > ORCH_WINDOW_LIMIT_MAX) errors.push('news_window_before_min must be integer 0..240');
    else next.news_window_before_min = value;
  }
  if (Object.prototype.hasOwnProperty.call(patch, 'news_window_after_min')) {
    const value = Number(patch.news_window_after_min);
    if (!Number.isInteger(value) || value < 0 || value > ORCH_WINDOW_LIMIT_MAX) errors.push('news_window_after_min must be integer 0..240');
    else next.news_window_after_min = value;
  }

  return {
    config: clampOrchConfig(next),
    errors,
  };
}

function loadOrchRuntimeConfig() {
  const fromDisk = tryReadOrchConfigFile();
  if (!fromDisk) {
    return clampOrchConfig(orchRuntimeConfig);
  }
  const validated = validateOrchConfigPatch(fromDisk, orchRuntimeConfig);
  if (validated.errors.length) {
    console.warn('[ORCH][CONFIG] invalid persisted config', validated.errors.join('; '));
    return clampOrchConfig(orchRuntimeConfig);
  }
  return validated.config;
}

function getOrchRuntimeConfig() {
  return clampOrchConfig(orchRuntimeConfig);
}

function buildOrchDisabledResponseLegacy() {
  return {
    allow: false,
    reason: 'orch_disabled',
    cooldown_sec: 0,
    max_trades_left_today: 0,
  };
}

function buildOrchDisabledResponseV2(config, signalTime) {
  const mode = config && config.mode ? String(config.mode) : 'ENFORCE';
  const provider = String(config?.newsProvider || 'none');
  return {
    allow: false,
    enforce: mode === 'ENFORCE',
    mode,
    reason: 'orch_disabled',
    confidence: 'high',
    regime_signature: null,
    stats: {
      n_closed: 0,
      winrate_last50: 0,
      avg_pnl_last50: 0,
      losses_last10: 0,
      daily_trades_count: 0,
      daily_losses_count: 0,
      current_day_pnl: 0,
      open_positions_count: 0,
      last_trade_result: null,
      current_loss_streak: 0,
    },
    risk_level: 'L0',
    risk_multiplier: 0,
    limits: {
      daily_trade_limit: Number(config?.dailyTradeLimit || 0),
      daily_trades_count: 0,
      cooldown_min: Number(config?.cooldownAfterSlMin || 0),
      cooldown_remaining_sec: 0,
      max_open_positions: Number(config?.maxOpenPositions || 0),
      open_positions_count: 0,
    },
    reason_codes: ['orch_disabled'],
    warnings: [],
    news: {
      enabled: provider !== 'none',
      has_news: false,
      impact: 'NONE',
      minutes_to_next: null,
      window_min: Number(config?.newsWindowMin || 30),
      events: [],
      provider,
      provider_error: null,
    },
    snapshot_id: null,
    signal_time: signalTime || null,
  };
}

function applyOrchRuntimeConfigPatch(patch) {
  const validated = validateOrchConfigPatch(patch, orchRuntimeConfig);
  if (validated.errors.length) {
    const err = new Error(validated.errors.join('; '));
    err.code = 'orch_config_validation';
    throw err;
  }
  orchRuntimeConfig = validated.config;
  persistOrchConfig(orchRuntimeConfig);
  return getOrchRuntimeConfig();
}

function pushOrchDecision(entry) {
  orchDecisions.unshift(entry);
  if (orchDecisions.length > ORCH_DECISIONS_LIMIT) {
    orchDecisions.splice(ORCH_DECISIONS_LIMIT);
  }
}

function recordOrchDecision(params) {
  const symbol = String(params?.symbol || '').trim().toUpperCase();
  const reason = String(params?.reason || '').trim() || 'unknown';
  const latency = Number(params?.latency_ms);
  const details = params?.details && typeof params.details === 'object'
    ? params.details
    : null;
  pushOrchDecision({
    time_utc: toIsoUtcNoMs(new Date()),
    symbol,
    allow: params?.allow === true,
    reason,
    latency_ms: Number.isFinite(latency) && latency >= 0 ? Math.round(latency) : null,
    details,
  });
}

orchRuntimeConfig = loadOrchRuntimeConfig();
function addColumn(schema, columns, placeholders, values, name, value) {
  const actual = schema.col(name);
  if (!actual) return;
  columns.push(schema.q(actual));
  placeholders.push('?');
  values.push(value);
}

function listRoutes(appInstance) {
  const routes = [];
  const stack = appInstance?._router?.stack || [];
  for (const layer of stack) {
    if (!layer.route) continue;
    const path = layer.route.path;
    const methods = Object.keys(layer.route.methods || {});
    for (const method of methods) {
      if (layer.route.methods[method]) {
        routes.push(`${method.toUpperCase()} ${path}`);
      }
    }
  }
  return routes.sort();
}

function isV2TablesMissingError(err) {
  if (!err) return false;
  if (err.code !== 'SQLITE_ERROR') return false;
  const msg = String(err.message || '').toLowerCase();
  return msg.includes('no such table: v2_snapshots')
    || msg.includes('no such table: v2_decisions')
    || msg.includes('no such table: news_checks');
}

async function findMapRow(accountId, positionId, ticket) {
  let row = null;
  if (positionId !== undefined && positionId !== null) {
    row = await get(
      `SELECT id, trade_row_id, ticket
       FROM orch_trade_map
       WHERE account_id = ? AND position_id = ?
       LIMIT 1`,
      [accountId, positionId]
    );
  }
  if (!row && ticket !== undefined && ticket !== null) {
    row = await get(
      `SELECT id, trade_row_id, ticket
       FROM orch_trade_map
       WHERE account_id = ? AND ticket = ?
       LIMIT 1`,
      [accountId, ticket]
    );
  }
  return row;
}

async function ensureMapRow(accountId, botId, positionId, ticket, tradeRowId, createdAt) {
  const existing = await findMapRow(accountId, positionId, ticket);
  if (existing) return existing;
  try {
    await run(
      `INSERT INTO orch_trade_map
        (trade_row_id, position_id, ticket, account_id, bot_id, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        tradeRowId,
        positionId,
        ticket,
        accountId,
        botId,
        createdAt,
      ]
    );
  } catch (err) {
    if (!err || err.code !== 'SQLITE_CONSTRAINT') throw err;
  }
  return await findMapRow(accountId, positionId, ticket);
}

async function tryLinkSnapshot(snapshotId, ticket, positionId) {
  if (!snapshotId) {
    return { linked: false, changes: 0 };
  }
  try {
    const result = await run(
      `UPDATE v2_snapshots
       SET linked_ticket = COALESCE(linked_ticket, ?),
           linked_position_id = COALESCE(linked_position_id, ?)
       WHERE id = ?`,
      [ticket ?? null, positionId ?? null, snapshotId]
    );
    const linked = Number(result?.changes || 0) > 0;
    return { linked, changes: Number(result?.changes || 0) };
  } catch (err) {
    const msg = String(err?.message || '');
    if (err && err.code === 'SQLITE_ERROR' && msg.toLowerCase().includes('no such table: v2_snapshots')) {
      return { linked: false, changes: 0, missing_table: true };
    }
    throw err;
  }
}

async function dedupUpdateTrade(schema, ticket, openPrice, lot, sl, tp, openTime, timeframe, strategy, accountId, positionId) {
  if (ticket === undefined || ticket === null) return;
  const updates = [];
  const values = [];
  if (schema.has('open_price')) {
    updates.push(`${schema.q(schema.col('open_price'))} = COALESCE(${schema.q(schema.col('open_price'))}, ?)`);
    values.push(openPrice);
  }
  if (schema.has('lot_size')) {
    updates.push(`${schema.q(schema.col('lot_size'))} = COALESCE(${schema.q(schema.col('lot_size'))}, ?)`);
    values.push(lot);
  }
  if (schema.has('lot')) {
    updates.push(`${schema.q(schema.col('lot'))} = COALESCE(${schema.q(schema.col('lot'))}, ?)`);
    values.push(lot);
  }
  if (schema.has('stop_loss') && sl !== null) {
    updates.push(`${schema.q(schema.col('stop_loss'))} = COALESCE(${schema.q(schema.col('stop_loss'))}, ?)`);
    values.push(sl);
  }
  if (schema.has('take_profit') && tp !== null) {
    updates.push(`${schema.q(schema.col('take_profit'))} = COALESCE(${schema.q(schema.col('take_profit'))}, ?)`);
    values.push(tp);
  }
  if (schema.has('open_time')) {
    updates.push(`${schema.q(schema.col('open_time'))} = COALESCE(${schema.q(schema.col('open_time'))}, ?)`);
    values.push(openTime);
  }
  if (schema.has('timeframe') && timeframe !== undefined && timeframe !== null) {
    updates.push(`${schema.q(schema.col('timeframe'))} = COALESCE(${schema.q(schema.col('timeframe'))}, ?)`);
    values.push(timeframe);
  }
  if (schema.has('strategy') && strategy !== undefined && strategy !== null) {
    updates.push(`${schema.q(schema.col('strategy'))} = COALESCE(${schema.q(schema.col('strategy'))}, ?)`);
    values.push(strategy);
  }
  if (schema.has('account_id') && accountId !== undefined && accountId !== null && accountId !== '') {
    updates.push(`${schema.q(schema.col('account_id'))} = COALESCE(${schema.q(schema.col('account_id'))}, ?)`);
    values.push(accountId);
  }
  if (schema.has('position_id') && positionId !== undefined && positionId !== null && positionId !== '') {
    updates.push(`${schema.q(schema.col('position_id'))} = COALESCE(${schema.q(schema.col('position_id'))}, ?)`);
    values.push(positionId);
  }
  if (!updates.length) return;
  values.push(ticket);
  await run(
    `UPDATE trades SET ${updates.join(', ')} WHERE ${schema.q(schema.col('ticket'))} = ?`,
    values
  );
}

function auth(req, res, next) {
  const apiKey = req.header('x-api-key');
  if (!apiKey) {
    res.locals.auth_status = 'missing';
    return fail(res, 401, 'api_key_missing', 'auth_failed');
  }
  if (apiKey !== API_KEY) {
    res.locals.auth_status = 'invalid';
    return fail(res, 403, 'api_key_invalid', 'auth_failed');
  }
  res.locals.auth_status = 'ok';
  return next();
}
// PowerShell examples:
// $payload = @{ bot_id = 'bot1'; account_id = 1; symbol = 'EURUSD'; direction = 'BUY'; timeframe = 'M5'; strategy = 'v2'; signal_time = '2026.01.30 12:00:00'; equity = 1000; balance = 1000; features = @{ trend_direction = 'UP' } } | ConvertTo-Json -Depth 6
// Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8081/v2/pretrade/check" -Headers @{ "x-api-key"="..." } -ContentType "application/json" -Body $payload
// Invoke-RestMethod -Method Get -Uri "http://127.0.0.1:8081/v2/debug/routes" -Headers @{ "x-api-key"="..." }


app.post('/pre_trade', (req, res) => {
  const startedAtMs = Date.now();
  console.log('[PRE_TRADE] request received', req.body);
  const runtimeConfig = getOrchRuntimeConfig();
  const disabled = runtimeConfig.enabled === false;
  const reason = disabled ? 'orch_disabled' : 'ok';
  const allow = disabled ? false : true;

  res.locals.allow = allow;
  res.locals.reason = reason;
  res.locals.risk_level = null;
  res.locals.risk_multiplier = null;

  const response = {
    allow,
    reason,
    risk_level: null,
    risk_multiplier: null,
  };

  recordOrchDecision({
    symbol: req?.body?.symbol,
    allow,
    reason,
    latency_ms: Math.max(0, Date.now() - startedAtMs),
    details: { endpoint: '/pre_trade', disabled },
  });

  res.status(200).json(response);
});
console.log('[ORCH] /pre_trade route registered');

app.get('/health', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.status(200).json({ ok: true, service: 'orchestrator' });
});

app.post('/ea/register', (req, res) => {
  captureEaTelemetry(req);
  const name = eaTelemetry.last_ea_name;
  const version = eaTelemetry.last_ea_version;
  console.log(`[ORCH] EA registered name=${name || 'unknown'} version=${version || 'unknown'}`);
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.status(200).json({ ok: true });
});

app.get('/status', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.status(200).json({
    ok: true,
    last_seen_at: eaTelemetry.last_seen_at,
    ea_name: eaTelemetry.last_ea_name,
    ea_version: eaTelemetry.last_ea_version,
    user_agent: eaTelemetry.last_user_agent,
    remote_ip: eaTelemetry.last_remote_ip,
  });
});
console.log('[ORCH] status route registered');

app.get('/debug/ping', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.json({
    ok: true,
    now: new Date().toISOString(),
    ip: getRemoteIp(req),
    port: PORT,
    pid: process.pid,
    version: VERSION,
  });
});

app.get('/debug/last_requests', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.json({
    ok: true,
    count: lastRequests.length,
    requests: lastRequests.slice(),
  });
});


app.get('/api/news/test-block', async (req, res, next) => {
  try {
    const symbol = String(req.query.symbol || '').trim();
    if (!symbol) {
      return fail(res, 400, 'missing_symbol', 'validation_error');
    }

    const check = await checkNewsBlockDecision(symbol);
    const config = getOrchRuntimeConfig();

    res.locals.allow = check.block !== true;
    res.locals.reason = check.block === true ? 'news_filter' : 'ok';

    return res.json({
      ok: true,
      symbol,
      config,
      decision: check.decision || { block: false },
    });
  } catch (err) {
    return next(err);
  }
});

app.use('/api/orch', auth);

app.get('/api/orch/health', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  return res.json({
    ok: true,
    version: VERSION,
    uptime_sec: Math.max(0, Math.floor((Date.now() - STARTED_AT_MS) / 1000)),
    now_utc: toIsoUtcNoMs(new Date()),
    last_request_utc: lastRequestUtc,
  });
});

app.get('/api/orch/config', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  return res.json({
    ok: true,
    config: getOrchRuntimeConfig(),
  });
});

app.post('/api/orch/config', (req, res) => {
  const body = req.body || {};
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return fail(res, 400, 'invalid_config_payload', 'validation_error');
  }
  try {
    const updated = applyOrchRuntimeConfigPatch(body);
    res.locals.allow = true;
    res.locals.reason = 'ok';
    return res.json({
      ok: true,
      config: updated,
    });
  } catch (err) {
    const message = String(err?.message || 'invalid_config_payload');
    return fail(res, 400, message, 'validation_error');
  }
});

app.get('/api/orch/decisions', (req, res) => {
  const requested = toIntSafe(req.query.limit, ORCH_DECISIONS_DEFAULT_LIMIT);
  const limit = Math.max(1, Math.min(ORCH_DECISIONS_LIMIT, requested));
  res.locals.allow = true;
  res.locals.reason = 'ok';
  return res.json({
    ok: true,
    items: orchDecisions.slice(0, limit),
  });
});
app.use('/v1', auth);

app.use('/v2', auth);

app.get('/v2/debug/routes', (req, res) => {
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.json({
    ok: true,
    version: VERSION,
    pid: process.pid,
    port: PORT,
    db_path: RESOLVED_DB_PATH,
    routes: listRoutes(app),
  });
});

app.get('/v2/debug/config', (req, res) => {
  const config = getMemoryConfig();
  const ladderConfig = getLadderConfigSnapshot(config);
  res.locals.allow = true;
  res.locals.reason = 'ok';
  res.json({
    ok: true,
    version: VERSION,
    pid: process.pid,
    port: PORT,
    db_path: RESOLVED_DB_PATH,
    memory_config: config,
    advisory_hard_guards: !!config.advisoryHardGuards,
    ladder_config: ladderConfig,
    api_key_masked: API_KEY ? '***' : '',
  });
});

app.get('/v2/debug/news', async (req, res, next) => {
  try {
    const symbol = req.query.symbol === undefined || req.query.symbol === null
      ? ''
      : String(req.query.symbol).trim();
    let sample = null;
    if (symbol) {
      const signalTime = req.query.signal_time === undefined || req.query.signal_time === null
        ? new Date().toISOString().slice(0, 19).replace('T', ' ')
        : String(req.query.signal_time).trim();
      const windowMin = req.query.window_min === undefined || req.query.window_min === null
        ? undefined
        : Number(req.query.window_min);
      const minImpact = req.query.min_impact === undefined || req.query.min_impact === null
        ? undefined
        : String(req.query.min_impact).trim();
      const currencies = req.query.currencies === undefined || req.query.currencies === null
        ? undefined
        : String(req.query.currencies)
          .split(',')
          .map((item) => item.trim())
          .filter(Boolean);

      sample = await checkUpcomingNews({
        symbol,
        signal_time: signalTime,
        window_min: Number.isFinite(windowMin) ? windowMin : undefined,
        min_impact: minImpact || undefined,
        currencies,
      });
    }

    const debugState = getNewsDebugState();

    res.locals.allow = true;
    res.locals.reason = 'ok';
    return res.json({
      ok: true,
      ...debugState,
      sample,
    });
  } catch (err) {
    if (String(err?.message || '').toLowerCase().includes('invalid_signal_time')) {
      return fail(res, 400, 'invalid_signal_time', 'validation_error');
    }
    return next(err);
  }
});

app.get('/v2/debug/state', async (req, res, next) => {
  try {
    const accountId = String(req.query.account_id || '').trim();
    if (!accountId) {
      return fail(res, 400, 'missing_account_id', 'validation_error');
    }
    const botIdRaw = req.query.bot_id === undefined || req.query.bot_id === null
      ? ''
      : String(req.query.bot_id).trim();
    const botId = botIdRaw || null;
    const config = getMemoryConfig();
    const dailyMetrics = await getDailyMetrics({
      accountId,
      botId,
      cooldownMin: config.cooldownAfterSlMin,
    });

    const whereParts = ['s.account_id = ?'];
    const params = [accountId];
    if (botId) {
      whereParts.push('s.bot_id = ?');
      params.push(botId);
    }

    let latest = null;
    try {
      latest = await get(
        `SELECT s.id AS snapshot_id,
                s.created_at AS snapshot_created_at,
                s.regime_signature,
                d.mode,
                d.decision,
                d.enforce,
                d.reason_code,
                d.confidence,
                d.created_at AS decision_created_at
         FROM v2_snapshots s
         LEFT JOIN v2_decisions d ON d.snapshot_id = s.id
         WHERE ${whereParts.join(' AND ')}
         ORDER BY s.id DESC, d.id DESC
         LIMIT 1`,
        params
      );
    } catch (err) {
      if (!isV2TablesMissingError(err)) throw err;
    }

    res.locals.allow = true;
    res.locals.reason = 'ok';
    return res.json({
      ok: true,
      account_id: accountId,
      bot_id: botId,
      mode: config.mode,
      ladder_config: getLadderConfigSnapshot(config),
      daily_metrics: dailyMetrics,
      latest_v2: latest || null,
    });
  } catch (err) {
    if (isV2TablesMissingError(err)) {
      return fail(res, 500, 'v2_tables_missing', 'db_error', { hint: 'run npm run migrate' });
    }
    return next(err);
  }
});

app.post('/v1/pre_trade', async (req, res, next) => {
  try {
    const startedAtMs = Date.now();
    const body = req.body || {};
    const missing = requireFields(body, [
      'bot_id',
      'account_id',
      'symbol',
      'direction',
      'timeframe',
      'strategy',
      'signal_time',
      'equity',
      'balance',
    ]);
    if (missing.length) {
      return fail(res, 400, `missing_fields: ${missing.join(', ')}`, 'validation_error');
    }
    const direction = String(body.direction || '').toUpperCase();
    if (!isDirection(direction)) {
      return fail(res, 400, 'invalid_direction', 'validation_error');
    }
    const signalTime = normalizeTimeString(body.signal_time);
    if (!signalTime) {
      return fail(res, 400, 'invalid_signal_time', 'validation_error');
    }
    if (isFiniteNumber(body.equity) === null || isFiniteNumber(body.balance) === null) {
      return fail(res, 400, 'invalid_equity_or_balance', 'validation_error');
    }

    const runtimeConfig = getOrchRuntimeConfig();
    if (runtimeConfig.enabled === false) {
      const response = buildOrchDisabledResponseLegacy();
      res.locals.allow = response.allow;
      res.locals.reason = response.reason;
      recordOrchDecision({
        symbol: body.symbol,
        allow: response.allow,
        reason: response.reason,
        latency_ms: Math.max(0, Date.now() - startedAtMs),
        details: { endpoint: '/v1/pre_trade', disabled: true },
      });
      return res.json(response);
    }

    const newsBlock = await checkNewsBlockDecision(body.symbol);
    if (newsBlock.block === true) {
      res.locals.allow = false;
      res.locals.reason = 'news_filter';
      const response = buildNewsFilterBlockResponse(newsBlock.decision);
      recordOrchDecision({
        symbol: body.symbol,
        allow: false,
        reason: response.reason,
        latency_ms: Math.max(0, Date.now() - startedAtMs),
        details: newsBlock.decision || { endpoint: '/v1/pre_trade' },
      });
      return res.json(response);
    }

    const decision = await evaluatePreTrade({
      accountId: body.account_id,
      symbol: body.symbol,
      direction,
      timeframe: body.timeframe,
      strategy: body.strategy,
    });
    res.locals.allow = decision.allow;
    res.locals.reason = decision.reason;
    res.locals.similar_match = decision.similar_match === true;
    if (decision.similar_match) {
      res.locals.similar_trade_id = decision.similar_trade_id ?? null;
      res.locals.similar_time = decision.similar_time ?? null;
    }
    await run(
      `INSERT INTO decisions_log
        (request_id, endpoint, account_id, bot_id, symbol, direction, signal_time, allow, reason)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.requestId,
        '/v1/pre_trade',
        body.account_id,
        body.bot_id,
        body.symbol,
        direction,
        signalTime,
        decision.allow ? 1 : 0,
        decision.reason,
      ]
    );
    if (decision.allow) {
      const response = {
        allow: true,
        reason: decision.reason,
        cooldown_sec: decision.cooldown_sec || 0,
        max_trades_left_today: decision.max_trades_left_today || 0,
      };
      recordOrchDecision({
        symbol: body.symbol,
        allow: true,
        reason: response.reason,
        latency_ms: Math.max(0, Date.now() - startedAtMs),
        details: {
          endpoint: '/v1/pre_trade',
          cooldown_sec: response.cooldown_sec,
          max_trades_left_today: response.max_trades_left_today,
        },
      });
      return res.json(response);
    }
    const response = {
      allow: false,
      reason: decision.reason,
    };
    recordOrchDecision({
      symbol: body.symbol,
      allow: false,
      reason: response.reason,
      latency_ms: Math.max(0, Date.now() - startedAtMs),
      details: { endpoint: '/v1/pre_trade' },
    });
    return res.json(response);
  } catch (err) {
    return next(err);
  }
});

app.post('/v2/pretrade/check', async (req, res, next) => {
  try {
    const startedAtMs = Date.now();
    const body = req.body || {};
    const missing = requireFields(body, [
      'bot_id',
      'account_id',
      'symbol',
      'direction',
      'timeframe',
      'strategy',
      'signal_time',
      'equity',
      'balance',
      'features',
    ]);
    if (missing.length) {
      return fail(res, 400, `missing_fields: ${missing.join(', ')}`, 'validation_error');
    }
    const direction = String(body.direction || '').toUpperCase();
    if (!isDirection(direction)) {
      return fail(res, 400, 'invalid_direction', 'validation_error');
    }
    const signalTime = normalizeTimeString(body.signal_time);
    if (!signalTime) {
      return fail(res, 400, 'invalid_signal_time', 'validation_error');
    }
    if (isFiniteNumber(body.equity) === null || isFiniteNumber(body.balance) === null) {
      return fail(res, 400, 'invalid_equity_or_balance', 'validation_error');
    }
    if (!body.features || typeof body.features !== 'object' || Array.isArray(body.features)) {
      return fail(res, 400, 'invalid_features', 'validation_error');
    }
    const strategyRaw = body.strategy === undefined || body.strategy === null ? null : String(body.strategy).trim();
    const strategyValue = strategyRaw === '' ? null : strategyRaw;
    const config = getMemoryConfig();
    const runtimeConfig = getOrchRuntimeConfig();
    if (runtimeConfig.enabled === false) {
      const response = buildOrchDisabledResponseV2(config, signalTime);
      res.locals.allow = response.allow;
      res.locals.reason = response.reason;
      res.locals.risk_level = response.risk_level;
      res.locals.risk_multiplier = response.risk_multiplier;
      recordOrchDecision({
        symbol: body.symbol,
        allow: response.allow,
        reason: response.reason,
        latency_ms: Math.max(0, Date.now() - startedAtMs),
        details: {
          endpoint: '/v2/pretrade/check',
          disabled: true,
        },
      });
      return res.json(response);
    }
    const buckets = bucketize({
      ...body,
      direction,
      signal_time: signalTime,
    }, config);
    const regimeSignature = buildRegimeSignature({
      ...body,
      direction,
    }, buckets);
    const featuresJson = canonicalJsonStringify(body.features);
    const enforced = config.mode === 'ENFORCE' ? 1 : 0;
    const snapshotResult = await run(
      `INSERT INTO v2_snapshots
        (request_id, account_id, bot_id, symbol, timeframe, direction, strategy, signal_time, regime_signature, features_json, enforced)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.requestId,
        body.account_id,
        body.bot_id,
        body.symbol,
        body.timeframe,
        direction,
        strategyValue,
        signalTime,
        regimeSignature,
        featuresJson,
        enforced,
      ]
    );
    const snapshotId = snapshotResult.lastID ? Number(snapshotResult.lastID) : null;
    let news;
    try {
      news = await checkUpcomingNews({
        symbol: body.symbol,
        signal_time: signalTime,
        window_min: config.newsWindowMin,
        min_impact: config.newsMinImpact,
      });
    } catch (err) {
      news = {
        enabled: true,
        provider: String(config.newsProvider || 'none'),
        has_news: false,
        impact: 'NONE',
        minutes_to_next: null,
        window_min: config.newsWindowMin,
        currencies: [],
        events: [],
        provider_error: String(err?.message || 'news_provider_error'),
      };
    }

    if (snapshotId) {
      await run(
        `INSERT INTO news_checks
          (snapshot_id, symbol, window_min, impact, has_news, minutes_to_next, events_json, provider)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          snapshotId,
          body.symbol,
          Number(news.window_min || config.newsWindowMin || 30),
          String(news.impact || 'NONE'),
          news.has_news ? 1 : 0,
          news.minutes_to_next === null || news.minutes_to_next === undefined ? null : Number(news.minutes_to_next),
          canonicalJsonStringify(Array.isArray(news.events) ? news.events : []),
          String(news.provider || config.newsProvider || 'none'),
        ]
      );
    }

    const stats = await getRegimeStats({
      accountId: body.account_id,
      regimeSignature,
      config,
    });
    const recommendation = evaluateMemoryDecision(stats, config);
    const dailyMetrics = await getDailyMetrics({
      accountId: body.account_id,
      botId: body.bot_id,
      cooldownMin: config.cooldownAfterSlMin,
    });
    const ladder = evaluateRiskLadder(stats, dailyMetrics, config, config.mode, {
      memoryDecision: recommendation,
      features: body.features,
      news,
    });

    const decisionStats = {
      memory_stats: stats,
      daily_metrics: dailyMetrics,
      memory_decision: recommendation,
      news,
      ladder: {
        allow: ladder.allow,
        enforce: ladder.enforce,
        reason: ladder.reason,
        confidence: ladder.confidence,
        risk_level: ladder.risk_level,
        risk_multiplier: ladder.risk_multiplier,
        reason_codes: ladder.reason_codes,
        warnings: ladder.warnings,
        recommended_action: ladder.recommended_action || null,
        limits: ladder.limits,
      },
    };

    await run(
      `INSERT INTO v2_decisions
        (snapshot_id, mode, decision, enforce, reason_code, confidence, stats_json)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        snapshotId,
        ladder.mode,
        ladder.allow ? 'ALLOW' : 'SKIP',
        ladder.enforce ? 1 : 0,
        ladder.reason,
        ladder.confidence,
        canonicalJsonStringify(decisionStats),
      ]
    );

    const warnings = Array.isArray(ladder.warnings)
      ? ladder.warnings.filter((item) => typeof item === 'string' && item.trim() !== '')
      : [];

    res.locals.allow = ladder.allow;
    res.locals.reason = ladder.reason;
    res.locals.risk_level = ladder.risk_level;
    res.locals.risk_multiplier = ladder.risk_multiplier;

    recordOrchDecision({
      symbol: body.symbol,
      allow: ladder.allow,
      reason: ladder.reason,
      latency_ms: Math.max(0, Date.now() - startedAtMs),
      details: {
        endpoint: '/v2/pretrade/check',
        risk_level: ladder.risk_level,
        risk_multiplier: ladder.risk_multiplier,
        minutes_to_next: news && news.minutes_to_next !== undefined ? news.minutes_to_next : null,
        impact: news && news.impact ? String(news.impact) : 'NONE',
      },
    });

    return res.json({
      allow: ladder.allow,
      enforce: ladder.enforce,
      mode: ladder.mode,
      reason: ladder.reason,
      confidence: ladder.confidence,
      regime_signature: regimeSignature,
      stats: {
        n_closed: stats.n_closed_total,
        winrate_last50: stats.winrate_last50,
        avg_pnl_last50: stats.avg_pnl_last50,
        losses_last10: stats.losses_last10,
        daily_trades_count: dailyMetrics.daily_trades_count,
        daily_losses_count: dailyMetrics.daily_losses_count,
        current_day_pnl: dailyMetrics.current_day_pnl,
        open_positions_count: dailyMetrics.open_positions_count,
        last_trade_result: dailyMetrics.last_trade_result,
        current_loss_streak: dailyMetrics.current_loss_streak,
      },
      risk_level: ladder.risk_level,
      risk_multiplier: ladder.risk_multiplier,
      limits: ladder.limits,
      reason_codes: Array.isArray(ladder.reason_codes) ? ladder.reason_codes : [],
      warnings,
      news: {
        enabled: news.enabled !== false,
        has_news: news.has_news === true,
        impact: String(news.impact || 'NONE'),
        minutes_to_next: news.minutes_to_next === undefined ? null : news.minutes_to_next,
        window_min: Number(news.window_min || config.newsWindowMin || 30),
        events: Array.isArray(news.events) ? news.events : [],
        provider: String(news.provider || config.newsProvider || 'none'),
        provider_error: news.provider_error || null,
      },
      snapshot_id: snapshotId,
    });
  } catch (err) {
    if (isV2TablesMissingError(err)) {
      console.error(JSON.stringify({
        status: 'error',
        error: 'v2_tables_missing',
        hint: 'run npm run migrate',
        message: err.message,
      }));
      return fail(res, 500, 'v2_tables_missing', 'db_error', { hint: 'run npm run migrate' });
    }
    return next(err);
  }
});

app.post('/v1/trade_open', async (req, res, next) => {
  try {
    const body = req.body || {};
    const missing = requireFields(body, [
      'bot_id',
      'account_id',
      'position_id',
      'ticket',
      'symbol',
      'direction',
      'open_time',
      'open_price',
      'lot',
    ]);
    if (missing.length) {
      return fail(res, 400, `missing_fields: ${missing.join(', ')}`, 'validation_error');
    }
    const direction = String(body.direction || '').toUpperCase();
    if (!isDirection(direction)) {
      return fail(res, 400, 'invalid_direction', 'validation_error');
    }
    if (!isIntegerLike(body.position_id) || !isIntegerLike(body.ticket)) {
      return fail(res, 400, 'invalid_position_or_ticket', 'validation_error');
    }
    const openTime = normalizeTimeString(body.open_time);
    if (!openTime) {
      return fail(res, 400, 'invalid_open_time', 'validation_error');
    }
    const openPrice = isFiniteNumber(body.open_price);
    const lot = isFiniteNumber(body.lot);
    if (openPrice === null || lot === null) {
      return fail(res, 400, 'invalid_open_price_or_lot', 'validation_error');
    }
    const sl = body.sl === undefined || body.sl === null ? null : isFiniteNumber(body.sl);
    const tp = body.tp === undefined || body.tp === null ? null : isFiniteNumber(body.tp);
    if (body.sl !== undefined && body.sl !== null && sl === null) {
      return fail(res, 400, 'invalid_sl', 'validation_error');
    }
    if (body.tp !== undefined && body.tp !== null && tp === null) {
      return fail(res, 400, 'invalid_tp', 'validation_error');
    }
    let snapshotId = null;
    if (body.snapshot_id !== undefined && body.snapshot_id !== null && body.snapshot_id !== '') {
      if (!isIntegerLike(body.snapshot_id)) {
        return fail(res, 400, 'invalid_snapshot_id', 'validation_error');
      }
      snapshotId = Number(body.snapshot_id);
    }
    const timeframeRaw = body.timeframe === undefined || body.timeframe === null ? null : String(body.timeframe).trim();
    const strategyRaw = body.strategy === undefined || body.strategy === null ? null : String(body.strategy).trim();
    const timeframeValue = timeframeRaw === '' ? null : timeframeRaw;
    const strategyValue = strategyRaw === '' ? null : strategyRaw;
    const comment = buildComment(body.account_id, body.bot_id, body.position_id);
    const schema = getTradeSchema();
    const ticketValue = body.ticket ?? null;
    const positionValue = body.position_id ?? null;
    const columns = [];
    const placeholders = [];
    const values = [];
    addColumn(schema, columns, placeholders, values, 'ticket', body.ticket);
    addColumn(schema, columns, placeholders, values, 'symbol', body.symbol);
    addColumn(schema, columns, placeholders, values, 'lot_size', lot);
    addColumn(schema, columns, placeholders, values, 'lot', lot);
    addColumn(schema, columns, placeholders, values, 'direction', direction);
    addColumn(schema, columns, placeholders, values, 'account_id', body.account_id);
    addColumn(schema, columns, placeholders, values, 'position_id', body.position_id);
    if (timeframeValue !== null) {
      addColumn(schema, columns, placeholders, values, 'timeframe', timeframeValue);
    }
    if (strategyValue !== null) {
      addColumn(schema, columns, placeholders, values, 'strategy', strategyValue);
    }
    addColumn(schema, columns, placeholders, values, 'open_time', openTime);
    addColumn(schema, columns, placeholders, values, 'open_price', openPrice);
    addColumn(schema, columns, placeholders, values, 'status', 'OPEN');
    addColumn(schema, columns, placeholders, values, 'stop_loss', sl);
    addColumn(schema, columns, placeholders, values, 'take_profit', tp);
    addColumn(schema, columns, placeholders, values, 'comment', comment);
    addColumn(schema, columns, placeholders, values, 'entry_price', openPrice);
    const insertSql = `INSERT INTO trades (${columns.join(', ')}) VALUES (${placeholders.join(', ')})`;
    const createdAt = new Date().toISOString().slice(0, 19).replace('T', ' ');
    const existingMap = await findMapRow(body.account_id, positionValue, ticketValue);
    const existingTrade = ticketValue !== null
      ? await get(
        `SELECT ${schema.q(schema.col('ticket'))} AS ticket
         FROM trades
         WHERE ${schema.q(schema.col('ticket'))} = ?
         LIMIT 1`,
        [ticketValue]
      )
      : null;
    if (existingTrade || existingMap) {
      const updateTicket = ticketValue ?? existingMap?.ticket;
      await dedupUpdateTrade(
        schema,
        updateTicket,
        openPrice,
        lot,
        sl,
        tp,
        openTime,
        timeframeValue,
        strategyValue,
        body.account_id,
        positionValue
      );
      await ensureMapRow(body.account_id, body.bot_id, positionValue, ticketValue, null, createdAt);
      const linkResult = await tryLinkSnapshot(snapshotId, updateTicket, positionValue);
      if (snapshotId && linkResult.linked) {
        console.log(`[V2] linked snapshot_id=${snapshotId} -> ticket=${updateTicket} position_id=${positionValue ?? 'null'}`);
      }
      console.log(JSON.stringify({
        event: 'trade_open_dedup',
        request_id: req.requestId,
        ticket: updateTicket,
        position_id: positionValue,
        account_id: body.account_id,
      }));
      res.locals.allow = true;
      res.locals.reason = 'dedup';
      return res.json({ ok: true, dedup: true });
    }
    try {
      await transaction(async () => {
        const tradeResult = await run(insertSql, values);
        const tradeRowId = tradeResult.lastID ? Number(tradeResult.lastID) : null;
        await ensureMapRow(body.account_id, body.bot_id, positionValue, ticketValue, tradeRowId, createdAt);
        const linkResult = await tryLinkSnapshot(snapshotId, ticketValue, positionValue);
        if (snapshotId && linkResult.linked) {
          console.log(`[V2] linked snapshot_id=${snapshotId} -> ticket=${ticketValue} position_id=${positionValue ?? 'null'}`);
        }
        return tradeResult;
      });
    } catch (err) {
      if (err && err.code === 'SQLITE_CONSTRAINT') {
        await dedupUpdateTrade(
          schema,
          ticketValue,
          openPrice,
          lot,
          sl,
          tp,
          openTime,
          timeframeValue,
          strategyValue,
          body.account_id,
          positionValue
        );
        await ensureMapRow(body.account_id, body.bot_id, positionValue, ticketValue, null, createdAt);
        const linkResult = await tryLinkSnapshot(snapshotId, ticketValue, positionValue);
        if (snapshotId && linkResult.linked) {
          console.log(`[V2] linked snapshot_id=${snapshotId} -> ticket=${ticketValue} position_id=${positionValue ?? 'null'}`);
        }
        console.log(JSON.stringify({
          event: 'trade_open_dedup',
          request_id: req.requestId,
          ticket: ticketValue,
          position_id: positionValue,
          account_id: body.account_id,
          reason: 'constraint_race',
        }));
        res.locals.allow = true;
        res.locals.reason = 'dedup';
        return res.json({ ok: true, dedup: true });
      }
      throw err;
    }
    res.locals.allow = true;
    res.locals.reason = 'ok';
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

app.post('/v1/trade_close', async (req, res, next) => {
  try {
    const body = req.body || {};
    const missing = requireFields(body, [
      'bot_id',
      'account_id',
      'position_id',
      'ticket',
      'close_time',
      'close_price',
      'profit',
      'close_reason',
    ]);
    if (missing.length) {
      return fail(res, 400, `missing_fields: ${missing.join(', ')}`, 'validation_error');
    }
    if (!isIntegerLike(body.position_id) || !isIntegerLike(body.ticket)) {
      return fail(res, 400, 'invalid_position_or_ticket', 'validation_error');
    }
    const closeTime = normalizeTimeString(body.close_time);
    if (!closeTime) {
      return fail(res, 400, 'invalid_close_time', 'validation_error');
    }
    const closePrice = isFiniteNumber(body.close_price);
    const profit = isFiniteNumber(body.profit);
    if (closePrice === null || profit === null) {
      return fail(res, 400, 'invalid_close_price_or_profit', 'validation_error');
    }
    const closeReason = String(body.close_reason || '').toUpperCase();
    if (!isCloseReason(closeReason)) {
      return fail(res, 400, 'invalid_close_reason', 'validation_error');
    }
    let snapshotId = null;
    if (body.snapshot_id !== undefined && body.snapshot_id !== null && body.snapshot_id !== '') {
      if (!isIntegerLike(body.snapshot_id)) {
        return fail(res, 400, 'invalid_snapshot_id', 'validation_error');
      }
      snapshotId = Number(body.snapshot_id);
    }
    let mapRow = await get(
      `SELECT trade_row_id, ticket
       FROM orch_trade_map
       WHERE account_id = ? AND position_id = ?
       LIMIT 1`,
      [body.account_id, body.position_id]
    );
    if (!mapRow) {
      mapRow = await get(
        `SELECT trade_row_id, ticket
         FROM orch_trade_map
         WHERE account_id = ? AND ticket = ?
         LIMIT 1`,
        [body.account_id, body.ticket]
      );
    }
    if (!mapRow) {
      return fail(res, 404, 'trade_not_found', 'not_found');
    }
    const updates = [];
    const values = [];
    const tradeSchema = getTradeSchema();
    updates.push(`${tradeSchema.q(tradeSchema.col('close_time'))} = ?`);
    values.push(closeTime);
    updates.push(`${tradeSchema.q(tradeSchema.col('close_price'))} = ?`);
    values.push(closePrice);
    updates.push(`${tradeSchema.q(tradeSchema.col('profit'))} = ?`);
    values.push(profit);
    if (tradeSchema.has('status')) {
      updates.push(`${tradeSchema.q(tradeSchema.col('status'))} = 'CLOSED'`);
    }
    if (tradeSchema.has('exit_price')) {
      updates.push(`${tradeSchema.q(tradeSchema.col('exit_price'))} = ?`);
      values.push(closePrice);
    }
    if (tradeSchema.closeReasonColumn) {
      updates.push(`${tradeSchema.q(tradeSchema.closeReasonColumn)} = ?`);
      values.push(closeReason);
    }
    const idCol = tradeSchema.has('id') ? tradeSchema.col('id') : null;
    const where = idCol && mapRow.trade_row_id
      ? `${tradeSchema.q(idCol)} = ?`
      : `${tradeSchema.q(tradeSchema.col('ticket'))} = ?`;
    values.push(idCol && mapRow.trade_row_id ? mapRow.trade_row_id : mapRow.ticket);
    const result = await run(
      `UPDATE trades SET ${updates.join(', ')} WHERE ${where}`,
      values
    );
    if (result.changes === 0) {
      return fail(res, 404, 'trade_not_found', 'not_found');
    }
    await tryLinkSnapshot(snapshotId, body.ticket, body.position_id);
    res.locals.allow = true;
    res.locals.reason = 'ok';
    return res.json({ ok: true });
  } catch (err) {
    return next(err);
  }
});

app.use((err, req, res, next) => {
  console.error('Unhandled error', err);
  if (res.headersSent) return next(err);
  if (err && err.type === 'entity.parse.failed') {
    const rawBody = Buffer.isBuffer(err.body)
      ? err.body
      : Buffer.from(typeof err.body === 'string' ? err.body : '', 'utf8');
    const rawPreview = rawBody
      .toString('utf8')
      .slice(0, 200)
      .replace(/\r/g, '\\r')
      .replace(/\n/g, '\\n')
      .replace(/\0/g, '\\0');
    const parseError = String(err?.message || 'entity.parse.failed');
    console.warn(JSON.stringify({
      status: 'invalid_json',
      request_id: req.requestId || null,
      path: req.path,
      method: req.method,
      raw_length: rawBody.length,
      raw_preview: rawPreview,
      parse_error: parseError,
    }));
    return fail(res, 400, 'invalid_json', 'validation_error', { hint: parseError });
  }
  if (err && err.code === 'SQLITE_CONSTRAINT') {
    return fail(res, 409, 'db_constraint', 'db_constraint');
  }
  return fail(res, 500, 'internal_error', 'error');
});

async function start() {
  console.log(`Starting orchestrator... host=${HOST} port=${PORT} base=${BASE_URL}`);
  console.log(`[BOOT] orch start pid=${process.pid} env=${ENV_MODE} host=${HOST} port=${PORT}`);
  const routes = listRoutes(app);
  console.log('[ROUTES]', routes.join(', '));
  await initDb();
  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Orch listening on port ${PORT}`);
    console.log(JSON.stringify({
      status: 'listening',
      port: PORT,
      host: HOST,
      base_url: BASE_URL,
      pid: process.pid,
    }));
  });
  server.on('error', (err) => {
    const code = err?.code || 'unknown';
    let message = 'Server listen failed.';
    if (code === 'EADDRINUSE') {
      message = `Port ${PORT} is already in use.`;
    } else if (code === 'EACCES') {
      message = `Permission denied binding to ${HOST}:${PORT}.`;
    }
    console.error(JSON.stringify({
      status: 'fatal',
      error: 'listen_failed',
      code,
      message,
      port: PORT,
      host: HOST,
    }));
    process.exit(1);
  });
}
start().catch((err) => {
  console.error('Failed to start server', err);
  process.exit(1);
});








