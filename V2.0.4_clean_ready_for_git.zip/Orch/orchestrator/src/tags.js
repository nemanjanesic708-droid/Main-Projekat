'use strict';

function buildComment(accountId, botId, positionId) {
  const parts = [`orch:account_id=${accountId}`];
  if (botId) parts.push(`bot_id=${botId}`);
  if (positionId !== undefined && positionId !== null) {
    parts.push(`position_id=${positionId}`);
  }
  return parts.join(';');
}

module.exports = {
  buildComment,
};
