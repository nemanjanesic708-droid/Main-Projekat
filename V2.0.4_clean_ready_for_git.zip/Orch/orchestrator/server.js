﻿'use strict';

// Entrypoint wrapper for production start.
require('./src/server');
