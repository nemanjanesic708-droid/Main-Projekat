'use strict';

require('dotenv').config();

const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3');

const ACCOUNT_ID_ALIASES = [
  'account_id',
  'accountid',
  'account',
  'account_number',
  'login',
  'account_login',
  'mt5_login',
];

const REQUIRED_TRADES_COLUMNS = [
  { name: 'ticket', type: 'INTEGER' },
  { name: 'symbol', type: 'TEXT' },
  { name: 'direction', type: 'TEXT' },
  { name: 'open_time', type: 'TEXT' },
  { name: 'open_price', type: 'REAL' },
  { name: 'close_time', type: 'TEXT' },
  { name: 'close_price', type: 'REAL' },
  { name: 'profit', type: 'REAL' },
  { name: 'status', type: 'TEXT' },
];

const OPTIONAL_TRADES_COLUMNS = [
  { name: 'timeframe', type: 'TEXT' },
  { name: 'close_reason', type: 'TEXT' },
  { name: 'position_id', type: 'INTEGER' },
  { name: 'lot', type: 'REAL' },
  { name: 'updated_at', type: 'TEXT' },
];

function resolveDbPath() {
  const raw = process.env.SQLITE_DB_PATH;
  if (!raw) {
    throw new Error('Missing SQLITE_DB_PATH');
  }
  return path.isAbsolute(raw) ? raw : path.resolve(process.cwd(), raw);
}

function quoteIdent(name) {
  return `"${String(name).replace(/"/g, '""')}"`;
}

function quoteString(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function exec(db, sql) {
  return new Promise((resolve, reject) => {
    db.exec(sql, (err) => {
      if (err) return reject(err);
      return resolve();
    });
  });
}

function run(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(err) {
      if (err) return reject(err);
      return resolve({ changes: this.changes, lastID: this.lastID });
    });
  });
}

function get(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      return resolve(row);
    });
  });
}

function all(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      return resolve(rows);
    });
  });
}

function openDatabase(dbPath) {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE, (err) => {
      if (err) return reject(err);
      return resolve(db);
    });
  });
}

function closeDatabase(db) {
  return new Promise((resolve, reject) => {
    db.close((err) => {
      if (err) return reject(err);
      return resolve();
    });
  });
}

async function tableExists(db, tableName) {
  const row = await get(
    db,
    "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ? LIMIT 1",
    [tableName]
  );
  return Boolean(row);
}

async function getTableColumns(db, tableName) {
  return all(db, `PRAGMA table_info(${quoteString(tableName)})`);
}

async function listTables(db) {
  const rows = await all(
    db,
    "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name"
  );
  return rows.map((row) => row.name);
}

function hasColumn(columns, columnName) {
  const wanted = String(columnName).toLowerCase();
  return columns.some((col) => String(col.name).toLowerCase() === wanted);
}

function findColumn(columns, candidates) {
  const lowered = new Map(columns.map((col) => [String(col.name).toLowerCase(), col.name]));
  for (const candidate of candidates) {
    const actual = lowered.get(String(candidate).toLowerCase());
    if (actual) return actual;
  }
  return null;
}

async function hasUniqueTicketConstraint(db, ticketColumnName) {
  const tableInfo = await getTableColumns(db, 'trades');
  const ticketInfo = tableInfo.find(
    (col) => String(col.name).toLowerCase() === String(ticketColumnName).toLowerCase()
  );
  if (ticketInfo && Number(ticketInfo.pk) > 0) {
    return true;
  }

  const indexes = await all(db, "PRAGMA index_list('trades')");
  for (const idx of indexes) {
    if (!idx || Number(idx.unique) !== 1) continue;
    const indexName = idx.name;
    if (!indexName) continue;
    const idxCols = await all(db, `PRAGMA index_info(${quoteString(indexName)})`);
    if (idxCols.length !== 1) continue;
    if (String(idxCols[0].name).toLowerCase() === String(ticketColumnName).toLowerCase()) {
      return true;
    }
  }

  return false;
}

async function ensureUniqueTicketIndex(db, ticketColumnName) {
  if (await hasUniqueTicketConstraint(db, ticketColumnName)) {
    return { created: false, reason: 'already_unique' };
  }

  const ticketIdent = quoteIdent(ticketColumnName);
  const duplicates = await get(
    db,
    `SELECT COUNT(*) AS cnt FROM (
       SELECT ${ticketIdent}
       FROM trades
       WHERE ${ticketIdent} IS NOT NULL
       GROUP BY ${ticketIdent}
       HAVING COUNT(*) > 1
     )`
  );

  if ((duplicates?.cnt || 0) > 0) {
    return { created: false, reason: `duplicate_tickets:${duplicates.cnt}` };
  }

  await run(
    db,
    `CREATE UNIQUE INDEX IF NOT EXISTS uq_trades_ticket ON trades (${ticketIdent})`
  );
  return { created: true, reason: 'created' };
}

async function ensureTradesColumns(db) {
  const exists = await tableExists(db, 'trades');
  if (!exists) {
    throw new Error('Missing required table: trades');
  }

  const before = await getTableColumns(db, 'trades');
  const addedColumns = [];

  for (const column of REQUIRED_TRADES_COLUMNS) {
    if (!hasColumn(before, column.name)) {
      await run(
        db,
        `ALTER TABLE trades ADD COLUMN ${quoteIdent(column.name)} ${column.type}`
      );
      addedColumns.push(column.name);
    }
  }

  const afterRequired = await getTableColumns(db, 'trades');
  const existingAccountColumn = findColumn(afterRequired, ACCOUNT_ID_ALIASES);
  if (!existingAccountColumn) {
    await run(
      db,
      `ALTER TABLE trades ADD COLUMN ${quoteIdent('account_id')} TEXT`
    );
    addedColumns.push('account_id');
  }

  let current = await getTableColumns(db, 'trades');
  for (const column of OPTIONAL_TRADES_COLUMNS) {
    if (!hasColumn(current, column.name)) {
      await run(
        db,
        `ALTER TABLE trades ADD COLUMN ${quoteIdent(column.name)} ${column.type}`
      );
      addedColumns.push(column.name);
      current = await getTableColumns(db, 'trades');
    }
  }

  const ticketColumnName = findColumn(current, ['ticket']);
  let uniqueTicket = { created: false, reason: 'ticket_missing' };
  if (ticketColumnName) {
    uniqueTicket = await ensureUniqueTicketIndex(db, ticketColumnName);
  }

  return {
    addedColumns,
    accountColumn: existingAccountColumn || 'account_id',
    uniqueTicket,
    columnsAfter: current.map((col) => col.name),
  };
}

async function applySqlMigrations(db, migrationsDir) {
  const files = fs.readdirSync(migrationsDir)
    .filter((name) => name.endsWith('.sql'))
    .sort();

  for (const file of files) {
    const sqlPath = path.join(migrationsDir, file);
    const sql = fs.readFileSync(sqlPath, 'utf8');
    await exec(db, sql);
    console.log(`[migrate] applied ${file}`);
  }
}

async function runMigrations() {
  const dbPath = resolveDbPath();
  if (!fs.existsSync(dbPath)) {
    throw new Error(`SQLite file not found: ${dbPath}`);
  }

  const db = await openDatabase(dbPath);
  try {
    await exec(db, 'PRAGMA journal_mode = WAL;');
    await exec(db, 'PRAGMA busy_timeout = 5000;');

    const migrationsDir = path.join(__dirname, '..', 'migrations');

    await exec(db, 'BEGIN IMMEDIATE;');
    try {
      await applySqlMigrations(db, migrationsDir);
      const tradesResult = await ensureTradesColumns(db);
      await exec(db, 'COMMIT;');

      const tables = await listTables(db);
      console.log(`[migrate] tables: ${tables.join(', ')}`);
      if (tradesResult.addedColumns.length) {
        console.log(`[migrate] trades added columns: ${tradesResult.addedColumns.join(', ')}`);
      } else {
        console.log('[migrate] trades added columns: none');
      }
      console.log(`[migrate] trades account column: ${tradesResult.accountColumn}`);
      console.log(`[migrate] trades ticket uniqueness: ${tradesResult.uniqueTicket.reason}`);
    } catch (err) {
      try {
        await exec(db, 'ROLLBACK;');
      } catch (rollbackErr) {
        console.error('[migrate] rollback failed', rollbackErr);
      }
      throw err;
    }
  } finally {
    await closeDatabase(db);
  }

  console.log('Migration applied');
}

runMigrations().catch((err) => {
  console.error('Migration failed', err);
  process.exit(1);
});
