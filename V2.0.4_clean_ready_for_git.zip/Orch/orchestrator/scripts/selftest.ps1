$ErrorActionPreference = 'Stop'

function Read-DotEnv([string]$path) {
  $vars = @{}
  if (-not (Test-Path $path)) {
    return $vars
  }
  foreach ($line in Get-Content $path) {
    $trimmed = $line.Trim()
    if (-not $trimmed -or $trimmed.StartsWith('#')) {
      continue
    }
    if ($trimmed -match '^\s*([^=]+?)\s*=\s*(.*)\s*$') {
      $key = $matches[1].Trim()
      $val = $matches[2].Trim()
      if ($val.StartsWith('"') -and $val.EndsWith('"')) {
        $val = $val.Substring(1, $val.Length - 2)
      }
      $vars[$key] = $val
    }
  }
  return $vars
}

function Get-Setting([string]$name, [string]$default, [hashtable]$dotenv) {
  $envValue = [Environment]::GetEnvironmentVariable($name)
  if ($envValue) {
    return [string]$envValue
  }
  if ($dotenv.ContainsKey($name)) {
    return [string]$dotenv[$name]
  }
  return $default
}

$repoRoot = Resolve-Path (Join-Path $PSScriptRoot '..')
$dotenvPath = Join-Path $repoRoot '.env'
$dotenv = Read-DotEnv $dotenvPath

$port = Get-Setting 'PORT' '8080' $dotenv
$bindHost = Get-Setting 'HOST' '127.0.0.1' $dotenv
$apiKey = Get-Setting 'API_KEY' '' $dotenv
$cooldownMinRaw = Get-Setting 'COOLDOWN_AFTER_SL_MIN' '0' $dotenv
$cooldownMin = 0
if ($cooldownMinRaw -match '^\d+$') {
  $cooldownMin = [int]$cooldownMinRaw
}

if (-not $apiKey) {
  Write-Host 'FAIL: Missing API_KEY (set API_KEY env var or .env)'
  exit 1
}

$baseUrl = if ($env:BASE_URL) {
  $env:BASE_URL
} else {
  $clientHost = $bindHost
  if ($clientHost -eq '0.0.0.0' -or $clientHost -eq '::') {
    $clientHost = '127.0.0.1'
  }
  "http://$clientHost`:$port"
}

$headers = @{ 'x-api-key' = $apiKey }
$results = @()

function Add-Result([string]$name, [bool]$pass, [string]$details) {
  $script:results += [pscustomobject]@{
    Name = $name
    Pass = $pass
    Details = $details
  }
}

function Invoke-Orch([string]$method, [string]$url, $body) {
  $params = @{
    Method = $method
    Uri = $url
    Headers = $headers
    TimeoutSec = 10
    ErrorAction = 'Stop'
  }
  if ($null -ne $body) {
    $params.Body = ($body | ConvertTo-Json -Depth 6)
    $params.ContentType = 'application/json'
  }
  return Invoke-RestMethod @params
}

try {
  $resp = Invoke-Orch 'Get' "$baseUrl/health" $null
  $ok = ($resp.ok -eq $true)
  Add-Result 'health' $ok ("ok=$($resp.ok)")
} catch {
  Add-Result 'health' $false ($_.Exception.Message)
}

$now = Get-Date -Format 'yyyy.MM.dd HH:mm:ss'
$prePayload = @{
  bot_id = 'selftest-bot'
  account_id = 'selftest-account'
  symbol = 'EURUSD'
  direction = 'BUY'
  timeframe = 'M5'
  strategy = 'selftest'
  signal_time = $now
  equity = 10000
  balance = 10000
}

try {
  $resp = Invoke-Orch 'Post' "$baseUrl/v1/pre_trade" $prePayload
  $hasAllow = ($null -ne $resp.allow)
  $hasReason = ($null -ne $resp.reason)
  $ok = $hasAllow -and $hasReason
  if ($resp.allow -eq $true) {
    $ok = $ok -and ($null -ne $resp.cooldown_sec) -and ($null -ne $resp.max_trades_left_today)
  }
  Add-Result 'pre_trade' $ok ("allow=$($resp.allow) reason=$($resp.reason)")
} catch {
  Add-Result 'pre_trade' $false ($_.Exception.Message)
}

$ticket = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$positionId = $ticket + 1
$openTime = Get-Date -Format 'yyyy.MM.dd HH:mm:ss'
$openPayload = @{
  bot_id = 'selftest-bot'
  account_id = 'selftest-account'
  position_id = $positionId
  ticket = $ticket
  symbol = 'EURUSD'
  direction = 'BUY'
  open_time = $openTime
  open_price = 1.23456
  lot = 0.01
  sl = 1.23000
  tp = 1.24000
  timeframe = 'M5'
  strategy = 'selftest'
}

try {
  $resp = Invoke-Orch 'Post' "$baseUrl/v1/trade_open" $openPayload
  $ok = ($resp.ok -eq $true)
  Add-Result 'trade_open' $ok ("ok=$($resp.ok) dedup=$($resp.dedup)")
} catch {
  Add-Result 'trade_open' $false ($_.Exception.Message)
}

try {
  $resp = Invoke-Orch 'Post' "$baseUrl/v1/trade_open" $openPayload
  $ok = ($resp.ok -eq $true -and $resp.dedup -eq $true)
  Add-Result 'trade_open_dedup' $ok ("ok=$($resp.ok) dedup=$($resp.dedup)")
} catch {
  Add-Result 'trade_open_dedup' $false ($_.Exception.Message)
}

$closeTime = Get-Date -Format 'yyyy.MM.dd HH:mm:ss'
$closePayload = @{
  bot_id = 'selftest-bot'
  account_id = 'selftest-account'
  position_id = $positionId
  ticket = $ticket
  close_time = $closeTime
  close_price = 1.20000
  profit = -10.5
  close_reason = 'SL'
}

try {
  $resp = Invoke-Orch 'Post' "$baseUrl/v1/trade_close" $closePayload
  $ok = ($resp.ok -eq $true)
  Add-Result 'trade_close' $ok ("ok=$($resp.ok)")
} catch {
  Add-Result 'trade_close' $false ($_.Exception.Message)
}

$prePayload.signal_time = (Get-Date -Format 'yyyy.MM.dd HH:mm:ss')
try {
  $resp = Invoke-Orch 'Post' "$baseUrl/v1/pre_trade" $prePayload
  if ($cooldownMin -gt 0) {
    $ok = ($resp.allow -eq $false -and $resp.reason -eq 'cooldown_active')
    Add-Result 'cooldown_check' $ok ("allow=$($resp.allow) reason=$($resp.reason)")
  } else {
    $ok = ($null -ne $resp.allow -and $null -ne $resp.reason)
    Add-Result 'cooldown_check' $ok ("cooldown disabled; allow=$($resp.allow) reason=$($resp.reason)")
  }
} catch {
  Add-Result 'cooldown_check' $false ($_.Exception.Message)
}

foreach ($r in $results) {
  if ($r.Pass) {
    Write-Host ("PASS {0} - {1}" -f $r.Name, $r.Details)
  } else {
    Write-Host ("FAIL {0} - {1}" -f $r.Name, $r.Details)
  }
}

$failures = $results | Where-Object { -not $_.Pass }
if ($failures.Count -eq 0) {
  Write-Host 'PASS: self-test complete'
  exit 0
}

Write-Host ("FAIL: {0} checks failed" -f $failures.Count)
exit 1
