﻿'use strict';

const assert = require('assert');
const {
  getMemoryConfig,
  evaluateMemoryDecision,
  evaluateRiskLadder,
} = require('../src/memory');

function makeConfig(mode) {
  const cfg = getMemoryConfig();
  return {
    ...cfg,
    mode,
    minSample: 30,
    winrateMin: 0.35,
    badStreakLosses: 8,
    dailyTradeLimit: 3,
    cooldownAfterSlMin: 120,
    maxOpenPositions: 1,
    advisoryHardGuards: false,
    riskL1Mult: 0.25,
    riskL2Mult: 1.0,
    spreadOkMaxPoints: 15,
  };
}

const goodStats = {
  n_closed_total: 50,
  winrate_last50: 0.6,
  avg_pnl_last50: 8,
  losses_last10: 2,
};

const lowSampleStats = {
  n_closed_total: 5,
  winrate_last50: 0.5,
  avg_pnl_last50: 3,
  losses_last10: 1,
};

const badStats = {
  n_closed_total: 60,
  winrate_last50: 0.2,
  avg_pnl_last50: -2,
  losses_last10: 9,
};

function run() {
  const enforceConfig = makeConfig('ENFORCE');
  const advisoryConfig = makeConfig('ADVISORY');

  const dailyLimitResult = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 3,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 10,
    },
    enforceConfig,
    'ENFORCE',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, enforceConfig),
      features: { spread_points: 10 },
    }
  );
  assert.strictEqual(dailyLimitResult.allow, false, 'daily_limit should block');
  assert.strictEqual(dailyLimitResult.risk_level, 'L0');
  assert.strictEqual(dailyLimitResult.reason, 'hard_guard');
  assert.ok(dailyLimitResult.reason_codes.includes('daily_limit'), 'daily_limit reason code should be present');

  const cooldownResult = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 1,
      daily_losses_count: 1,
      cooldown_remaining_sec: 360,
      open_positions_count: 0,
      current_day_pnl: -5,
    },
    enforceConfig,
    'ENFORCE',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, enforceConfig),
      features: { spread_points: 5 },
    }
  );
  assert.strictEqual(cooldownResult.allow, false, 'cooldown should block');
  assert.strictEqual(cooldownResult.risk_level, 'L0');
  assert.ok(cooldownResult.reason_codes.includes('cooldown_active'), 'cooldown reason code should be present');

  const advisoryCooldownResult = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 1,
      daily_losses_count: 1,
      cooldown_remaining_sec: 360,
      open_positions_count: 0,
      current_day_pnl: -5,
    },
    advisoryConfig,
    'ADVISORY',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, advisoryConfig),
      features: { spread_points: 5 },
    }
  );
  assert.strictEqual(advisoryCooldownResult.allow, true, 'advisory cooldown should not block');
  assert.strictEqual(advisoryCooldownResult.risk_level, 'L1');
  assert.ok(advisoryCooldownResult.warnings.includes('cooldown_active'), 'advisory warnings should include cooldown_active');

  const advisoryHardGuardsResult = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 1,
      daily_losses_count: 1,
      cooldown_remaining_sec: 360,
      open_positions_count: 0,
      current_day_pnl: -5,
    },
    { ...advisoryConfig, advisoryHardGuards: true },
    'ADVISORY',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, advisoryConfig),
      features: { spread_points: 5 },
    }
  );
  assert.strictEqual(advisoryHardGuardsResult.allow, false, 'ADVISORY_HARD_GUARDS should allow hard block');
  assert.strictEqual(advisoryHardGuardsResult.risk_level, 'L0');

  const badMemoryDecision = evaluateMemoryDecision(badStats, enforceConfig);
  const enforceBadMemory = evaluateRiskLadder(
    badStats,
    {
      daily_trades_count: 0,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 0,
    },
    enforceConfig,
    'ENFORCE',
    {
      memoryDecision: badMemoryDecision,
      features: { spread_points: 5 },
    }
  );
  assert.strictEqual(enforceBadMemory.allow, false, 'enforce+bad memory should block');
  assert.strictEqual(enforceBadMemory.risk_level, 'L0');

  const insufficientData = evaluateRiskLadder(
    lowSampleStats,
    {
      daily_trades_count: 0,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 0,
    },
    advisoryConfig,
    'ADVISORY',
    {
      memoryDecision: evaluateMemoryDecision(lowSampleStats, advisoryConfig),
      features: { spread_points: 5 },
    }
  );
  assert.strictEqual(insufficientData.allow, true, 'insufficient data should allow');
  assert.strictEqual(insufficientData.risk_level, 'L1');
  assert.strictEqual(insufficientData.risk_multiplier, 0.25);

  const advisoryBadMemory = evaluateRiskLadder(
    badStats,
    {
      daily_trades_count: 0,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 0,
    },
    advisoryConfig,
    'ADVISORY',
    {
      memoryDecision: evaluateMemoryDecision(badStats, advisoryConfig),
      features: { spread_points: 20 },
    }
  );
  assert.strictEqual(advisoryBadMemory.allow, true, 'advisory mode should not block memory skip');
  assert.strictEqual(advisoryBadMemory.risk_level, 'L1');
  assert.ok(advisoryBadMemory.warnings.length >= 1, 'advisory warnings should be present');

  const normalResult = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 0,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 4,
    },
    enforceConfig,
    'ENFORCE',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, enforceConfig),
      features: { spread_points: 8 },
    }
  );
  assert.strictEqual(normalResult.allow, true, 'good setup should allow');
  assert.strictEqual(normalResult.risk_level, 'L2');
  assert.strictEqual(normalResult.risk_multiplier, 1.0);

  const enforceNewsHigh = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 0,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 4,
    },
    enforceConfig,
    'ENFORCE',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, enforceConfig),
      features: { spread_points: 8 },
      news: {
        enabled: true,
        has_news: true,
        impact: 'HIGH',
        window_min: 30,
        minutes_to_next: 10,
        events: [],
      },
    }
  );
  assert.strictEqual(enforceNewsHigh.allow, false, 'ENFORCE should block on HIGH news');
  assert.strictEqual(enforceNewsHigh.risk_level, 'L0');
  assert.ok(enforceNewsHigh.reason_codes.includes('news_high_upcoming'));

  const advisoryNewsHigh = evaluateRiskLadder(
    goodStats,
    {
      daily_trades_count: 0,
      daily_losses_count: 0,
      cooldown_remaining_sec: 0,
      open_positions_count: 0,
      current_day_pnl: 4,
    },
    advisoryConfig,
    'ADVISORY',
    {
      memoryDecision: evaluateMemoryDecision(goodStats, advisoryConfig),
      features: { spread_points: 8 },
      news: {
        enabled: true,
        has_news: true,
        impact: 'HIGH',
        window_min: 30,
        minutes_to_next: 10,
        events: [],
      },
    }
  );
  assert.strictEqual(advisoryNewsHigh.allow, true, 'ADVISORY should not block on HIGH news');
  assert.strictEqual(advisoryNewsHigh.risk_level, 'L1');
  assert.ok(advisoryNewsHigh.warnings.includes('news_high_upcoming'));

  console.log('OK test-risk-ladder');
}

run();
