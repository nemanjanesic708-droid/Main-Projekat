﻿'use strict';

require('dotenv').config();

const assert = require('assert');
const sqlite3 = require('sqlite3');
const { checkUpcomingNews, resetNewsCacheForTests } = require('../src/news');
const { getMemoryConfig, evaluateMemoryDecision, evaluateRiskLadder } = require('../src/memory');

const baseUrl = process.env.ORCH_BASE_URL || `http://127.0.0.1:${process.env.PORT || '8081'}`;
const apiKey = process.env.ORCH_API_KEY || process.env.API_KEY;
const dbPath = process.env.SQLITE_DB_PATH;

if (!apiKey) {
  throw new Error('Missing ORCH_API_KEY or API_KEY in environment.');
}
if (!dbPath) {
  throw new Error('Missing SQLITE_DB_PATH in environment.');
}

function fmtMt5Time(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getUTCFullYear()}.${pad(date.getUTCMonth() + 1)}.${pad(date.getUTCDate())} `
    + `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
}

function dbGet(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) return reject(err);
      return resolve(row);
    });
  });
}

function dbClose(db) {
  return new Promise((resolve, reject) => {
    db.close((err) => {
      if (err) return reject(err);
      return resolve();
    });
  });
}

async function postJson(path, payload, base = baseUrl, key = apiKey) {
  const res = await fetch(`${base}${path}`, {
    method: 'POST',
    headers: {
      'x-api-key': key,
      'content-type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`${path} failed (${res.status}): ${JSON.stringify(data)}`);
  }
  return data;
}

async function getJson(path, base = baseUrl, key = apiKey) {
  const res = await fetch(`${base}${path}`, {
    method: 'GET',
    headers: {
      'x-api-key': key,
    },
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(`${path} failed (${res.status}): ${JSON.stringify(data)}`);
  }
  return data;
}

function makeNewsProvider(events) {
  return {
    name: 'integration-mock',
    enabled: true,
    timezone: 'UTC',
    getEvents: async () => events,
  };
}

async function runNewsModeScenario(mode) {
  const now = new Date();
  const eventTs = new Date(now.getTime() + 10 * 60 * 1000).toISOString();
  const mockEvents = [{
    ts: eventTs,
    currency: 'USD',
    title: 'Unit Test High Impact',
    impact: 'HIGH',
    id: `mock-${mode}`,
  }];

  resetNewsCacheForTests();
  const news = await checkUpcomingNews({
    symbol: 'EURUSD',
    signal_time: fmtMt5Time(now),
    window_min: 30,
    min_impact: 'MEDIUM',
    providerOverride: makeNewsProvider(mockEvents),
  });

  assert.strictEqual(news.has_news, true, `${mode}: expected has_news=true`);
  assert.strictEqual(news.impact, 'HIGH', `${mode}: expected HIGH impact`);

  const cfg = {
    ...getMemoryConfig(),
    mode,
    dailyTradeLimit: 10,
    cooldownAfterSlMin: 120,
    maxOpenPositions: 5,
    advisoryHardGuards: false,
    newsBlockHigh: true,
    newsBlockMedium: false,
    newsFailClosed: false,
    riskL1Mult: 0.25,
    riskL2Mult: 1.0,
  };

  const stats = {
    n_closed_total: 50,
    winrate_last50: 0.6,
    avg_pnl_last50: 5,
    losses_last10: 1,
  };
  const dailyMetrics = {
    daily_trades_count: 0,
    daily_losses_count: 0,
    cooldown_remaining_sec: 0,
    open_positions_count: 0,
    current_day_pnl: 0,
  };
  const memoryDecision = evaluateMemoryDecision(stats, cfg);
  const ladder = evaluateRiskLadder(stats, dailyMetrics, cfg, mode, {
    memoryDecision,
    features: { spread_points: 8, spread_ok: 1 },
    news,
  });

  assert.ok(ladder.reason_codes.includes('news_high_upcoming'), `${mode}: reason_codes should include news_high_upcoming`);
  if (mode === 'ENFORCE') {
    assert.strictEqual(ladder.allow, false, 'ENFORCE should block HIGH news');
    assert.strictEqual(ladder.risk_level, 'L0', 'ENFORCE should set L0 on HIGH news');
    assert.strictEqual(ladder.reason, 'news_high_upcoming', 'ENFORCE reason should be news_high_upcoming');
  } else {
    assert.strictEqual(ladder.allow, true, 'ADVISORY should not block HIGH news');
    assert.strictEqual(ladder.risk_level, 'L1', 'ADVISORY should reduce risk to L1 on HIGH news');
    assert.ok(ladder.warnings.includes('news_high_upcoming'), 'ADVISORY warnings should include news_high_upcoming');
  }
}

async function main() {
  const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE);
  try {
    const debugConfig = await getJson('/v2/debug/config');
    const mode = String(debugConfig?.memory_config?.mode || '').toUpperCase();
    const cooldownMin = Number(debugConfig?.memory_config?.cooldownAfterSlMin || 0);
    assert.ok(mode === 'ADVISORY' || mode === 'ENFORCE', `unexpected mode for this test: ${mode}`);
    assert.ok(cooldownMin > 0, 'COOLDOWN_AFTER_SL_MIN must be > 0 for this integration test');

    const now = new Date();
    const accountId = `it-risk-${Date.now()}`;
    const botId = 'bot-risk-integration';
    const symbol = 'EURUSD';
    const timeframe = 'H1';
    const strategy = 'V2';
    const direction = 'BUY';

    const ticket = Number(`7${Date.now().toString().slice(-9)}`);
    const positionId = ticket + 1;

    const pretradePayload = {
      bot_id: botId,
      account_id: accountId,
      symbol,
      direction,
      timeframe,
      strategy,
      signal_time: fmtMt5Time(now),
      equity: 10000,
      balance: 10000,
      features: {
        trend_direction: 'UP',
        adx_value: 25,
        atr_pips: 10,
        spread_points: 8,
        spread_ok: 1,
        session_hour: now.getUTCHours(),
        session_allowed: 1,
      },
    };

    const pretrade1 = await postJson('/v2/pretrade/check', pretradePayload);
    assert.ok(Number(pretrade1.snapshot_id) > 0, 'snapshot_id should be present');
    const snapshotId = Number(pretrade1.snapshot_id);

    const openTime = new Date(now.getTime() + 15 * 1000);
    const tradeOpenPayload = {
      bot_id: botId,
      account_id: accountId,
      position_id: positionId,
      ticket,
      symbol,
      direction,
      timeframe,
      strategy,
      open_time: fmtMt5Time(openTime),
      open_price: 1.10001,
      lot: 0.1,
      sl: 1.09001,
      tp: 1.12001,
      snapshot_id: snapshotId,
    };

    const tradeOpen = await postJson('/v1/trade_open', tradeOpenPayload);
    assert.strictEqual(tradeOpen.ok, true, 'trade_open should succeed');

    const linked = await dbGet(
      db,
      'SELECT linked_ticket, linked_position_id FROM v2_snapshots WHERE id = ?',
      [snapshotId]
    );
    assert.ok(linked, 'snapshot row should exist');
    assert.strictEqual(Number(linked.linked_ticket), ticket, 'linked_ticket should match trade ticket');

    const closeTime = new Date(now.getTime() + 75 * 1000);
    const tradeClosePayload = {
      bot_id: botId,
      account_id: accountId,
      position_id: positionId,
      ticket,
      close_time: fmtMt5Time(closeTime),
      close_price: 1.09001,
      profit: -12.34,
      close_reason: 'SL',
      snapshot_id: snapshotId,
    };

    const tradeClose = await postJson('/v1/trade_close', tradeClosePayload);
    assert.strictEqual(tradeClose.ok, true, 'trade_close should succeed');

    const pretrade2Payload = {
      ...pretradePayload,
      signal_time: fmtMt5Time(new Date(now.getTime() + 120 * 1000)),
    };
    const pretrade2 = await postJson('/v2/pretrade/check', pretrade2Payload);

    const nClosed = Number(pretrade2?.stats?.n_closed || 0);
    assert.ok(nClosed >= 1, `expected stats.n_closed >= 1, got ${nClosed}`);
    const reasonCodes = Array.isArray(pretrade2?.reason_codes) ? pretrade2.reason_codes : [];
    const warnings = Array.isArray(pretrade2?.warnings) ? pretrade2.warnings : [];
    assert.ok(reasonCodes.includes('cooldown_active'), 'reason_codes should include cooldown_active after SL');

    if (mode === 'ADVISORY') {
      assert.strictEqual(pretrade2.allow, true, 'ADVISORY should not block after SL cooldown');
      assert.strictEqual(pretrade2.enforce, false, 'ADVISORY should not enforce');
      assert.strictEqual(pretrade2.risk_level, 'L1', 'ADVISORY should reduce risk to L1');
      assert.ok(warnings.includes('cooldown_active'), 'ADVISORY warnings should include cooldown_active');
    } else {
      assert.strictEqual(pretrade2.allow, false, 'ENFORCE should block during cooldown after SL');
      assert.strictEqual(pretrade2.enforce, true, 'ENFORCE should enforce');
      assert.strictEqual(pretrade2.risk_level, 'L0', 'ENFORCE cooldown block should return L0');
    }

    await runNewsModeScenario('ENFORCE');
    await runNewsModeScenario('ADVISORY');

    console.log('OK test-risk-integration', {
      mode,
      snapshot_id: snapshotId,
      linked_ticket: linked.linked_ticket,
      n_closed: nClosed,
      allow: pretrade2.allow,
      risk_level: pretrade2.risk_level,
      risk_multiplier: pretrade2.risk_multiplier,
    });
  } finally {
    await dbClose(db);
  }
}

main().catch((err) => {
  console.error('FAIL test-risk-integration', err.message);
  process.exit(1);
});
