'use strict';

const assert = require('assert');
const {
  checkUpcomingNews,
  extractCurrenciesFromSymbol,
  resetNewsCacheForTests,
} = require('../src/news');

function makeProvider(name, events) {
  return {
    name,
    enabled: true,
    timezone: 'UTC',
    getEvents: async () => events,
  };
}

async function run() {
  const signal = '2026-02-03 10:00:00';

  resetNewsCacheForTests();
  const highResult = await checkUpcomingNews({
    symbol: 'EURUSD',
    signal_time: signal,
    window_min: 30,
    min_impact: 'MEDIUM',
    providerOverride: makeProvider('unit-high', [
      { ts: '2026-02-03T10:05:00Z', currency: 'USD', title: 'NFP', impact: 'HIGH', id: 'h1' },
      { ts: '2026-02-03T10:08:00Z', currency: 'EUR', title: 'CPI', impact: 'MEDIUM', id: 'm1' },
    ]),
  });
  assert.strictEqual(highResult.has_news, true, 'HIGH event in window should set has_news');
  assert.strictEqual(highResult.impact, 'HIGH', 'HIGH should dominate MEDIUM');
  assert.strictEqual(highResult.minutes_to_next, 5, 'minutes_to_next should match nearest event');

  resetNewsCacheForTests();
  const mediumResult = await checkUpcomingNews({
    symbol: 'EURUSD',
    signal_time: signal,
    window_min: 30,
    min_impact: 'MEDIUM',
    providerOverride: makeProvider('unit-medium', [
      { ts: '2026-02-03T10:12:00Z', currency: 'USD', title: 'Retail Sales', impact: 'MEDIUM', id: 'm2' },
      { ts: '2026-02-03T10:20:00Z', currency: 'EUR', title: 'Survey', impact: 'LOW', id: 'l1' },
    ]),
  });
  assert.strictEqual(mediumResult.has_news, true, 'MEDIUM in window should be detected');
  assert.strictEqual(mediumResult.impact, 'MEDIUM', 'impact should be MEDIUM when no HIGH');
  assert.strictEqual(mediumResult.minutes_to_next, 12, 'nearest MEDIUM event should set minutes_to_next');

  resetNewsCacheForTests();
  const outsideWindow = await checkUpcomingNews({
    symbol: 'EURUSD',
    signal_time: signal,
    window_min: 30,
    min_impact: 'MEDIUM',
    providerOverride: makeProvider('unit-none', [
      { ts: '2026-02-03T10:45:00Z', currency: 'USD', title: 'Late event', impact: 'HIGH', id: 'h2' },
    ]),
  });
  assert.strictEqual(outsideWindow.has_news, false, 'event outside window should not trigger');
  assert.strictEqual(outsideWindow.impact, 'NONE', 'outside window should return impact NONE');
  assert.strictEqual(outsideWindow.minutes_to_next, null, 'outside window should have null minutes_to_next');

  resetNewsCacheForTests();
  const currencyFilter = await checkUpcomingNews({
    symbol: 'EURJPY',
    signal_time: signal,
    window_min: 30,
    min_impact: 'MEDIUM',
    providerOverride: makeProvider('unit-currency', [
      { ts: '2026-02-03T10:10:00Z', currency: 'USD', title: 'USD Event', impact: 'HIGH', id: 'usd' },
      { ts: '2026-02-03T10:14:00Z', currency: 'JPY', title: 'JPY Event', impact: 'MEDIUM', id: 'jpy' },
    ]),
  });
  assert.strictEqual(currencyFilter.has_news, true, 'JPY event should remain after currency filter');
  assert.strictEqual(currencyFilter.impact, 'MEDIUM', 'USD event should be filtered for EURJPY');
  assert.ok(currencyFilter.events.every((evt) => evt.currency === 'JPY' || evt.currency === 'EUR'), 'events should match symbol currencies');

  const fxCurrencies = extractCurrenciesFromSymbol('EURUSD');
  assert.deepStrictEqual(fxCurrencies, ['EUR', 'USD'], 'EURUSD should resolve to EUR+USD');
  const xauCurrencies = extractCurrenciesFromSymbol('XAUUSD');
  assert.deepStrictEqual(xauCurrencies, ['USD'], 'XAUUSD should default to USD-only');

  console.log('OK test-news');
}

run().catch((err) => {
  console.error('FAIL test-news', err.message);
  process.exit(1);
});
