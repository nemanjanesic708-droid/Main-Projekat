CREATE TABLE IF NOT EXISTS orch_trade_map (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trade_row_id INTEGER NULL,
  position_id INTEGER NOT NULL,
  ticket INTEGER NOT NULL,
  account_id TEXT NOT NULL,
  bot_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_orch_trade_map_account_ticket
  ON orch_trade_map (account_id, ticket);

CREATE INDEX IF NOT EXISTS idx_orch_trade_map_account_created
  ON orch_trade_map (account_id, created_at);

CREATE INDEX IF NOT EXISTS idx_orch_trade_map_ticket
  ON orch_trade_map (ticket);
