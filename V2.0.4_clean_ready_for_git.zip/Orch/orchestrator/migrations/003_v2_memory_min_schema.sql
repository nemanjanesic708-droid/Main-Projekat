CREATE TABLE IF NOT EXISTS v2_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  account_id TEXT NOT NULL,
  bot_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  direction TEXT NOT NULL,
  strategy TEXT NOT NULL,
  signal_time TEXT NOT NULL,
  regime_signature TEXT NOT NULL,
  features_json TEXT NOT NULL,
  snapshot_hash TEXT NULL,
  linked_ticket INTEGER NULL,
  linked_position_id INTEGER NULL,
  request_id TEXT NULL,
  enforced INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_v2_snapshots_signature_time
  ON v2_snapshots(regime_signature, created_at);

CREATE INDEX IF NOT EXISTS idx_v2_snapshots_account_time
  ON v2_snapshots(account_id, created_at);

CREATE INDEX IF NOT EXISTS idx_v2_snapshots_linked_ticket
  ON v2_snapshots(linked_ticket);

CREATE TABLE IF NOT EXISTS v2_decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  snapshot_id INTEGER NOT NULL,
  mode TEXT NOT NULL,
  decision TEXT NOT NULL,
  enforce INTEGER NOT NULL DEFAULT 0,
  reason_code TEXT NOT NULL,
  confidence TEXT NOT NULL,
  stats_json TEXT NOT NULL,
  FOREIGN KEY(snapshot_id) REFERENCES v2_snapshots(id)
);

CREATE INDEX IF NOT EXISTS idx_v2_decisions_snapshot
  ON v2_decisions(snapshot_id);

CREATE INDEX IF NOT EXISTS idx_v2_decisions_time
  ON v2_decisions(created_at);
