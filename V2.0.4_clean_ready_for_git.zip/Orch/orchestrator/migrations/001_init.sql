CREATE TABLE IF NOT EXISTS decisions_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id TEXT,
  endpoint TEXT,
  account_id TEXT,
  bot_id TEXT,
  symbol TEXT,
  direction TEXT,
  signal_time TEXT,
  allow INTEGER,
  reason TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_decisions_account_created ON decisions_log (account_id, created_at);
