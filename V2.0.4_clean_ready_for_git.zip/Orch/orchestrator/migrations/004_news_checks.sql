CREATE TABLE IF NOT EXISTS news_checks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  snapshot_id INTEGER NOT NULL,
  symbol TEXT NOT NULL,
  window_min INTEGER NOT NULL,
  impact TEXT NOT NULL,
  has_news INTEGER NOT NULL DEFAULT 0,
  minutes_to_next INTEGER NULL,
  events_json TEXT NOT NULL,
  provider TEXT NOT NULL,
  FOREIGN KEY(snapshot_id) REFERENCES v2_snapshots(id)
);

CREATE INDEX IF NOT EXISTS idx_news_checks_snapshot
  ON news_checks(snapshot_id);

CREATE INDEX IF NOT EXISTS idx_news_checks_created_at
  ON news_checks(created_at);
