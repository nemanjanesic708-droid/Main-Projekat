CREATE TABLE IF NOT EXISTS v2_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  request_id TEXT,
  account_id TEXT NOT NULL,
  bot_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  direction TEXT NOT NULL,
  strategy TEXT NULL,
  signal_time TEXT NULL,
  regime_signature TEXT NOT NULL,
  features_json TEXT NOT NULL,
  enforced INTEGER NOT NULL DEFAULT 0,
  linked_ticket INTEGER NULL,
  linked_position_id INTEGER NULL
);

CREATE INDEX IF NOT EXISTS idx_v2_snapshots_sig_time
  ON v2_snapshots (regime_signature, created_at);

CREATE INDEX IF NOT EXISTS idx_v2_snapshots_account_time
  ON v2_snapshots (account_id, created_at);

CREATE TABLE IF NOT EXISTS v2_decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  snapshot_id INTEGER NOT NULL REFERENCES v2_snapshots(id),
  mode TEXT NOT NULL,
  decision TEXT NOT NULL,
  enforce INTEGER NOT NULL,
  reason_code TEXT NOT NULL,
  confidence TEXT NOT NULL,
  stats_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_v2_decisions_snapshot
  ON v2_decisions (snapshot_id);

CREATE INDEX IF NOT EXISTS idx_v2_decisions_time
  ON v2_decisions (created_at);
