# Orchestrator (MVP)

Node.js + Express service that decides ALLOW/DENY for trades and logs trades/decisions to SQLite (shared `trades.db`), using the existing `trades` table from trade_logger plus an `orch_trade_map` table for account/bot mapping.

## Requirements
- Node.js 18+ (for local run)
- Existing trade_logger SQLite file (`trades.db`)
  - Uses `sqlite3` driver (no Visual Studio C++ build tools required on Windows).

## Quick start (Docker Compose)
1. Bind-mount the trade_logger database into the container.
   Example (Windows path):
   ```
   volumes:
     - C:/Users/Nemanja/Desktop/mt5-trade-logger/database:/data
   ```
2. Start:
   ```
   docker compose up --build
   ```
3. Apply migration (in another terminal):
   ```
   docker compose exec app node scripts/migrate.js
   ```

## Local run (no Docker)
1. Copy env file and edit values:
   ```
   cp .env.example .env
   ```
2. Set `SQLITE_DB_PATH` to the existing SQLite file, for example:
   ```
   SQLITE_DB_PATH=C:\Users\Nemanja\Desktop\mt5-trade-logger\database\trades.db
   ```
3. Install deps:
   ```
   npm install
   ```
4. Run migrations:
   ```
   npm run migrate
   ```
5. Start server:
   ```
   npm start
   ```

## Env vars
- `PORT=8080`
- `API_KEY=...`
- `SQLITE_DB_PATH=...` (must point to an existing `trades.db`)
- `DAILY_TRADE_LIMIT=5`
- `COOLDOWN_AFTER_SL_MIN=120`
- `SIMILAR_LOOKBACK_MIN=180`
- `NEWS_PROVIDER=none` (`none`, `http_json`, `mock`)
- `NEWS_API_URL=...`
- `NEWS_API_KEY=...`
- `NEWS_TZ=UTC`
- `NEWS_WINDOW_MIN=30`
- `NEWS_CACHE_SEC=60`
- `NEWS_MIN_IMPACT=MEDIUM`
- `NEWS_BLOCK_HIGH=1`
- `NEWS_BLOCK_MEDIUM=0`
- `FAIL_CLOSED=0`

## DB path examples (Windows + Docker)
- Windows local:
  `SQLITE_DB_PATH=C:\Users\Nemanja\Desktop\mt5-trade-logger\database\trades.db`
- Docker (bind-mount):
  `SQLITE_DB_PATH=/data/trades.db` and mount `C:/Users/Nemanja/Desktop/mt5-trade-logger/database:/data`

## API
All `/v1/*` endpoints require `x-api-key`.

### POST /v1/pre_trade
```bash
curl -X POST http://localhost:8080/v1/pre_trade \
  -H "x-api-key: devkey" \
  -H "Content-Type: application/json" \
  -d '{
    "bot_id": "bot-1",
    "account_id": "acc-1",
    "symbol": "EURUSD",
    "direction": "BUY",
    "timeframe": "M15",
    "strategy": "V1",
    "signal_time": "2026.01.23 10:15:30",
    "equity": 10000.0,
    "balance": 10000.0
  }'
```
Allow response:
```json
{ "allow": true, "reason": "ok", "cooldown_sec": 0, "max_trades_left_today": 3 }
```
Deny response:
```json
{ "allow": false, "reason": "cooldown_active|daily_limit|max_open_positions|similar_trade_recent" }
```

### POST /v1/trade_open
```bash
curl -X POST http://localhost:8080/v1/trade_open \
  -H "x-api-key: devkey" \
  -H "Content-Type: application/json" \
  -d '{
    "bot_id": "bot-1",
    "account_id": "acc-1",
    "position_id": 123456,
    "ticket": 111222,
    "symbol": "EURUSD",
    "direction": "BUY",
    "open_time": "2026.01.23 10:20:00",
    "open_price": 1.23456,
    "lot": 0.10,
    "sl": 1.23000,
    "tp": 1.24000
  }'
```
Response:
```json
{ "ok": true }
```

### POST /v1/trade_close
```bash
curl -X POST http://localhost:8080/v1/trade_close \
  -H "x-api-key: devkey" \
  -H "Content-Type: application/json" \
  -d '{
    "bot_id": "bot-1",
    "account_id": "acc-1",
    "position_id": 123456,
    "ticket": 111222,
    "close_time": "2026.01.23 11:05:00",
    "close_price": 1.23500,
    "profit": 12.34,
    "close_reason": "TP"
  }'
```
Response:
```json
{ "ok": true }
```

### GET /health
```bash
curl http://localhost:8080/health
```
Response:
```json
{ "ok": true }
```

## Similarity v1.0
Rule: deny if there is an Orchestrator trade with the same signature in the last `SIMILAR_LOOKBACK_MIN` minutes.

Signature must match exactly:
- `account_id` (from request, matched via `orch_trade_map`)
- `symbol`
- `direction` (same direction only)
- `timeframe`
- `strategy`

Time window:
- Uses `open_time` from `trades`.
- If `open_time` is missing or NULL, it falls back to the first available of: `signal_time`, `entry_time`, `created_at`, `signal_timestamp`.
- "Recent" means the trade time is within the last `SIMILAR_LOOKBACK_MIN` minutes (default 180).

Scope:
- Only Orchestrator trades are checked (via `orch_trade_map` JOIN on `account_id`).

### Test (PowerShell)
Copy/paste (adjust `x-api-key` if needed). This uses `http://127.0.0.1:8081`.
```powershell
$ts = Get-Date -Format "yyyy.MM.dd HH:mm:ss"

$open = @{
  bot_id = "bot-1"
  account_id = "acc-1"
  position_id = 10001
  ticket = 20001
  symbol = "EURUSD"
  direction = "BUY"
  timeframe = "H1"
  strategy = "V1"
  open_time = $ts
  open_price = 1.1000
  lot = 0.10
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8081/v1/trade_open" `
  -Headers @{ "x-api-key" = "devkey" } `
  -ContentType "application/json" `
  -Body $open

$pre = @{
  bot_id = "bot-1"
  account_id = "acc-1"
  symbol = "EURUSD"
  direction = "BUY"
  timeframe = "H1"
  strategy = "V1"
  signal_time = $ts
  equity = 10000
  balance = 10000
} | ConvertTo-Json

Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:8081/v1/pre_trade" `
  -Headers @{ "x-api-key" = "devkey" } `
  -ContentType "application/json" `
  -Body $pre
```
Expected result:
```json
{ "allow": false, "reason": "similar_trade_recent" }
```

### Test "after X minutes"
Option A (simulate older trade time):
- Set `$ts` to an older time, e.g.:
  ```powershell
  $ts = (Get-Date).AddMinutes(-200).ToString("yyyy.MM.dd HH:mm:ss")
  ```
  Keep `SIMILAR_LOOKBACK_MIN=180` and rerun the test.

Option B (shorten the lookback):
- Temporarily set `SIMILAR_LOOKBACK_MIN=1`, restart the server, and rerun the test.

## Notes
- Time format expected from EA: `YYYY.MM.DD HH:MM:SS`. The server normalizes it to `YYYY-MM-DD HH:MM:SS` for SQLite.
- The SQLite file must already exist; the server will refuse to start if it does not.
- Migrations only create `decisions_log` and `orch_trade_map`; existing trade_logger tables are not modified.
- Orchestrator stores account/bot mapping in `orch_trade_map`; `comment` tagging is optional and not used for rules.
- Decisions are logged to `decisions_log` with `request_id` and `endpoint`.
- Every request is logged to stdout as JSON (request_id, endpoint, allow, reason).

## How open trades are detected
At startup, the server inspects the `trades` schema and picks the first available rule:
1. `is_open = 1`
2. `close_time IS NULL`
3. `close_reason IS NULL` (or `exit_reason IS NULL`)

This check counts **all** rows in `trades` (not only Orchestrator rows).
